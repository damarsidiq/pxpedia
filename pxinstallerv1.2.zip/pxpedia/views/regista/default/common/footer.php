<?php if(!isset($pagevar['installer'])){ ?>

    <?php if(Pxpedia::isLoggedin()){ ?>
    </div></div>
    <?php } ?>

<?php } ?>

<div id="footer">
</div>
<script type="text/javascript">
<?php 

if(!isset($pagevar['installer'])){ ?>
    var activeapp = <?php echo App::getUser() === false ? '0' : App::getUser()['currentrole']['appid']; ?>;
    var backslash = '\\';
    var mobile = <?php echo $pagevar['mobile']; ?>;
<?php } ?>
</script>
<?php $velp->printfootsrc(); ?>