<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="canonical" href="http://localhost/pxpedia/?app=regista">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
</head>
<body class="dark <?php if(Pxpedia::isLoggedin()){ echo 'loggedinadmin'; }?>">
    <div id="messagebox">
        <div id="messageboxtitle"></div>
        <div id="messageboxcontent">
            <div id="messageboxmsg"></div>
            <div class="table">
                <div class="tablecell">

                </div>
            </div>
        </div>
        <div id="messageboxaction">

        </div>
    </div>
    <div id="opaquebg"></div>
    <?php if(!isset($pagevar['installer'])){ ?>
        <?php if(Pxpedia::isLoggedin()){ ?>
            <?php $dockedclass = 'docked'; if(Pxpedia::isMobile()){ $dockedclass = ''; }?>
            <div id="sidebar" class="<?php echo $dockedclass; ?>">
            <div id="menus">
                <ul id="menucontainer">
                    <?php
                        $menu='';
                        foreach(App::adminmenu() as $idx=>$elem){
                            $currentmenuclass = $elem['current'] ? ' current' : '';
                            $currentmenuclass .= $idx == 0 ? ' first' : '';
                            $menu .='<li class="adminmenuitem'. $currentmenuclass .'"><a href="javascript:void(0);" id="'. $elem['link'] .'">'. $elem['name'] .'</a></li>';
                        }
                        echo $menu;
                    ?>
                    <li id="logout"><a href="javascript:void(0);">Logout</a></li>
                </ul>
            </div>
            <div id="logo"><div id="roundr"></div><div id="registalogo"></div></div>
        </div>
        <div class="pagecontainer <?php echo $dockedclass; ?>" id="thepagecontainer">
            <div class="thepageitcontains active" id="thepageitcontains_0">
        <?php } ?>
    <?php } ?>