<div class="pageheader">
    <h3 class="ptitle">Plugins</h3>
    <ul id="Pluginsheader" class="adminmenus">
        <li id=adminmenu_addplugins>Add Plugin</li>
        <li class="active" id="adminmenu_pluginslist">Plugins List</li>
    </ul>
</div>

<div class="<?php if(isset($pagevar['message']))echo 'message active'; else echo 'message'; ?>">
    <?php if(isset($pagevar['message'])) echo $pagevar['message']; ?>
</div>

<div class="pagecontent active pagecontent_Pluginsheader" id="pluginslist">
    
<div class="row bottomless prepagemenu">
    <span class="actionsspan" id="searchplugins">
        <input type="text" name="search" value="search" id="searchfrompluginlist">
        <input type="button" value="Go" id="searchpluginsubmit" class="blogbutton">
    </span>
    <?php if($pagevar['pluginpagenum']){ ?>
    <input type="button" value="next &rarr;" class="right blogbutton" id="nextpluginnav">
    <input type="button" value="&larr; prev" class="right blogbutton disabled" id="prevpluginnav">
    
    <span class="actionsspan right" id="pluginpagegoto">
        <select name="gotopage" id="plugingotopage">
            <?php
                for($i=1;$i<=ceil($pagevar['pluginpagenum']);$i++){
                    ?>
                    
                    <option value="<?php echo $i; ?>">page <?php echo $i; ?></option>
                    
                    <?php
                }
            ?>    
        </select>
    </span>
    <?php } ?>
</div>
    

<div class="row head pluginitem">
    <span class="pluginnum">No</span>
    <span class="pluginname">Title</span>
    <span class="actionsspan">&nbsp;</span>
</div>
    
<?php
$count = 0;
foreach($pagevar['plugins'] as $plugk=>$plugv){
    $count++;
?>

<div id="plugin_<?php echo $plugv['name'] ?>" class="pluginitem">
    <span class="pluginnum"><?php echo $count.'. ' ?></span>
    <span class="pluginname"><?php echo  $plugv['name']; ?></span>
    <span class="actionsspan pluginaddorremove"><?php echo $plugv['linkactivate']; ?></span>
</div>
<div class="clearline"></div>
    
<?php
}

?>
</div>

<div class="pagecontent pagecontent_Pluginsheader" id="addplugins">
    <div class="row bottomless">
        <input type="text" name="plugin name" value="plugin name" id="pluginsubmitname">
    </div>
    <div class="row bottomless">
        <input type="file" name="pluginfile" value="pluginfile" id="pluginzipedfiles">
    </div>
    <div class="row submitrow top bottomless">
        <input type="button" value="Submit" value="Upload" class="submitpluginzip">
    </div>
</div>