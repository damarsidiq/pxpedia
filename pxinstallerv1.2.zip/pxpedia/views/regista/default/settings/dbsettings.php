<div class="row bottomless">
    <div class="forminput">
        <input type="text" name="dbhost" value="<?php if(isset($pagevar['dbsetting'])){echo $pagevar['dbsetting']['dbhost']; }else echo 'dbhost'; ?>" <?php if(isset($pagevar['dbsetting'])) echo 'class="filled"' ?>>
    </div>
</div>
<div class="row bottomless">
    <div class="forminput">
         <input type="text" name="dbuser" value="<?php if(isset($pagevar['dbsetting'])){echo $pagevar['dbsetting']['dbuser']; }else echo 'dbuser'; ?>" <?php if(isset($pagevar['dbsetting'])) echo 'class="filled"' ?> >
    </div>
</div>
<div class="row bottomless">
    <div class="forminput">
        <input type="text" name="dbpassword" value="<?php if(isset($pagevar['dbsetting'])){ if($pagevar['dbsetting']['dbpasswd'] == '') $passwdval = 'dbpassword'; else $passwdval = $pagevar['dbsetting']['dbpasswd']; }else $passwdval = 'dbpassword'; echo $passwdval; ?>" <?php if($passwdval !== 'dbpassword') echo 'class="filled"' ?>>
    </div>
</div>
<div class="row bottomless">
    <div class="forminput">
        <input type="text" name="dbname" value="<?php if(isset($pagevar['dbsetting'])){echo $pagevar['dbsetting']['dbname']; }else echo 'dbname'; ?>" <?php if(isset($pagevar['dbsetting'])) echo 'class="filled"' ?>>
    </div>
</div>

<input type="button" class="adminmenu_savesettings db" value="Save">