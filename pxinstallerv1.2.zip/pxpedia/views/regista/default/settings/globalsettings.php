<input type="text" id="settings_appname" value="<?php echo Pxpedia::appById(Pxpedia::currentRole()['appid']); ?>" name="appname"  class="filled">
<input type="text" id="settings_keywords" value="<?php if(isset($pagevar['keywords']) && $pagevar['keywords'] !== '') $keyval = $pagevar['keywords']; else $keyval = 'keywords'; echo $keyval; ?>" name="keywords"  class="<?php if($keyval !== 'keywords') echo 'filled'; ?>">

<input type="button" class="adminmenu_savesettings global" value="Save">

<ul id="settingsseg">
    <li id="headsource" class="settingssegment active">head sources</li>
    <li id="footsource" class="settingssegment">foot sources</li>
</ul>

<div id="container_headsource" class="settingscontainer active">
    <?php
        if(isset($pagevar['headsource']) && is_array($pagevar['headsource']) && count($pagevar['headsource'])>0){
            foreach($pagevar['headsource'] as $hk=>$hv){
    ?>
        
                <div class="row bottomless">
                    <div class="forminput"><input type="text" name="sourcename[]" value="<?php echo $hk; ?>" class="sourcename filled"><input type="text" value="<?php echo $hv; ?>" class="sourcefilepath active filled" name="sourcefilepath[]"><input type="file" name="sourcefile[]" value="sourcefile" class="uploadresource"><input type="button" name="uploadfile" class="uploadfile" value="upload"><input type="button" name="addfilecontent" class="addcontent browse" value="browse"><input type="button" name="addcontent" class="addcontent addrow" value="+"><input type="button" name="removecontent" class="removecontent" value="-"></div>
                </div>
    
    <?php
            }
        }
    ?>
    <div class="row bottomless">
        <div class="forminput"><input type="text" name="sourcename[]" value="sourcename" class="sourcename"><input type="text" value="sourcefilepath" class="sourcefilepath" name="sourcefilepath[]"><input type="file" name="sourcefile[]" value="sourcefile" class="uploadresource"><input type="button" name="uploadfile" class="uploadfile" value="upload"><input type="button" name="addfilecontent" class="addcontent  browse" value="browse"><input type="button" name="addcontent" class="addcontent addrow" value="+"><input type="button" name="removecontent" class="removecontent" value="-"></div>
    </div>
</div>

<div id="container_footsource" class="settingscontainer">
    <?php
        if(isset($pagevar['footsource']) && is_array($pagevar['footsource']) && count($pagevar['footsource'])>0){
            foreach($pagevar['footsource'] as $hk=>$hv){
    ?>
        
                <div class="row bottomless">
                    <div class="forminput"><input type="text" name="sourcename[]" value="<?php echo $hk; ?>" class="sourcename filled"><input type="text" value="<?php echo $hv; ?>" class="sourcefilepath active filled" name="sourcefilepath[]"><input type="file" name="sourcefile[]" value="sourcefile" class="uploadresource"><input type="button" name="uploadfile" class="uploadfile" value="upload"><input type="button" name="addfilecontent" class="addcontent browse" value="browse"><input type="button" name="addcontent" class="addcontent addrow" value="+"><input type="button" name="removecontent" class="removecontent" value="-"></div>
                </div>
    
    <?php
            }
        }
    ?>
    <div class="row bottomless">
        <div class="forminput">
            <input type="text" name="sourcename[]" value="sourcename" class="sourcename"><input type="text" value="sourcefilepath" class="sourcefilepath" name="sourcefilepath[]"><input type="file" name="sourcefile[]" value="sourcefile" class="uploadresource" id="uploadtest"><input type="button" name="uploadfile" class="uploadfile" value="upload"><input type="button" name="addfilecontent" class="addcontent browse" value="browse"><input type="button" name="addcontent" class="addcontent addrow" value="+"><input type="button" name="removecontent" class="removecontent" value="-">
        </div>
    </div>
</div>