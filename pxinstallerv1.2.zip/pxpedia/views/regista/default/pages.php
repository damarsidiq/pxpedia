<div class="pageheader">
    <h3 class="ptitle">Pages</h3>
    <ul id="settingsmenu" class="adminmenus">
        <li id="adminmenu_models">Models</li>
        <li id="adminmenu_views">Views</a></li>
        <li class="active" id="adminmenu_controllers">Controllers</li>
    </ul>
</div>

<div class="pagecontent active pagecontent_settingsmenu" id="controllers">
    <?php
        foreach($pagevar['pages'] as $pageidx=>$page){
            echo '<li>'.$page.'</li>';
        }
    ?>
</div>

<div class="pagecontent pagecontent_settingsmenu" id="models">
</div>

<div class="pagecontent pagecontent_settingsmenu" id="views">
</div>