<div class="pageheader">
    <h3 class="ptitle">Blog</h3>
    <ul id="settingsmenu"  class="adminmenus">
        <li class="" id="adminmenu_blogcatman">Category</li>
        <li class="" id="adminmenu_newentry">New Entry</li>
        <li class="active" id="adminmenu_pastentries">Past Entries</li>
    </ul>
</div>


<div class="pagecontent pagecontent_settingsmenu" id="blogcatman">
   <?php  include_once('blog/crudblogcategory.php'); ?>
</div>

<div class="pagecontent pagecontent_settingsmenu blogentrycontainer" id="newentry">
   <?php  include_once('blog/newentry.php'); ?>
</div>

<div class="pagecontent pagecontent_settingsmenu active blogentrycontainer" id="pastentries">
   <?php  include_once('blog/pastentries.php'); ?>
</div>

<?php  include_once('blog/addblogcategory.php'); ?>

<div id="distinctattributekey">
    <?php
        if(count($pagevar['blogattrkey'])){
            
            foreach($pagevar['blogattrkey'] as $blogattridx =>$blogattr)
            {
                ?>
                
                <li class="attributekeyopt" id="blogattr_<?php echo $blogattridx; ?>"><?php echo $blogattr['attrkey']; ?></li>
                
                <?php
            }
        
        }
    ?>
</div>

<script type="text/javascript">
    var pastentriesnumperpage = <?php echo $pagevar['pastentriesnumperpage']; ?>;
</script>