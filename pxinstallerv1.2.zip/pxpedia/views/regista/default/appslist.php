<div class="pageheader">
    <h3 class="ptitle">Apps</h3>
    <ul id="Appsheader" class="adminmenus">
        <li class="active" id="adminmenu_appspage">Apps List</li>
    </ul>
</div>

<div id="appspage" class="pagecontent  pagecontent_Appsheader active">
    <div class="appelemhead elemid">ID</div>
    <div class="appelemhead appname">Name</div>
    <div class="appelemhead">Created On</div>
    <div class="appelemhead elemcreator">Creator</div>
    <div class="appelemhead actions administer">Actions</div>
    
    <div class="clearline"></div>
    <?php
        foreach($pagevar['appslist'] as $ak=>$av){
            $current = $pagevar['currentapp'] == $av['id'] ? ' current' : '';
    ?>
    <div class="appelements" id="app_<?php echo $av['id']; ?>">
            <div class="appelem elemid<?php echo $current ?>"><?php echo $av['id']; ?></div>
            <div class="appelem appname actionsspan"><a href="<?php echo Pxpedia::appurl($av['name']) ?>" target="_blank"><?php echo $av['name']; ?></a></div>
            <div class="appelem"><?php echo date('l, F jS Y H:i:s',strtotime($av['createdon'])); ?></div>
            <div class="appelem elemcreator"><?php echo ($av['creator']); ?></div>
            <div class="appelem administer">
                <span class="administerapp righttext actionsspan"><a href="<?php echo Pxpedia::appurl('',array('d'=>array('switchapp'=>$av['id'])),true); ?>"><?php if($current == '') echo 'administer'; ?></a></span>
            </div>
    </div>
            <div class="clearline"></div>
    <?php
        }
    ?>

</div>