<div id="sidebar" class="docked">
    <div id="menus">
        <ul id="menucontainer">
            <?php
                $menu='';
                foreach(App::adminmenu() as $idx=>$elem){
                    $currentmenuclass = $elem['current'] ? ' current' : '';
                    $currentmenuclass .= $idx == 0 ? ' first' : '';
                    $menu .='<li class="adminmenuitem'. $currentmenuclass .'"><a href="javascript:void(0);" id="'. $elem['link'] .'">'. $elem['name'] .'</a></li>';
                }
                echo $menu;
            ?>
            <li id="logout"><a href="javascript:void(0);">Logout</a></li>
        </ul>
    </div>
    <div id="logo"></div>
</div>
<div class="pagecontainer docked" id="thepagecontainer">
    <div class="thepageitcontains active" id="thepageitcontains_0">
        <?php if(isset($pagevar['homecontent'])) echo $pagevar['homecontent']; ?>    
    </div>
</div>