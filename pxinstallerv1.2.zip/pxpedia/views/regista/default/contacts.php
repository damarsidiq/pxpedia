<div class="pageheader">
    <h3 class="ptitle">Contacts</h3>
    <ul id="settingsmenu"  class="adminmenus">
        <li class="" id="adminmenu_contactsettings">Settings</li>
        <li class="active" id="adminmenu_contactmessages">Messages</li>
    </ul>
</div>

<div class="pagecontent active  pagecontent_settingsmenu" id="contactmessages">
   <?php  include_once('contacts/messages.php'); ?>
</div>

<div class="pagecontent pagecontent_settingsmenu" id="contactsettings">
   <?php  include_once('contacts/settings.php'); ?>
</div>