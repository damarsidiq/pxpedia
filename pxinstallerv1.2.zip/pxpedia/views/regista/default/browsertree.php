<ul id="tree" class="tree">
    <li class="browsetree" id="a_app"><span class="treeitem app">app.php</span></li>
    <li class="browsetree" id="c_controllers"><span class="treeitem controllers">Controllers</span></li>
    <li class="browsetree" id="m_models"><span class="treeitem models">Models</span></li>
    <li class="browsetree" id="v_views"><span class="treeitem views">Views<span class="reloadti"></span></span></li>
    <li class="browsetree" id="res_resources"><span class="treeitem resources">Resources<span class="reloadti"></span></span></li>
    <?php if(count($pagevar['response']['plugins'])){ ?>
        <li class="browsetree" id="pl_plugins"><span class="treeitem plugins">Plugins<span class="reloadti"></span></span></li>
    <?php } ?>
    
    <li class="browsetree" id="u_uploads"><span class="treeitem uploads">Uploads<span class="reloadti"></span></span></li>
</ul>