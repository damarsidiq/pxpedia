<div class="row bottomless prepagemenu">
    <span class="actionsspan" id="searchcontacts">
        <input type="text" name="search" value="search" id="searchpastcontacts">
        <input type="button" value="Go" id="searchcontactsubmit" class="blogbutton">
    </span>
    <?php if($pagevar['contactpagenum']){ ?>
    <input type="button" value="next &rarr;" class="right blogbutton" id="nextcontactnav">
    <input type="button" value="&larr; prev" class="right blogbutton disabled" id="prevcontactnav">
    
    <span class="actionsspan right" id="contactpagegoto">
        <select name="gotopage" id="contactgotopage">
            <?php
                for($i=1;$i<=ceil($pagevar['contactpagenum']);$i++){
                    ?>
                    
                    <option value="<?php echo $i; ?>">page <?php echo $i; ?></option>
                    
                    <?php
                }
            ?>    
        </select>
    </span>
    <?php } ?>
</div>

<div class="row head">
    <div class="messagenum">No</div>
    <div class="messagesubject">Subject</div>
    <div class="sendername">Sender</div>
    <div class="senderemail">Email</div>
    <div class="messageaction">&nbsp;</div>
</div>

<?php foreach($pagevar['messages'] as $mk=>$mv){ ?>

<div class="row">
    <div class="messagenum"><?php echo ($mk+1); ?></div>
    <div class="messagesubject"><?php echo $mv['subject']; ?></div>
    <div class="sendername"><?php echo $mv['name']; ?></div>
    <div class="senderemail"><?php echo $mv['email']; ?></div>
    <div class="messageaction">
        <span class="deletemessage redfont actionsspan" id="deletecontactmsg_<?php echo $mv['id']; ?>">delete</span>
        <span class="viewmessage actionsspan" id="viecontactmsg_<?php echo $mv['id']; ?>">view</span>
    </div>
</div>

<?php } ?>