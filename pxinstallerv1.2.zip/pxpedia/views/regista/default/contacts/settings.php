<div class="row bottomless">
    <input type="text" name="mail forward address" value="mail forward address" id="mailforwardaddress">
</div>

<div class="row bottomless">
    <input type="text" name="mail form address" value="mail form address" id="mailformaddress">
</div>

<div class="row bottomless">
    <input type="button" name="savecontactsettings" value="save" id="savecontactsettings">
</div>