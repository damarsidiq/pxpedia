<div class="pageheader">
    <h3 class="ptitle">Dashboard</h3>
    <ul id="settingsmenu"  class="adminmenus">
        <li class="" id="adminmenu_blogcatman">Category</li>
        <li class="" id="adminmenu_newentry">New Entry</li>
        <li class="active" id="adminmenu_pastentries">Past Entries</li>
    </ul>
</div>