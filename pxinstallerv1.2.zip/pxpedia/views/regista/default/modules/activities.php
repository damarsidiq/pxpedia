<div class="pageheader">
    <h3 class="ptitle">Home</h3>
    <!-- <ul id="settingsmenu"  class="adminmenus"><li class="active" id="adminmenu_pastentries">Past Entries</li></ul>-->
</div>
<div class="modulebox">
    <h3 class="moduletitle">Recent Activities</h3>
    <ul>
        <li><?php echo $pagevar['visit']; ?> visits</li>
        <li><?php echo $pagevar['newuser']; ?> new user</li>
        <li><?php echo $pagevar['newapp']; ?> new app</li>
        <li><?php echo $pagevar['newplugin']; ?>  new plugin</li>
        <li><?php echo $pagevar['login']; ?> login</li>
    </ul>
</div>