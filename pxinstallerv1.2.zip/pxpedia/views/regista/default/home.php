<?php
/*
    if(isset($pagevar['plugin'])){
       foreach($pagevar['plugin'] as $plugink=>$pluginvar){
           print_r($pluginvar);
       }
    }
    */
?>
