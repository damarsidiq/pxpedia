<div class="table">
    <div class="tablecell">
        <h1><span id="logo"></span></h1>
        <div id="installercontainer">
            <div id="installerstage1" class="installerstage active">
                <h3>Database Authorization</h3>
                <div class="installerform">
                    <div class="formmessage"></div>
                    <div class="table"><div class="tablecell">
                        <input type="text" name ="db name" value="db name" id="dbname" class="required">
                        <input type="text" name ="db host" value="db host" id="dbhost" class="required">
                        <div class="newline"></div>
                        <input type="text" name ="db user" value="db user" id="dbuser" class="required">
                        <input type="text" name ="db password" value="db password" id="dbpassword" class="">
                        <div class="newline"></div>
                        <input type="button" value="Confirm" class="confirmstage" id="confirmstage1">
                    </div></div>
                </div>
            </div>
            <div id="installerstage2" class="installerstage">
                <h3>Admin Account</h3>
                <div class="installerform">
                    <div class="formmessage"></div>
                    <div class="table"><div class="tablecell">
                        <input type="text" name ="username" value="username" id="username" class="required">
                        <input type="text" name ="email" value="email" id="email" class="required">
                        <input type="text" name ="password" value="password" id="password" class="required">
                        <div class="newline"></div>
                        <input type="button" value="Confirm" class="confirmstage" id="confirmstage2">
                    </div></div>
                </div>
            </div>
            <div id="installerstage3" class="installerstage">
                <h3>Installation</h3>
                <div class="installerform">
                    <div class="formmessage"></div>
                    <div class="table"><div class="tablecell">
                        <h2 id="installationprogress">Please Complete The Required Form</h2>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
</div>