<div class="pagecontainer hide browser" id="browser">
    
    <ul id="tree" class="tree">
        <li class="browsetree" id="a_app"><span class="treeitem app">app.php</span></li>
        <li class="browsetree" id="c_controllers"><span class="treeitem controllers">Controllers</span></li>
        <li class="browsetree" id="m_models"><span class="treeitem models">Models</span></li>
        <li class="browsetree" id="v_views"><span class="treeitem views">Views</span></li>
        <li class="browsetree" id="res_resources"><span class="treeitem resources">Resources</span></li>
        <li class="browsetree" id="pl_plugins"><span class="treeitem plugins">Plugins</span></li>
        <li class="browsetree" id="u_uploads"><span class="treeitem uploads">Uploads</span></li>
    </ul>

	<div id="browseview" class="codeeditorplaceholder">
		<div class="loadingnotification"></div>
        <div id="browserlists"></div>
        <div id="hidecodeeditor"><span></span></div>
        <div id="savecodechanges" class="editormenu"></div>
        <div id="closefile" class="editormenu"></div>
        <div id="editorfilelist" class="editormenu"></div>
        <div id="helpwithace" class="editormenu"></div>
        <div id="settheace" class="editormenu"></div>
        <div id="editormessage" class="editormenu"></div>
        <div id="aceshortcut" class=""></div>
        <div id="decoder"></div>
        <div id="editormaxmin" class="editormenu"></div>
        <div id="autocompleteace" class="editormenu"></div>
        <div id="jspacker" class="editormenu hide jspacker"></div>
        <div id="jspackerdeco" class="editormenu hide jspacker"></div>
        <pre id="codeeditor_0" class="codeeditor media"></pre>
	</div>
</div>


    
