<div class="pageheader">
    <h3 class="ptitle">Settings</h3>
    <ul id="settingsmenu"  class="adminmenus">
        <li class="" id="adminmenu_dbsetting">Database</li>
        <li class="active" id="adminmenu_globalsetting">Global Settings</li>
    </ul>
</div>

<form action="<?php echo App::appurl('regista',array('p'=>'settings','a'=>'pageInit'),false) ?>" enctype="multipart/form-data" method="post" name="settingsform" id="settingsform">
<div class="pagecontent pagecontent_settingsmenu" id="dbsetting">
   <?php  include_once('settings/dbsettings.php'); ?>
</div>

<div class="pagecontent active pagecontent_settingsmenu" id="globalsetting">
   <?php  include_once('settings/globalsettings.php'); ?>
</div>
<input type="hidden" id="headcount" name="headcount" value="0">
<input type="hidden" id="footcount" name="footcount" value="0">
<div class="submitform hidden"><input type="submit" name="savesettings"></div>

</form>

<div id="browseresources">
    <div id="closebrowseresources">X</div>
    <div class="listcontent"></div>
    <div class="listcontent"></div>
    <ul id="resourcetype">
        <li class="active" id="resourcesbrowse">Resources</li>
        <li id="themebrowse">Theme</li>
    </ul>
</div>