<?php

$logmessage = array('&nbsp;','','','','','','','','','','','logmessage');
$nameinput = array('','loginemail','registalogininput','text','email','email');
$passwdinput = array('','loginpasswd','registalogininput','text','password','password');
$submit = array('','login','','submit','login','Login','','','loginuser();');
$fields = array($nameinput,$passwdinput,$logmessage,$submit);



?>
<div id="registabody">
    <div id="formcontainer" class="formcontainer">
        <h3 id="registaloginlogo"></h3>
        <?php echo $velp->forms('login','registalogin','','POST',$fields,'return false'); ?>
    </div>
</div>