<div id="fouroffourcontainer">
    <div id="fouroffourmessage">
        Page Not Found
    </div>
</div>