<div class="row bottomless prepagemenu">
    <span class="actionsspan" id="searchblog">
        <input type="text" name="search" value="search" id="searchpastentrykeywords">
        <div class="blogcategoryselectcontainer">
            <input type="text" name="category" id="searchincategory" value="category" class="blogcategoryselect">
            <ul id="editblogcategorylistfilter" class="blogcategorylist">
                <?php echo $velp->blogcathierarchylist('filterpastentry',$pagevar['bloghierarchy']);  ?>
            </ul>
        </div>
        <div class="blogcategoryselectcontainer">
            <input type="text" class="statusoption" name="status" id="searchinstatus" value="status">
            <ul class="blogstatusselection">
                <li class="blogstatusselect">All Status</li>
                <li class="blogstatusselect">Draft</li>
                <li class="blogstatusselect">Published</li>
            </ul>
        </div>
        <input type="button" value="Go" id="searchblogsubmit" class="blogbutton">
    </span>
    <?php if($pagevar['blogpagenum']){ ?>
    <input type="button" value="next &rarr;" class="right blogbutton" id="nextblognav">
    <input type="button" value="&larr; prev" class="right blogbutton disabled" id="prevblognav">
    
    
    <span class="actionsspan" id="blogpagegoto">
        <select name="gotopage" id="bloggotopage">
            <?php
                for($i=1;$i<=ceil($pagevar['blogpagenum']);$i++){
                    ?>
                    
                    <option value="<?php echo $i; ?>">page <?php echo $i; ?></option>
                    
                    <?php
                }
            ?>    
        </select>
    </span>
    <?php } ?>
</div>

<div class="row head">
    <div class="blognum">No</div>
    <div class="blogid">ID</div>
    <div class="blogtitle">Title</div>
    <div class="blogcategory">Category</div>
    <div class="blogstatus">Status</div>
    <div class="blogdate">Created</div>
    <div class="blogaction">&nbsp;</div>
</div>

<?php if(is_array($pagevar['blog'])){ ?>

<?php foreach($pagevar['blog'] as $mk=>$mv){ ?>

<div class="row">
    <div class="blognum"><?php echo $mk+1; ?></div>
    <div class="blogid"><?php echo $mv['id']; ?></div>
    <div class="blogtitle"><?php echo $mv['title']; ?></div>
    <div class="blogcategory blogcategory_<?php echo $mv['category']; ?>"><?php echo $pagevar['blogcat'][$mv['category']]['name']; ?></div>
    <div class="blogstatus"><?php echo $pagevar['blogstatus'][$mv['status']]; ?></div>
    <div class="blogdate"><?php echo $mv['created']; ?></div>
    <div class="blogaction">
        <span class="deleteblog redfont" id="deleteblog_<?php echo $mv['id']; ?>">delete</span>
        <span class="editblog" id="editblog_<?php echo $mv['id']; ?>">edit</span>
    </div>
</div>

<?php } ?>

<?php } ?>

<div id="editblogcontainer">
<?php include_once('editblog.php'); ?>
</div>

<script type="text/javascript">
    var defaultfilterblogpagenum = <?php echo $pagevar['blogpagenum']; ?>;
</script>