<input type="text" name="title" value="title" id="editblogtitle" class="blogtitle">

<div class="blogcategoryselectcontainer">
    <input type="text" name="category" id="editblogcategoryselect" value="category" class="blogcategoryselect">
    <ul id="editblogcategorylist" class="blogcategorylist">
        <?php echo $velp->blogcathierarchylist('editselectcat',$pagevar['bloghierarchy']);  ?>
    </ul>
</div>
<input type="hidden" value="0" id="editselectedblogcat">
<input type="button" name="savedraft" id="editsavedraft" value="Save" class="savedraft">
<input type="button" name="editupdateblogstatus" id="editupdateblogstatus" value="Publish" class="updateblogstatus">
<input type="button" name="resetdraft" id="editresetdraft" value="Done" class="resetdraft">

<ul class="adminmenus innersubmenus blogmenus" id="editblogmenus">
    <li id="adminmenu_editblogcontent" class="admintab blogsub active">Content</li>
    <li id="adminmenu_editblogexcerpttab" class="admintab blogsub">Excerpt</li>
    <li id="adminmenu_editblogattributes" class="admintab blogsub">Attributes</li>
    <li id="adminmenu_editblogimage" class="admintab blogsub">Featured Image</li>
</ul>

<div id="editblogcontent" class="pagecontent pagecontent_editblogmenus blogsubcontent active">
    <textarea name="content" id="editblogcontenttext" class="blogcontenttext"  style="height:270px;"></textarea>
</div>
<div id="editblogexcerpttab" class="pagecontent pagecontent_editblogmenus blogsubcontent">
    <textarea name="excerpt" id="editblogexcerpt" class="blogexcerpt" rows="15" cols="80"></textarea>
</div>
<div id="editblogattributes" class="pagecontent pagecontent_editblogmenus">
    <div class="row">
        <input type="text" name="attribute name[]" value="attribute name" class="blogattr" id="editblogattrname_0">
        <ul class="blogattrkeyoptprovider"></ul>
        <input type="text" name="attribute value[]" value="attribute value" class="blogattrval" id="editblogattrval_0">
        <input type="button" class="addblogattr" value="+">
        <input type="button" class="minblogattr" value="-">        
    </div>
</div>
<div id="editblogimage" class="pagecontent pagecontent_editblogmenus blogsubcontent">
    <div class="holdercontainer">
          <div class="holder"></div>
          <input type="text" value="image name" name="image name" class="imagename">
          <input type="button" value="upload" class="goupload">
          <progress class="uploadprogress hidden" min="0" max="100" value="0">0</progress>
          <p class="upload hidden">
            <label>
              Drag &amp; drop not supported, but you can still upload via this input field:
              <br>
              <input type="file">
            </label>
          </p>
          <p class="filereader hidden">File API &amp; FileReader API not supported</p>
          <p class="formdata hidden">XHR2's FormData is not supported</p>
          <p class="progress hidden">XHR2's upload progress isn't supported</p>
    </div>
</div>

