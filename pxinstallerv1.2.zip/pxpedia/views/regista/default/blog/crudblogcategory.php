<div class="row bottomless prepagemenu">
    <span class="actionsspan" id="addcategory">add +</span>
</div>
<div class="row head">
    <div class="blogcatlistid">ID</div>
    <div class="blogcatlistname">Name</div>
    <div class="blogcatlistaction"></div>
</div>

<?php echo App::blogcathierarchylist($pagevar['bloghierarchy']); ?>

