<input type="text" name="title" value="title" id="blogtitle" class="blogtitle">

<div class="blogcategoryselectcontainer">
    <input type="text" name="category" id="blogcategoryselect" value="category" class="blogcategoryselect">
    <ul id="blogcategorylist" class="blogcategorylist">
        <?php echo $velp->blogcathierarchylist('selectcat',$pagevar['bloghierarchy']);  ?>
    </ul>
</div>
<input type="hidden" value="0" id="selectedblogcat">
<input type="button" name="savedraft" id="savedraft" value="Save" class="savedraft">
<input type="button" name="updateblogstatus" id="newupdateblogstatus" value="Publish" class="updateblogstatus">
<input type="button" name="resetdraft" id="resetdraft" value="Reset" class="resetdraft">

<ul class="adminmenus innersubmenus blogmenus" id="blogmenus">
    <li id="adminmenu_blogcontent" class="admintab blogsub active">Content</li>
    <li id="adminmenu_blogcontentexcerpttab" class="admintab blogsub">Excerpt</li>
    <li id="adminmenu_blogattributes" class="admintab blogsub">Attributes</li>
    <li id="adminmenu_blogimage" class="admintab blogsub">Featured Image</li>
</ul>




<div id="blogcontent" class="pagecontent pagecontent_blogmenus blogsubcontent active">
    <h4>Content</h4>
    <textarea name="content" id="blogcontenttext" class="blogcontenttext" style="height:270px;"></textarea>
</div>
<div id="blogcontentexcerpttab" class="pagecontent pagecontent_blogmenus blogsubcontent">
    <textarea name="excerpt" id="blogexcerpt" class="blogexcerpt"></textarea>
</div>
<div id="blogattributes" class="pagecontent pagecontent_blogmenus">
    <div class="row">
        <input type="text" name="attribute name[]" value="attribute name" class="blogattr" id="blogattrname_0">
        <ul class="blogattrkeyoptprovider"></ul>
        <input type="text" name="attribute value[]" value="attribute value" class="blogattrval" id="blogattrval_0">
        <input type="button" class="addblogattr" value="+">
        <input type="button" class="minblogattr" value="-">
    </div>
</div>
<div id="blogimage" class="pagecontent pagecontent_blogmenus blogsubcontent">
    <div class="holdercontainer">
          <div class="holder"></div>
          <input type="text" value="image name" name="image name" class="imagename">
          <input type="button" value="upload" class="goupload">
          <progress class="uploadprogress hidden" min="0" max="100" value="0">0</progress>
          <p class="upload hidden">
            <label>
              Drag &amp; drop not supported, but you can still upload via this input field:
              <br>
              <input type="file">
            </label>
          </p>
          <p class="filereader hidden">File API &amp; FileReader API not supported</p>
          <p class="formdata hidden">XHR2's FormData is not supported</p>
          <p class="progress hidden">XHR2's upload progress isn't supported</p>
    </div>
</div>

