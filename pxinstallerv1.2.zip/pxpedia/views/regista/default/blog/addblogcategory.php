<div id="addcategorycontainer" class="modals">
    <div class="closemodal"></div>
    <h3>Add Blog Category</h3>
    <h4 class="row bottomless singleinput modalmsg" id="addblogcatmsg"></h4>
    <div class="row bottomless singleinput">
        <input type="text" name="category name" value="category name" id="newblogcategoryname">
    </div>
    <div class="row bottomless singleinput">
        <input type="text" name="parent category" class="blogcategoryselect" value="parent category" id="newblogcategoryparent">
    </div>
    <div class="row bottomless heightless singleinput">
        <ul id="parentcatforadding" class="blogcategorylist">
            <li id="selectparentcatforadding_0"><span class="catname">None</span></li>
            <?php echo $velp->blogcathierarchylist('selectparentcatforadding',$pagevar['bloghierarchy'],array(1));  ?>
        </ul>
    </div>
    <div class="row bottomless singleinput autoheight">
        <textarea name="category description" id="newblogcategorydescription">category description</textarea>
    </div>
    
    <div class="row bottomless singleinput submitrow">
        <input type="button" value="Submit" id="addnewcategorysubmit">
    </div>
    <input type="hidden" id="submitcategoryid" value="0">
</div>