<div class="pageheader">
    <h3 class="ptitle">Apps</h3>
    <ul id="Appsheader" class="adminmenus">
        <li id="adminmenu_syncapp">Sync App</li>
        <!--<li id="adminmenu_importapp">Import App</li>
        <li id="adminmenu_exportapp">Export App</li>-->
        <li id="adminmenu_searchcode">Search Code</li>
        <li id="adminmenu_addapp">Add App</li>
        <li class="active" id="adminmenu_appspage">Apps List</li>
    </ul>
</div>


<div id="syncapp" class="pagecontent pagecontent_Appsheader">
    <input type="text" name="sync app url" value="sync app url" id="syncappurl">
    <input type="button" value="Request to Sync" id="gosyncapp">
    <input type="button" value="Refresh List" class="hide" id="syncapprefresh">
    <input type="button" class="hide" value="Reset" id="goresetsyncapp">
    
    <div class="clearline"></div>
</div>

<div id="importapp" class="pagecontent pagecontent_Appsheader">
    <input type="file" name="app files" value="app files">
    <input type="button" value="import app" id="goimportapp">
</div>

<div id="exportapp" class="pagecontent pagecontent_Appsheader">
    <input type="text" value="app name" class="" id="apptoexport" name="app name">
    <ul class="appprovider">
        <li class="selectappfromlist" id="0">All</li>
        <?php
         foreach($pagevar['appslist'] as $ak=>$av){
             ?>
                <li class="selectappfromlist" id="<?php echo $av['id'] ?>"><?php echo $av['name']; ?></li>
             <?php
         }
        ?>
    </ul>
</div>

<div id="searchcode" class="pagecontent pagecontent_Appsheader">
    <div class="row">
        <input type="text" value="app name" class="appoptions" id="apptosearch" name="app name">
        <ul class="appprovider">
            <li class="selectappfromlist" id="0">All</li>
            <?php
             foreach($pagevar['appslist'] as $ak=>$av){
                 ?>
                    <li class="selectappfromlist" id="<?php echo $av['id'] ?>"><?php echo $av['name']; ?></li>
                 <?php
             }
            ?>
        </ul>
        <input type="text" value="keyword" id="searchcodekey" name="keyword">
    </div>
    <div class="row">
        <input type="checkbox" id="phpsearch" class="typetosearch"><span>php</span>
        <input type="checkbox" id="jssearch" class="typetosearch"><span>js</span>
        <input type="checkbox" id="csssearch" class="typetosearch"><span>css</span>
    </div>
    
    <div class="row"><input type="button" id="gosearchcode" value="Search"></div>
    
    <div class="browser pagecontainer hide " id="searchcoderesultbrowser">
        <ul id="searchreslist" class="tree"></ul>
        <div id="searchcoderesult" class="codeeditorplaceholder">
    		<div class="loadingnotification"></div>
            <div id="searchresbrowserlists"></div>
            <div class="hidecodeeditor" id="hidesearchrescodeeditor"><span></span></div>
    	</div>
	</div>
</div>

<div id="appspage" class="pagecontent  pagecontent_Appsheader active">
    <div class="appelemhead elemid">ID</div>
    <div class="appelemhead appname">Name</div>
    <div class="appelemhead">Created On</div>
    <div class="appelemhead elemcreator">Creator</div>
    <div class="appelemhead actions administer">Actions</div>
    
    <div class="clearline"></div>
    <?php
        foreach($pagevar['appslist'] as $ak=>$av){
            $current = $pagevar['currentapp'] == $av['id'] ? ' current' : '';
    ?>
    <div class="appelements" id="app_<?php echo $av['id']; ?>">
            <div class="appelem elemid<?php echo $current ?>"><?php echo $av['id']; ?></div>
            <div class="appelem appname actionsspan"><a href="<?php echo Pxpedia::appurl($av['name']) ?>" target="_blank"><?php echo $av['name']; ?></a></div>
            <div class="appelem"><?php echo date('l, F jS Y H:i:s',strtotime($av['createdon'])); ?></div>
            <div class="appelem elemcreator"><?php echo ($av['creator']); ?></div>
            <div class="appelem administer">
                <span class="deleteapp redfont actionsspan"><a class="deleteappbtn" id="deleteappbtn_<?php echo $av['id']; ?>" href="<?php echo Pxpedia::appurl('',array('d'=>array('delete'=>$av['id'])),true); ?>">delete</a></span>
                <span class="browseapp actionsspan"><a href="javascript:void(0);" class="browseapplink" id="browseapp_<?php echo $av['id']; ?>">browse</a></span>
                <span class="administerapp actionsspan"><a href="<?php echo Pxpedia::appurl('',array('d'=>array('switchapp'=>$av['id'])),true); ?>"><?php if($current == '') echo 'administer'; ?></a></span>
            </div>
    </div>
            <div class="clearline"></div>
    <?php
        }
    ?>
<?php include_once('browser.php'); ?>
</div>

<div id="addapp" class="pagecontent pagecontent_Appsheader">
    <input type="text" name="new app name" value="new app name" id="newappname">
    <input type="button" id="createnewapp" name="createnewapp" value="create app" class="submitform">
</div>


