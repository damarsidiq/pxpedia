<div class="pageheader">
    <h3 class="ptitle">Users</h3>
    <ul id="usermenu" class="adminmenus">
        <li id="adminmenu_roles">Roles</a></li>
        <li class="active" id="adminmenu_userlist">Users</li>
    </ul>
</div>

<div class="pagecontent_usermenu pagecontent active" id="userlist">
    <?php if(isset($pagevar['users'])){ ?>
        <div id="filterfield">
            <input type="button" value="+ add user" id="modallink_adduser" class="modallink short right">
            <input type="button" class="short right" value="next &rarr;" id="nextuserpage">
            <input type="button" class="short right" value="&larr; prev" id="prevuserpage">
            
            <span class="actionsspan" id="blogpagegoto">
                <select id="usersgotopage" class="short right">
                <?php for($i=1;$i<=ceil($pagevar['userspagenum']);$i++){ ?>
                
                    <option value="<?php echo $i; ?>">page <?php echo $i; ?></option>
                
                <?php } ?>
                </select>
            </span>
            
            <input type="button" class="short modallink" name="filteruser" id="modallink_addfilteruser" value="+ filter">
        </div>
        
    
        
        <div id="userlistcontainer">
            <div class="useritem head row">
                <span class="userid">ID</span>
                <span class="username">Username</span>
                <span class="email">Email</span>
                <span class="registered">Registered</span>
                <span class="appelemhead actions">Actions</span>
            </div>
        <?php
            foreach($pagevar['users'] as $useridx=>$user){
                ?>
                
                    <div class="useritem row">
                        <span class="userid"><?php $velp->printvar('id',false,$user); ?></span>
                        <span class="username"><?php $velp->printvar('username',false,$user); ?></span>
                        <span class="email"><?php $velp->printvar('email',false,$user); ?></span>
                        <span class="registered"><?php $velp->printvar('registered',false,$user,'d-m-Y H:i:s'); ?></span>
                        <span class="actions">
                            <span class="actionsspan deleteuser"><a href="javascript:void(0);">delete</a></span>
                            <span class="actionsspan edituser"><a href="javascript:void(0);">edit</a></span>
                        </span>
                    </div>
                
                <?php
            }
        ?>
        </div>
    <?php } ?>
</div>

<div class="pagecontent_usermenu pagecontent" id="roles">
    <div class="row bottomless prepagemenu">
        <input type="button" value="+ add role" id="modallink_addrole" class="modallink short right">
    </div>
    
     <div id="rolelistcontainer">
        <div class="roleitem head row">
            <span class="roleid">ID</span>
            <span class="rolename">Name</span>
            <span class="appelemhead actions">Actions</span>
        </div>
    <?php
        foreach($pagevar['roles'] as $roleidx=>$role){
            ?>
            
                <div class="roleitem row">
                    <span class="roleid"><?php $velp->printvar('id',false,$role); ?></span>
                    <span class="rolename"><?php $velp->printvar('rolename',false,$role); ?></span>
                    <span class="actions">
                        <span class="actionsspan deleterole"><a href="javascript:void(0);">delete</a></span>
                        <span class="actionsspan editrole"><a href="javascript:void(0);">edit</a></span>
                    </span>
                </div>
            
            <?php
        }
    ?>
    </div>
</div>

<div class="modals wide" id="addfilteruser">
    <div class="closemodal"></div>
    <h3>Filter User</h3>
    <h4 class="row modalmsg"></h4>
    <div class="row bottomless inputrow">
        <input type="text" class="left halfish metakey" name="meta key" value="meta key">
        <input type="text" class="left halfish metavalue" name="meta value" value="meta value">
        <input type="button" class="left addusermeta" value="+">
        <input type="button" class="left minusermeta" value="-">
    </div>
    
    <div class="submitrow row bottomless top">
        <input type="button" class="right" name="filteruser" id="filteruser" value="filter">
    </div>
</div>

<div class="modals wide" id="addrole">
    <div class="closemodal"></div>
    <h3>Add Role</h3>
    <h4 class="row modalmsg"></h4>
    <div class="row bottomless singleinput">
        <input type="text" name="rolename" class="left addrolename required" value="rolename">
    </div>
    <h4 class="">role settings</h4>
    <div class="row bottomless inputrow metadata">
        <input type="text" class="left halfish rolesettingname rolemetak" value="settings key" name="settings key[]">
        <input type="text" class="left halfish rolesettingvalue rolemetav" value="settings value" name="settings value[]">
        <input type="button" value="+" class="left addrolessetting">
        <input type="button" value="-" class="left minrolessetting">
    </div>
    <div class="row submitrow bottomless top">
        <input type="submit" name="addrolesubmit" id="addrolesubmit" class="submit right" value="Submit Role">
    </div>
</div>

<div class="modals wide" id="adduser">
    <div class="closemodal"></div>
    <h3>Add User</h3>
    <h4 class="row modalmsg"></h4>
        <div class="row bottomless">
        <label class="left half">Username</label>
        <label class="left half">Email</label>
    </div>
    <div class="row bottomless">
        <input type="text" class="left half required" name="username" id="username" value="username">
        <input type="text" class="left half required" name="email" id="email" value="email">
    </div>
    <div class="row bottomless">
        <label class="left half">Password</label>
        <label class="left half">Repeat Password</label>
    </div>
    <div class="row bottomless">
        <input type="text" class="left half required" name="password" id="password" value="password">
        <input type="text" class="left half required" name="repeat password" id="repeatpassword" value="repeat password">
    </div>
    <h4 class="row">Role</h4>
    <div class="row bottomless">
        <select name="userole" id="useroleselect" class="left required userrole">
            <option value="userole">select role</option>
            <?php foreach($pagevar['roles'] as $rk=>$rv){        ?>
                <option value="<?php echo $rv['id']; ?>"><?php echo $rv['rolename']; ?></option>
            <?php } ?>
        </select>
    </div>
    <h4 class="row">Metadata</h4>
    <div class="row bottomless inputrow">
        <input type="text" class="left halfishfirst metakey extras" name="meta key" value="meta key">
        <input type="text" class="left halfishsecond metavalue extras" name="meta value" value="meta value">
        <input type="button" class="left addusermeta" value="+">
        <input type="button" class="left minusermeta" value="-">
    </div>
    
    <div class="submitrow row bottomless top">
        <input type="submit" name="addusersubmit" id="addusersubmit" class="submit right" value="Submit User">
    </div>
</div>

<div class="modals wide" id="edituserform">
    <div class="closemodal"></div>
    <h3>Edit User</h3>
    <h4 class="row modalmsg"></h4>
    <div class="row bottomless">
        <label class="left half">Username</label>
        <label class="left half">Email</label>
    </div>
    <div class="row bottomless">
        <input type="text" class="left half required" name="username" id="editusername" value="username">
        <input type="text" class="left half required" name="email" id="editemail" value="email">
    </div>
    <div class="row bottomless">
        <label class="left half">Password</label>
        <label class="left half">Repeat Password</label>
    </div>
    <div class="row bottomless">
        <input type="text" class="left half" name="password" id="editpassword" value="password">
        <input type="text" class="left half" name="repeat password" id="editrepeatpassword" value="repeat password">
    </div>
    <h4 class="row">Role</h4>
    <div class="row bottomless singleinput">
        <select name="userole" class="left required userrole">
            <option value="userole">select role</option>
            <?php foreach($pagevar['roles'] as $rk=>$rv){        ?>
                <option value="<?php echo $rv['id']; ?>"><?php echo $rv['rolename']; ?></option>
            <?php } ?>
        </select>
    </div>
    <h4 class="row">Metadata</h4>
    <div class="row bottomless inputrow metadata">
        <input type="text" class="left halfishfirst metakey extras" name="meta key" value="meta key">
        <input type="text" class="left halfishsecond metavalue extras" name="meta value" value="meta value">
        <input type="button" class="left addusermeta" value="+">
        <input type="button" class="left minusermeta" value="-">
    </div>
    <div class="submitrow row bottomless top">
        <input type="submit" name="editusersubmit" id="editusersubmit" class="submit right" value="Save">
    </div>
</div>

<div class="modals wide" id="editrolemodal">
    <div class="closemodal"></div>
    <h3>Edit Role</h3>
    <h4 class="row modalmsg"></h4>
    <div class="row bottomless singleinput">
        <input type="text" name="rolename" value="rolename" class="left required">
    </div>
    <h4 class="">role settings</h4>
    <div class="row bottomless inputrow">
        <input type="text" class="left halfish rolesettingname rolemetak" value="settings key" name="settings key[]">
        <input type="text" class="left halfish rolesettingvalue rolemetav" value="settings value" name="settings value[]">
        <input type="button" value="+" class="left addrolessetting">
        <input type="button" value="-" class="left minrolessetting">
    </div>
    <div class="row submitrow bottomless top">
        <input type="submit" name="saverolesubmit" id="saverolesubmit" class="submit right" value="Save">
    </div>
</div>
<ul id="distinctusermetakey" class="hide">
        <li class="usermetakeyopt">ID</li>
        <li class="usermetakeyopt">username</li>
        <li class="usermetakeyopt">email</li>
        <li class="usermetakeyopt">registered date from</li>
        <li class="usermetakeyopt">registered date end</li>
    <?php foreach($pagevar['distinctusermetakey'] as $k=>$v){ ?>
        <li class="usermetakeyopt"><?php echo $v['metakey']; ?></li>
    <?php } ?>
</ul>
<script type="text/javascript">
    var defaultfilteruserpagenum = <?php echo $pagevar['userspagenum']; ?>;
</script>