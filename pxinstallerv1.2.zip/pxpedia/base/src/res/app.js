$(document).ready(
    function () {
        
    }
);