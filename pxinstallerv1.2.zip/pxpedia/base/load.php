<?php
/**
 * loader to base files
 */

$path = 'base/';

require_once($path.'config.php');
require_once($baseroot.'db.php');
require_once($baseroot.'application.php');
require_once($baseroot.'pxpedia.php'); 




?>