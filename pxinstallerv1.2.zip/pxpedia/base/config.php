<?php
/**
 * configurations
 */

$domain         = 'http://'. $_SERVER['SERVER_ADDR'].':'.$_SERVER['SERVER_PORT'] .'/pxpedia/';
$approot        = './app/';
$baseroot       = './base/';
$views      	  = './views/';
$resources      = './res/';
$uploads        = './uploads/';
$plugins        = './plugins/';

$defaultapp     = $approot.'regista';
$adminapp       = $approot.'regista';
$theme          = 'default';
$mobiletheme    = 'default';

$autoloadmodels = false;

$lang = 'en';
$debug = true;