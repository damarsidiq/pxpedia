<?php
/**
 * PluginController Class.
 */

/**
 *	Class PluginController.Base class for the plugin's controllers
 *
 *	Quite similar to Controller class differ only to few plugin specific variables and functions
 *
 *	
 *	@name PluginController
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class PluginController{
    /** 
	 * @var mixed stores the database connection or false if failed connecting
	*/
    var $db;
    /** 
	 * @var array stores the models class instance
	*/
    var $models;
    /** 
	 * @var array stores page variable, allowing any modification by the plugin
	*/
    var $pagevar;
    /** 
	 * @var array stores variable produce by the plugins, avoids any mix up with the main app
	*/
    var $pluginvar;
    /** 
	 * @var int stores the plugin ID 
	*/
    var $pluginid;
    
    /**
	 * Constructor.
	 *
	 * @param int $pluginid the plugin id
	 * @param array $controllerpagevars the current page/controller pagevars
	 */
    public function __construct($pluginid,$controllerpagevars=null){
        $this->pluginid     = $pluginid;
        $this->db           = Pxpedia::appdb();
        $this->pagevar      = $controllerpagevars == null ? Array() : $controllerpagevars;
        $this->models       = Array();
        
        $this->loadAllModels();
    }
    /**
	 * Retrieves the model instance
	 *
	 * @param string $modelname the model's class name
	 * 
	 * @return object the model's instance
	 */
    public function model($modelname){
        if(isset($this->models[$modelname])){
            return $this->models[$modelname];
        }
        else{
            $this->loadModels($modelname);
            return $this->models[$modelname];
        }
    }
    /**
	 * Loads/instantiate all the models resides in the plugin's model directory
	 * 
	 * @return void
	 */
    public function loadAllModels(){
        $models = Application::loadAllPluginModels($this->pluginid);
        if(is_array($models)){
            foreach($models as $mk=>$mv){
                if(!isset($this->models[$mk])){
                    $this->models[$mk] = $mv;
                }
            }
        }
    }
    /**
	 * Instantiate and stores the model class in the $models variable
	 *
	 * @param mixed $modelnames the name/names of the model
	 * 
	 * @return void
	 */
    public function loadModels($modelnames){
        $models = Application::loadPluginModels($modelnames,$this->pluginid);
        if(is_array($models)){
            foreach($models as $mk=>$mv){
                if(!isset($this->models[$mk])){
                    $this->models[$mk] = $mv;
                }
            }
        }
        else{
            if(!isset($this->models[$modelnames])){
                $this->models[$modelnames] = $models;
            }
        }
    }
    /**
	 * Retrieves the variable produce by the plugin's instance
	 * 
	 * @return mixed
	 */
    public function getPluginvars(){
        return $this->pluginvar;
    }
    /**
	 * Sets the plugin variable
	 *
	 * @param string $index the variable name
	 * @param mixed $value the value
	 * 
	 * @return void
	 */
    public function setPluginvar($index='',$value=''){
        $index = $index=='' ? count($this->pluginvar) : $index;
        if(isset($this->pluginvar[$index])){
            if(is_array($this->pluginvar[$index]))
                $this->pluginvar[$index] = array_merge($this->pluginvar[$index], $value);
            else
                $this->pluginvar[$index] = $value;
        }
        else{
            $this->pluginvar[$index] = $value;
        }
    }
    /**
	 * Get all the page variables initialy set by the app's controller
	 * 
	 * @return array
	 */
    public function getPagevars(){
        return $this->pagevar;
    }
    /**
	 * Get a page variable
	 *
	 * @param string $index the variable name
	 * 
	 * @return mixed
	 */
    public function getPagevar($index){
        return $this->pagevar[$index];
    }
    /**
	 * Sets a page variable
	 *
	 * @param string $index the variable name
	 * @param mixed $value the value
	 * 
	 * @return void
	 */
    public function setPagevar($index='',$value=''){
        $index = $index=='' ? count($this->pagevar) : $index;
        if(isset($this->pagevar[$index])){
            if(is_array($this->pagevar[$index]))
                $this->pagevar[$index] = array_merge($this->pagevar[$index], $value);
            else
                $this->pagevar[$index] = $value;
        }
        else{
            $this->pagevar[$index] = $value;
        }
    }
    /**
	 * pageInit. basically a placeholder to be overriden by the extension of this class if it needs any further statement
	 *
	 * @param array $data the data sent by the client
	 * 
	 * @return string the view file name
	 */
    public function pageInit($data){
        return $view;
    }
    /**
	 * loadView. process view file
	 *
	 * @param string $page page layout file
	 * @param bool $return return page result
	 * 
	 * @return string
	 */
    public function loadView($page,$return=false){
	if($return)
	        return App::loadView($page,$this,true);
	
        App::loadView($page,$this);
    }
            
}

?>