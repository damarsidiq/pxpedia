<?php

// **PREVENTING SESSION HIJACKING**
// Prevents javascript XSS attacks aimed to steal the session ID
ini_set('session.cookie_httponly', 1);

// **PREVENTING SESSION FIXATION**
// Session ID cannot be passed through URLs
ini_set('session.use_only_cookies', 1);

// https only
// ini_set('session.cookie_secure', 1);

session_start();
ob_start();
$_SESSION['starttime'] = time();


require_once('base/load.php');

$app        = isset($_POST['app'])       ? $_POST['app']      : (isset($_GET['app'])     ? $_GET['app']         : '');
$admin      = isset($_POST['regista'])   ? $_POST['regista']  : (isset($_GET['regista']) ? $_GET['regista']     :false);
$admin      = isset($_POST['admin']) && $_POST['admin'] == 1 ? true : $admin;

$_SESSION['currentapp'] = $admin ? $adminapp : ($app !== '' ? $approot.$app : (isset($_SESSION['currentapp']) ? $_SESSION['currentapp'] : null));
$_SESSION['currentapp'] = $currentapp = is_null($_SESSION['currentapp']) ? $defaultapp : $_SESSION['currentapp'];

if($currentapp == $adminapp){
    $admin = true;
}

error_reporting(0);
if(file_exists($currentapp.'/app.php')){
	require_once($currentapp.'/app.php');
	$app = new App();
	$app->run();
}
else{
	require_once($GLOBALS['baseroot'].'404.php');
}



$_SESSION['endtime'] = time();
ob_end_flush();


//echo '<!-- '. ($_SESSION['endtime'] - $_SESSION['starttime']).' -->';
?>