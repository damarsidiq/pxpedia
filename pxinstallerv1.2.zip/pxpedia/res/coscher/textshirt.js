var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

$(document).ready(
    function () {
        texter.initfont();
        texter.initrandombg();
        registaforminput('body','input[type="text"],input[type="password"],textarea,select');
        pageaction.init();
        dialogbox.init();
        
        $('#adjustcolor').spectrum({
            color: "#000000",
            move: function(color) {
                $('#canvas').css({'background':color.toHexString()});
            },
            hide: function(color) {
                $('#canvas').css({'background':color.toHexString()});
            },
            clickoutFiresChange: true,
            showInput: true,
            preferredFormat: "hex"
        });
        $('#fontcolor').spectrum({
            color: "#000000",
            move: function(color) {
                texter.colorize(color.toHexString());
            },
            hide: function(color) {
                texter.colorize(color.toHexString());
            },
            clickoutFiresChange: true,
            showInput: true,
            preferredFormat: "hex"
        });
        
        $('body').find('.sp-container').eq(1).find('.sp-button-container').before('<div id="sptoptionscontainer"><div id="spbg_"><input type="checkbox" class="spoption" id="spbg">bg</div><div id="spborder_"><input type="checkbox" class="spoption" id="spborder">border</div><div id="spcolor_"><input type="checkbox" class="spoption" id="spcolor">color</div></div>');
        
        $('#sptoptionscontainer div').on('click',function(event){
            event.stopPropagation();
            
            if($(this).children('input').prop('checked')){
                $(this).children('input').prop('checked',false);
                texter.colorizedefault([false,$(this).attr('id')]);
            }
            else{
                $(this).children('input').prop('checked',true);
                texter.colorizedefault([true,$(this).attr('id')]);
            }
        });
        
        $('#sptoptionscontainer input[type="checkbox"]').on('click',function(event){
            event.stopPropagation();
            
            if($(this).prop('checked')){
                texter.colorizedefault([true,$(this).parent().attr('id')]);
            }
            else{
                texter.colorizedefault([false,$(this).parent().attr('id')]);
            }
            
        });
        
        $('#canvaswrapper').delegate('.aruler','mousedown',function(event){
            event.stopPropagation();
            theruler.mocinmode_insuspense = false;
            
            if($(this).attr('class').indexOf('grabbing')!==-1){
                $(this).removeClass('grabbing');
                photox.grabed = false;
                return;
            }
            photox.rulergrab(event,this);
        });
    }
);
var polygon = {
    rectangle:function(){
        if(dialogbox.checkexists('Rectangle'))
            return;
            
        dialogbox.mbox(['Rectangle','<input type="text" value="width" name="width" id="rectwidth"><input type="text" value="height" name="height" id="rectheight">','<span id="createrect">Create Rectangle</span>'],'',function(){
            $('#rectwidth').focus().addClass('regiformfoc');
            $('#rectheight').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    $(this).blur().removeClass('regiformfoc');
                    polygon.rectangle_($('#rectwidth').val(),$('#rectheight').val());
                }
            });
            $('#createrect').on('click',function(event){
                event.stopPropagation();
                
                polygon.rectangle_($('#rectwidth').val(),$('#rectheight').val());
            }); 
        });
    },
    rectangle_:function(width,height){
        texter.textcounter++;
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt rectshirt" style="width:'+width+'px;height:'+height+'px"></div>'); 
        settings.placeelem('text_'+texter.textcounter);
        
        uredo.registermove({type:'newrect',elem:[$('#text_'+texter.textcounter)[0].outerHTML,false,'text_'+texter.textcounter]});
        $('.regiformfoc').removeClass('regiformfoc').blur();
        dialogbox.close();
    },
    square:function(){
        if(dialogbox.checkexists('Square'))
            return;
            
        dialogbox.mbox(['Square','<input type="text" value="size" name="size" id="squaresize">','<span id="createsquare">Create Square</span>'],'',function(){
            $('#squaresize').focus().addClass('regiformfoc');
            $('#squaresize').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    $(this).blur().removeClass('regiformfoc');
                    polygon.square_($('#squaresize').val());
                }
            });
            $('#createsquare').on('click',function(event){
                event.stopPropagation();
                
                polygon.square_($('#squaresize').val());
            }); 
        });
    },
    square_:function(size){
        texter.textcounter++;
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt squareshirt" style="width:'+size+'px;height:'+size+'px"></div>'); 
        settings.placeelem('text_'+texter.textcounter);
        
        $('#text_'+texter.textcounter).css('top',($('#canvas').height()/2)-(size/2)+'px');
        $('#text_'+texter.textcounter).css('left',($('#canvas').width()/2)-(size/2)+'px');
        
        uredo.registermove({type:'newsquare',elem:[$('#text_'+texter.textcounter)[0].outerHTML,false,'text_'+texter.textcounter]});
        $('.regiformfoc').removeClass('regiformfoc').blur();
        dialogbox.close();
    },
    canvascount:-1,
    canvasavailability:0,
    drawingaux:[],
    drawingmode_:function(event){
        if(!polygon.drawingaux.length){
            polygon.drawingaux[0] = [event.clientX,event.clientY];
            
            texter.newcircle(5);
            $('#text_'+texter.textcounter).css('left',polygon.drawingaux[0][0]+'px');
            $('#text_'+texter.textcounter).css('top',polygon.drawingaux[0][1]+'px');
            $('#text_'+texter.textcounter).addClass('polygoninitpoint');
            
            return;
        }
        polygon.drawingaux[1] = [event.clientX,event.clientY];
        
            texter.newcircle(5);
            $('#text_'+texter.textcounter).css('left',polygon.drawingaux[1][0]+'px');
            $('#text_'+texter.textcounter).css('top',polygon.drawingaux[1][1]+'px');
            $('#text_'+texter.textcounter).addClass('polygoninitpoint');
        
        var initpoint;
        if(polygon.drawingaux[1][0] > polygon.drawingaux[0][0]){
            initpoint = 0;
            polygon.drawingaux[2] = [polygon.drawingaux[1][0] - polygon.drawingaux[0][0],polygon.drawingaux[1][1] - polygon.drawingaux[0][1]];
        }
        else{
            initpoint = 1;
            polygon.drawingaux[2] = [polygon.drawingaux[0][0] - polygon.drawingaux[1][0],polygon.drawingaux[0][1] - polygon.drawingaux[1][1]];
        }
        
        polygon.drawingaux[2][2] = Math.abs(polygon.drawingaux[2][0]);
        polygon.drawingaux[2][3] = Math.abs(polygon.drawingaux[2][1]);
        
        polygon.drawingaux[2][4] = Math.sqrt(Math.pow(polygon.drawingaux[2][2],2)+ Math.pow(polygon.drawingaux[2][3],2));
        polygon.drawingaux[2][5] = (0.5 * polygon.drawingaux[2][4]);
        
        texter.textcounter++;
        texter.horizline(polygon.drawingaux[2][4]);
            
            $('#text_'+texter.textcounter).css('left',polygon.drawingaux[initpoint][0]+'px');
            $('#text_'+texter.textcounter).css('top',polygon.drawingaux[initpoint][1]+'px');
            
            texter.textis($('#text_'+texter.textcounter),false);
            
            polygon.drawingaux[2][6] = Math.atan(polygon.drawingaux[2][1]/polygon.drawingaux[2][0])*57.295779513;//ro
            polygon.drawingaux[2][7] = (90 - polygon.drawingaux[2][6]);//ro1
            
            polygon.drawingaux[2][8] = polygon.drawingaux[2][5] - (Math.sin(polygon.drawingaux[2][7]/57.295779513) * polygon.drawingaux[2][5]);
            polygon.drawingaux[2][8] = (polygon.drawingaux[initpoint][0]-polygon.drawingaux[2][8])+2;//deltaxx
            
            transformer.rotate_(polygon.drawingaux[2][6]);
            $('#text_'+texter.textcounter).css('left',polygon.drawingaux[2][8]+'px');
            $('#text_'+texter.textcounter).css('top',polygon.drawingaux[initpoint][1]+(polygon.drawingaux[2][1]/2)+'px');
    
        polygon.drawingaux.splice(0,1);
        
        texter.blurs();
    },
    stopdrawing:function(cntx){
        polygon.drawingaux = [];
        polygon.drawingmode=false;
        $('#themover').removeClass('active');
        
        $('.polygoninitpoint').remove();
    },
    posnotif:function(event){
        polygon.drawingaux[1] = [event.clientX,event.clientY];
        polygon.drawingaux[2] = [polygon.drawingaux[1][0] - polygon.drawingaux[0][0],polygon.drawingaux[1][1] - polygon.drawingaux[0][1]];
        polygon.drawingaux[2][2] = Math.abs(polygon.drawingaux[2][0]);
        polygon.drawingaux[2][3] = Math.abs(polygon.drawingaux[2][1]);
        polygon.drawingaux[2][4] = Math.sqrt(Math.pow(polygon.drawingaux[2][2],2)+ Math.pow(polygon.drawingaux[2][3],2));
        polygon.drawingaux[2][5] = (0.5 * polygon.drawingaux[2][4]);
        polygon.drawingaux[2][6] = Math.atan(polygon.drawingaux[2][1]/polygon.drawingaux[2][0])*57.295779513;//ro
        
        $('#countermove').html(polygon.roundnumbers(polygon.drawingaux[2][4],2)+'px,'+polygon.roundnumbers(polygon.drawingaux[2][6],2)+'°');
    },
    roundnumbers:function(numbers,aftercomma){
        var roundtwo = Math.round(numbers * 10 * aftercomma);
        roundtwo = roundtwo / (10 * aftercomma);
        return roundtwo;
    },
    drawingmode:false,
    polygon:function(){
        if(polygon.drawingmode){
            polygon.stopdrawing(false);
            return;
        }
        
        polygon.drawingmode=true;
        $('#themover').addClass('active');
        return;
        
        polygon.polygon_();
    },
    drawing:false,
    context:false,
    polygon_:function(){
        if(polygon.canvasavailability===false){
            alert('unavailable');
            return;
        }
        
        if(polygon.context !== false){
            return;
        }
        
        if(typeof $('#thecanvas_0') !== 'undefined'){
            polygon.canvascount++;
            polygon.drawing = document.getElementById('thecanvas_'+polygon.canvascount);
            if(polygon.drawing.getContext){
                polygon.context = polygon.drawing.getContext('2d');
            }
            
            return;
        }
        polygon.canvascount++;
        $('#canvas').append('<canvas class="thecanvas" id="thecanvas_'+polygon.canvascount+'" width="'+$('#canvas').width()+'" height="'+$('#canvas').height()+'"></canvas>');
        
        polygon.drawing = document.getElementById('thecanvas_'+polygon.canvascount);
        if(polygon.drawing.getContext){
            polygon.context = polygon.drawing.getContext('2d');
            
            polygon.context.strokeStyle = '#0000ff';
            polygon.context.fillStyle = '#0000ff';
            
            polygon.context.beginPath();
            polygon.context.arc(100, 100, 90, 0,1.5*Math.PI, false);
            //draw inner circle
            polygon.context.moveTo(14, 100);
            polygon.context.arc(100, 100, 86, Math.PI , 2.5*Math.PI, false);
            
            polygon.context.arcTo(195, 210, 190,270, 190);
            //draw minute hand
            //polygon.context.moveTo(100, 100);
            //polygon.context.lineTo(100, 15);
            //draw hour hand
            //polygon.context.moveTo(100, 100);
            //polygon.context.lineTo(14, 100);
            //stroke the path
            polygon.context.stroke();
        }
        else{
            polygon.canvasavailability = false;
            return;
        }
        $('#thecanvas_'+polygon.canvascount).on('click',function(event){
            event.stopPropagation();    
        });
    }
};
var texter={
    initrandombg:function(){
        var selectedrand = ['#4f5463','#09180d','#494949','#608369','#0f1f2b','#2b3b47','#323433','#2f3330','#270a0a','#174158'];
        var sr = texter.getrand(0,9);
        
        $('#canvas').css('background',selectedrand[sr]);
        
        setTimeout(function(){
            $('#adjustcolor').spectrum('set', selectedrand[sr]);
        },500);
    },
    getrand:function(start,end){
        return Math.floor(Math.random() * (end-start)+start);
    },
    opertype:function(opername){
        switch (opername) {
            case 'merge':
                if(texter.focused !== false && texter.selectmerged){
                    opername = 'unmerge';
                }
                else{
                    var allme=true;
                    if($('#canvas').children('.selected').length)
                    $.each($('#canvas').children('.selected'),function(si,se){
                        if($(se).attr('class').indexOf('mergershirt')===-1){
                            allme=false;
                            return false;
                        }
                    });
                    else
                        allme = false;
                    
                    if(allme){
                        opername = 'unmerge';
                    }
                }
                break;
            default:
                // code
        }
        $('#themover').removeClass('active');
        texter.movingmode_ = false;
        
        texteditor.reset();
        
        
        if(opername == 'move'){
            texter.blurmoving = 0;
            texter.movingmode_=false;
        }
        $('#textofthemover').html(opername);
    },
    circle:function(){
        if(dialogbox.checkexists('Circle'))
            return;
            
        dialogbox.mbox(['Circle','<input type="text" name="diameter" value="diameter" id="circlesize">','<span id="createcircle" class="">Create Circle</span>'],'',function(){
           $('#circlesize').focus().addClass('regiformfoc');
            $('#circlesize').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    $(this).blur().removeClass('regiformfoc');
                    texter.newcircle($('#circlesize').val());
                }
            });
            $('#createcircle').on('click',function(){
                texter.newcircle($('#circlesize').val());
            }); 
        });
    },
    newcircle:function(circlesize){
        texter.textcounter++;
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt circleshirt" style="height:'+circlesize+'px;width:'+circlesize+'px"></div>'); 
        settings.placeelem('text_'+texter.textcounter);
        
        uredo.registermove({type:'newcircle',elem:[$('#text_'+texter.textcounter)[0].outerHTML,false,'text_'+texter.textcounter]});
        
        $('.regiformfoc').removeClass('regiformfoc').blur();
        dialogbox.close();
    },
    newline:function(){
        if(dialogbox.checkexists('Line'))
            return;
            
        dialogbox.mbox(['Line','<input type="text" name="length" value="length" id="linelength">','<span id="horizline" class="nline">Horizontal</span><span class="nline" id="verline">Vertical</div>'],'',function(){
            $('#linelength').focus().addClass('regiformfoc');
            $('.nline').on('click',function(event){
                event.stopPropagation();
                
                texter.newline_(this);
            }); 
        });
    },
    newline_:function(elem){
        texter.textcounter++;
        
        if($(elem).attr('id') == 'horizline'){
            texter.horizline($('#linelength').val());
        }
        else{
            texter.verline($('#linelength').val());
        }
        $('.regiformfoc').removeClass('regiformfoc').blur();
        dialogbox.close();
    },
    horizline:function(linelength){
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt lineshirt" style="top:7px;left:7px;height:4px;width:'+linelength+'px"><div style="width:100%;height:1px" class=""></div></div>');
        settings.placeelem('text_'+texter.textcounter);
        uredo.registermove({type:'newline',elem:[$('#text_'+texter.textcounter)[0].outerHTML,false,'text_'+texter.textcounter]});
    },
    verline:function(linelength){
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt lineshirt" style="top:7px;left:7px;width:4px;height:'+linelength+'px"><div style="height:100%;width:1px" class=""></div></div>');
        settings.placeelem('text_'+texter.textcounter);
        uredo.registermove({type:'newline',elem:[$('#text_'+texter.textcounter)[0].outerHTML,false,'text_'+texter.textcounter]});
    },
    selectzioncord:[],
    selectzionmode:false,
    pageview:function(cm){
        if(!cm){
            window.open('./?app='+appname+'&p=textshirt&a=shirttext&d[electronapp]=1&d[id]='+$('#pageid').html(),"","height=686,width=1345,top=0,left=0,resizable=yes"); 
            return;
        }
        
        if(dialogbox.checkexists('Page Url'))
            return;
            
        dialogbox.mbox(['Page Url','<input style="width:97%;text-align:center;" type="text" value="'+window.location.toString().split('?')[0]+'?app='+appname+'&p=textshirt&a=shirttext&d[id]='+$('#pageid').html()+'">',''],'wide');
    },
    addselections:function(elem){
        var insert = true;
        for(var i=0;i<texter.selections.length;i++){
            if($(texter.selections[i]).attr('id') == $(elem).attr('id')){
                insert = false;
                break;
            }
        }
        
        if(!insert){
            return;
        }
        
        texter.selections[texter.selections.length] = elem;
        $('#countermove').html(texter.selections.length);
        
        $('.btn.readonly').removeClass('readonly');
    },
    removeselections:function(elem){
        var insert = false;
        for(var i=0;i<texter.selections.length;i++){
            if($(texter.selections[i]).attr('id') == $(elem).attr('id')){
                texter.selections.splice(i,1);
                insert = true;
                break;
            }
        }
        
        if(!insert){
            return;
        }
        
        $('#countermove').html(texter.selections.length);
        if(!texter.selections.length){
            texter.blurs();
        }
    },
    removeselected:function(){
        uredo.newmoveinst('removal',1);
        
        $.each($('.selectall'),function(si,se){
            uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $(se)[0].outerHTML;
            uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
            uredo.cmove.elem[2][uredo.cmove.elem[2].length] = $(se).attr('id');
            
            texter.removeselections(se);
            $(se).remove();
        });
        
        $.each($('.selectmuch'),function(si,se){
            uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $(se)[0].outerHTML;
            uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
            uredo.cmove.elem[2][uredo.cmove.elem[2].length] = $(se).attr('id');
            
            texter.removeselections(se);
            $(se).remove();
        });
        
        $.each($('.selected'),function(si,se){
            uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $(se)[0].outerHTML;
            uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
            uredo.cmove.elem[2][uredo.cmove.elem[2].length] = $(se).attr('id');
            
            texter.removeselections(se);
            $(se).remove();
        });
        
        uredo.registermove(uredo.cmove);
        
        selection.removal();
        texter.blurmoving = true;
        texter.blurs();
    },
    showall:function(){
        if($('body').attr('class').indexOf('showall')===-1){
            $('body').addClass('showall');
            editors.adjustsize();
            return;
        }
        $('body').removeClass('showall');
    },
    selectallmode:false,
    selectallmodemove:function(key){
        if(key==40){
            $.each($('.textshirt.selectall'),function(i,e){
                $(e).css({'top':(parseInt($(e).css('top').split('px')[0])+settings.elementsett[0])+'px'});
            });
        }
        else if(key==38){
            $.each($('.textshirt.selectall'),function(i,e){
                $(e).css({'top':(parseInt($(e).css('top').split('px')[0])-settings.elementsett[0])+'px'});
            });
        }
        else if(key==37){
            $.each($('.textshirt.selectall'),function(i,e){
                $(e).css({'left':(parseInt($(e).css('left').split('px')[0])-settings.elementsett[0])+'px'});
            });
        }
        else{
            $.each($('.textshirt.selectall'),function(i,e){
                $(e).css({'left':(parseInt($(e).css('left').split('px')[0])+settings.elementsett[0])+'px'});
            });
        }
    },
    selectall:function(){
        if(texter.selectallmode){
            texter.selectallmode=false;
            $('.textshirt').removeClass('selectall');
            $('#textoptions').removeClass('selectallmode');
            if(texter.focused===false){
                texter.blurs();
            }
            return;
        }
        
        
        texter.blurs();
        
        $('.toolbars.active').removeClass('active');
        $('#textoptions').addClass('active selectallmode');
            
        $('#csstext').val('css');
        texter.csstoinspect_();
        
        texter.selectallmode=true;
        
        $.each($('.textshirt'),function(ti,te){
            $(te).addClass('selectall');
            texter.addselections(te);
        });
    },
    selectmuchmode_:false,
    selectmuchmode:function(){
        if(texter.selections.length < 2){
            texter.selectmuchmode_=false;
            $('.textshirt').removeClass('selectmuch');
            $('#textoptions').removeClass('selectallmode');
            if(texter.focused===false){
                texter.blurs();
            }
            return;
        }
        
        if(texter.focused===false){
            $('.toolbars.active').removeClass('active');
            $('#textoptions').addClass('active selectallmode');
        }
        else{
            $('#textoptions').addClass('selectallmode');
        }
        
        $('#csstext').val('css');
        texter.csstoinspect_();
        
        texter.selectmuchmode_=true;
        texter.classandstyleofmuch();
    },
    classandstyleofmuch:function(){
        texter.classofmuch = [];
        texter.styleofmuch = [];
        var temp = '';
        for(var i=0;i<texter.selections.length;i++){
            $(texter.selections[i]).addClass('selectmuch');
            temp = $(texter.selections[i]).attr('class').split(' ');
            if(i==0){
                for(var o=0;o<temp.length;o++){
                    if(temp[o] == 'textshirt' || temp[o] == 'selected' || temp[o] == 'selectmuch' || temp[o] == 'selectall' || temp[o]=='' || temp[o]==' '){
                        
                    }
                    else
                        texter.classofmuch[texter.classofmuch.length] = temp[o];
                }
            }
            else{
                for(var o=0;o<texter.classofmuch.length;o++){
                    if($(texter.selections[i]).attr('class').indexOf(texter.classofmuch[o]) === -1){
                        texter.classofmuch.splice(o,1);
                        o--;
                        if(!texter.classofmuch.length){
                            break;
                        }
                    }
                }
            }
            
            temp = $(texter.selections[i])[0].style.cssText.split(';');
            if(i==0){
                for(var o=0;o<temp.length;o++){
                    if(temp[o] == '' || temp[o] == ' '){
                        
                    }
                    else
                        texter.styleofmuch[texter.styleofmuch.length] = temp[o];
                }
            }
            else{
                for(var o=0;o<texter.styleofmuch.length;o++){
                    if($(texter.selections[i])[0].style.cssText.indexOf(texter.styleofmuch[o]) === -1){
                        texter.styleofmuch.splice(o,1);
                        o--;
                        if(!texter.styleofmuch.length){
                            break;
                        }
                    }
                }
            }
        }
        
        if(texter.styleofmuch.length){
            $('#csstext').val(texter.styleofmuch.join(';'));
            texter.csstoinspect_();
        }
        else
            $('#csstext').val('css');
            
        
        
        if(texter.classofmuch.length){
            $('#classtext').val(texter.classofmuch.join(' '));
        }
        else
            $('#classtext').val('class');
    },
    savedlist:false,
    showlist:function(){
        if(texter.savedlist===false){
            $.ajax({
                url:'./',
                data:{app:appname,p:'textshirt',a:'getlist'}
            }).done(function(msg){
                msg=JSON.parse(msg);
                texter.savedlist=msg.list;
                texter.showlist_();
            });
            return;
        }
        texter.showlist_();
    },
    urlopener:function(){
        if(dialogbox.checkexists('Open URL'))
            return;
            
        texter.newcanv(true);
        dialogbox.mbox(['Open URL','<input type="text" value="URL" name="URL" id="urladdr" style="width:90%;">','<span id="openaurl">Open</span><span style="float:left;margin-left:0px;" id="backtolist">&larr;</span>'],'',function(){
            $('#urladdr').val('http://pxpedia/pxpedia/?app=coscher&p=textshirt&a=shirttext&d[id]=28');
            $('#backtolist').on('click',function(event){
                event.stopPropagation();
                dialogbox.close();
                texter.showlist_();
            });
            $('#openaurl').on('click',function(event){
                event.stopPropagation();
                
                if($('#urladdr').val() == 'URL'){
                    return;
                }
                $(this).html('fetching page...');
                texter.urlopener_($('#urladdr').val());
            });
        });
    },
    urlopener_:function(address){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'textshirt',a:'urlopener',d:{url:address}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.result){
                $('#canvas').html(msg.content);
            }
            dialogbox.close();
        });
    },
    listsort:0,
    alfasort:['0','1','2','3','4','5','6','7','8','9','_','/','.','-','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],
    listsorter:function(so){
        if(so!==false){
            switch(texter.listsort){
                case 0:
                    texter.listsort = 1;
                break;
                case 1:
                    texter.listsort = 2;
                break;
                case 2:
                    texter.listsort = 0;
                break;
            }   
        }
        if(texter.listsort == 0){
            texter.savedlist.sort(function(a,b){
                return a.id - b.id;
            });            
            return;
        }
        
        var result;
        if(texter.listsort == 1){
            texter.savedlist.sort(function(a,b){
                for(i=0;i<a.description.length;i++){
                        result = texter.alfasort.indexOf(a.description.substr(i,1)) - texter.alfasort.indexOf(b.description.substr(i,1));
                    
                    if(result !== 0 || b.description.length === i+1)
                        break;
                }
                return result;
            });        
            return;
        }
        
        if(texter.listsort == 3){
            texter.savedlist.sort(function(a,b){
                return b.id - a.id;
            });   
            return;
        }
        
        texter.savedlist.sort(function(a,b){
            for(i=0;i<a.description.length;i++){
                    result = texter.alfasort.indexOf(b.description.substr(i,1)) - texter.alfasort.indexOf(a.description.substr(i,1));
                
                if(result !== 0 || b.description.length === i+1)
                    break;
            }
            return result;
        });
    },
    listsearch:[0,0],
    searchfromlist_:function(){
         $('#searchfromlist').on('click',function(event){
            event.stopPropagation();
            texter.searchfromlist__();
        });
    },
    searchfromlist__:function(){
        $('#searchfromlist').replaceWith('<input type="text" name="title" value="title" id="titlesearch">');
        $('#titlesearch').focus();
        $('#titlesearch').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 17){
                return;
            }
            
            if(event.which == 27){
                $(this).blur();
                return;
            }
            if(event.which == 13){
                texter.foundfromlist();
                return;
            }
            texter.searchfromlist($(this).val());
        });
        $('#titlesearch').on('blur',function(event){
            event.stopPropagation();
            
            setTimeout(function(){
                $('#titlesearch').replaceWith('<span id="searchfromlist"></span>');
                $('.teedesc.hide').removeClass('hide');
                
                texter.searchfromlist_();
            },300);
        });
    },
    foundfromlist:function(){
        if(!texter.listsearch[0]){
            if($('#titlesearch').val() == 'quit'){
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
            }
            return;
        }
        if(texter.listsearch[0]===1){
            texter.gettee(texter.savedlist[texter.listsearch[1]].description,texter.savedlist[texter.listsearch[1]].id);
            return;
        }
    },
    searchfromlist:function(val){
        texter.listsearch[0] = 0;
        for(var i=0;i<texter.savedlist.length;i++){
            if(texter.savedlist[i].description.indexOf(val)!==-1){
                $('#tee_'+texter.savedlist[i].id).removeClass('hide');
                texter.listsearch[0]+=1;
                texter.listsearch[1]=i;
            }
            else{
                $('#tee_'+texter.savedlist[i].id).addClass('hide');
            }
        }        
    },
    showlist_:function(){
        if(texter.savedlist.length==0){
            dialogbox.mbox(['List','none found']);
            return;
        }
        
        var c='';
        for(var i=0;i<texter.savedlist.length;i++){
            c+='<span class="teedesc" id="tee_'+texter.savedlist[i].id+'">'+texter.savedlist[i].description+'<span class="delshirt" id="delshirt_'+i+'">X</span></span>';
        }
        
        if(dialogbox.checkexists('List'))
            return;
            
        dialogbox.mbox(['List',c,'<span id="quitshirt">Quit</span><span id="urlopener">URL</span><span id="newcanv">New</span><select id="sortlister"><option value="0">id asc</option><option value="3">id desc</option><option value="1">name desc</option><option value="2">name asc</option></select><span id="searchfromlist"></span>'],'',function(){
           texter.searchfromlist_();
            
            $('#sortlister').val(texter.listsort);
            $('#sortlister').on('change',function(event){
                dialogbox.close();
                texter.listsort = this.value;
                texter.listsorter(texter.listsort);
                texter.showlist_();
            });
            
            $('#urlopener').on('click',function(event){
                event.stopPropagation();
                
                texter.urlopener();
            });
            $('#quitshirt').on('click',function(event){
                event.stopPropagation();
                
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
            });
            
            if(texter.saved.length){
                $('#tee_'+texter.saved[1])[0].scrollIntoView();
            }
            
            $('#newcanv').on('click',function(event){
                event.stopPropagation();
                
                texter.newcanv(true);
            });
            $('.delshirt').on('click',function(event){
                event.stopPropagation();
                
                texter.delshirt($(this).attr('id').split('_')[1]);
            });
            $('.teedesc').on('click',function(event){
                event.stopPropagation();
                
                texter.gettee($(this).html().split('<span')[0],$(this).attr('id').split('_')[1]);
            }); 
        });
    },
    delshirt:function(sidx){
        if(dialogbox.checkexists('Delete Page'))
            return;
            
        dialogbox.mbox(['Delete Page','Delete '+texter.savedlist[sidx].description+'?','<span id="confirmdelshirt" class="killryan">Delete</span>'],'',function(){
            $('#confirmdelshirt').on('click',function(event){
                event.stopPropagation();
                
                dialogbox.close();
                texter.delshirt_(sidx);
            }); 
        });
    },
    delshirt_:function(sidx){
        dialogbox.mbox(['Delete Page','Processing...'],'',function(){
           $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'textshirt',a:'delshirt',d:{id:texter.savedlist[sidx].id}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                dialogbox.close();
                
                if(msg.deleted){
                    dialogbox.mbox(['Delete Page','Page Deleted Successfully']);
                    
                    if(texter.saved.length && texter.saved[1] == texter.savedlist[sidx].id){
                        texter.newcanv(false);
                    }
                    
                    texter.savedlist.splice(sidx,1);
                
                    return;
                }
                dialogbox.mbox(['Delete Page','Error Deleting']);
            }); 
        });
    },
    currenttee:false,
    gettee:function(desc,id){
        editors.refresh();
        $('#canvaswrapper').html('');
        texter.currenttee = desc;
        dialogbox.close();
        dialogbox.mbox(['Loading Page','Downloading...'],'',function(){
           $.ajax({
                url:'./',
                data:{app:appname,p:'textshirt',a:'gettee',d:{id:id}}
            }).done(function(msg){
                msg=JSON.parse(msg);
                texter.saved[1]=id;
                texter.saved[0]=msg.content;
                $('#canvaswrapper').html(texter.saved[0]);
                $('#adjustcolor').spectrum('set', $('#canvas').css('background') == '' ? '#000000' : $('#canvas').css('background') );
                
                texter.findtextcounter();
                settings.resetcanvas();
                editors.countcode();
                
                pagesheets.init(false);
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
            }); 
        });
    },
    gettee_source:function(desc,id){
        texter.currenttee = desc;
        dialogbox.mbox(['Loading Page','Downloading...'],'',function(){
           $.ajax({
                url:'./',
                data:{app:appname,p:'textshirt',a:'gettee',d:{id:id}}
            }).done(function(msg){
                dialogbox.close();
                
                msg=JSON.parse(msg);
                texter.saved[1]=id;
                texter.saved[0]=msg.content;
                
                texter.pagecss_ = texter.saved[0];
                dialogbox.mbox(['Source','','<span id="savesource">Apply</span>'],'wide');
                
                editors.sourcecode();
                
                $('#savesource').on('click',function(event){
                    event.stopPropagation();
                    
                    $('#canvas').html(editors.getsource());
                    $('.regiformfoc').removeClass('regiformfoc').blur();
                    dialogbox.close();
                });
                
                $('#canvaswrapper').html(texter.saved[0]);
                $('#adjustcolor').spectrum('set', $('#canvas').css('background') == '' ? '#000000' : $('#canvas').css('background') );
                
                texter.findtextcounter();
                
            }); 
        });
    },
    findtextcounter:function(){
        var temp;
        
        texter.textcounter=$('#canvas').find('.textshirt').length+1;
        $.each($('.textshirt'),function(ti,te){
           temp = parseInt($(te).attr('id').split('_')[1]);
           if(temp > texter.textcounter || temp == texter.textcounter){
               texter.textcounter = temp;
           }
        });
        
        if(typeof $('.aruler').attr('class') !== 'undefined'){
            theruler.rulercount = $('#canvaswrapper').find('.aruler').length+1;
            $.each($('.aruler'),function(ru,ri){
                temp = parseInt($(ri).attr('id').split('_')[1]);
                if(temp > theruler.rulercount || theruler.rulercount == temp){
                    theruler.rulercount = temp;
                }
            });
        }
        
        $('#pageid').html(texter.saved[1]);
    },
    newcanv:function(clobo){
        editors.refresh();
        texter.saved = [];
        dialogbox.refresh();
        
        $('#canvas').html('');
        $('#pageid').html('');
        
        
        pagesheets.init_(true);
        texter.textcounter=0;
        
        if(clobo){
            $('.regiformfoc').removeClass('regiformfoc').blur();
            dialogbox.close();   
        }
    },
    save:function(){
        if(texter.saved.length){
            texter.savedsaved();
            return;
        }
        if(dialogbox.checkexists('Save Page'))
            return;
            
        dialogbox.mbox(['Save Page','<input type="text" value="description" style="text-align:center;" name="description" id="teedesc">','<span id="savetext_">save</span>'],'',function(){
            $('#teedesc').focus().addClass('regiformfoc');
            $('#teedesc').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    $(this).blur().removeClass('regiformfoc');
                    texter.save_();
                }
            });
            $('#savetext_').on('click',function(event){
                event.stopPropagation();
                
                texter.save_();
            }); 
        });
    },
    save_:function(){
        $(dialogbox.actionbox).html('<span id="loadingwaiting">Saving...</span>');
        texter.saved[0]=$('#teedesc').val();
        
        editors.javaorder();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'textshirt',a:'savetext',d:{description:texter.saved[0],content:pagesheets.thecompleteset()}}
        }).done(function(msg){
            msg=JSON.parse(msg);
            
            dialogbox.close();
            
            if(msg.results){
                texter.saved[1]=msg.result;
                texter.savedlist[texter.savedlist.length] = {id:msg.result,description:texter.saved[0]};
                dialogbox.mbox(['save','saved!']);
                
                $('#pageid').html(msg.result);
            }
            else{
                texter.saved = [];
                dialogbox.mbox(['save','Error!']);
            }
        });
    },
    savedsaved:function(){
        if(dialogbox.checkexists('Save Page - '+texter.currenttee))
            return;
            
        dialogbox.mbox(['Save Page - '+texter.currenttee,'<span class="contentbtn" id="saveas">Save As...</span><span id="replaceold" class="contentbtn">Save</span>'],'',function(){
           $('#replaceold').on('click',function(event){
                event.stopPropagation();
                
                dialogbox.close();
                
                dialogbox.mbox(['Save Page','Saving...']);
                
                
                editors.javaorder();
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'textshirt',a:'savedsaved',d:{id:texter.saved[1],content:pagesheets.thecompleteset()}}
                }).done(function(msg){
                    dialogbox.close();
                    msg=JSON.parse(msg);
                    
                    dialogbox.mbox(['save','saved!']);
                }); 
            });
            
            
            $('#saveas').on('click',function(event){
                event.stopPropagation();
                
                dialogbox.close();
                
                texter.saved = [];
                
                dialogbox.mbox(['save','<input type="text" value="description" style="text-align:center;" name="description" id="teedesc">','<span id="savetext_">save</span>'],'',function(){
                    $('#teedesc').focus().addClass('regiformfoc');
                    $('#teedesc').on('keyup',function(event){
                        if(event.which == 13){
                            texter.save_();
                        }
                    });
                    
                    $('#savetext_').on('click',function(event){
                        event.stopPropagation();
                        
                        texter.save_();
                    }); 
                });
            }); 
        });
    },
    saved:[],
    textcounter:0,
    focused:false,
    afamily:['ubuntu condensed','ubuntu semi-light italic','clickerscript','kristi','leaguescript','loversquarrel','pinyonscript','rougescript','ruthie','sueellenfrancisco','xbriyaz','amatic bold','amatic','arial','andale mono','arial black','book antiqua','comic sans ms','courier new','georgia','helvetica','impact','symbol','tahoma','terminal','times new roman','trebuchet','verdana','webdings'],
    changefont:function(){
        if(texter.selectmuchmode_ || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                $(texter.selections[i]).css({'font-family':$('#fontfamilyopt').val()});
            }
            
            texter.classandstyleofmuch();
            return;
        }
        
        $(texter.focusedid).css({'font-family':$('#fontfamilyopt').val()});
        $('#csstext').val($(texter.focusedid)[0].style.cssText);
    },
    pagecss_:false,
    pagecss__:false,
    pagejava:function(){
        if(dialogbox.checkexists('page java'))
            return;
        
        texter.pagecss_ = '';
        texter.pagecss__ = false;
        
        if(editors.currentcode !==false){
            if(editors.currentcode ===0){
                texter.pagecss_ = $('#pagejava').html();
            }
            else{
                texter.pagecss_ = $('#javacode_'+editors.currentcode).html();
            }
            
            texter.pagecss__ = true;            
        }
        else if(typeof $('#pagejava').attr('id') !== 'undefined'){
            texter.pagecss_ = $('#pagejava').html();
            texter.pagecss__ = true;
        }
        dialogbox.mbox(['page java','','<span id="savepagecss" style="display:none;">Apply</span><span id="saveandclose" class="savingprivateryan">Close</span><span id="savethepage" class="savingprivateryan"></span><span id="deletecode" class="killryan"></span><span id="javasett"></span><span id="javamagnif"></span><span id="javapacker" class="editing"></span>'],'wide',function(){
        editors.javacode();
        
        $('#javapacker').on('click',function(event){
            event.stopPropagation();
            editors.packermode()
        });
        
        $('#javasett').on('click',function(event){
            event.stopPropagation();
            if(typeof $('#ace_settingsmenu').attr('id') === 'undefined'){
                globalacesettingsmenu(event.clientX,event.clientY);
            }
            else{
                $('#javasett').removeClass('set');
                $('#ace_settingsmenu').parent().parent().remove();
            }
        });
        
            $('#deletecode').on('click',function(event){
                event.stopPropagation();
                
                editors.deletecode();
            });
            $('#pagecs').on('focus',function(event){
                event.stopPropagation();
                
                $('#pagecs').addClass('regiformfoc');
            });
            $('#saveandclose').on('click',function(event){
                event.stopPropagation();
                
                editors.savejavacode(1);
            });        
            $('#savethepage').on('click',function(event){
                event.stopPropagation();
                
                editors.savejavacode(0);
            });        
            $('#savepagecss').on('click',function(event){
                event.stopPropagation();
                
                editors.applyjavacode(true,false);
            }); 
        });
    },
    viewsource:function(){
        if(dialogbox.checkexists('Source'))
            return;
            
        texter.pagecss_ = $('#canvas').html();
        dialogbox.mbox(['Source','','<span id="savesource">Apply</span>'],'wide',function(){
            editors.sourcecode();
            $('#savesource').on('click',function(event){
                event.stopPropagation();
                
                $('#canvas').html(editors.getsource());
                
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
            }); 
        });
    },
    pagecss:function(){
        if(dialogbox.checkexists('page css'))
            return;
        
        texter.pagecss_ = '';
        texter.pagecss__ = false;
        if(typeof $('#pagecss_').attr('id') !== 'undefined'){
            texter.pagecss_ = $('#pagecss_').html();
            texter.pagecss__ = true;
        }
        
        dialogbox.mbox(['page css','','<span id="savedontclose" class="savingprivateryan">Save</span><span id="savepagecss" class="savingprivateryan">Apply & Close</span>'],'wide',function(){
            editors.csssource();
            $('#savedontclose').on('click',function(event){
                event.stopPropagation();
                
                editors.savethecss();
            });
            $('#savepagecss').on('click',function(event){
                event.stopPropagation();
                
                $('#pagecss_').remove();
                $('#canvaswrapper').append('<style id="pagecss_">'+editors.csssource_()+'</style>');
                
                dialogbox.close();
                $('.regiformfoc').removeClass('regiformfoc');
            }); 
        });
    },
    applyclass:function(){
        var classis;
        if((texter.selections.length>1 && texter.selectmuchmode_) || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                classis = $(texter.selections[i]).attr('class').split(' ');
                for(var e=0;e<classis.length;e++){
                    if(classis[e] == 'textshirt' || classis[e] == 'selected' || classis[e] == 'selectmuch' || classis[e] == 'selectall'){
                        
                    }
                    else{
                        if(texter.classofmuch.indexOf(classis[e]) !==-1)
                            $(texter.selections[i]).removeClass(classis[e]);
                    }
                }
                $(texter.selections[i]).addClass($('#classtext').val());
            }
            return;
        }
        classis = $(texter.focusedid).attr('class').split(' ');
        for(var e=0;e<classis.length;e++){
            if(classis[e] == 'textshirt' || classis[e] == 'selected' || classis[e] == 'selectmuch' || classis[e] == 'selectall'){
                
            }
            else{
                $(texter.focusedid).removeClass(classis[e]);
            }
        }
        $(texter.focusedid).addClass($('#classtext').val());
    },
    changeapart:function(dispart,dispartval){
        if((texter.selections.length>1 && texter.selectmuchmode_) || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                $(texter.selections[i]).css(dispart,dispartval);
                
                if($(texter.selections[i]).attr('class').indexOf('imageshirt') !== -1){
                    if(dispart == 'width' || dispart == 'height'){
                        $(texter.selections[i]).children().css(dispart,dispartval);
                    }
                }
            }
            
            return;
        }
        
        $(texter.focusedid).css(dispart,dispartval);
        if($(texter.focusedid).attr('class').indexOf('imageshirt') !== -1){
            if(dispart == 'width' || dispart == 'height'){
                $(texter.focusedid).children().css(dispart,dispartval);
            }
        }
    },
    csstoinspect__:[],
    csstoinspect_:function(){
        texter.csstoinspect = [];
        if($('#csstext').val() == 'css'){
            return;
        }
        
        var cssText = $('#csstext').val().split(';'),csstext_='',dispart,dispartval;
        for(var ci=0;ci<cssText.length;ci++){
            if(cssText[ci]!=''){
                csstext_ = cssText[ci].split(':');
                dispart = texter.cssvaluecleaner(csstext_[0]);
                dispartval = texter.cssvaluecleaner(csstext_[1]);
                
                texter.csstoinspect[texter.csstoinspect.length] = [dispart,dispartval];
            }
        }  
    },
    changecss:function(){
        if((texter.selections.length>1 && texter.selectmuchmode_) || texter.selectallmode){
            for(var o=0;o<texter.csstoinspect__.length;o++){
                for(var i=0;i<texter.selections.length;i++){
                    $(texter.selections[i]).css(texter.csstoinspect__[o][0],texter.csstoinspect__[o][1]);
                    
                    if($(texter.selections[i]).attr('class').indexOf('imageshirt') !== -1){
                        if(texter.csstoinspect__[o][0] == 'width' || texter.csstoinspect__[o][1] == 'height'){
                            $(texter.selections[i]).children().css(texter.csstoinspect__[o][0],texter.csstoinspect__[o][1]);
                        }
                    }
                }
                for(var pp =0;pp<texter.csstoinspect.length;pp++){
                    if(texter.csstoinspect[pp][0] == texter.csstoinspect__[o][0]){
                        texter.csstoinspect.splice(pp,1);
                        break;
                    }
                }
            }
            
            if(texter.csstoinspect.length){
                for(var o=0;o<texter.csstoinspect.length;o++){
                    for(var i=0;i<texter.selections.length;i++){
                        $(texter.selections[i]).css(texter.csstoinspect[o][0],'');
                        
                        if($(texter.selections[i]).attr('class').indexOf('imageshirt') !== -1){
                            if(texter.csstoinspect[o][0] == 'width' || texter.csstoinspect[o][1] == 'height'){
                                $(texter.selections[i]).children().css(texter.csstoinspect[o][0],'');
                            }
                        }
                    }
                }
                texter.csstoinspect = [];
            }
            return;
        }
        
        var csst = '',wi=false,he=false;
        for(var o=0;o<texter.csstoinspect__.length;o++){
            if(texter.csstoinspect__[o][0] == 'width'){
                wi = texter.csstoinspect__[o][1];
            }
            else if(texter.csstoinspect__[o][0] == 'height'){
                he = texter.csstoinspect__[o][1];
            }
            texter.csstoinspect__[o] = texter.csstoinspect__[o].join(':');
        }
        csst = texter.csstoinspect__.join(';')
        
        $(texter.focusedid)[0].style.cssText = csst;
        if($(texter.focusedid).attr('class').indexOf('imageshirt') !== -1){
            if(wi !== false){
                $(texter.focusedid).children().css('width',wi);
            }
            if(he !==false){
                $(texter.focusedid).children().css('height',he);
            }
        }
    },
    applycss:function(){
        uredo.newmoveinst('applycss',1);
        if((texter.selections.length>1 && texter.selectmuchmode_) || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                uredo.newinitial($(texter.selections[i])[0].outerHTML);
                uredo.newid($(texter.selections[i]).attr('id'));
            }
        }
        else{
            uredo.newinitial($(texter.focusedid)[0].outerHTML);
            uredo.newid($(texter.focusedid).attr('id'));
        }
        
        texter.csstoinspect__=[];
        var cssText = $('#csstext').val().split(';'),csstext_='',dispart,dispartval,csst='';
        if(cssText!='css')
        for(var ci=0;ci<cssText.length;ci++){
            if(cssText[ci]!=''){
                csstext_ = cssText[ci].split(':');
                dispart = csstext_[0].indexOf(' ')  !== -1 ? csstext_[0].split(' ')[1] : csstext_[0];
                dispartval = texter.cssvaluecleaner(csstext_[1]);
                
                texter.csstoinspect__[texter.csstoinspect__.length] = [dispart,dispartval];
            }
        }
        
        texter.changecss();
        
        if((texter.selections.length>1 && texter.selectmuchmode_) || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                uredo.newendstate($(texter.selections[i])[0].outerHTML);
            }
        }
        else{
            uredo.newendstate($(texter.focusedid)[0].outerHTML);
        }
        uredo.registermove(uredo.cmove);
    },
    cssvaluecleaner:function(val){
        if(val.indexOf('"')!==-1){
            val = val.split('"')[1];
        }
        
        var vals = val.split(' ');
        val = '';
        for(var i=0;i<vals.length;i++){
            if(vals[i]!= ''){
                if(val!=''){
                    val+=' '+vals[i];
                }
                else{
                    val+=vals[i];
                }   
            }
        }
        
        return val;
    },
    changetext_area:function(){
        if(typeof $('#changetext_area').attr('id') !== 'undefined'){
            $('#changetext_area').remove();
            return;
        }
        $('#changetext').addClass('disabled');
        $('#changetext').before('<input type="text" id="changetext_area" value="">');
        $('#changetext_area').val($('#changetext').val());
        
        $('#changetext_area').on('keyup',function(event){
            event.stopPropagation();
            texter.changetext(event); 
        });
        
        $('#changetext_area').on('contextmenu',function(event){
            event.stopPropagation();
            
            texter.changetext_area();
        });
    },
    cssapart:function(){
        if(texter.selectmuchmode_){
            return;
        }
        
        $('#cssapartone').remove();
        var csst='';
        var csstt = $(texter.focusedid)[0].style.cssText.split(';');
        var cssttt='';
        for(var i=0;i<csstt.length;i++){
            if(csstt[i].indexOf(':')!==-1){
                cssttt=csstt[i].split(':');
                if(cssttt[1].indexOf('"')!==-1){
                    csst+='<span>'+cssttt[0]+'</span><input id="cssa_'+i+'" type="text" value="'+texter.cssvaluecleaner(cssttt[1].split('"')[1])+'" class="cssapart quota">';
                }
                else{
                    csst+='<span>'+cssttt[0]+'</span><input id="cssa_'+i+'" type="text" value="'+texter.cssvaluecleaner(cssttt[1])+'" class="cssapart">';
                }
            }
        }
        $('#csstext').before('<div id="cssapartone">'+csst+'</div>');
        $('.cssapart').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 27){
                $('.regiformfoc').removeClass('regiformfoc');
                $('#cssapartone').remove();
                return;
            }
            
            if(event.which != 13){
                return;
            }
            $(this).addClass('changed');
            uredo.newmoveinst('applycss',1);
            uredo.newinitial($(texter.focusedid)[0].outerHTML);
            
            var dispart = ($(this).prev().html().indexOf(' ')!==-1) ? $(this).prev().html().split(' ')[1] : $(this).prev().html();
            var dispartval = $(this).attr('class').indexOf('quota') !== -1 ? '"'+$(this).val()+'"' : $(this).val();
            texter.changeapart(dispart,dispartval);
            
            uredo.newendstate($(texter.focusedid)[0].outerHTML);
            uredo.newid('text_'+texter.focused);
            uredo.registermove(uredo.cmove);
        });
        $('.cssapart').on('blur',function(event){
            if($(this).attr('class').indexOf('changed') !== -1){
                $(this).removeClass('changed');
                return;
            }            
        });
        $('.cssapart').on('change',function(){
            if($(this).attr('class').indexOf('changed') !== -1){
                $(this).removeClass('changed');
                return;
            }
            uredo.newmoveinst('applycss',1);
            uredo.newinitial($(texter.focusedid)[0].outerHTML);
            
            var dispart = ($(this).prev().html().indexOf(' ')!==-1) ? $(this).prev().html().split(' ')[1] : $(this).prev().html();
            var dispartval = $(this).attr('class').indexOf('quota') !== -1 ? '"'+$(this).val()+'"' : $(this).val();
            texter.changeapart(dispart,dispartval);
            
            uredo.newendstate($(texter.focusedid)[0].outerHTML);
            uredo.newid('text_'+texter.focused);
            uredo.registermove(uredo.cmove);
        });
    },
    initfont:function(){
        texter.afamily.sort(function(a,b){
            for(i=0;i<a.length;i++){
                result = texter.alfasort.indexOf(a.substr(i,1)) - texter.alfasort.indexOf(b.substr(i,1));
                if(result !== 0 || b.length === i+1)
                    break;
            }
            return result;    
        });
        var c='';
        for(var i=0;i<texter.afamily.length;i++){
            c+='<option value="'+texter.afamily[i]+'">'+texter.afamily[i]+'</option>';
        }
        $('#fontfamilyopt').html(c);
    },
    colorizepref_:[],
    colorizepref:function(){
        texter.colorizepref_ = [0,0,0,0];
        if($('#spbg').prop('checked')){
            texter.colorizepref_[0] = 1;
            texter.colorizepref_[3]++;
        }
        if($('#spborder').prop('checked')){
            texter.colorizepref_[1] = 1;
            texter.colorizepref_[3]++;
        }
        if($('#spcolor').prop('checked')){
            texter.colorizepref_[2] = 1;
            texter.colorizepref_[3]++;
        }
    },
    colorizedefault:function(action){
        if(action[0]){
            var cst = $('#csstext').val();
            if(action[1]=='spbg_'){
                if(texter.selections.length > 1){
                    if($('#csstext').val().indexOf('background-color') !==-1){
                        $('#fontcolor').spectrum('set',$(texter.selections[0]).css('background-color'));
                    }
                }
                else{
                    $('#fontcolor').spectrum('set',$(texter.focusedid).css('background-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('background-color'));   
                }
            }
            else if(action[1]=='spborder_'){
                if(texter.selections.length > 1){
                    if($('#csstext').val().indexOf('border-color') !==-1){
                        $('#fontcolor').spectrum('set',$(texter.selections[0]).css('border-color'));
                    }
                }
                else{
                    $('#fontcolor').spectrum('set',$(texter.focusedid).css('border-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('border-color'));   
                }
            }
            else if(action[1]=='spcolor_'){
                if(texter.selections.length > 1){
                    for(var op=0;op<texter.styleofmuch.length;op++){
                        if(texter.cssvaluecleaner(texter.styleofmuch[op].split(':')[0]) == 'color'){
                            $('#fontcolor').spectrum('set',$(texter.selections[0]).css('color'));
                            break;
                        }
                    }
                }
                else{
                    $('#fontcolor').spectrum('set',$(texter.focusedid).css('color')=='' ? '#bdbdbd' : $(texter.focusedid).css('color'));   
                }
            }
        }
        else{
            texter.colorizepref();
            for(var i=2;i>=0;i--){
                if(texter.colorizepref_[i]){
                    switch(i){
                        case 2:
                            if(texter.selections.length > 1){
                                for(var op=0;op<texter.styleofmuch.length;op++){
                                    if(texter.cssvaluecleaner(texter.styleofmuch[op].split(':')[0]) == 'color'){
                                        $('#fontcolor').spectrum('set',$(texter.selections[0]).css('color'));
                                        break;
                                    }
                                }
                            }
                            else{
                                $('#fontcolor').spectrum('set',$(texter.focusedid).css('color')=='' ? '#bdbdbd' : $(texter.focusedid).css('color'));   
                            }
                        break;
                        case 1:
                            if(texter.selections.length > 1){
                                if($('#csstext').val().indexOf('border-color') !==-1){
                                    $('#fontcolor').spectrum('set',$(texter.selections[0]).css('border-color'));
                                }                    
                            }
                            else{
                                $('#fontcolor').spectrum('set',$(texter.focusedid).css('border-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('border-color'));   
                            }
                        break;
                        case 0:
                            if(texter.selections.length > 1){
                                if($('#csstext').val().indexOf('background-color') !==-1){
                                    $('#fontcolor').spectrum('set',$(texter.selections[0]).css('background-color'));
                                }
                            }
                            else{
                                $('#fontcolor').spectrum('set',$(texter.focusedid).css('background-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('background-color'));   
                            }
                        break;
                    }
                    break;
                }
            }
        }
    },
    colorize:function(colorhex){
        texter.colorizepref();
        if(texter.selectmuchmode_ || texter.selectallmode || texter.selections.length > 1){
            uredo.newmoveinst('colorize',1);
            
            for(var i=0;i<texter.selections.length;i++){
                uredo.newinitial($(texter.selections[i])[0].outerHTML);
                
                if($(texter.selections[i]).attr('class').indexOf('lineshirt') !== -1){
                    $(texter.selections[i]).children().css({'background':colorhex});
                }
                else{
                    if(texter.colorizepref_[0]){
                        $(texter.selections[i]).css({'background-color':colorhex});
                    }
                    if(texter.colorizepref_[1]){
                        $(texter.selections[i]).css({'border-color':colorhex});
                    }
                    if(texter.colorizepref_[2]){
                        $(texter.selections[i]).css({'color':colorhex});
                    }   
                }
                    
                uredo.newendstate($(texter.selections[i])[0].outerHTML,colorhex);
                uredo.newid($(texter.selections[i]).attr('id'));
            }
            
            texter.classandstyleofmuch();
            
            uredo.color = colorhex;
            uredo.registermove(uredo.cmove);
            return;
        }
        
        uredo.newmoveinst('colorize',1);
        uredo.newinitial($(texter.focusedid)[0].outerHTML);
      
            if(texter.colorizepref_[0]){
                $(texter.focusedid).css({'background-color':colorhex});
            }
            if(texter.colorizepref_[1]){
                $(texter.focusedid).css({'border-color':colorhex});
            }
            if(texter.colorizepref_[2]){
                $(texter.focusedid).css({'color':colorhex});
            }   
        
        $('#csstext').val($(texter.focusedid)[0].style.cssText);
        
        uredo.newendstate($(texter.focusedid)[0].outerHTML,colorhex);
        uredo.newid($(texter.focusedid).attr('id'));
        
        uredo.color = colorhex;
        uredo.registermove(uredo.cmove);
    },
    changetext:function(event){
        if(event.target.id == 'changetext_area'){
            $('#changetext').val($('#changetext_area').val());
            
            if(event.which == 13 || event.which == 27){
                $('#changetext_area').remove();
                $('#changetext').removeClass('disabled');
            }
        }
        if($(texter.focusedid).attr('class').indexOf('imageshirt') !== -1){
            if(event.which==13){
                var nimg = new Image();
                var refresher = (($('#changetext').val().indexOf('?')!==-1 ? '&' : '?') +'timeit='+texter.getrand(0,3000));
                nimg.src = $('#changetext').val()+ refresher;
                nimg.onload = function(){
                    var imstyle = $(texter.focusedid).children('img')[0].style.cssText;
                    $(texter.focusedid).children('img').replaceWith('<img src="'+nimg.src+'" style="'+imstyle+'">');
                }
            }
        }
        else{
            if($(texter.focusedid).attr('class').indexOf('htmel') !== -1){
                if(event.which==13)
                    $(texter.focusedid).replaceWith($('#changetext').val());
            }
            else
                $(texter.focusedid).html($('#changetext').val());   
        }
    },
    blurmoving:0,
    blurs:function(){
        texteditor.reset();
        $("#adjustcolor").spectrum("hide");
        $("#fontcolor").spectrum("hide");
        htmel.blured();
        texter.selectmerged = false;
        if($('#textofthemover').html() == 'unmerge'){
            texter.opertype('merge');
        }
        else if($('#textofthemover').html() == 'anagram'){
            texter.opertype('move');
        }
        $('#operationslist').remove();
        $('.regiformfoc').removeClass('regiformfoc').blur();
        $('.btn.onoff').addClass('readonly');
        
        $('#textoptions').removeClass('polygon');
        $('#changetext_area').remove();
        
        $('#cssapartone').remove();
        
        if(texter.movingmode_){
            if(texter.blurmoving==0){
                texter.blurmoving++;
            }
            else{
                texter.blurmoving = 0;
                texter.movingmode_=false;
                $('#themover').removeClass('active');
            }
        }
        else{
            if($('#textofthemover').html() == 'move' && texter.blurmoving == 0 && !texter.selections.length){
                texter.movingmode_=true;
                $('#themover').addClass('active');
            }
        }
        
        if(texter.selectallmode){
            texter.selectall();
        }
        texter.selections = [];
        texter.selectmuchmode_ = false;
        
        $('.selected').removeClass('selected');
        $('.selectall').removeClass('selectall');
        $('.selectmuch').removeClass('selectmuch');
        
        $('#countermove').html(texter.selections.length);
        if(texter.focused!==false){
            texter.focused=false;
        }
        
            $('.toolbars.active').removeClass('active');
            $('#defaulttoolbar').addClass('active');
            
        uredo.registermove({type:'blur',elem:[0,0,0]});
    },
    selectmerged:false,
    textis:function(elem,event){
        var moving;
        if($(elem).parent().attr('id') != 'canvas' || $(elem).attr('class').indexOf('mergershirt') !== -1){
            if(event !== false){
                texter.selectmerged = true;
                while($(elem).parent().attr('id') != 'canvas'){
                    elem = $(elem).parent();
                }
                texter.textis_(elem);
                merger.selectmerged($(elem));
                moving = texter.textmove(elem,event);
                if(moving){
                    texter.blurmoving = 0;
                    return;
                }        
            }
            else{
                $(elem).addClass('selected');
                return;
            }
        }
        $(elem).addClass('selected');
        
        moving = texter.textmove(elem,event);
        if(moving){
            texter.blurmoving = 0;
            return;
        }
            
        texter.textis_(elem);
    },
    setfocus:function(elem){
        if($(elem).attr('id').indexOf('text_') !== -1){
            texter.focused = $(elem).attr('id').split('_')[1];
            texter.focusedid = '#text_'+texter.focused;
        }
        else{
            texter.focused = $(elem).attr('id');
            texter.focusedid = '#'+texter.focused;
        }
    },
    textis_:function(elem){
        if(texter.focused===false || texter.selectmerged){
            $('.toolbars.active').removeClass('active');
            $('#textoptions').addClass('active');
        }
        
        if(!texter.selectmuchmode_ && !texter.selectallmode){
            $('#textoptions').removeClass('selectallmode');
        }
        
        $('#cssapartone').remove();
        texter.setfocus(elem);
        
        $('#textoptions').removeClass('polygon');
        if($(texter.focusedid).attr('class').indexOf('imageshirt') !== -1){
            var imgurl = $(texter.focusedid).children().prop('src');
            if(imgurl.indexOf('&timeit=')!==-1){
                imgurl = imgurl.split('&timeit=')[0];
            }
            else if(imgurl.indexOf('?timeit=')!==-1){
                imgurl = imgurl.split('?timeit=')[0];
            }
            $('#changetext').val(imgurl);
            $(texter.focusedid).css('width',$(texter.focusedid).children().width()+'px');
            $(texter.focusedid).css('height',$(texter.focusedid).children().height()+'px');
        }
        else if($(texter.focusedid).attr('class').indexOf('circleshirt') !== -1){
            $('#textoptions').addClass('polygon');
            $('#fontcolor').spectrum('set',$(texter.focusedid).css('border-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('border-color'));
            $('#changetext').val($(texter.focusedid).html());
            
            $('#spborder').prop('checked',true);
            $('#spbg').prop('checked',false);
            $('#spcolor').prop('checked',false);
        }
        else if($(texter.focusedid).attr('class').indexOf('squareshirt') !== -1){
            $('#textoptions').addClass('polygon');
            $('#fontcolor').spectrum('set',$(texter.focusedid).css('border-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('border-color'));
            $('#changetext').val($(texter.focusedid).html());
            
            $('#spborder').prop('checked',true);
            $('#spbg').prop('checked',false);
            $('#spcolor').prop('checked',false);
        }
        else if($(texter.focusedid).attr('class').indexOf('rectshirt') !== -1){
            $('#textoptions').addClass('polygon');
            $('#fontcolor').spectrum('set',$(texter.focusedid).css('border-color')=='' ? '#bdbdbd' : $(texter.focusedid).css('border-color'));
            $('#changetext').val($(texter.focusedid).html());
            
            $('#spborder').prop('checked',true);
            $('#spbg').prop('checked',false);
            $('#spcolor').prop('checked',false);
        }
        else if($(texter.focusedid).attr('class').indexOf('lineshirt') !== -1){
            $('#textoptions').addClass('polygon');
            $('#fontcolor').spectrum('set',$(texter.focusedid).children().css('background')=='' ? '#bdbdbd' : $(texter.focusedid).children().css('background'));
            $('#changetext').val($(texter.focusedid).html());
            
            $('#spborder').prop('checked',false);
            $('#spbg').prop('checked',true);
            $('#spcolor').prop('checked',false);
        }
        else{
            if($(texter.focusedid).attr('class').indexOf('htmel') !== -1){
                $('#changetext').val($(texter.focusedid)[0].outerHTML);
            }
            else
                $('#changetext').val($(texter.focusedid).html());
            
            $('#fontcolor').spectrum('set',$(texter.focusedid).css('color')=='' ? '#bdbdbd' : $(texter.focusedid).css('color'));
            var thefont = texter.cssvaluecleaner($(texter.focusedid).css('font-family')).toLowerCase();
            $('#fontfamilyopt').val(thefont==''? 'arial' : thefont);
            
            $('#spborder').prop('checked',false);
            $('#spbg').prop('checked',false);
            $('#spcolor').prop('checked',true);
        }
        
        
        $('#csstext').val($(texter.focusedid)[0].style.cssText == '' ? 'css' : $(texter.focusedid)[0].style.cssText);
        texter.csstoinspect_();
        
        var classis = $(texter.focusedid).attr('class').split(' ');
        var classis_='';
        for(var i=0;i<classis.length;i++){
            if(classis[i] == '' || classis[i] == 'selected' || classis[i]== 'textshirt' || classis[i] == 'selectmuch' || classis[i] == 'selectall'){
                
            }
            else{
                if(classis_ != ''){
                    classis_+=' ';
                }
                classis_+=classis[i];
            }
        }
        if(classis_ !='')
            $('#classtext').val(classis_);
        else
            $('#classtext').val('class');
        
        $('#numberfontsize').val($(texter.focusedid).css('font-size')=='' ? 15:$(texter.focusedid).css('font-size').split('px')[0]);
        
        $('#textidis').html(texter.focused);
        $('#countermove').html($('#canvas').children('.selected').length);
    },
    adjustrulerpos:function(offsets,type){
        switch(type){
            case 0:
                $.each($('#canvaswrapper').children('.aruler.vertic'),function(rui,rue){
                    $(rue).css('left',parseInt($(rue).css('left'))+offsets);
                });
            break;
            case 1:
                $.each($('#canvaswrapper').children('.aruler.horiz'),function(rui,rue){
                    $(rue).css('top',parseInt($(rue).css('top'))+offsets);
                });
            break;
            case 2:
                $.each($('#canvaswrapper').children('.aruler.horiz'),function(rui,rue){
                    $(rue).css('top',parseInt($(rue).css('top'))+offsets[1]);
                });
                $.each($('#canvaswrapper').children('.aruler.vertic'),function(rui,rue){
                    $(rue).css('left',parseInt($(rue).css('left'))+offsets[0]);
                });
            break;
        }
    },
    canvasmovebyarrow:function(key){
        switch(key){
            case 40:
                photox.canvasoffset[1]-=1;
                $('#canvas').css('top',photox.canvasoffset[1]);
                texter.adjustrulerpos(-1,1);
            break;
            case 33:
                photox.canvasoffset[1]+=5;
                $('#canvas').css('top',photox.canvasoffset[1]);
                texter.adjustrulerpos(5,1);
            break;
            case 34:
                photox.canvasoffset[1]-=5;
                $('#canvas').css('top',photox.canvasoffset[1]);
                texter.adjustrulerpos(-5,1);
            break;
            case 38:
                photox.canvasoffset[1]+=1;
                $('#canvas').css('top',photox.canvasoffset[1]);
                texter.adjustrulerpos(1,1);
            break;
            case 37:
                photox.canvasoffset[0]+=1;
                $('#canvas').css('left',photox.canvasoffset[0]);
                texter.adjustrulerpos(1,0);
            break;
            default:
                photox.canvasoffset[0]-=1;
                $('#canvas').css('left',photox.canvasoffset[0]);
                texter.adjustrulerpos(-1,0);
                
        }
        
        $('#countermove').html(photox.canvasoffset[0]+','+photox.canvasoffset[1]);
    },
    textmovebyarrow:function(key){
        if($('#textofthemover').html() == 'canvas'){
            texter.canvasmovebyarrow(key);
            return;
        }
        if(photox.grabed !==false && $(photox.grabed).attr('class').indexOf('aruler') !== -1){
            if(photox.rulergrabedtype){
                if(!(key==37 || key == 39)){
                    $(photox.grabed).removeClass('grabbing');
                    photox.grabed = false;
                    return;
                }
                if(key == 39){
                    $('#ruler_'+photox.grabber[2][0]).css({'left':($('#ruler_'+photox.grabber[2][0])[0].offsetLeft+settings.elementsett[0])+'px'});    
                }
                else{
                    $('#ruler_'+photox.grabber[2][0]).css({'left':($('#ruler_'+photox.grabber[2][0])[0].offsetLeft-settings.elementsett[0])+'px'});
                }
                photox.rulerposnotif($('#ruler_'+photox.grabber[2][0])[0].offsetLeft,1);
            }
            else{
                if(!(key==40 || key == 38)){
                    $(photox.grabed).removeClass('grabbing');
                    photox.grabed = false;
                    return;
                }
                if(key==40){
                    $('#ruler_'+photox.grabber[2][0]).css({'top':($('#ruler_'+photox.grabber[2][0])[0].offsetTop+settings.elementsett[0])+'px'});    
                }
                else{
                    $('#ruler_'+photox.grabber[2][0]).css({'top':($('#ruler_'+photox.grabber[2][0])[0].offsetTop-settings.elementsett[0])+'px'});
                }
                photox.rulerposnotif($('#ruler_'+photox.grabber[2][0])[0].offsetTop,0);
            }
            
            return;
        }
        
        
        if(typeof $('.regiformfoc').attr('class') !== 'undefined' || (texter.focused == false && !texter.selections.length)){
            return;
        }
        if(texter.selectallmode){
            texter.selectallmodemove(key);
            return;
        }
        
            if(texter.selections.length){
                if(key==40){
                    for(var i=0;i<texter.selections.length;i++){
                        $(texter.selections[i]).css({'top':(parseInt($(texter.selections[i]).css('top').split('px')[0])+settings.elementsett[0])+'px'});
                    }
                }
                else if(key==38){
                    for(var i=0;i<texter.selections.length;i++){
                        $(texter.selections[i]).css({'top':(parseInt($(texter.selections[i]).css('top').split('px')[0])-settings.elementsett[0])+'px'});
                    }
                }
                else if(key==37){
                    for(var i=0;i<texter.selections.length;i++){
                        $(texter.selections[i]).css({'left':(parseInt($(texter.selections[i]).css('left').split('px')[0])-settings.elementsett[0])+'px'});
                    }
                }
                else{
                    for(var i=0;i<texter.selections.length;i++){
                        $(texter.selections[i]).css({'left':(parseInt($(texter.selections[i]).css('left').split('px')[0])+settings.elementsett[0])+'px'});
                    }
                }
                
                if(texter.selections.length===1){
                    $('#csstext').val($(texter.focusedid)[0].style.cssText);
                }
            }
    },
    movingmode_:false,
    mocinmode:function(){
        if($('#textofthemover').html() == 'ruler'){
            theruler.mocinmode();
        }
    },
    movingmode:function(){
        if($('#textofthemover').html() == 'move'){
            if(texter.movingmode_){
                texter.movingmode_=false;
                $('#themover').removeClass('active');
                return;
            }
            texter.movingmode_=true;
            $('#themover').addClass('active');
            
            texter.selectmuchmode();
            
            return;
        }
        
        if($('#textofthemover').html() == 'clone'){
            if(texter.focused===false && !texter.selections.length){
                return;
            }
            cloner.clone();
            return;
        }
        
        if($('#textofthemover').html() == 'selection'){
            selection.selections();
            return;
        }
        if($('#textofthemover').html() == 'ruler'){
            theruler.add();
            return;
        }
        if($('#textofthemover').html() == 'canvas'){
            return;
        }
        if($('#textofthemover').html() == 'merge'){
            merger.merge();
            return;
        }
        if($('#textofthemover').html() == 'unmerge'){
            merger.unmerge();
            return;
        }
        if($('#textofthemover').html() == 'line'){
            texter.newline();
            return;
        }
        if($('#textofthemover').html() == 'circle'){
            texter.circle();
            return;
        }
        if($('#textofthemover').html() == 'transform'){
            transformer.seltrans_(false);
            return;
        }
        if($('#textofthemover').html() == 'rectangle'){
            polygon.rectangle();
            return;
        }
        if($('#textofthemover').html() == 'square'){
            polygon.square();
            return;
        }
        if($('#textofthemover').html() == 'charts'){
            charts.box();
            return;
        }
        if($('#textofthemover').html() == 'drawline'){
            polygon.polygon();
            return;
        }
        if($('#textofthemover').html() == 'animate'){
            animate.animation();
            return;
        }
        if($('#textofthemover').html() == 'paper'){
            paper.box();
            return;
        }
        if($('#textofthemover').html() == 'texteditor'){
            texteditor.edit();
            return;
        }
        if($('#textofthemover').html() == 'anagram'){
            anagram.start();
            return;
        }
    },
    selections:[],
    textmoveselection:function(event){
        photox.grabmuch(event);
    },
    textmove:function(elem,event){
        if(event===false){
            return;
        }
        if(!texter.movingmode_){
            texter.addselections(elem);
            return false;
        }
        
        if(texter.focused===false){
            $('.toolbars.active').removeClass('active');
            $('#textoptions').addClass('active');
        }
        
        $('#textoptions').removeClass('polygon');
        if($(elem).attr('class').indexOf('circleshirt') !== -1 || $(elem).attr('class').indexOf('lineshirt') !== -1 || $(elem).attr('class').indexOf('rectshirt') !== -1 || $(elem).attr('class').indexOf('squareshirt') !== -1){
            $('#textoptions').addClass('polygon');
        }
        
        texter.setfocus(elem);
        $('#changetext').val($(texter.focusedid).html());
        $('#fontcolor').spectrum('set',$(texter.focusedid).css('color')=='' ? '#bdbdbd' : $(texter.focusedid).css('color'));
        
        photox.grab(event,elem);
        
        $('#textidis').html(texter.focused);
        
        return true;
    },
    fontsizeis:function(){
        if(texter.selectmuchmode || texter.selectallmode){
            for(var i=0;i<texter.selections.length;i++){
                $(texter.selections[i]).css({'font-size':$('#numberfontsize').val()+'px'});
            }
        }
        
        texter.classandstyleofmuch();
    },
    add:function(textval){
        texter.textcounter++;
        
        if(texter.textermode){
            $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt imageshirt"><img src="'+textval+'"></div>');
            $('#textshirt').val('imageurl').removeClass('filled');
            settings.placeelem('text_'+texter.textcounter);
            
            texter.textis($('#text_'+texter.textcounter),false);
            
            return;
        }
        
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt">'+textval+'</div>');
        $('#textshirt').val('text').removeClass('filled');
        settings.placeelem('text_'+texter.textcounter);
        
        texter.textis($('#text_'+texter.textcounter),false);
    },
    textermode:0,
    shifttexter:function(){
        switch(texter.textermode){
            case 0://textmode
                $('#textshirt').prop('name','imageurl');
                $('#textshirt').prop('value','imageurl');
                texter.textermode = 1;//imagemode
            break;
            case 1://imagemode
                $('#textshirt').prop('name','HTML Element');
                $('#textshirt').prop('value','HTML Element');
                texter.textermode = 2;//html element mode
                
                htmel.list(false);
            break;
            case 2://html element mode
                $('#htmellist').remove();
                $('#textshirt').prop('name','text');
                $('#textshirt').prop('value','text');
                texter.textermode = 0;//textmode
            break;
        }
    }
};
var selection={
    elems:[],
    selections:function(){
        selection.elems = [];
        $.each($('.textshirt'),function(si,se){
            selection.elems[si]=se;
        });
        selection.selections_();
    },
    filter_:0,
    filter:function(){
        selection.filter_ = $('#selecttypes').val();
        
        if(selection.filter_==0){
            $('.row.hide').removeClass('hide');
            return;
        }
        
        if(selection.filter_==1){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('circleshirt') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            return;
        }
        
        if(selection.filter_==2){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('lineshirt') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            return;
        }
        
        if(selection.filter_==3){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('squareshirt') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            return;
        }
        
        if(selection.filter_==4){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('rectshirt') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            return;
        }
        if(selection.filter_==5){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('selected') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            
            return;
        }
        if(selection.filter_==6){
            $('.row.hide').removeClass('hide');
            $.each($('.elemco'),function(hi,he){
                if($(he).val().indexOf('mergershirt') === -1){
                    $(he).parent().parent().addClass('hide');
                }
            });
            
            return;
        }
    },
    filterbysearch:function(key){
        selection.fbs = key;
        if(selection.fbs=='' || selection.fbs == 'search'){
            $('.hidebyco').removeClass('hidebyco');
            return;
        }
        
        $.each($('.elemco'),function(i,e){
            if($(e).val().indexOf(key) !== -1 && ( ($(e).val().indexOf('mergershirt') === -1 && selection.filter_ != 6) || ($(e).val().indexOf('mergershirt') !== -1 && selection.filter_ == 6) )){
                $(e).parent().parent().removeClass('hidebyco');
            }
            else{
                $(e).parent().parent().addClass('hidebyco');
            }
        });
    },
    fbs:'',
    fbsval:function(){
        return selection.fbs == '' ? 'search' : selection.fbs;
    },
    selections_:function(){
        if(dialogbox.checkexists('Selections'))
            return;
        
        var sall = true;
        var sel = '<div class="row header">';
        sel+='<div class="elemname" id="sortel">Element</div>';
        sel+='<div class="elemselection"><input type="checkbox" value="checked" id="sortelselall">Selection</div>';
        sel+='</div>';
        for(var i=0;i<selection.elems.length;i++){
            if($(selection.elems[i]).attr('class').indexOf('selected') ===-1){
                sall = false;
            }
            sel+='<div class="row bordered">';
            sel+='<div class="elemname" id="elemnameof_'+$(selection.elems[i]).attr('id')+'">'+$(selection.elems[i]).attr('id')+'<input type="text" value="" class="elemco" id="elemcontent_'+i+'"></div>';
            sel+='<div class="elemselection">'+($(selection.elems[i]).attr('class').indexOf('selected') !== -1 || $(selection.elems[i]).attr('class').indexOf('selectall') !== -1 ||$(selection.elems[i]).attr('class').indexOf('selectmuch') !== -1 ? 'selected' : '-')+'</div>';
            sel+='</div>';
        }
        
        var typehu = '<option value="0">All</option><option value="1">circle</option>';
        typehu+='<option value="2">line</option><option value="3">square</option>';
        typehu+='<option value="4">rectangle</option>';
        typehu+='<option value="5">selected</option>';
        typehu+='<option value="6">merged container</option>';
        
        dialogbox.mbox(['Selections',sel,'<select id="selecttypes">'+typehu+'</select><input type="text" id="sssearch" value="'+selection.fbsval()+'" name="search">'],'xxl',function(){
           $('#sssearch').on('keyup',function(event){
                event.stopPropagation();
                
                selection.filterbysearch($('#sssearch').val());
            });
            
            if(sall || texter.selectallmode){
                $('#sortelselall').prop('checked',true);
                texter.selectallmode = true;
            }
            else{
                $('#sortelselall').prop('checked',false);
                texter.selectallmode = false;
            }
            
            for(var i=0;i<selection.elems.length;i++){
                $('#elemcontent_'+i).val($(selection.elems[i])[0].outerHTML);
            }
            
            selection.filterbysearch($('#sssearch').val());
            
            $('#sortelselall').on('click',function(event){
                event.stopPropagation();
                
                selection.modifyselection_(this);
            });
            
            $('#selecttypes').val(selection.filter_);
            selection.filter();
            
            $('#selecttypes').on('change',function(event){
                event.stopPropagation();
                
                selection.filter();
            });
            
            $('.elemselection').on('click',function(event){
                event.stopPropagation();
                
                selection.modifyselection(this);
            });
            
            $('#sortel').on('click',function(event){
                event.stopPropagation();
                
                selection.sortel();
            });
            
            $('.elemco').on('click contextmenu',function(event){
                event.stopPropagation();
                
                if(event.type == 'contextmenu'){
                    selection.elemco(this);
                }
            });
            
            $('.elemco').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    selection.elemcoupdate(this);
                }
            });
            
            $('.elemco').on('blur',function(event){
                event.stopPropagation();
                
                $(this).removeClass('regiformfoc');
            }); 
        });
    },
    elemcoupdate:function(elem){
        if($(elem).attr('class').indexOf('inco')===-1){
            $(selection.elems[parseInt($(elem).attr('id').split('_')[1])]).replaceWith($(elem).val());
        }
    },
    elemco:function(elem){
        if($(elem).attr('class').indexOf('inco') !== -1){
            $.each($('.elemco'),function(ei,ey){
                $(ey).removeClass('inco');
                $(ey).val($(selection.elems[parseInt($(ey).attr('id').split('_')[1])])[0].outerHTML);
            });
        }
        else{
            $.each($('.elemco'),function(ei,ey){
                $(ey).addClass('inco');
                $(ey).val($(selection.elems[parseInt($(ey).attr('id').split('_')[1])]).html());
            });
        }
    },
    removal:function(){
        $.each($('.elemselection'),function(ei,ey){
            if($(ey).html() == 'selected'){
                $(ey).parent().remove();
            }
        });
        
        selection.elems = [];
        $.each($('.textshirt'),function(si,se){
            selection.elems[si]=se;
        });
    },
    sortsel_:0,
    sortel_:0,
    sortsel:function(){
        selection.sortsel_ = !selection.sortsel_;
        
        if(selection.sortsel_)
            selection.elems.sort(function(a,b){
                return $(a).attr('class').indexOf('selected') - $(b).attr('class').indexOf('selected');
            });
        else
            selection.elems.sort(function(a,b){
                return $(b).attr('class').indexOf('selected') - $(a).attr('class').indexOf('selected');
            });
            
        selection.selections_();
    },
    alfasort:['0','1','2','3','4','5','6','7','8','9','_','/','.','-','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],
    sortel:function(){
        dialogbox.close();
        
        selection.sortel_ = !selection.sortel_;
        if(selection.sortel_)
            selection.elems.sort(function(a,b){
                var atitle = $(a).attr('id');
                var vtitle = $(b).attr('id');
                return parseInt(atitle.split('_')[1]) - parseInt(vtitle.split('_')[1]);
            });
        else
            selection.elems.sort(function(a,b){
                var vtitle = $(a).attr('id');
                var atitle = $(b).attr('id');
                return parseInt(atitle.split('_')[1]) - parseInt(vtitle.split('_')[1]);
            });
        
        selection.selections_();
    },
    modifyselection_:function(elem){
        if($(elem).prop('checked')){
            var all=true;
            $.each($('.elemselection'),function(ei,ey){
                if($(ey).children().length){
                    
                }
                else{
                    if($(ey).parent().attr('class').indexOf('hide')!==-1){
                        all=false;
                    }
                    else{
                        $(ey).html('selected');
                        $('#'+$(ey).prev().attr('id').substr(11)).addClass('selected');
                        texter.addselections($('#'+$(ey).prev().attr('id').substr(11))[0]);
                        $(ey).parent().find('input').val($('#'+$(ey).prev().attr('id').substr(11))[0].outerHTML);   
                    }
                }
            });
            
            if(all){
                texter.selectallmode = true;
            }
            else{
                if(!texter.selectmuchmode_)
                    texter.selectmuchmode();
            }
            return;
        }
        
            texter.selectallmode = false;
            texter.selectmuchmode_ = false;
            
            $.each($('.elemselection'),function(ei,ey){
                if($(ey).children().length){
                    
                }
                else{
                    if($(ey).parent().attr('class').indexOf('hide')!==-1){
                        
                    }
                    else{
                        $(ey).html('-');
                        texter.removeselections($('#'+$(ey).prev().attr('id').substr(11))[0]);
                        $('#'+$(ey).prev().attr('id').substr(11)).removeClass('selected selectmuch selectall');
                        $(ey).parent().find('input').val($('#'+$(ey).prev().attr('id').substr(11))[0].outerHTML);   
                    }
                }
            });
        
    },
    modifyselection:function(elem){
        if($(elem).children().length){
            selection.sortsel();
            return;
        }
        
        if($(elem).html() == '-'){
            $(elem).html('selected');
            $('#'+$(elem).prev().attr('id').substr(11)).addClass('selected');
            texter.addselections($('#'+$(elem).prev().attr('id').substr(11))[0]);
            $(elem).parent().find('input').val($('#'+$(elem).prev().attr('id').substr(11))[0].outerHTML);
            
            
            if(texter.selections.length == $('#canvas').find('.textshirt').length){
                texter.selectallmode = true;
                $('#sortelselall').prop('checked',true);
            }
            
            texter.textis_($('#'+$(elem).prev().attr('id').substr(11))[0]);
            
            return;
        }
        
        
        $('#sortelselall').prop('checked',false);
        if(texter.selectallmode){
            $('.selectall').removeClass('selectall').addClass('selected');
            
            $.each($('.elemselection'),function(ei,ey){
                if($(ey).children().length){
                    
                }
                else{
                    $('#'+$(ey).prev().attr('id').substr(11)).removeClass('selectall');
                    $(ey).parent().find('input').val($('#'+$(ey).prev().attr('id').substr(11))[0].outerHTML);
                }
            });
            
            texter.selectallmode = false;    
        }
        
        $(elem).html('-');
        texter.removeselections($('#'+$(elem).prev().attr('id').substr(11))[0]);
        $('#'+$(elem).prev().attr('id').substr(11)).removeClass('selected selectmuch selectall');
        $(elem).parent().find('input').val($('#'+$(elem).prev().attr('id').substr(11))[0].outerHTML);
        
        if(!texter.selections.length){
            texter.selectmuchmode_ = false;
        }
    }
};
var cutpaste = {
    clipboard:false,
    clipboardtype:0,
    marktocut:function(elem){//merged
        $.each($(elem).children(),function(i,e){
            $(e).addClass('cuttopaste');
            if($(e).children().length && $(e).attr('class').indexOf('lineshirt') ===-1){
                cutpaste.marktocut($(e)[0]);
            }
        });
    },
    marktocut_:function(){//selected
        $.each($('#canvas').children('.selected'),function(siy,sey){
            if($(sey).children().length && $(sey).attr('class').indexOf('lineshirt') ===-1){
                $(sey).addClass('cuttopaste');
                cutpaste.marktocut($(sey)[0]);
            }
            else{
                $(sey).addClass('cuttopaste');
            }
        });
    },
    marktocopy:function(elem){//merged
        $.each($(elem).children(),function(i,e){
            $(e).addClass('copytopaste');
            if($(e).children().length && $(e).attr('class').indexOf('lineshirt') ===-1){
                cutpaste.marktocopy($(e)[0]);
            }
        });
    },
    marktocopy_:function(){//selected
        $.each($('#canvas').children('.selected'),function(siy,sey){
            if($(sey).children().length && $(sey).attr('class').indexOf('lineshirt') ===-1){
                $(sey).addClass('copytopaste');
                cutpaste.marktocopy($(sey)[0]);
            }
            else{
                $(sey).addClass('copytopaste');
            }
        });
    },
    copy:function(){
        cutpaste.clipboard = '';
        
        if(texter.selectmerged){
            $(texter.focusedid).addClass('copytopaste');
            cutpaste.marktocopy($(texter.focusedid)[0]);
            cutpaste.clipboard+= $(texter.focusedid)[0].outerHTML;
        }
        else{
            if(texter.selectallmode){
                $('.selectall').addClass('copytopaste');
            }
            else{
                cutpaste.marktocopy_();
            }
                
            $.each($('.copytopaste'),function(ci,cu){
                if($(cu).parent().attr('id')!== 'canvas'){
                    
                }
                else{
                    cutpaste.clipboard+= $(cu)[0].outerHTML;
                }
            });
        }
        if(cutpaste.clipboard == ''){
            cutpaste.clipboard = false;
        }
        cutpaste.clipboardtype = 1;
        
        dialogbox.mbox(['','Copied','<span id="snappaste">Snap Mode</span>'],'',function(){
           $('#snappaste').on('click',function(event){
                event.stopPropagation();
                
                $('#textofthemover').html('paste');
                $('#themover').addClass('active');
                dialogbox.close();
            }); 
        });
    },
    cut:function(){
        cutpaste.clipboard = '';
        
        if(texter.selectmerged){
            $.each($('#canvas').children('.mergershirt.selected'),function(mi,me){
                $(me).addClass('cuttopaste');
                
                cutpaste.marktocut($(me)[0]);
                cutpaste.clipboard+= $(me)[0].outerHTML; 
                
                $(me).remove();
            });
        }
        else{
            if(texter.selectallmode){
                $('.selectall').addClass('cuttopaste');
            }
            else{
                cutpaste.marktocut_();
            }
                
            $.each($('.cuttopaste'),function(ci,cu){
                if($(cu).parent().attr('id')!== 'canvas'){
                    
                }
                else{
                    cutpaste.clipboard+= $(cu)[0].outerHTML;
                    $(cu).remove();   
                }
            });
        }
        texter.blurs();
        
        if(cutpaste.clipboard == ''){
            cutpaste.clipboard = false;
        }
        cutpaste.clipboardtype = 0;
        
        dialogbox.mbox(['','Copied to Clipboard','<span id="snappaste">Snap Mode</span>'],'',function(){
           $('#snappaste').on('click',function(event){
                event.stopPropagation();
                
                $('#textofthemover').html('paste');
                $('#themover').addClass('active');
                dialogbox.close();
            }); 
        });
    },
    paste:function(){
        if(cutpaste.clipboard === false)
            return;
            
        texter.blurs();
        
        texter.textcounter++;
        
        if(cutpaste.clipboardtype){//copy
            $('.copytopaste').removeClass('copytopaste');
            $('#canvas').append(cutpaste.clipboard);
            
            $.each($('.copytopaste'),function(cu,ci){
                $(ci).prop('id','text_'+texter.textcounter);
                texter.textcounter++;
                texter.addselections(ci);
                
                if($(ci).attr('class').indexOf('mergershirt')!==-1){
                    cutpaste.pasteid(ci);
                }
            });
            
            if(cutpaste.snappastemode){
                cutpaste.snappaste_('copytopaste');
            }
            
            $('.copytopaste').removeClass('copytopaste');
        }
        else{//cut
            $('#canvas').append(cutpaste.clipboard);
            
            $.each($('.cuttopaste'),function(cu,ci){
                $(ci).prop('id','text_'+texter.textcounter);
                texter.textcounter++;
                texter.addselections(ci);
                
                if($(ci).attr('class').indexOf('mergershirt')!==-1){
                    cutpaste.pasteid(ci);
                }
            });
            
            if(cutpaste.snappastemode){
                cutpaste.snappaste_('cuttopaste');
            }
            
            $('.cuttopaste').removeClass('cuttopaste');            
            
            cutpaste.clipboard = false;
        }
    },
    snappastemode:false,
    snappaste_:function(cla){
        var childrenofpaste = $('#canvas').children('.'+cla).length,copaste=[];
        if(childrenofpaste>1){
            $.each($('#canvas').children('.'+cla),function(cpi,cpm){
                copaste[copaste.length] =  {elem:cpm,top:$(cpm)[0].offsetTop,left:$(cpm)[0].offsetLeft};
                if(cpi>0){
                   copaste[copaste.length-1].deltatop = copaste[copaste.length-1].top - copaste[0].top;
                   copaste[copaste.length-1].deltaleft = copaste[copaste.length-1].left - copaste[0].left;
                }
            });
            
            $('#canvas').children('.'+cla).eq(0).css('left',event.clientX-(photox.canvasoffset[0])+'px');
            $('#canvas').children('.'+cla).eq(0).css('top',event.clientY-(photox.canvasoffset[1])+'px');
            for(var p=1;p<copaste.length;p++){
                $('#canvas').children('.'+cla).eq(p).css('left',(event.clientX-(photox.canvasoffset[0])+copaste[p].deltaleft)+'px');
                $('#canvas').children('.'+cla).eq(p).css('top',(event.clientY-(photox.canvasoffset[1])+copaste[p].deltatop)+'px');
            }
            
            return;
        }
        if($('#canvas').children('.'+cla).attr('class').indexOf('mergershirt') !== -1){
            copaste=[];
            copaste[copaste.length] =  {elem:false,top:$('#canvas').children('.'+cla)[0].offsetTop,left:$('#canvas').children('.'+cla)[0].offsetLeft};
            $.each($('#canvas').children('.selected').children(),function(cpi,cpm){
                copaste[copaste.length] =  {elem:cpm,top:$(cpm)[0].offsetTop,left:$(cpm)[0].offsetLeft};
                
                copaste[copaste.length-1].deltatop = copaste[copaste.length-1].top - copaste[0].top;
                copaste[copaste.length-1].deltaleft = copaste[copaste.length-1].left - copaste[0].left;
            });
            
            $('#canvas').children('.'+cla).eq(0).css('left',event.clientX-(photox.canvasoffset[0])+'px');
            $('#canvas').children('.'+cla).eq(0).css('top',event.clientY-(photox.canvasoffset[1])+'px');
            
            
            for(var p=1;p<copaste.length;p++){
               $('#canvas').children('.'+cla).eq(0).children('.'+cla).eq(p-1).css('left',(event.clientX-(photox.canvasoffset[0])+copaste[p].deltaleft)+'px');
                $('#canvas').children('.'+cla).eq(0).children('.'+cla).eq(p-1).css('top',(event.clientY-(photox.canvasoffset[1])+copaste[p].deltatop)+'px');
            }
            
            return;
        }
        $('#canvas').children('.'+cla).eq(0).css('left',event.clientX-(photox.canvasoffset[0])+'px');
        $('#canvas').children('.'+cla).eq(0).css('top',event.clientY-(photox.canvasoffset[1])+'px');
    },
    snappaste:function(event){
        if(event === false){
            texter.blurs();
            texter.opertype('move');
            cutpaste.clipboard = false;
            cutpaste.snappastemode = false;
            return;
        }
        
        cutpaste.snappastemode = true;
        cutpaste.paste();
    },
    pasteid:function(elem){
        $.each($(elem).children(),function(ci,ce){
            $(ce).prop('id','text_'+texter.textcounter);
            texter.textcounter++;
            texter.addselections(ce);
            
            if($(ce).attr('class').indexOf('mergershirt')!==-1){
                cutpaste.pasteid(ce);
            }
        });
    }
};
var uredo = {
    moves:[],
    color:false,
    itsnew:true,
    newinitial:function(initial){
        if(uredo.cmove.type == 'colorize' && uredo.itsnew !== true){
            return;
        }
        uredo.cmove.elem[0][uredo.cmove.elem[0].length] = initial;
    },
    newendstate:function(endstate,color){
        if(uredo.cmove.type == 'colorize'){
            if(color != uredo.color){
                uredo.color = color;
                uredo.cmove.elem[1] = [];   
            }
            else{
                if(uredo.cmove.elem[1].length == uredo.cmove.elem[0].length)
                    return;
            }
        }
        uredo.cmove.elem[1][uredo.cmove.elem[1].length] = endstate;
    },
    newid:function(id){
        if(uredo.cmove.type == 'colorize' && uredo.itsnew !== true){
            return;
        }
        
        uredo.cmove.elem[2][uredo.cmove.elem[2].length] = id;
    },
    newmoveinst:function(name,multi){
        if(name == 'colorize'){
            if(uredo.color !== false){
                return;
            }
        }
        
        uredo.cmove = {};
        uredo.cmove.type = name;
        uredo.cmove.elem = [0,0,0];
        
        if(multi){
            uredo.cmove.elem[0] = [];
            uredo.cmove.elem[1] = [];
            uredo.cmove.elem[2] = [];       
        }
    },
    currentmove:0,
    registermove:function(move){
        if(move.type == 'colorize'){
            if(uredo.itsnew!== true){
                uredo.itsnew = uredo.color;
                return;
            }
            uredo.itsnew = uredo.color;
        }
        else{
            uredo.itsnew = true;
            uredo.color = false;
            
            if(move.type == 'blur'){
                return;
            }
        }
        move.state = 1;
        
        if(uredo.currentmove > 0){
            if(uredo.moves.length > uredo.currentmove){
                uredo.moves.splice(uredo.currentmove,(uredo.moves.length-uredo.currentmove));
            }
            
            if(!uredo.moves[uredo.currentmove-1].state){
                uredo.currentmove -=1;
            }
        }
        uredo.moves[uredo.currentmove] = move;
        uredo.currentmove++;
        
        if(uredo.currentmove > 30){
            uredo.collectgarbage();
        }
    },
    collectgarbage:function(){
        uredo.currentmove -= 23;
        uredo.moves.splice(0,23);
    },
    undo:function(){
        if(!uredo.moves.length){
            return;
        }
        
        if(!uredo.moves[uredo.currentmove-1].state){
            uredo.currentmove--;
            
            if((uredo.currentmove-1)<0){
                uredo.currentmove = 1;
                return;
            }
        }
        if(uredo.moves[uredo.currentmove-1].type == 'removal'){
            if(typeof uredo.moves[uredo.currentmove-1].elem[0] === 'object'){
                for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                    $('#canvas').append(uredo.moves[uredo.currentmove-1].elem[0][oi]);
                    
                    if(uredo.moves[uredo.currentmove-1].elem[0][oi].indexOf('selected') !== -1){
                        texter.textis($('#'+$('#canvas').children().eq($('#canvas').children().length-1).attr('id')),false);   
                    }
                }
            }
            else{
                $('#canvas').append(uredo.moves[uredo.currentmove-1].elem[0]);
                if(uredo.moves[uredo.currentmove-1].elem[0].indexOf('selected') !== -1){
                    texter.textis($('#'+$('#canvas').children().eq($('#canvas').children().length-1).attr('id')),false);   
                }
            }
        }
        else{
            if(typeof uredo.moves[uredo.currentmove-1].elem[0] === 'object'){
                if(uredo.moves[uredo.currentmove-1].elem[1][0]===false){
                    for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                        $('#'+uredo.moves[uredo.currentmove-1].elem[2][oi]).remove();
                    }
                }
                else
                for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                    $('#'+uredo.moves[uredo.currentmove-1].elem[2][oi]).replaceWith(uredo.moves[uredo.currentmove-1].elem[0][oi]);
                }
            }
            else{
                if(uredo.moves[uredo.currentmove-1].elem[1]===false){
                    $('#'+uredo.moves[uredo.currentmove-1].elem[2]).remove();
                }
                else
                    $('#'+uredo.moves[uredo.currentmove-1].elem[2]).replaceWith(uredo.moves[uredo.currentmove-1].elem[0]);
            }
        }
            
        uredo.moves[uredo.currentmove-1].state = 0;
    },
    cmove:[],
    redo:function(){
        if(!uredo.moves.length){
            return;
        }
        
        if(uredo.moves[uredo.currentmove-1].state){
            uredo.currentmove++;
            
            if((uredo.currentmove-1)==uredo.moves.length){
                uredo.currentmove--;
                return;
            }
        }
        if(uredo.moves[uredo.currentmove-1].type == 'removal'){
            if(typeof uredo.moves[uredo.currentmove-1].elem[0] === 'object'){
                for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                    $('#'+uredo.moves[uredo.currentmove-1].elem[2][oi]).remove();
                }
            }
            else{
                $('#'+uredo.moves[uredo.currentmove-1].elem[2]).remove();
            }
        }
        else{
            if(uredo.moves[uredo.currentmove-1].elem[1]===false){
                $('#canvas').append(uredo.moves[uredo.currentmove-1].elem[0]);
            }
            else{
                if(typeof uredo.moves[uredo.currentmove-1].elem[0] === 'object'){
                    if(uredo.moves[uredo.currentmove-1].elem[1][0]===false){
                        for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                            $('#canvas').append(uredo.moves[uredo.currentmove-1].elem[0][oi]);
                        }
                    }
                    else
                    for(var oi=0;oi<uredo.moves[uredo.currentmove-1].elem[0].length;oi++){
                        $('#'+uredo.moves[uredo.currentmove-1].elem[2][oi]).replaceWith(uredo.moves[uredo.currentmove-1].elem[1][oi]);
                    }
                }
                else{
                    if(uredo.moves[uredo.currentmove-1].elem[1]===false){
                        $('#canvas').append(uredo.moves[uredo.currentmove-1].elem[0]);
                    }
                    else{
                        $('#'+uredo.moves[uredo.currentmove-1].elem[2]).replaceWith(uredo.moves[uredo.currentmove-1].elem[1]);
                    }
                }
            }   
        }
            
        uredo.moves[uredo.currentmove-1].state = 1;
    }
};
var htmel = {
    blured:function(){
        if(texter.textermode != 2){
            return;
        }        
        $('#textshirt').blur();
        htmel.removelist();
    },
    listelem:['text input','numeric input','select','ordered list','unordered list','textarea','radio','checkbox','button','audio','video'],
    removelist:function(){
        $('#htmellist').remove();
    },
    selectelem:false,
    removelist_:function(event){
        setTimeout(function(){
            if(htmel.selectelem){
                htmel.selectelem = false;
                return;
            }
            
            $('#htmellist').remove();
        },350);
    },
    list:function(elem){
        htmel.removelist();
        if(texter.textermode != 2){
            return;
        }
        
        var hlist='';
        if(elem === false){
            for(var o=0;o<htmel.listelem.length;o++){
                hlist+='<span class="htmellist">'+htmel.listelem[o]+'</span>';
            }
            $('#textshirt').before('<div id="htmellist">'+hlist+'</div>');
        }
        else{
            var inp = $(elem).val();
            for(var o=0;o<htmel.listelem.length;o++){
                if(htmel.listelem[o].indexOf(inp) !== -1){
                    hlist+='<span class="htmellist">'+htmel.listelem[o]+'</span>';
                }
            }
            $(elem).before('<div id="htmellist">'+hlist+'</div>');
        }
        
        $('.htmellist').on('click',function(event){
            event.stopPropagation();
            
            htmel.selectelem = true;
            
            htmel.newelem(this);
        });
    },
    newelem:function(elem){
        texter.textcounter++;
        switch($(elem).html()){
            case 'text input':
                $('#canvas').append('<input type="text" class="textshirt htmel" value="text" name="text" id="text_'+texter.textcounter+'">');
            break;
            case 'numeric input':
                $('#canvas').append('<input type="number" class="textshirt htmel" value="1" name="textnumeric" id="text_'+texter.textcounter+'">');
            break;
            case 'textarea':
                $('#canvas').append('<textarea class="textshirt htmel" id="text_'+texter.textcounter+'" style="">textarea</textarea>');
            break;
            case 'radio':
                $('#canvas').append('<input type="radio" class="textshirt htmel" value="" name="radiotext" id="text_'+texter.textcounter+'">');
            break;
            case 'checkbox':
                $('#canvas').append('<input type="checkbox" class="textshirt htmel" value="" name="checkboxtext" id="text_'+texter.textcounter+'">');
            break;
            case 'button':
                $('#canvas').append('<input type="button" class="textshirt htmel" value="Button" name="button" id="text_'+texter.textcounter+'">');
            break;
            case 'audio':
                $('#canvas').append('<audio style="display:block;" class="textshirt htmel audio" id="text_'+texter.textcounter+'" src=""></audio>');
            break;
            case 'video':
                $('#canvas').append('<video class="textshirt htmel video" id="text_'+texter.textcounter+'" src=""></video>');
            break;
        }
        settings.placeelem('text_'+texter.textcounter);
        htmel.removelist();
    }
};
var paper = {
    papersizes:[],
    init:function(){
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A0'
        paper.papersizes[paper.papersizes.length-1].size = [2383.94, 3370.39];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A1'
        paper.papersizes[paper.papersizes.length-1].size = [1683.78, 2383.94];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A2'
        paper.papersizes[paper.papersizes.length-1].size = [1190.55, 1683.78];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A3'
        paper.papersizes[paper.papersizes.length-1].size = [841.89, 1190.55];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A4'
        paper.papersizes[paper.papersizes.length-1].size = [595.28, 841.89];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A5'
        paper.papersizes[paper.papersizes.length-1].size = [419.53, 595.28];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A6'
        paper.papersizes[paper.papersizes.length-1].size = [297.64, 419.53];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A7'
        paper.papersizes[paper.papersizes.length-1].size = [209.76, 297.64];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A8'
        paper.papersizes[paper.papersizes.length-1].size = [147.40, 209.76];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A9'
        paper.papersizes[paper.papersizes.length-1].size = [104.88, 147.40];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'A10'
        paper.papersizes[paper.papersizes.length-1].size = [73.70, 104.88];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'letter'
        paper.papersizes[paper.papersizes.length-1].size = [612.00, 792.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'half-letter'
        paper.papersizes[paper.papersizes.length-1].size = [396.00, 612.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'legal'
        paper.papersizes[paper.papersizes.length-1].size = [612.00, 1008.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'ledger'
        paper.papersizes[paper.papersizes.length-1].size = [1224.00, 792.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'tabloid'
        paper.papersizes[paper.papersizes.length-1].size = [792.00, 1224.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'executive'
        paper.papersizes[paper.papersizes.length-1].size = [521.86, 756.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'folio'
        paper.papersizes[paper.papersizes.length-1].size = [612.00, 936.00];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'commercial #10 envelope'
        paper.papersizes[paper.papersizes.length-1].size = [684, 297];
        paper.papersizes[paper.papersizes.length] = [];
        paper.papersizes[paper.papersizes.length-1].name = 'catalog #10 1/2 envelope'
        paper.papersizes[paper.papersizes.length-1].size = [648, 864];
    },
    papertype:false,
    box:function(){
        if(dialogbox.checkexists('Paper Sizes'))
            return;
            
        if(!paper.papersizes.length){
            paper.init();
        }
        var c = '';
        for(var o=0;o<paper.papersizes.length;o++){
            c+='<div id="addpaper_'+o+'" class="addpaper row">'+paper.papersizes[o].name+'</div>';
        }
        
        dialogbox.mbox(['Paper Sizes',c,''],'',function(){
           $('.addpaper').on('click',function(event){
                event.stopPropagation();
                
                paper.papertype = $(this).attr('id').split('_');
                
                paper.chooseres();
            }); 
        });
    },
    chooseres:function(){
        var c = '<div class="row bordered restype" id="72ppi">72 ppi</div><div class="row bordered restype" id="96ppi">96 ppi</div><div class="row bordered restype" id="150ppi">150 ppi</div><div class="row bordered restype" id="300ppi">300 ppi</div>';
        
        dialogbox.close();
        
        dialogbox.mbox(['Resolution Size',c,''],'',function(){
           $('.restype').on('click',function(event){
                event.stopPropagation();
                
                switch ($(this).attr('id')) {
                    case '72ppi':
                        paper.papertype[2] = paper.papersizes[paper.papertype[1]].size[0];
                        paper.papertype[3] = paper.papersizes[paper.papertype[1]].size[1];
                    break;
                    case '96ppi':
                        paper.papertype[2] = (96/72) * paper.papersizes[paper.papertype[1]].size[0];
                        paper.papertype[3] = (96/72) * paper.papersizes[paper.papertype[1]].size[1];
                    break;
                    case '150ppi':
                        paper.papertype[2] = (150/72) * paper.papersizes[paper.papertype[1]].size[0];
                        paper.papertype[3] = (150/72) * paper.papersizes[paper.papertype[1]].size[1];
                    break;
                    case '300ppi':
                        paper.papertype[2] = (300/72) * paper.papersizes[paper.papertype[1]].size[0];
                        paper.papertype[3] = (300/72) * paper.papersizes[paper.papertype[1]].size[1];
                    break;
                    default:
                        // code
                }
                polygon.rectangle_(paper.papertype[2],paper.papertype[3]);
                
                $('#text_'+texter.textcounter).addClass('papershirt_'+paper.papersizes[paper.papertype[1]].name+'_'+$(this).attr('id'));
                    
                $('#text_'+texter.textcounter).css('background','#ffffff');       
                $('#text_'+texter.textcounter).css('top','0px');
                
                $('#text_'+texter.textcounter).css('top',($('#canvas').height()/2)-(paper.papertype[3]/2)+'px');
                $('#text_'+texter.textcounter).css('left',($('#canvas').width()/2)-(paper.papertype[2]/2)+'px');
                
                settings.canvasadjustpaper([paper.papertype[2],paper.papertype[3]]);
                $('#text_'+texter.textcounter).css('top',($('#canvas').height()/2)-(paper.papertype[3]/2)+'px');
            }); 
        });
    }
};
var animate = {
    animation:function(){
        var ani ='';
        
        if(texter.focused !== false){
            ani+='';
        }
        else{
            animate.animations();
            return;
        }
        
        dialogbox.mbox(['Animation','','<span id="applyanimation">Apply</span>'],'extrawide',function(){
            $('#applyanimation').on('click',function(event){
                event.stopPropagation();
                
                transformer.animationrotation('#text_'+texter.focused,30);
                dialogbox.close();
            }); 
        });
    },
    animations:function(){
        dialogbox.mbox(['Animations','','<span id="applyanimation">apply</span>'],'extrawide',function(){
            $('#applyanimation').on('click',function(event){
                event.stopPropagation();
                
                transformer.animationrotation('#text_'+texter.focused,360);
                dialogbox.close();
            }); 
        });
    }
};
var pagesheets = {
    thecompleteset:function(){
        if(pagesheets.sheets.length == 1){
            return $('#canvaswrapper').html();
        }
        
        for (var i = 0; i < pagesheets.sheets.length; i++) {
            if(i!=pagesheets.currentsheet){
                $('#canvas').after(pagesheets.sheets[i].elem);
            }
        }
        
        var tcs = $('#canvaswrapper').html();
        $('.canvassheet').remove();
        return tcs;
    },
    sheets:[false],
    currentsheet:0,
    init_:function(reset){
        if(reset){
            $('#canvas').removeClass('canvsheet_'+pagesheets.currentsheet);
        }
        pagesheets.sheets = [false];
        pagesheets.currentsheet = 0;
        
        photox.savecanvasoffset(parseInt($('#canvas')[0].offsetLeft),parseInt($('#canvas')[0].offsetTop));
    },
    init:function(pro){
        if(pro){
            return;
        }
        pagesheets.init_(false);
        
        var csheet = 0;
        if(typeof $('.canvassheet').attr('class') !== 'undefined'){
            $.each($('.canvassheet'),function(ti,te){
                pagesheets.sheets[csheet] = {elem:$(te)[0].outerHTML,idx:parseInt($(te).attr('class').split('canvsheet_')[1].split(' ')[0])};
                $(te).remove();
                csheet++;
            });
            
            pagesheets.sheets[csheet] = {elem:$('#canvas')[0].outerHTML,idx:parseInt($('#canvas').attr('class').split('canvsheet_')[1].split(' ')[0])};
            pagesheets.currentsheet = parseInt($('#canvas').attr('class').split('canvsheet_')[1].split(' ')[0]);
            
            pagesheets.sheets.sort(function(a,b){
                return a.idx - b.idx;
            });
        }
        else{
            pagesheets.sheets[csheet] = {elem:$('#canvas')[0].outerHTML,idx:0};
        }
    },
    sheettodel:false,
    delsheet_:function(idx){
        if(pagesheets.sheets.length == 1){
            return;
        }
        
        if(pagesheets.currentsheet == idx){
            if(idx>0){
                pagesheets.loadsheet((idx-1));
            }
            else{
                pagesheets.loadsheet(idx+1);
            }
        }
        
        pagesheets.sheets.splice(idx,1);
        for(var i = idx; i < pagesheets.sheets.length;i++){
            if(pagesheets.currentsheet == pagesheets.sheets[i].idx){
                $('#canvas').removeClass('canvsheet_'+pagesheets.currentsheet).addClass('canvsheet_'+i);
                
                pagesheets.currentsheet = i;
                pagesheets.sheets[i].idx = i;
            }
            else{
                pagesheets.sheets[i].elem = pagesheets.sheets[i].elem.split('canvsheet_'+pagesheets.sheets[i].idx).join('canvsheet_'+i);
                pagesheets.sheets[i].idx = i;
            }
        }
        
        pagesheets.box();
    },
    delsheet:function(idx){
        dialogbox.close();
        if(dialogbox.checkexists('Delete Sheet'))
            return;
            
        dialogbox.mbox(['Delete Sheet','Please Confirm','<span id="back" style="float:left;margin-left:0px;">&larr;</span><span id="deletesheet" class="killryan">Delete</span>'],'',function(){
            $('#back').on('click',function(event){
                event.stopPropagation();
                dialogbox.close();
                pagesheets.box();
            });        
            $('#deletesheet').on('click',function(event){
                event.stopPropagation();
                dialogbox.close();
                pagesheets.delsheet_(idx);
            }); 
        });
    },
    box:function(){
        if(dialogbox.checkexists('Canvas Sheets'))
            return;
            
        var c='';
        for(var i=0;i<pagesheets.sheets.length;i++){
            c+='<span class="teedesc'+(pagesheets.currentsheet == i ? ' activesheet' : '' )+'" id="tee_'+i+'">'+i+'<span class="delshirt" id="delshirt_'+i+'">X</span></span>';
        }
        dialogbox.mbox(['Canvas Sheets',c,'<span id="newsheet">New Sheet</span>'],'',function(){
            $('.delshirt').on('click',function(event){
                event.stopPropagation();
                
                pagesheets.delsheet(parseInt($(this).attr('id').split('_')[1]));
            });
            $('#newsheet').on('click',function(event){
                event.stopPropagation();
                pagesheets.newsheet();
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
            });
            $('.teedesc').on('click',function(event){
                event.stopPropagation();
                
                $('.regiformfoc').removeClass('regiformfoc').blur();
                
                if($(this).attr('class').indexOf('activesheet') !== -1){
                    dialogbox.close();
                    return;
                }
                
                pagesheets.loadsheet($(this).attr('id').split('_')[1]);
                dialogbox.close();
            }); 
        });
    },
    navsheet:function(){
        if(pagesheets.sheets.length == 1){
            return;
        }
        
        var idx = pagesheets.currentsheet+1;
        if(idx == pagesheets.sheets.length){
            idx=0;
        }
        pagesheets.loadsheet(idx);
    },
    loadsheet:function(idx){
        idx = parseInt(idx);
        $('#canvas').prop('id','canvsheet_'+pagesheets.currentsheet).addClass('canvassheet canvsheet_'+pagesheets.currentsheet);
        pagesheets.sheets[pagesheets.currentsheet].elem = $('#canvsheet_'+pagesheets.currentsheet)[0].outerHTML;
        $('#canvsheet_'+pagesheets.currentsheet).remove();
        
        pagesheets.currentsheet = idx;
        $('#canvaswrapper').append(pagesheets.sheets[pagesheets.currentsheet].elem);
        $('#canvsheet_'+pagesheets.currentsheet).prop('id','canvas').removeClass('canvassheet');
        
        photox.savecanvasoffset(parseInt($('#canvas')[0].offsetLeft),parseInt($('#canvas')[0].offsetTop));
        settings.boxpreference[0] = false;
        settings.initcanvas();
        
        $('#adjustcolor').spectrum('set', $('#canvas').css('background') == '' ? '#000000' : $('#canvas').css('background') );
    },
    newsheet:function(){
        var coute = $('#canvas')[0].style.cssText;
        
        $('#canvas').prop('id','canvsheet_'+pagesheets.currentsheet).addClass('canvassheet canvsheet_'+pagesheets.currentsheet);
        pagesheets.sheets[pagesheets.currentsheet].elem = $('#canvsheet_'+pagesheets.currentsheet)[0].outerHTML;
        $('#canvsheet_'+pagesheets.currentsheet).remove();
        
        pagesheets.currentsheet = pagesheets.sheets.length;
        if($('#canvaswrapper').children().length){
            $('#canvaswrapper').children().eq(0).before('<div id="canvas" style="'+coute+'" class="canvsheet_'+pagesheets.currentsheet+'"></div>');
        }
        else
            $('#canvaswrapper').append('<div id="canvas" style="'+coute+'" class="canvsheet_'+pagesheets.currentsheet+'"></div>');
            
        pagesheets.sheets[pagesheets.currentsheet] = {idx:pagesheets.currentsheet};  
        $('#canvas').html('');
        
        photox.savecanvasoffset(parseInt($('#canvas')[0].offsetLeft),parseInt($('#canvas')[0].offsetTop));
    }
};
var settings = {
    placeelem:function(id){
        switch(settings.defaultelemplacing[1]){
            case 0:
                if(photox.canvasoffset[1] != 0 || photox.canvasoffset[1] != 0){
                    $('#'+id).css('top',(0-photox.canvasoffset[1])+'px');
                    $('#'+id).css('left',(0-photox.canvasoffset[0])+'px');
                }
            break;
            case 1:
                $('#'+id).css('top',((settings.boxpreference[1]/2) - (photox.canvasoffset[1]) -($('#'+id).height()/2))+'px');
                $('#'+id).css('left',((settings.boxpreference[0]/2) - (photox.canvasoffset[0]) -($('#'+id).width()/2))+'px');
            break;
            case 2:
                $('#'+id).css('top',(settings.boxpreference[1]- (photox.canvasoffset[1]) - $('#'+id).height()-35)+'px');
                $('#'+id).css('left',(settings.boxpreference[0] - (photox.canvasoffset[0]) - $('#'+id).width()-10)+'px');
            break;
        }
    },
    boxaction:function(){
        switch(settings.boxtype){
            case 0:
                $('#restoredefault').on('click',function(event){
                    event.stopPropagation();
                    
                    $('#canvaswidth').val(1345);
                    $('#canvasheight').val(676);
                    settings.canvaspreview(1);
                    
                });
                $('#lorati').on('click',function(event){
                    event.stopPropagation();
                    
                    if($('#lorati').prop('checked')){
                        settings.canvasratio[1] = true;
                        return
                    }
                    settings.canvasratio[1] = false;
                });
                 $('#loratilab').on('click',function(event){
                    event.stopPropagation();
                    
                    if($('#lorati').prop('checked')){
                        $('#lorati').prop('checked',false);
                        settings.canvasratio[1] = false;
                        return
                    }
                    $('#lorati').prop('checked',true);
                    settings.canvasratio[1] = true;
                });
                $('#canvaswidth').on('change',function(event){
                    settings.canvaspreview(0);
                });
                $('#canvasheight').on('change',function(event){
                    settings.canvaspreview(1);
                });
                $('#canvaswidth').on('keyup',function(event){
                    event.stopPropagation();
                    
                    if(event.which == 13){
                        settings.applycanvassettings();
                    }
                });
                $('#canvasheight').on('keyup',function(event){
                    event.stopPropagation();
                    
                    if(event.which == 13){
                        settings.applycanvassettings();
                    }
                });
                
                $('#savesett').on('click',function(event){
                    event.stopPropagation();
                    settings.applycanvassettings();
                });
            break;
            case 1:
                $('#defepo').val(settings.defaultelemplacing[0]);
                $('#defepo').on('change',function(event){
                    event.stopPropagation();
                    settings.defaultpos($(this).val());
                });
                $('#defplace').val(settings.defaultelemplacing[1]);
                $('#defplace').on('change',function(event){
                    event.stopPropagation();
                    settings.defaultplace($(this).val());
                });
                
                $('#tmbab').on('change',function(event){
                    event.stopPropagation();  
                    settings.elementsett[0] = parseInt($(this).val());
                });
                $('#tmbab').on('keyup',function(event){
                    event.stopPropagation();  
                    if(event.which == 13){
                        dialogbox.close();
                    }
                });
            break;
        }
        $('.settchooser').on('click',function(event){
            event.stopPropagation();
            
            dialogbox.close();
            
            settings.boxtype = parseInt($(this).attr('id').split('_')[0]);
            settings.box();
        });
    },
    defaultelemplacing:[0,1],
    defaultcss:false,
    defaultplace:function(posval){
        settings.defaultelemplacing[1] = parseInt(posval);
    },
    defaultpos:function(posval){
        posval = parseInt(posval);
        
        if(!settings.defaultcss){
            settings.defaultcss = true;
            settings.elementsett[1] = document.createElement('style'); 
            settings.elementsett[1].type = "text/css";
            document.getElementsByTagName("head")[0].appendChild(settings.elementsett[1]);
            settings.elementsett[2] = settings.elementsett[1].sheet;            
        }
        settings.defaultelemplacing[0] = posval;
        var stylerule;
        if(posval == 0){
            stylerule = '.textshirt{position:absolute;}';
        }
        else if(posval == 1){
            stylerule = '.textshirt{position:fixed;}';
        }
        else{
            stylerule = '.textshirt{position:relative;}';
        }
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
    },
    elementsett:[1,false,false],
    initcanvas:function(){
        if(settings.boxpreference[0] !== false){
            return;
        }
        settings.boxpreference[0] = $('#canvas').width();
        settings.boxpreference[1] = $('#canvas').height();
    },
    resetcanvas:function(){
        settings.boxpreference[0] = $('#canvas').width();
        settings.boxpreference[1] = $('#canvas').height();
    },
    boxpreference:[false,false,717,360.365,0,0,0],
    canvasratio:[(1345/676),true,(676/1345),[(717/360.365),(360.365/717)]],
    applycanvassettings:function(){
        $('#canvas').css('width',settings.boxpreference[0]);
        $('#canvas').css('height',settings.boxpreference[1]);
        
        $('.regiformfoc').removeClass('regiformfoc');
        dialogbox.close();
    },
    canvasadjustpaper:function(wihe){
        if(settings.boxpreference[1] < wihe[1]){
            settings.boxpreference[1] = wihe[1]+300;
            settings.boxpreference[0] = (settings.canvasratio[0] * settings.boxpreference[1]);
            
            $('#canvas').css('width',settings.boxpreference[0]);
            $('#canvas').css('height',settings.boxpreference[1]);
        }
    },
    canvaspreview:function(wihe){
        if(wihe){
            settings.boxpreference[1] = $('#canvasheight').val();
            
            if(settings.canvasratio[1]){
                settings.boxpreference[0] = (settings.canvasratio[0] * settings.boxpreference[1]);
                $('#canvaswidth').val(settings.boxpreference[0]);   
            }
        }
        else{
            settings.boxpreference[0] = $('#canvaswidth').val();
            
            if(settings.canvasratio[1]){
                settings.boxpreference[1] = (settings.canvasratio[2] * settings.boxpreference[0]);
                $('#canvasheight').val(settings.boxpreference[1]);
            }
        }
        
        settings.canvasratio[3] = [settings.boxpreference[0]/settings.boxpreference[1],settings.boxpreference[1]/settings.boxpreference[0]];
        
        if(settings.boxpreference[0] >= 1345 && settings.boxpreference[1] >= 676){
            settings.boxpreference[2] = 717 * (1345/settings.boxpreference[0]);
            settings.boxpreference[3] = settings.canvasratio[3][1] * settings.boxpreference[2];
        }
        else if(settings.boxpreference[0] <= 1345 && settings.boxpreference[1] <= 676){
            settings.boxpreference[2] = 717 * (settings.boxpreference[0]/1345);
            settings.boxpreference[3] = settings.canvasratio[3][1] * settings.boxpreference[2];
        }
        else{
            //114
            settings.boxpreference[4] = [];
            if(settings.boxpreference[0] > 1345){
                settings.boxpreference[4][0] = Math.abs(settings.boxpreference[0]-1345);
                settings.boxpreference[4][1] = Math.abs(settings.boxpreference[1]-676);
                
                
                settings.boxpreference[3] = 360.365 * (settings.boxpreference[1]/676);
                settings.boxpreference[2] = settings.canvasratio[3][0] * settings.boxpreference[3];
            }
            else{
                settings.boxpreference[2] = 717 * (settings.boxpreference[0]/1345);
                settings.boxpreference[3] = settings.canvasratio[3][1] * settings.boxpreference[2];
            }
        }
        
        $('#canv').css('width',settings.boxpreference[2]);
        $('#canv').css('height',settings.boxpreference[3]);
    },
    boxtype:0,
    box:function(){
        switch(settings.boxtype){
            case 0:
                if(dialogbox.checkexists('Canvas Settings'))
                    return;
                
                settings.initcanvas();
                var canvassett = '<div class="row" style="margin-top: -20px;text-align: center;margin-bottom: 30px;"><input style="margin-right:15px;" type="number" value="'+settings.boxpreference[0]+'" id="canvaswidth"><span>X</span><input type="number" style="margin-left:15px;" value="'+settings.boxpreference[1]+'" id="canvasheight"><input type="checkbox" checked="checked" id="lorati" style="height: 12px;margin-right: 7px;margin-left: 10px;"><span id="loratilab">lock ratio</span></div>';
                canvassett+='<div id="canvwrap"><div id="canv"></div></div>';
                canvassett+='<div id="restoredefault">Restore Default</div>';
                
                dialogbox.mbox(['Canvas Settings',canvassett,'<span id="0_sett" class="settchooser active">Canvas</span><span id="1_sett" class="settchooser">Elements</span><span id="savesett">Save</span>'],'extrawide',function(){
                    settings.boxaction();
                });
            break;
            case 1:
                if(dialogbox.checkexists('Other Settings'))
                    return;
                
                var canvassett = '<div class="row" style="margin-top:-20px;text-align: center;margin-bottom: 30px;">';
                canvassett+='<span style="width:40%;display:inline-block;float: left;text-align:right;height: 23px;line-height: 23px;">default element position:</span> <span style="width:40%;display:inline-block;float: left;"><select id="defepo" style="width: 165px;"><option value="0">absolute</option><option value="1">fixed</option><option value="2">relative</option></select></span>';
                canvassett+='</div>';
                canvassett+= '<div class="row" style="text-align: center;margin-bottom: 30px;">';
                canvassett+='<span style="width:40%;display:inline-block;float: left;text-align:right;height: 23px;line-height: 23px;">default element placement:</span> <span style="width:40%;display:inline-block;float: left;"><select id="defplace" style="width: 165px;"><option value="0">top left</option><option value="1">center</option><option value="2">bottom right</option></select></span>';
                canvassett+='</div>';
                canvassett+= '<div class="row" style="text-align: center;margin-bottom: 30px;">';
                canvassett+='<span style="width:40%;display:inline-block;float: left;text-align:right;height: 23px;line-height: 23px;">text move by arrow by:</span> <span style="width:40%;display:inline-block;float: left;"><input style="height: 23px;line-height: 23px;" type="number" id="tmbab" value="'+settings.elementsett[0]+'" min="1">&nbsp;&nbsp;&nbsp;px</span>';
                canvassett+='</div>';
                
                dialogbox.mbox(['Other Settings',canvassett,'<span id="0_sett" class="settchooser">Canvas</span><span id="1_sett" class="settchooser active">Elements</span>'],'extrawide',function(){
                    settings.boxaction();
                });
            break;
        }
    }
};
var charts = {
    charttype:0,
    charttype_:function(){
        charts.charttype = parseInt($('#seltrans').val());
        dialogbox.close();
        charts.box();
    },
    charttypetext:function(){
        var seltrans = '<select id="seltrans">';
        seltrans+='<option value="0" '+(charts.charttype == 0 ? 'selected="selected"' : '')+'>pie</option>';
        seltrans+='<option value="1" '+(charts.charttype == 1 ? 'selected="selected"' : '')+'>bar</option>';
        seltrans+='<option value="2" '+(charts.charttype == 2 ? 'selected="selected"' : '')+'>graph</option>';
        seltrans+='</select>';
        
        return seltrans;
    },
    typetext:function(){
        var boxtitle = '';
        switch (charts.charttype) {
            case 0:
                boxtitle = 'Pie Chart'
            break;
            case 1:
                boxtitle = 'Bar Chart'
            break;
            case 2:
                boxtitle = 'Graph Chart'
            break;
            default:
        }
        return boxtitle;
    },
    chartdata:[{xval:'January',yval:29},{xval:'February',yval:23},{xval:'March',yval:18},{xval:'April',yval:22},{xval:'May',yval:11},{xval:'June',yval:9},{xval:'July',yval:6},{xval:'August',yval:5},{xval:'September',yval:0},{xval:'October',yval:5},{xval:'November',yval:8},{xval:'December',yval:4}],
    chartsaux:[],
    initchart:false,
    initchart_:function(){
        if(charts.initchart){
            return;
        }
        
        switch (charts.charttype) {
            case 0:
                charts.chartsaux[0] = $('#canvas').width() * 0.3;//pie diameter
                charts.chartsaux[1] = [($('#canvas').width() * 0.35), ( ($('#canvas').height() - charts.chartsaux[0]) /2) ];//pie left,top offset
                charts.chartsaux[2] = charts.chartsaux[1] + (charts.chartsaux[1]/2);//pie center
                charts.chartsaux[3] = (charts.chartsaux[0]/2);//pie r  
            break;
            case 1:
            case 2:
                charts.chartsaux[0] = $('#canvas').width() * 0.7;//chart width
                charts.chartsaux[1] = $('#canvas').height() * 0.7;//chart height
                charts.chartsaux[2] = $('#canvas').width() * 0.15;//x axis left offset
                charts.chartsaux[3] = $('#canvas').height() * 0.85;//x axis top offset
            break;
        }
        
        charts.chartsaux[4] = [0,0,0,0,0,0,0,0,0,0];//y axis min,max
    },
    create:function(){
        charts.initchart_();
        
        charts.chartdata = [];
        $.each($('#chartdata').children(),function(di,de){
            if($(de).children('.chartxinput').attr('class').indexOf('filled') === -1 || $(de).children('.chartyinput').attr('class').indexOf('filled') === -1){
                
            }
            else{
                charts.chartdata[charts.chartdata.length] = {xval:$(de).children('.chartxinput').val(),yval:parseInt($(de).children('.chartyinput').val())};
                if(di == 0){
                    charts.chartsaux[4][0] = charts.chartdata[charts.chartdata.length-1].yval;
                    charts.chartsaux[4][1] = charts.chartdata[charts.chartdata.length-1].yval;
                }
                else{
                    charts.chartsaux[4][0] = Math.min(charts.chartsaux[4][0],charts.chartdata[charts.chartdata.length-1].yval);
                    charts.chartsaux[4][1] = Math.max(charts.chartsaux[4][1],charts.chartdata[charts.chartdata.length-1].yval);
                }
                
                charts.chartsaux[4][8] += charts.chartdata[charts.chartdata.length-1].yval;
            }
        });
        charts.mapdata();
        
        dialogbox.close();
    },
    rotatingpieshirt:function(){
        texter.textis($(charts.chartsaux[9])[0],true);
        transformer.animationrotation(charts.chartsaux[9],360);
    },
    mapdata:function(){
        texter.textermode = 0;
        switch (charts.charttype) {
            case 0:
                texter.newcircle(charts.chartsaux[0]);
                $('#text_'+texter.textcounter).css('left',charts.chartsaux[1][0]+'px');
                $('#text_'+texter.textcounter).css('top',charts.chartsaux[1][1]+'px');
                charts.chartsaux[4][6] = [];
                charts.chartsaux[4][6][0] = texter.textcounter;
                
                charts.chartsaux[5] = '#text_'+texter.textcounter;
                charts.chartsaux[6] = 0;
                charts.chartsaux[4][7] = (charts.chartsaux[3]/10);
                
                texter.textcounter++;
                texter.horizline(charts.chartsaux[3]);
                $('#text_'+texter.textcounter).css('left',charts.chartsaux[1][0]+'px');
                $('#text_'+texter.textcounter).css('top',charts.chartsaux[1][1]+charts.chartsaux[3]+'px');
                
                for(var i=0;i<charts.chartdata.length;i++){
                    texter.blurs();
                    texter.textis($(charts.chartsaux[5]),false);
                    transformer.rotate_(0);
                    
                    charts.chartdata[i].pieportion = charts.chartdata[i].yval/charts.chartsaux[4][8];
                    
                    texter.textcounter++;
                    texter.horizline(charts.chartsaux[3]);
                    $('#text_'+texter.textcounter).css('left',charts.chartsaux[1][0]+'px');
                    $('#text_'+texter.textcounter).css('top',charts.chartsaux[1][1]+charts.chartsaux[3]+'px');
                    
                    charts.chartsaux[7] = '#text_'+texter.textcounter;
                    texter.add(charts.chartdata[i].xval);
                    $('#text_'+texter.textcounter)[0].style.cssText = 'background:transparent;';
                    $('#text_'+texter.textcounter).css('left',charts.chartsaux[1][0]+charts.chartsaux[4][7]+'px');
                    $('#text_'+texter.textcounter).css('top',charts.chartsaux[1][1]+charts.chartsaux[3]+'px').addClass('piexlabel');
                    charts.chartsaux[8] = '#text_'+texter.textcounter;
                    
                    texter.blurs();
                    $(charts.chartsaux[7]).addClass('selected');
                    $(charts.chartsaux[8]).addClass('selected');
                    merger.merge();
                    
                    texter.blurs();
                    $(charts.chartsaux[7]).parent().addClass('selected');
                    $(charts.chartsaux[5]).addClass('selected');
                    merger.merge();
                    
                    charts.chartsaux[6] = charts.chartsaux[6]+(charts.chartdata[i].pieportion * 360);
                    
                    transformer.rotate_(charts.chartsaux[6]);
                    merger.unmerge();
                }
                
                texter.blurs();
                texter.textis($(charts.chartsaux[5]),false);
                transformer.rotate_(0);
                
                texter.blurs();
                for(var i=charts.chartsaux[4][6][0];i<=texter.textcounter;i++){
                    if(typeof $('#text_'+i).attr('id') !== 'undefined')
                        $('#text_'+i).addClass('selected');
                }
                merger.merge();
                $(texter.focusedid).addClass(charts.chartclassname());
                charts.chartsaux[9] = '#text_'+texter.focused;
                $(texter.focusedid).find('.lineshirt').eq(0).remove();
                texter.blurs();
                
                charts.chartselemdata_();
                //charts.rotatingpieshirt();
            break;
            case 1:
            case 2:
                texter.textcounter++;
                texter.verline(charts.chartsaux[1]);
                $('#text_'+texter.textcounter).css('top',($('#canvas').height() * 0.15 )+'px');
                $('#text_'+texter.textcounter).css('left',($('#canvas').width() * 0.15 )+'px').addClass('chartelem chartsyaxis');
                
                charts.chartsaux[4][7] = [];
                charts.chartsaux[4][7][0] = texter.textcounter;
                
                texter.textcounter++;
                texter.horizline(charts.chartsaux[0]);
                $('#text_'+texter.textcounter).css('left',($('#canvas').width() * 0.15 )+'px');
                $('#text_'+texter.textcounter).css('top',($('#canvas').height() * 0.85 )+'px').addClass('chartelem chartsxaxis');
                
                
                charts.chartsaux[5] = charts.chartsaux[4][0] != 0 ? 40 : 0;
                charts.chartsaux[4][2] = charts.chartsaux[4][1] - charts.chartsaux[4][0];//y axis data range
                
                    charts.chartsaux[4][3] = (charts.chartsaux[1]-charts.chartsaux[5])/charts.chartsaux[4][2];//yval label 1px height
                    charts.chartsaux[4][4] = [];
                    charts.chartsaux[4][4][0] = Math.ceil(charts.chartsaux[4][2]/ charts.chartdata.length);//y axis label incremental value
                    charts.chartsaux[4][4][1] = Math.round(charts.chartsaux[4][2] / charts.chartsaux[4][4][0]);//incremental y axis value
                    charts.chartsaux[4][5] = [];
                    for(var i=0;i<charts.chartdata.length;i++){
                        charts.chartsaux[4][5][i] = [];
                        charts.chartsaux[4][5][i].label = charts.chartsaux[4][0]+(i*charts.chartsaux[4][4][0]);
                        charts.chartsaux[4][5][i].bottommarg = ((charts.chartsaux[4][5][i].label-charts.chartsaux[4][0])*charts.chartsaux[4][3])+charts.chartsaux[5];
                    }
                    
                    for(var i=0;i<charts.chartsaux[4][5].length;i++){
                        texter.add(charts.chartsaux[4][5][i].label);
                        $('#text_'+texter.textcounter).css('top',(charts.chartsaux[3]-charts.chartsaux[4][5][i].bottommarg)+'px');
                        $('#text_'+texter.textcounter).css('left',(charts.chartsaux[2]-$('#text_'+texter.textcounter).width()-5)+'px');
                    }
                
                charts.chartsaux[6] = charts.chartsaux[0] / charts.chartdata.length;//width of x value label
                
                for(var i=0;i<charts.chartdata.length;i++){
                    charts.chartsaux[7] = (charts.chartsaux[2]+(i*charts.chartsaux[6]));//left offset of y value point
                    texter.add(charts.chartdata[i].xval);
                    $('#text_'+texter.textcounter).addClass('chartelem chartxlabel');
                    $('#text_'+texter.textcounter).css('width',charts.chartsaux[6]+'px');
                    $('#text_'+texter.textcounter).css('text-align','center');
                    $('#text_'+texter.textcounter).css('top',charts.chartsaux[3]+'px');
                    $('#text_'+texter.textcounter).css('left',charts.chartsaux[7]+'px');
                    
                    
                    charts.chartsaux[8] = ((charts.chartsaux[4][3]*(charts.chartdata[i].yval - charts.chartsaux[4][0]))+charts.chartsaux[5]);
                    if(charts.charttype == 1){
                        polygon.rectangle_(charts.chartsaux[6],charts.chartsaux[8]);
                        $('#text_'+texter.textcounter).addClass('chartelem chartelem_barelem');
                        $('#text_'+texter.textcounter).css('top',(charts.chartsaux[3]-$('#text_'+texter.textcounter).height())+'px');
                        $('#text_'+texter.textcounter).css('left',charts.chartsaux[7]+'px');   
                    }
                    else{
                        texter.newcircle(1);
                        $('#text_'+texter.textcounter).addClass('chartelem chartelem_graphpoint');
                        $('#text_'+texter.textcounter).css('top', (charts.chartsaux[3]-charts.chartsaux[8]) +'px');
                        $('#text_'+texter.textcounter).css('left',charts.chartsaux[7]+(charts.chartsaux[6]/2)+'px');   
                    }
                }
                charts.chartsaux[4][7][1] = texter.textcounter;//end of chart elem type 1
                
                texter.blurs();
                for(var i=charts.chartsaux[4][7][0];i<=charts.chartsaux[4][7][1];i++){
                    $('#text_'+i).addClass('selected');
                }
                if(charts.charttype == 2){
                    charts.linegraph();
                }
                merger.merge();
                
                $(texter.focusedid).addClass(charts.chartclassname());
                texter.blurs();
                charts.chartselemdata_();
            break;
            default:
        }
    },
    chartpref:[true],
    linegraph:function(){
        var poin = [];
        var linegraph = [];
        if(charts.chartpref[0]){
            $.each($('.selected.chartelem_graphpoint'),function(ci,ce){
                poin[poin.length] = [];
                poin[poin.length-1].elem = ce;
                poin[poin.length-1].id = $(ce).attr('id').split('_')[1];
                poin[poin.length-1].topoff = $(ce)[0].offsetTop;
                poin[poin.length-1].leftoff = $(ce)[0].offsetLeft;
            });
            
            poin.sort(function(a,b){
                return a.id - b.id;
            });
            
            for(var i=0;i<poin.length-1;i++){
                texter.textcounter++;
                linegraph[linegraph.length] = [];
                linegraph[linegraph.length-1].deltax = poin[i+1].leftoff-poin[i].leftoff;
                linegraph[linegraph.length-1].deltay = poin[i+1].topoff-poin[i].topoff;
                linegraph[linegraph.length-1].mi = Math.sqrt(Math.pow(Math.abs(linegraph[linegraph.length-1].deltax),2)+Math.pow(Math.abs(linegraph[linegraph.length-1].deltay),2));
                linegraph[linegraph.length-1].halfmi =(0.5 *linegraph[linegraph.length-1].mi);
                texter.horizline(linegraph[linegraph.length-1].mi);
                
                $('#text_'+texter.textcounter).addClass('chartelem_linegraph');
                texter.textis($('#text_'+texter.textcounter),false);
                $('#text_'+texter.textcounter).css('left',poin[i].leftoff+'px');
                $('#text_'+texter.textcounter).css('top',poin[i].topoff+'px');
                linegraph[linegraph.length-1].ro = Math.atan(linegraph[linegraph.length-1].deltay/linegraph[linegraph.length-1].deltax)*57.295779513;
                linegraph[linegraph.length-1].ro1 = (90 - linegraph[linegraph.length-1].ro);
                
                linegraph[linegraph.length-1].deltaxx = linegraph[linegraph.length-1].halfmi - (Math.sin(linegraph[linegraph.length-1].ro1/57.295779513) * linegraph[linegraph.length-1].halfmi);
                linegraph[linegraph.length-1].deltaxx = (poin[i].leftoff-(linegraph[linegraph.length-1].deltaxx))+2;
                
                transformer.rotate_(linegraph[linegraph.length-1].ro);
                
                $('#text_'+texter.textcounter).css('left',linegraph[linegraph.length-1].deltaxx+'px');
                $('#text_'+texter.textcounter).css('top',poin[i].topoff+(linegraph[linegraph.length-1].deltay/2)+'px');
            }
        }
        for(var i=charts.chartsaux[4][7][1];i<=texter.textcounter;i++){
            $('#text_'+i).addClass('selected');
        }
    },
    chartclassname:function(){
        var boxtitle = '';
        switch (charts.charttype) {
            case 0:
                boxtitle = 'Pie_Chart'
            break;
            case 1:
                boxtitle = 'Bar_Chart'
            break;
            case 2:
                boxtitle = 'Graph_Chart'
            break;
            default:
        }
        return boxtitle;
    },
    addinputrow:function(elem){
        var c ='';
        c+='<div class="row"><input type="text" value="x" name="x" class="chartxinput">';
        c+='<input type="text" value="y" name="y" class="chartyinput">';
        c+='<input type="button" value="+" class="addchartdata"><input type="button" value="-" class="minchartdata"></div>';
        
        $(elem).parent().after(c);
    },
    mininputrow:function(elem){
        if($('#chartdata').children().length==1){
            return;
        }
        $(elem).parent().remove();
    },
    chartselemdata_:function(){
        var yvaldata = 'chartdata_';
        for(var o=0;o<charts.chartdata.length;o++){
            if(o>0){
                yvaldata+='_';
            }
            yvaldata+=charts.chartdata[o].yval;
        }
        if($('#text_'+texter.textcounter).attr('class').indexOf('Pie_Chart') !==-1){
            $('#text_'+texter.textcounter).find('.piexlabel').eq(0).addClass(yvaldata);
        }
        else{
            $('#text_'+texter.textcounter).find('.chartxlabel').eq(0).addClass(yvaldata);
        }
    },
    chartselemdata:function(){
        charts.chartdata = [];
        
        if($(texter.focusedid).attr('class').indexOf('Pie_Chart') !==-1){
            $.each($(texter.focusedid).find('.piexlabel'),function(i,e){
                charts.chartdata[charts.chartdata.length] = [];
                charts.chartdata[charts.chartdata.length-1].xval = $(e).html();
            });            
            
            var yvaldata = $(texter.focusedid).find('.piexlabel').eq(0).attr('class').split('chartdata_')[1].split(' ')[0];
            yvaldata = yvaldata.split('_');
            for(var i=0;i<yvaldata.length;i++){
                charts.chartdata[i].yval = yvaldata[i];
            }
        }
        else{
            $.each($(texter.focusedid).find('.chartxlabel'),function(i,e){
                charts.chartdata[charts.chartdata.length] = [];
                charts.chartdata[charts.chartdata.length-1].xval = $(e).html();
            });
            
            var yvaldata = $(texter.focusedid).find('.chartxlabel').eq(0).attr('class').split('chartdata_')[1].split(' ')[0];
            yvaldata = yvaldata.split('_');
            for(var i=0;i<yvaldata.length;i++){
                charts.chartdata[i].yval = yvaldata[i];
            }
        }
    },
    box:function(){
        if(dialogbox.checkexists(charts.typetext()))
            return;
            
        var c = '<div id="chartdata">';
        
        if(texter.focused!==false){
            if($(texter.focusedid).attr('class').indexOf('mergershirt')!== -1 && $(texter.focusedid).attr('class').indexOf('_Chart')!==-1){
                charts.chartselemdata();
            }
        }
        
        if(!charts.chartdata.length){
            c+='<div class="row"><input type="text" value="x" name="x" class="chartxinput">';
            c+='<input type="text" value="y" name="y" class="chartyinput">';
            c+='<input type="button" value="+" class="addchartdata"><input type="button" value="-" class="minchartdata"></div>';            
        }
        else{
            for(var i=0;i<charts.chartdata.length;i++){
                c+='<div class="row"><input type="text" value="'+charts.chartdata[i].xval+'" name="x" class="chartxinput filled">';
                c+='<input type="text" value="'+charts.chartdata[i].yval+'" name="y" class="chartyinput filled">';
                c+='<input type="button" value="+" class="addchartdata"><input type="button" value="-" class="minchartdata"></div>';            
            }
        }
        
        c+='</div>';
        
        dialogbox.mbox([charts.typetext(),c,'<span id="createchart">Create Chart</span><span id="resetdata">Reset Data</span>'+charts.charttypetext()],'',function(){
           $('#resetdata').on('click',function(event){
                event.stopPropagation();
                
                charts.chartdata = [];
                charts.box();
            });
            $('#chartdata').delegate('.addchartdata','click',function(){
                charts.addinputrow(this);
            });
            $('#chartdata').delegate('.minchartdata','click',function(){
                charts.mininputrow(this);
            });
            
            $('#seltrans').on('change',function(event){
                charts.charttype_();
            });
            
            $('#createchart').on('click',function(event){
                event.stopPropagation();
                $(this).html('Processing...');
                charts.create();
            }); 
        });
    }
};
var transformer = {
    scale_:function(elem){
        if(elem === false){
            elem = '#text_'+texter.focused;
        }
        
        switch(transformer.size[0]){
            case 0:
                $(elem).css('width',transformer.size[3]+'px');
            break;
            case 1:
            case 2:
                $(elem).css('width',transformer.size[3]+'px');
                $(elem).css('height',transformer.size[3]+'px');
            break;
            case 3:
            case 99:
                $(elem).css('width',transformer.size[1]+'px');
                $(elem).css('height',transformer.size[2]+'px');
                if($(elem)[0].style.cssText.indexOf('font-size') !== -1){
                    $(elem).css('font-size',transformer.size[4][2][2]*parseInt($(elem).css('font-size').split('px')[0])+'px');
                    $(elem).css('line-height',$(elem).height()+'px');
                }
            break;
            case 4:
                $(elem).css('width',transformer.size[1]+'px');
                $(elem).children().css('width',transformer.size[1]+'px');
                $(elem).css('height',transformer.size[2]+'px');
                $(elem).children().css('height',transformer.size[2]+'px');
            break;
            case 5:
                $(elem).css('width',transformer.size[1]+'px');
                $(elem).css('height',transformer.size[2]+'px');
                
                if($(elem).attr('class').indexOf('oripos_') !== -1){
                    var cnamex = $(elem)[0].className.split(' '),cname='',oripos='';
                    for(var ci=0;ci<cnamex.length;ci++){
                        if(cname!= ''){
                            cname+= ' ';
                        }
                        if(cnamex[ci].indexOf('oripos_') === -1){
                            cname+=cnamex[ci];
                        }
                        else{
                            oripos=cnamex[ci].split('oripos_')[1].split(' ')[0];
                            oripos = oripos.split('_');
                        }
                    }
                    $(elem)[0].className = cname;
                    oripos[0] = ($(elem)[0].offsetTop+(transformer.size[2]/2));
                    oripos[1] = ($(elem)[0].offsetLeft+(transformer.size[1]/2));
                    $(elem).addClass('oripos_'+oripos[0]+'_'+oripos[1]+'_'+transformer.size[1]+'_'+transformer.size[2]);
                }
                
                if($(elem).attr('class').indexOf('mergershirt') !== -1){
                    transformer.scalemerged_($(elem)[0]);
                }
                transformer.size[0] = 5;
            break;
        }
    },
    mergedpos:function(elem,pos){
        if(pos){
            return $(elem).parent()[0].offsetTop + (transformer.size[4][2][3] * ($(elem)[0].offsetTop - $(elem).parent()[0].offsetTop));
        }
        return $(elem).parent()[0].offsetLeft + (transformer.size[4][2][2] * ($(elem)[0].offsetLeft - $(elem).parent()[0].offsetLeft));
    },
    scalemerged_:function(elem){
        var texttype;
        $.each($(elem).children(),function(ei,ey){
            if($(ey).attr('class').indexOf('mergershirt') !== -1){
                transformer.size[0] = 5;
                transformer.size[1] = transformer.size[4][2][2] * $(ey).width();
                transformer.size[2] = transformer.size[4][2][3] * $(ey).height();
                
                var leto = [$(ey)[0].offsetLeft,$(ey)[0].offsetTop,transformer.mergedpos(ey,0),transformer.mergedpos(ey,1)];
                
                leto[4] = leto[2] - leto[0];
                leto[5] = leto[3] - leto[1];
                
                $(ey).css('top', leto[3]+'px');
                $(ey).css('left', leto[2]+'px');
                
                $.each($(ey).children(),function(eiy,eyy){
                    $(eyy).css('left', $(eyy)[0].offsetLeft + leto[4] +'px');
                    $(eyy).css('top', $(eyy)[0].offsetTop + leto[5] +'px');
                });
                
                transformer.scale_(ey);
            }
            else{
                transformer.size[0] = 99;
                texttype = $(ey).attr('class');
                for(var i=0;i<transformer.texttype__.length;i++){
                    if(texttype.indexOf(transformer.texttype__[i]) !== -1){
                        transformer.size[0] = i;
                        break;
                    }
                }
                
                switch (transformer.size[0]) {
                    case 0:
                    case 1:
                    case 2:
                        transformer.size[1] = $(ey).width();
                        transformer.size[2] = $(ey).height();
                        transformer.size[3] = transformer.size[0] == 0 ? Math.max(transformer.size[1],transformer.size[2]) : transformer.size[1];
                        
                        transformer.size[3] = transformer.size[4][2][2] * transformer.size[3];
                        
                        $(ey).css('top', transformer.mergedpos(ey,1)+'px');
                        $(ey).css('left', transformer.mergedpos(ey,0)+'px');
                    break;
                    case 3:
                    case 4:
                    case 99:
                        transformer.size[1] = transformer.size[4][2][2] * $(ey).width();
                        transformer.size[2] = transformer.size[4][2][3] * $(ey).height();
                        
                        $(ey).css('top', transformer.mergedpos(ey,1)+'px');
                        $(ey).css('left', transformer.mergedpos(ey,0)+'px');
                    break;
                }
                transformer.scale_(ey);   
            }
        });
    },
    size:[],
    kratio:true,
    scaler:function(idx){
        if(!(transformer.size[0] == 3 || transformer.size[0] == 4 || transformer.size[0]==5 || transformer.size[0]==99)){
            transformer.size[3] = $('#size').val();
            transformer.scale_(false);
            return;
        }
        
        if(!transformer.kratio){
            if(idx == 1){
                transformer.size[1] = $('#widths').val();
                
                transformer.size[4][2][2] = transformer.size[1]/transformer.size[4][2][0];
                transformer.size[4][2][3] = transformer.size[2]/transformer.size[4][2][1];
                
                transformer.size[4][2][0] = transformer.size[1];
                transformer.size[4][2][1] = transformer.size[2];
            }
            else{
                transformer.size[2] = $('#heights').val();
                
                transformer.size[4][2][2] = transformer.size[1]/transformer.size[4][2][0];
                transformer.size[4][2][3] = transformer.size[2]/transformer.size[4][2][1];
                
                transformer.size[4][2][0] = transformer.size[1];
                transformer.size[4][2][1] = transformer.size[2];
            }
            transformer.scale_(false);
            return;
        }
        if(idx == 1){
            transformer.size[1] = $('#widths').val();
            transformer.size[2] = transformer.size[4][1] * transformer.size[1];
            $('#heights').val(transformer.size[2]);
            
            transformer.size[4][2][2] = transformer.size[1]/transformer.size[4][2][0];
            transformer.size[4][2][3] = transformer.size[2]/transformer.size[4][2][1];
            
            transformer.size[4][2][0] = transformer.size[1];
            transformer.size[4][2][1] = transformer.size[2];
        }
        else{
            transformer.size[2] = $('#heights').val();
            transformer.size[1] = transformer.size[4][0] * transformer.size[2];
            $('#widths').val(transformer.size[1]);
            
            transformer.size[4][2][2] = transformer.size[1]/transformer.size[4][2][0];
            transformer.size[4][2][3] = transformer.size[2]/transformer.size[4][2][1];
            
            transformer.size[4][2][0] = transformer.size[1];
            transformer.size[4][2][1] = transformer.size[2];
        }
        transformer.scale_(false);
    },
    texttype__:['lineshirt','circleshirt','squareshirt','rectshirt','imageshirt','mergershirt'],
    scale:function(){
        if(texter.focused === false){
            return;
        }
        var texttype = $(texter.focusedid).attr('class');
        var texttype_=0;
        transformer.size = [];
        
        if(texter.selectmerged){
            transformer.size[0] = 5;
        }
        else{
            transformer.size[0] = 99;
            for(var i=0;i<transformer.texttype__.length;i++){
                if(texttype.indexOf(transformer.texttype__[i]) !== -1){
                    transformer.size[0] = i;
                    break;
                }
            }   
        }
        
        switch(transformer.size[0]){
            case 0:
            case 1:
            case 2:
                if(dialogbox.checkexists('Scale'))
                    return;
                    
                transformer.size[1] = $(texter.focusedid).width();
                transformer.size[2] = $(texter.focusedid).height();
                transformer.size[3] = transformer.size[0] == 0 ? Math.max(transformer.size[1],transformer.size[2]) : transformer.size[1];
                transformer.size[4] = [transformer.size[3],1];
                
                dialogbox.mbox(['Scale','<input type="number" value="'+transformer.size[3]+'" name="size" id="size">',transformer.seltranstext()],'',function(){
                    $('#size').focus().addClass('regiformfoc');
                    $('#size').on('keyup',function(event){
                        event.stopPropagation();
                        
                        if(event.which == 13){
                            $(this).blur().removeClass('regiformfoc');
                            dialogbox.close();
                            return;
                        }
                        
                        transformer.scaler(2);
                    }); 
                    
                    $('#seltrans').on('change',function(event){
                        event.stopPropagation();
                        transformer.seltrans_($(this).val());
                    });
                });
            break;
            case 3:
            case 4:
            case 5:
                if($(texter.focusedid).attr('class').indexOf('oripos_') !== -1){
                    var cnamex = $(texter.focusedid)[0].className.split(' '),cname='',oripos='';
                    for(var ci=0;ci<cnamex.length;ci++){
                        if(cname!= ''){
                            cname+= ' ';
                        }
                        if(cnamex[ci].indexOf('oripos_') === -1){
                            cname+=cnamex[ci];
                        }
                        else{
                            oripos=cnamex[ci].split('oripos_')[1].split(' ')[0];
                            oripos = oripos.split('_');
                        }
                    }
                    
                    $(texter.focusedid).css('width',oripos[2]+'px');
                    $(texter.focusedid).css('height',oripos[3]+'px');
                }
            case 99:
                if(dialogbox.checkexists('Scale'))
                    return;
                    
                transformer.size[1] = $(texter.focusedid).width();
                transformer.size[2] = $(texter.focusedid).height();
                transformer.size[4] = [(transformer.size[1]/transformer.size[2]),(transformer.size[2]/transformer.size[1]),[transformer.size[1],transformer.size[2]]];
                
                dialogbox.mbox(['Scale','<div class="row"><input type="number" value="'+transformer.size[1]+'" name="width" id="widths" style="padding-left:7px;margin-left:10px;"><input style="float:right;margin-left:10px;padding-left:7px;" type="number" value="'+transformer.size[2]+'" name="height" id="heights"></div><div class="row"><input type="checkbox" checked="checked" id="kratio" style="float:left;margin-left:10px;"><span style="float:left;display:inline-block;line-height: 34px;" id="kratiolab">Keep Ratio</span></div>',transformer.seltranstext()],'',function(){
                    if(transformer.kratio){
                        $('#kratio').prop('checked',true);
                    }
                    else{
                        $('#kratio').prop('checked',false);
                    }
                    
                    $('#kratiolab').on('click',function(event){
                        event.stopPropagation();
                        
                        if($(this).prev().prop('checked')){
                            $(this).prev().prop('checked',false);
                            transformer.kratio = false;
                        }
                        else{
                            $(this).prev().prop('checked',true);
                            transformer.kratio = true;
                        }
                    });
                    
                    $('#widths').focus().addClass('regiformfoc');
                    $('#widths').on('keyup',function(event){
                        event.stopPropagation();
                        
                        if(event.which == 17 || event.ctrlKey || $.inArray(event.which,[8,37,39,46,35,36]) !== -1 ){
                            return;
                        }
                        if(event.which == 13){
                            $(this).blur().removeClass('regiformfoc');
                            dialogbox.close();
                            return;
                        }
                        
                        transformer.scaler(1);
                    });
                    $('#heights').on('keyup',function(event){
                        event.stopPropagation();
                        
                        if(event.which == 17 || event.ctrlKey || $.inArray(event.which,[8,37,39,46,35,36]) !== -1 ){
                            return;
                        }
                        
                        if(event.which == 13){
                            $(this).blur().removeClass('regiformfoc');
                            dialogbox.close();
                            return;
                        }
                        
                        transformer.scaler(2);
                    }); 
                    
                    $('#seltrans').on('change',function(event){
                        event.stopPropagation();
                        transformer.seltrans_($(this).val());
                    });
                });
            break;
        }
        $('#transform').on('click',function(event){
            event.stopPropagation();
            
           transformer.scale_(false);
        });
    },
    transtype:0,
    seltrans_:function(sel){
        dialogbox.close();
        if(sel === false){
        }
        else{
            transformer.transtype = parseInt(sel);
        }
        
        switch(transformer.transtype){
            case 0:
                transformer.rotate();
            break;
            case 1:
                transformer.scale();
            break;
            case 2:
                transformer.centerthings();
            break;
        }
    },
    centerthings:function(){
        dialogbox.mbox(['Center Element Relative To:','<input type="text" value="element id" name="element id" id="centerrelat">',transformer.seltranstext()],'',function(){
            $('#centerrelat').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 13){
                    transformer.centerthings_($(this).val());
                }
            });
            
            $('#seltrans').on('change',function(event){
                event.stopPropagation();
                transformer.seltrans_($(this).val());
            });
        });
    },
    centerthings_:function(elemid){
        if(texter.focused == false){
            return;
        }
        
        var centerof = [];
        if(elemid == 'screen'){
            centerof[0] = ((settings.boxpreference[0]/2) - (photox.canvasoffset[0]) -($(texter.focusedid).width()/2));
            centerof[1] = ((settings.boxpreference[1]/2) - (photox.canvasoffset[1]) -($(texter.focusedid).height()/2));
        }
        else if(elemid == '#canvas'){
            centerof[0] = ((settings.boxpreference[0]/2) - (photox.canvasoffset[0])  -($(texter.focusedid).width()/2));
            centerof[1] = ((settings.boxpreference[1]/2) - (photox.canvasoffset[1]) -($(texter.focusedid).height()/2));
        }
        else{
            centerof[0] = (($(elemid)[0].offsetLeft+($(elemid).width()/2)) - ($(texter.focusedid).width()/2));
            centerof[1] = (($(elemid)[0].offsetTop+($(elemid).height()/2)) - ($(texter.focusedid).height()/2));
        }
        
        centerof[2] = [$(texter.focusedid)[0].offsetLeft,$(texter.focusedid)[0].offsetTop];
        
        $(texter.focusedid).css('top',centerof[1]+'px');
        $(texter.focusedid).css('left',centerof[0]+'px');
        
        if($(texter.focusedid).attr('class').indexOf('mergershirt') !== -1){
            centerof[3] = [centerof[0]- centerof[2][0] , centerof[1]- centerof[2][1]];
            
            transformer.centerthingsmerged($(texter.focusedid)[0],elemid,centerof);
        }
        
        dialogbox.close();
    },
    centerthingsmerged:function(merged,elemid,centerof){
        $.each($(merged).children(),function(mi,me){
            $(me).css('top', $(me)[0].offsetTop + centerof[3][1]+'px');
            $(me).css('left', $(me)[0].offsetLeft + centerof[3][0]+'px');
            
            if($(me).attr('class').indexOf('mergershirt') !== -1){
                transformer.centerthingsmerged(me,elemid,centerof);
            }
        });
    },
    seltranstext:function(){
        var seltrans = '<select id="seltrans">';
        seltrans+='<option value="0" '+(transformer.transtype == 0 ? 'selected="selected"' : '')+'>rotate</option>';
        seltrans+='<option value="1" '+(transformer.transtype == 1 ? 'selected="selected"' : '')+'>scale</option>';
        seltrans+='<option value="2" '+(transformer.transtype == 2 ? 'selected="selected"' : '')+'>center</option>';
        seltrans+='</select>';
        
        return seltrans;
    },
    rotate:function(){
        if(dialogbox.checkexists('Rotation'))
            return;
            
        dialogbox.mbox(['Rotation','<input type="number" value="0" id="rotate">',transformer.seltranstext()],'',function(){
            $('#seltrans').on('change',function(event){
                event.stopPropagation();
                transformer.seltrans_($(this).val());
            });
            
            $('#rotate').focus().addClass('regiformfoc');
            $('#rotate').on('keyup',function(event){
                event.stopPropagation();
                
                if(event.which == 17 || event.ctrlKey || $.inArray(event.which,[8,37,39,46,35,36]) !== -1 ){
                    return;
                }
                if(event.which == 13 || event.which == 27){
                    $(this).blur().removeClass('regiformfoc');
                    dialogbox.close();
                    return;
                }
                    
                    transformer.rotate_($('#rotate').val());
            }); 
        });
    },
    stopanimationflag:false,
    animationcount:0,
    startanimation:function(){
        $('#canvas').addClass('animation');
        transformer.animationcount++;
    },
    stopanimation:function(){
        transformer.stopanimationflag = true;
        $('#canvas').removeClass('animation');
    },
    animationstopped:function(){
        transformer.animationcount--;
        if(!transformer.animationcount){
            transformer.stopanimationflag = false;
        }
    },
    animationrotation:function(elemid,ro){
        transformer.animationaux[0] = 0;
        transformer.animationaux[1] = elemid;
        transformer.animationaux[2] = ro;
        texter.blurs();
        texter.textis($(elemid)[0],true);
        
        var elem = $(texter.focusedid)[0];
        $(elem).css('display','none');
        transformer.animationaux[3] = $(elem)[0].outerHTML;
        $(transformer.animationaux[1]).css('display','block');
        
        transformer.startanimation();
        requestAnimationFrame(transformer.animationrotation_);
    },
    animationaux:[],
    animationrotation_:function(start){
        transformer.animationaux[4] = start;
        
        requestAnimationFrame(transformer.animationrotation__);
    },
    animationrotation__:function(times){
        if($('#canvas').attr('class').indexOf('animation') === -1){
            transformer.animationstopped();
            return;
        }
        
        transformer.animationaux[2]--;
        if(transformer.animationaux[2]<0)
            return;
            
        $(transformer.animationaux[1]).replaceWith(transformer.animationaux[3]);
        $(transformer.animationaux[1]).css('display','block');
        texter.textis_($(transformer.animationaux[1])[0],true);
            
        transformer.animationaux[0]++;
        transformer.rotate_(transformer.animationaux[0]);
        
        requestAnimationFrame(transformer.animationrotation__);
    },
    rotate_:function(ro){
        var elem = $(texter.focusedid);
        if(texter.selectmerged){
            var mclass = $(elem)[0].className;
            
            $(elem).addClass('collateralshirt');
            var aux = [];
            aux[0] = $(elem)[0].offsetTop;
            aux[1] = $(elem)[0].offsetLeft;
            aux[2] = $(elem).width();
            aux[3] = $(elem).height();
            aux[4] = [aux[1]+(aux[2]/2),(aux[0]+(aux[3]/2))];
            
            if($(elem).attr('class').indexOf('rotatingshirt_') !== -1){
                aux[0] = $(elem).attr('class').split('oripos_')[1].split(' ')[0];
                aux[0] = aux[0].split('_');
                
                aux[1] = parseFloat(aux[0][1]);
                aux[2] = parseFloat(aux[0][2]);
                aux[3] = parseFloat(aux[0][3]);
                aux[0] = parseFloat(aux[0][0]);
                aux[4] = [aux[1]+(aux[2]/2),(aux[0]+(aux[3]/2))];
            }
            
            var rox = [ro,(ro/57.295779513)];
            transformer.rotatemerged(elem,aux,rox);
            var mid = $(elem).attr('id');
            $(elem).remove();
            
            texter.blurs();
            $('.rotatingshirt').addClass('selected').removeClass('rotatingshirt');
            
            merger.merge();
            
            $('#text_'+texter.textcounter).prop('id',mid).addClass('rotatingshirt_'+rox[0]+'_'+aux[4][0]+'_'+aux[4][1]);
            $('#'+mid).addClass('oripos_'+aux[0]+'_'+aux[1]+'_'+aux[2]+'_'+aux[3]);
            $('#'+mid).addClass(mclass);
            
            $('.collateralshirt').remove();
            return;
        }
        
        if(texter.selections.length > 1){
            for(var i=0;i<texter.selections.length;i++){
                $(texter.selections[i]).css('-webkit-transform','rotate('+ro+'deg)');
                $(texter.selections[i]).css('-moz-transform','rotate('+ro+'deg)');
                $(texter.selections[i]).css('-o-transform','rotate('+ro+'deg)');
            }
            return;
        }
        
        $(elem).css('-webkit-transform','rotate('+ro+'deg)');
        $(elem).css('-moz-transform','rotate('+ro+'deg)');
        $(elem).css('-o-transform','rotate('+ro+'deg)');
    },
    rotatemerged:function(elem,aux,rox){
        var t;
        $.each($(elem).children(),function(ei,ey){
            $(ey).addClass('rotatingshirt');
            t = transformer.rotatemerged_(aux,ey,rox);
            if(t !== false){
                $('#canvas').append($(ey)[0].outerHTML);
            }
            $(ey).remove();
        });
        $(elem).remove();
    },
    rotatemerged__:function(elem,aux,rox){
        var a = [];
        $.each($(elem).children(),function(ei,ey){
            a[a.length] = $(ey).attr('id');
            $(ey).addClass('rotatingshirt_ rotatingshirt');
            
            $(ey).css('top', ($(ey)[0].offsetTop+aux[5])+'px');
            $(ey).css('left', ($(ey)[0].offsetLeft+aux[6])+'px');
            
            $('#canvas').append($(ey)[0].outerHTML);
            $(ey).remove();
            
            a[a.length-1] = $('#'+a[a.length-1])[0];
        });
        
        for(var o=0;o<a.length;o++){
            var p = transformer.rotatemerged_(aux,a[o],rox);
            if(p){
                $('#canvas').append($(a[o])[0].outerHTML);
            }
            $(a[o]).remove();
        }
    },
    rotatemerged_:function(aux,elem,ro){
        aux[5] = $(elem)[0].offsetTop;
        aux[6] = $(elem)[0].offsetLeft;
        aux[7] = $(elem).width();
        aux[8] = $(elem).height();
        aux[9] = [aux[6]+(aux[7]/2),(aux[5]+(aux[8]/2))];//middle point
        
        aux[10] = [aux[9][0] - aux[4][0],aux[9][1] - aux[4][1]];//middle point coord relative to parent elem middle point
        
        aux[11] = [(Math.cos(ro[1]) * aux[10][0]) - (Math.sin(ro[1]) * aux[10][1]), (Math.sin(ro[1]) * aux[10][0]) + (Math.cos(ro[1]) * aux[10][1])];//middle point after rotation
        
        aux[12] = [(aux[4][0]+aux[11][0]),(aux[4][1]+aux[11][1])];//elem's middle coord un-relative to parent
        aux[13] = [aux[12][0]- (aux[7]/2), aux[12][1]- (aux[8]/2)];//elems left top offset after rotation un-relative to parent
        
        if($(elem).attr('class').indexOf('mergershirt') !== -1){
            var mid = $(elem).attr('id');
            var mclass = $(elem)[0].className;
            
            $(elem).addClass('collateralshirt');
            
            $(elem).css('left',aux[13][0]+'px');
            $(elem).css('top',aux[13][1]+'px');
            
            var aux_ = [];
            
            if($(elem).attr('class').indexOf('rotatingshirt_') !== -1){
                aux[11] = [(Math.cos(ro[1]) * aux[10][0]) - (Math.sin(ro[1]) * aux[10][1]), (Math.sin(ro[1]) * aux[10][0]) + (Math.cos(ro[1]) * aux[10][1])];//middle point coord after rotation

                aux[12] = [(aux[4][0]+aux[11][0]),(aux[4][1]+aux[11][1])];//elem's middle coord un-relative to parent
                aux[13] = [aux[12][0]- (aux[7]/2), aux[12][1]- (aux[8]/2)];//elems left top offset after rotation un-relative to parent
                
                aux_[0] = aux[13][1];
                aux_[1] = aux[13][0];
                aux_[2] = aux[7];
                aux_[3] = aux[8];
                aux_[4] = [aux_[1]+(aux_[2]/2),(aux_[0]+(aux_[3]/2))];
                
                aux_[5] = aux_[0]-aux[5];
                aux_[6] = aux_[1]-aux[6];
                
                aux[4] = $(elem).attr('class').split('rotatingshirt_')[1];
                aux[4] = aux[4].split(' ')[0];
                aux[4] = aux[4].split('_');
                aux[4] = [parseFloat(aux[4][1]),parseFloat(aux[4][2]),parseFloat(aux[4][0])];
                ro = [ro[0],ro[1],parseFloat(ro[0])+aux[4][2],false];
                ro[3] = ro[2]/57.295779513;
                
                transformer.rotatemerged__(elem,aux_,ro);
            }
            else{
                aux_[0] = aux[13][1];
                aux_[1] = aux[13][0];
                aux_[2] = aux[7];
                aux_[3] = aux[8];
                aux_[4] = [aux_[1]+(aux_[2]/2),(aux_[0]+(aux_[3]/2))];
                
                aux_[5] = aux_[0]-aux[5];
                aux_[6] = aux_[1]-aux[6];
                transformer.rotatemerged__(elem,aux_,ro);
            }
            
            $(elem).remove();
            
            texter.blurs();
            $('.rotatingshirt_').addClass('selected').removeClass('rotatingshirt_');
            
            merger.merge();
            
            $('#text_'+texter.textcounter).prop('id',mid).addClass('rotatingshirt rotatingshirt_'+ro[0]+'_'+aux[4][0]+'_'+aux[4][1]);
            $('#'+mid).addClass('oripos_'+aux[5]+'_'+aux[6]+'_'+aux[7]+'_'+aux[8]);
            $('#'+mid).addClass(mclass);
            
            return true;
        }
        
        if(typeof ro[3] !== 'undefined'){
            ro[0] = ro[2];
        }
        
        $(elem).css('-webkit-transform','rotate('+ro[0]+'deg)');
        $(elem).css('-moz-transform','rotate('+ro[0]+'deg)');
        $(elem).css('-o-transform','rotate('+ro[0]+'deg)');
        
        $(elem).css('left',aux[13][0]+'px');
        $(elem).css('top',aux[13][1]+'px');
        
        return true;
    }
};
var cloner = {
    clone:function(){
        if(dialogbox.checkexists('Clone'))
            return;
            
        dialogbox.mbox(['Clone','<input type="number" value="1" id="clonenum">','<span id="cloneit">Clone</span>'],'',function(){
            $('#clonenum').focus().addClass('regiformfoc');
            $('#clonenum').on('keyup',function(event){
                if(event.which != 13)
                    return;
                    
                $(this).blur().removeClass('regiformfoc');
                cloner.clone_();
                dialogbox.close();
            });
            $('#cloneit').on('click',function(event){
                event.stopPropagation();
                
                $('.regiformfoc').blur().removeClass('regiformfoc');
                cloner.clone_();
                dialogbox.close();
            }); 
        });
    },
    clone_:function(){
        if(texter.selectmerged){
            cloner.clonemerged();
            return;
        }
        
        if(texter.selections.length>1){
            cloner.clone__();
            return;
        }
        
        uredo.newmoveinst('clone',1);
        
        
        var classis_;
        
        if($(texter.focusedid).attr('class').indexOf('htmel')!==-1){
            classis_ = $(texter.focusedid)[0].outerHTML.split('id="text_');
            classis_[1] = classis_[1].split('"');
            classis_[1].splice(0,1);
            classis_[1] = classis_[1].join('"');
            
            var clown = '';
            for(var p=0;p<$('#clonenum').val();p++){
                texter.textcounter++;
                clown = classis_[0]+'id="text_'+texter.textcounter+'"'+classis_[1];
                $('#canvas').append(clown);    
                
                uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $('#text_'+texter.textcounter)[0].outerHTML;
                uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
                uredo.cmove.elem[2][uredo.cmove.elem[2].length] = 'text_'+texter.textcounter;
            }
        }
        else{
            var csste = $(texter.focusedid)[0].style.cssText;
            var classis = $(texter.focusedid).attr('class').split(' ');
            classis_ = 'textshirt ';
            for(var o=0;o<classis.length;o++){
                if(classis[o]=='textshirt' || classis[o]=='' || classis[o]=='selected' || classis[o]=='selectmuch' || classis[o] == 'selectall'){
                    
                }
                else{
                    classis_+= ' '+classis[o];
                }
            }
            
            
            for(var p=0;p<$('#clonenum').val();p++){
                texter.textcounter++;
                $('#canvas').append('<div id="text_'+texter.textcounter+'" class="'+classis_+'" style="'+csste+'">'+$(texter.focusedid).html()+'</div>');
                if(classis_.indexOf('mergershirt')!==-1){
                    cutpaste.pasteid($('#text_'+texter.textcounter)[0]);
                }
                
                uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $('#text_'+texter.textcounter)[0].outerHTML;
                uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
                uredo.cmove.elem[2][uredo.cmove.elem[2].length] = 'text_'+texter.textcounter;
            }
        }
        uredo.registermove(uredo.cmove);
    },
    clonemerged:function(){
        var csste,classis,classis_;
        
        csste = $(texter.focusedid)[0].style.cssText;
        classis = $(texter.focusedid).attr('class').split(' ');
        classis_ = 'textshirt ';
        for(var t=0;t<classis.length;t++){
            if(classis[t]=='textshirt' || classis[t]=='' || classis[t]=='selected' || classis[t]=='selectmuch' || classis[t] == 'selectall'){
                
            }
            else{
                classis_+= ' '+classis[t];
            }
        }
        
        uredo.newmoveinst('clone',1);
        
        var tempcount
        for(var p=0;p<$('#clonenum').val();p++){
            texter.textcounter++;
            tempcount = texter.textcounter;
            $('#canvas').append('<div id="text_'+texter.textcounter+'" class="'+classis_+'" style="'+csste+'"></div>');
            
            uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $('#text_'+texter.textcounter)[0].outerHTML;
            uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
            uredo.cmove.elem[2][uredo.cmove.elem[2].length] = 'text_'+texter.textcounter;
            
            $.each($(texter.focusedid).children(),function(fi,fe){
                cloner.clonemerged_(fe,tempcount);
            });
        }
        uredo.registermove(uredo.cmove);
    },
    clonemerged_:function(chi,tempcount){
        var csste,classis,classis_;
        
        csste = $(chi)[0].style.cssText;
        classis = $(chi).attr('class').split(' ');
        classis_ = 'textshirt ';
        for(var t=0;t<classis.length;t++){
            if(classis[t]=='textshirt' || classis[t]=='' || classis[t]=='selected' || classis[t]=='selectmuch' || classis[t] == 'selectall'){
                
            }
            else{
                classis_+= ' '+classis[t];
            }
        }
        texter.textcounter++;
        $('#text_'+tempcount).append('<div id="text_'+texter.textcounter+'" class="'+classis_+'" style="'+csste+'">'+$(chi).html()+'</div>');
        if(classis_.indexOf('mergershirt')!==-1){
            cutpaste.pasteid($('#text_'+texter.textcounter)[0]);
        }
        
        uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $('#text_'+texter.textcounter)[0].outerHTML;
        uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
        uredo.cmove.elem[2][uredo.cmove.elem[2].length] = 'text_'+texter.textcounter;
    },
    clone__:function(){
        var csste,classis,classis_;
        
        if(texter.selectmerged){
            cloner.clonemerged();
            return;
        }
        
        uredo.newmoveinst('clone',1);
        for(var o=0;o<texter.selections.length;o++){
            csste = $(texter.selections[o])[0].style.cssText;
            classis = $(texter.selections[o]).attr('class').split(' ');
            classis_ = 'textshirt ';
            for(var t=0;t<classis.length;t++){
                if(classis[t]=='textshirt' || classis[t]=='' || classis[t]=='selected' || classis[t]=='selectmuch' || classis[t] == 'selectall'){
                    
                }
                else{
                    classis_+= ' '+classis[t];
                }
            }
            
            for(var p=0;p<$('#clonenum').val();p++){
                texter.textcounter++;
                $('#canvas').append('<div id="text_'+texter.textcounter+'" class="'+classis_+'" style="'+csste+'">'+$(texter.selections[o]).html()+'</div>');    
                
                uredo.cmove.elem[0][uredo.cmove.elem[0].length] = $('#text_'+texter.textcounter)[0].outerHTML;
                uredo.cmove.elem[1][uredo.cmove.elem[1].length] = false;
                uredo.cmove.elem[2][uredo.cmove.elem[2].length] = 'text_'+texter.textcounter;
            }
            
            uredo.registermove(uredo.cmove);
        }
    }
};
var merger = {
    topmost:[],
    topmost_:0,
    bottommost:0,
    leftmost:[],
    leftmost_:0,
    rightmost:0,
    unmerge:function(){
        $.each($('#canvas').children('.mergershirt.selected'),function(mis,mes){
            merger.leftmost_ = $(mes)[0];
            var themerge = [];
            $.each($(merger.leftmost_).children(),function(mi,me){
                themerge[themerge.length] = me;
            });
            
            themerge.sort(function(a,b){
                return parseInt($(b).attr('id').split('_')[1]) - parseInt($(a).attr('id').split('_')[1]);
            });
            if(photox.canvasoffset[0] != 0 || photox.canvasoffset[1]!=0){
                for(var i=0;i<themerge.length;i++){
                    $(merger.leftmost_).after($(themerge[i])[0].outerHTML);
                    if($(merger.leftmost_).next().attr('class').indexOf('mergershirt')!== -1){
                        
                    }
                    else{
                        $(merger.leftmost_).next().css('top',($(merger.leftmost_).next()[0].offsetTop - photox.canvasoffset[1]) +'px');
                        $(merger.leftmost_).next().css('left',($(merger.leftmost_).next()[0].offsetLeft - photox.canvasoffset[0])+'px');
                    }
                }
            }
            else{
                for(var i=0;i<themerge.length;i++){
                    $(merger.leftmost_).after($(themerge[i])[0].outerHTML);
                }            
            }
            $(merger.leftmost_).remove();
        });
        texter.blurs();
        texter.opertype('merge');
    },
    selectmerged:function(elem){
        if(typeof $(elem).attr('class') !== 'undefined' && $(elem).attr('class').indexOf('lineshirt') === -1){
            $.each($(elem).children(),function(mi,me){
                merger.selectmerged(me);
            });    
        }
        
        texter.addselections(elem);
        texter.textis(elem,false);
        
        if($('#textofthemover').html() == 'merge'){
            texter.opertype('merge');
        }
    },
    merge:function(){
        if($('.selected').length == 1){
            merger.leftmost_ = $('.selected').parent();
            if($(merger.leftmost_).attr('id') == 'canvas'){
                return;
            }
            
            $('.selected').removeClass('selected');
            
            merger.selectmerged(merger.leftmost_);
            return;
        }
        
        texter.textcounter++;
        $('#canvas').append('<div id="text_'+texter.textcounter+'" class="textshirt mergershirt"></div>');
        
        merger.topmost    = [];
        merger.leftmost   = [];
        merger.mergedwidth = [];
        merger.mergedheight = [];
        
        if(texter.selectallmode){
            if(photox.canvasoffset[0] != 0 || photox.canvasoffset[1]!=0){
                $.each($('.selectall'),function(si,se){
                    if($(se).parent().attr('id') != 'canvas'){
                        
                    }
                    else{
                        merger.topmost[merger.topmost.length] = $(se)[0].offsetTop + parseInt($('#canvas')[0].offsetTop);
                        merger.leftmost[merger.leftmost.length] = $(se)[0].offsetLeft + parseInt($('#canvas')[0].offsetLeft);
                        merger.mergedwidth[merger.mergedwidth.length] = $(se).width();
                        merger.mergedheight[merger.mergedheight.length] = $(se).height();
                                            
                        $(se).css('top',merger.topmost[merger.topmost.length-1]+'px');
                        $(se).css('left',merger.leftmost[merger.leftmost.length-1]+'px');
                        
                        $('#text_'+texter.textcounter).append($(se)[0].outerHTML);
                        $(se).remove();   
                    }
                });           
            }
            else{
                $.each($('.selectall'),function(si,se){
                    if($(se).parent().attr('id') != 'canvas'){
                        
                    }
                    else{
                        merger.topmost[merger.topmost.length] = $(se)[0].offsetTop;
                        merger.leftmost[merger.leftmost.length] = $(se)[0].offsetLeft;
                        merger.mergedwidth[merger.mergedwidth.length] = $(se).width();
                        merger.mergedheight[merger.mergedheight.length] = $(se).height();
                        
                        $('#text_'+texter.textcounter).append($(se)[0].outerHTML);
                        $(se).remove();   
                    }
                });
            }
        }
        else{
            if(photox.canvasoffset[0] != 0 || photox.canvasoffset[1]!=0){
                $.each($('.selected'),function(si,se){
                    if($(se).parent().attr('id') != 'canvas'){
                        
                    }
                    else{
                        merger.topmost[merger.topmost.length] = $(se)[0].offsetTop + parseInt($('#canvas')[0].offsetTop);
                        merger.leftmost[merger.leftmost.length] = $(se)[0].offsetLeft + parseInt($('#canvas')[0].offsetLeft);
                        merger.mergedwidth[merger.mergedwidth.length] = $(se).width();
                        merger.mergedheight[merger.mergedheight.length] = $(se).height();   
                        
                        $(se).css('top',merger.topmost[merger.topmost.length-1]+'px');
                        $(se).css('left',merger.leftmost[merger.leftmost.length-1]+'px');
                        
                        $('#text_'+texter.textcounter).append($(se)[0].outerHTML);
                        $(se).remove();
                    }
                });           
            }
            else{
                $.each($('.selected'),function(si,se){
                    if($(se).parent().attr('id') != 'canvas'){
                        
                    }
                    else{
                        merger.topmost[merger.topmost.length] = $(se)[0].offsetTop;
                        merger.leftmost[merger.leftmost.length] = $(se)[0].offsetLeft;
                        merger.mergedwidth[merger.mergedwidth.length] = $(se).width();
                        merger.mergedheight[merger.mergedheight.length] = $(se).height();
                        
                        $('#text_'+texter.textcounter).append($(se)[0].outerHTML);
                        $(se).remove();
                    }
                });
            }
        }
        
        for(var p=0;p<merger.topmost.length;p++){
            if(p==0){
                merger.topmost_ = merger.topmost[p];
                merger.leftmost_ = merger.leftmost[p];
                
                merger.bottommost = (merger.topmost_+merger.mergedheight[p]);
                merger.rightmost = (merger.leftmost_+merger.mergedwidth[p]);
            }
            else{
                merger.topmost_ = Math.min(merger.topmost_,merger.topmost[p]);
                merger.leftmost_ = Math.min(merger.leftmost_,merger.leftmost[p]);
                
                merger.bottommost = Math.max(merger.bottommost,(merger.topmost[p]+merger.mergedheight[p]));
                merger.rightmost = Math.max(merger.rightmost,(merger.leftmost[p]+merger.mergedwidth[p]));
            }
        }
        
        $('#text_'+texter.textcounter).css('top',merger.topmost_+'px');
        $('#text_'+texter.textcounter).css('left',merger.leftmost_+'px');
        
        $('#text_'+texter.textcounter).css('width',(merger.rightmost-merger.leftmost_)+'px');
        $('#text_'+texter.textcounter).css('height',(merger.bottommost-merger.topmost_)+'px');
        
        texter.blurs();
        merger.selectmerged($('#text_'+texter.textcounter));
        texter.selectmerged=true;
        texter.textis_($('#text_'+texter.textcounter));
    }
};
var theruler={
    mocinmode_insuspense:false,
    mocinmode:function(){
        if(theruler.mocinmode_insuspense){
            $('#ruler_'+(theruler.rulercount-1)).remove();
            theruler.mocinmode_insuspense = false;
            
            theruler.addhoriz();
            return;
        }
        theruler.mocinmode_insuspense = true;
        theruler.addvert();
    },
    rulercount:0,
    add:function(){
        if(dialogbox.checkexists('Ruler'))
            return;
                    
        dialogbox.mbox(['Ruler','Select Type','<span id="horizruler">Horizontal</span><span id="vertruler">Vertical</span>'],'',function(){
           $('#horizruler').on('click',function(event){
                event.stopPropagation();
                
                theruler.addhoriz();
                dialogbox.close();
            });
            
            $('#vertruler').on('click',function(event){
                event.stopPropagation();
                
                theruler.addvert();
                dialogbox.close();
            }); 
        });
    },
    addhoriz:function(){
        $('#canvaswrapper').append('<div id="ruler_'+theruler.rulercount+'" class="aruler horiz"></div>');
        
        theruler.rulercount++;
    },
    addvert:function(){
        $('#canvaswrapper').append('<div id="ruler_'+theruler.rulercount+'" class="aruler vertic"></div>');
        
        theruler.rulercount++;
    }
};
var anagram = {
    word:false,
    wordx:[],
    vowel:['a','i','u','e','o'],
    vowelcount:0,
    consonantcount:0,
    anagram:[],
    anagramcount:0,
    thelist:function(){
        anagram.compil.sort(function(a,b){
            for(i=0;i<a.length;i++){
                    result = texter.alfasort.indexOf(a.substr(i,1)) - texter.alfasort.indexOf(b.substr(i,1));
                
                if(result !== 0)
                    break;
            }
            return result;
        });
        var c='';
        for(var i=0;i<anagram.compil.length;i++){
            c+='<div class="row bordered">'+(i+1)+'. '+anagram.compil[i]+'</div>';
        }
        return c;
    },
    initwordpos:function(){
        for(var ii=0;ii<anagram.wordx.length;ii++){
            anagram.wordxx[ii].pos = [];
            anagram.topos[ii] = ii;
            for(var o=0;o<anagram.wordx.length;o++){
                anagram.wordxx[ii].pos[anagram.wordxx[ii].pos.length] = o;
            }
        }
    },
    inittopos:function(){
        anagram.splicedletter = [];
        anagram.topos = [];
        for(var ii=0;ii<anagram.wordx.length;ii++){
            anagram.topos[ii] = ii;
        }
        return anagram.topos;
    },
    start:function(){
        anagram.word = $(texter.focusedid).html();
        anagram.wordx = [];
        anagram.anagram = [];
        anagram.anagramcount = 0;
        
        for(var i=0;i<anagram.word.length;i++){
            anagram.wordx[i] = [];
            anagram.wordx[i].letter = anagram.word[i];
            anagram.wordx[i].vowel = anagram.vowel.indexOf(anagram.wordx[i].letter) !== -1 ? 1 : 0;
            
            if(anagram.wordx[i].letter == 'y'){
                if(i!=0){
                    if(!anagram.wordx[i-1].vowel){
                        anagram.wordx[i].vowel = 1;
                    }
                    else{
                        anagram.wordx[i].vowel = 0;
                    }
                }
            }
            
            if(anagram.wordx[i].vowel){
                anagram.vowelcount++;
            }
            else{
                anagram.consonantcount++;
            }
        }
        
        console.log(anagram.wordx.length);
        anagram.anagramcount = 1;
        for(var ii=anagram.wordx.length;ii>1;ii--){
            anagram.anagramcount = anagram.anagramcount * ii;
        }
        console.log(anagram.anagramcount);
        
        anagram.wordxx = anagram.wordx;
        anagram.anag = new Array(anagram.word.length);
        anagram.compil = [];
        anagram.compil[0] = anagram.word;
        anagram.topos = [];
        
        anagram.initwordpos();
        
        anagram.youmissed = 0;
        for(var k=0;k<anagram.wordx.length;k++){
            anagram.start_(k);
        }
        
        dialogbox.mbox(['Anagram of "'+anagram.word+'"',anagram.thelist(),'']);
        console.log(anagram.youmissed);
    },
    pospart:function(ki,i,flag){
        if(anagram.splicedletter.indexOf(i) !== -1){
            return;
        }
        var insert = false;
        for(var o=ki;o<anagram.wordxx[i].pos.length;o++){
            if(anagram.topos.indexOf(anagram.wordxx[i].pos[o])!==-1){
                insert = true;
                anagram.anag[anagram.wordxx[i].pos[o]] = anagram.wordxx[i].letter;
                anagram.topos.splice(anagram.topos.indexOf(anagram.wordxx[i].pos[o]),1);
                break;
            }
        }
        
        if(!insert && ki > 0){
            for(var o=0;o<ki;o++){
                if(anagram.topos.indexOf(anagram.wordxx[i].pos[o])!==-1){
                    insert = true;
                    anagram.anag[anagram.wordxx[i].pos[o]] = anagram.wordxx[i].letter;
                    anagram.topos.splice(anagram.topos.indexOf(anagram.wordxx[i].pos[o]),1);
                    break;
                }
            }   
        }
        
        if(!insert){
            anagram.anag[anagram.topos[0]] = anagram.wordxx[i].letter;
            anagram.topos.splice(0,1);
        }
        
        if(anagram.wordxx[i].pos.length){
            anagram.thereispos = true;
        }
    },
    pospart_splice:function(i,kkl){
        var insert = false;
        for(var p=0;p<kkl;p++){
            if(i+p == anagram.wordxx.length){
                break;
            }
            for(var o=0;o<anagram.wordxx[i+p].pos.length;o++){
                if(anagram.topos.indexOf(anagram.wordxx[i+p].pos[o])!==-1){
                    insert = true;
                    anagram.anag[anagram.wordxx[i+p].pos[o]] = anagram.wordxx[i+p].letter;
                    anagram.topos.splice(anagram.topos.indexOf(anagram.wordxx[i+p].pos[o]),1);
                    
                    anagram.splicedletter[anagram.splicedletter.length] = i+p;
                    break;
                }
            }   
        }
    },
    start_:function(whiteflag){
        anagram.thereispos = false;
        
        for(var ki=whiteflag;ki<anagram.wordxx.length;ki++){
            //twopart linear
            for(var si=0;si<anagram.wordxx.length;si++){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i<anagram.wordxx.length;i++){
                        anagram.pospart(ki,i,1);
                    }
                    if(si > 0){
                        for(var i=0;i<si;i++){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                }
            }
            //twopart linear with one part in reverse
            for(var si=0;si<anagram.wordxx.length;si++){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i<anagram.wordxx.length;i++){
                        anagram.pospart(ki,i,1);
                    }
                    
                    if(si > 0){
                        for(var i=si-1;i>=0;i--){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //twopart linear in reverse
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    //every letter
                    for(var i=si;i>=0;i--){
                        anagram.pospart(ki,i,99);
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=anagram.wordxx.length-1;i>=si;i--){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    //every letter
                    
                    
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                    }
                    
                    if(!anagram.thereispos){
                        //anagram.initwordpos();
                    }
                }
            }
            //twopart linear in reverse with one part forward
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                        
                    //every letter
                    for(var i=si;i>=0;i--){
                        anagram.pospart(ki,i,99);
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=si+1;i<anagram.wordxx.length;i++){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    //every letter
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                    }
                    
                    if(!anagram.thereispos){
                        //anagram.initwordpos();
                    }
                }
            }
            //all even - all odd
            for(var si=0;si<anagram.wordxx.length;si++){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i<anagram.wordxx.length;i++){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si > 0){
                        for(var i=0;i<si;i++){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    
                    for(var i=si;i<anagram.wordxx.length;i++){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si > 0){
                        for(var i=0;i<si;i++){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //all even - all odd in reverse with one part forward
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i>=0;i--){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=si+1;i<anagram.wordxx.length;i++){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    for(var i=si;i>=0;i--){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=si+1;i<anagram.wordxx.length;i++){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //all even - all odd in reverse
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                        
                    for(var i=si;i>=0;i--){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=anagram.wordxx.length-1;i>si;i--){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    for(var i=si;i>=0;i--){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=anagram.wordxx.length-1;i>si;i--){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //all odd - all even
            for(var si=0;si<anagram.wordxx.length;si++){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i<anagram.wordxx.length;i++){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si > 0){
                        for(var i=0;i<si;i++){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    for(var i=si;i<anagram.wordxx.length;i++){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si > 0){
                        for(var i=0;i<si;i++){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //all odd - all even in reverse
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i>=0;i--){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=anagram.wordxx.length-1;i>si;i--){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    for(var i=si;i>=0;i--){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=anagram.wordxx.length-1;i>si;i--){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
            //all odd - all even in reverse with one part forward
            for(var si=anagram.wordxx.length-1;si>=0;si--){
                for(var kkl=0;kkl<=anagram.wordxx.length-2;kkl++){
                    anagram.inittopos();
                    anagram.anag = [];
                    
                    anagram.pospart_splice(si,kkl);
                    
                    for(var i=si;i>=0;i--){
                        if(i%2!=0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=si+1;i<anagram.wordxx.length;i++){
                            if(i%2!=0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    for(var i=si;i>=0;i--){
                        if(i%2==0){
                            anagram.pospart(ki,i,1);
                        }
                    }
                    if(si < anagram.wordxx.length-1){
                        for(var i=si+1;i<anagram.wordxx.length;i++){
                            if(i%2==0){
                                anagram.pospart(ki,i,1);
                            }
                        }
                    }
                    if(anagram.compil.indexOf(anagram.anag.join('')) === -1){
                        anagram.compil[anagram.compil.length] = anagram.anag.join('');
                    }
                    else{
                        anagram.youmissed++;
                        //console.log(anagram.anag.join('')+'-----------------------------');
                    }
                    
                    if(!anagram.thereispos){
                        //console.log(si+'******'+whiteflag);
                        //anagram.initwordpos();
                    }
                }
            }
        }
    }
};
var texteditor = {
    init_:false,
    init:function(){
        if(texteditor.init_){
            return;
        }
        texteditor.init_ = true;
        
        CKEDITOR.on( 'instanceCreated', function( event ) {
            var editor = event.editor,
            element = editor.element;
            
            editor.on( 'configLoaded', function() {
                editor.config.removePlugins = 'colorbutton,flash,forms,iframe,newpage,magicline';
                editor.config.toolbarGroups = [
                	{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
                	{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] },
                	{ name: 'links' },
                	{ name: 'insert', groups: [ 'insert' ] },
                	'/',
                	{ name: 'styles' },
                	{ name: 'colors' },
                	{ name: 'tools' },
                	{ name: 'others' },
                	{ name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
                	{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
                	{ name: 'clipboard', groups: [ 'clipboard', 'undo' ] }
                ];
            });
        });
    },
    edit:function(){
        if(texter.focused === false){
            return;
        }
        texteditor.init();
        
        CKEDITOR.config.height = 298;
        $(texter.focusedid).addClass('cked').prop('contenteditable',true);
        CKEDITOR.inline(document.getElementById('text_'+texter.focused));
        
        texteditor.editing = 'text_'+texter.focused;
        texteditor.styling();
    },
    editor:false,
    editing:false,
    styling:function(){
        setTimeout(function(){
            if(texteditor.editor === false)
                texteditor.editor = $('body').find('.cke_reset_all').eq(0)[0];
                
            $(texteditor.editor).css('position','fixed');
            $(texteditor.editor).css('display','block'); 
            
            $('#'+texteditor.editing).focus().addClass('cke_focus');
        },400);
    },
    reset:function(){
        if(texteditor.editing!==false){
            CKEDITOR.instances[texteditor.editing].destroy();
            $(texteditor.editor).css('display','none'); 
            $('#'+texteditor.editing).blur();
        }
        
        texteditor.editor= false;
        texteditor.editing= false;
        
        $('.textshirt.cked').removeClass('cked cke_editable cke_editable_inline cke_contents_ltr cke_show_borders cke_focus');
    }
};
var editors = {
    fontsize:12,
    editor2:[],
    editor1:false,
    editor3:false,
    scrolled:[],
    countcode:function(){
        if(typeof $('#pagejava').attr('id') !== 'undefined'){
            for(var jc=1;jc<100;jc++){
                if(typeof $('#javacode_'+jc).attr('id') === 'undefined'){
                    editors.setcodenum(jc);
                    break;   
                }
            }   
        }
    },
    packcode:function(code){
        for(var o=0;o<editors.codenum;o++){
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'textshirt',a:'packcode',d:{code:editors.plaincode[o],codeidx:o}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                
                editors.codetopack -=1;
                
                if(msg.codeidx==0){
                    $('#pagejava').html(msg.packed);
                }
                else{
                    activecode = 'javacode_'+msg.codeidx;
                    $('#'+activecode).html(msg.packed);
                }
                
                if(!editors.codetopack){
                    editors.savepackedcode();
                }
            });
        }  
    },
    savepackedcode:function(){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'textshirt',a:'savedsavedmini',d:{packed:editors.packermode_,id:texter.saved[1],content:pagesheets.thecompleteset()}}
        }).done(function(msg){
            if(typeof $('#magnifsearch').attr('id') === 'undefined')
                $('.jcs').removeClass('dormant');
                
            editors.packcode_();
            editors.packermode_ = true;
            
            msg=JSON.parse(msg);
            
            $(dialogbox.actionbox).find('.editing').removeClass('editing');
            $('#javapacker').addClass('editing')
            
            setTimeout(function(){
                $('#savethepage').removeClass('saving');
            },3000);
        }); 
    },
    packcode_:function(){
        var cocontent,activecode;
        for(var o=0;o<editors.codenum;o++){
            if(o==0){
                $('#pagejava').html(editors.plaincode[o]);
            }
            else{
                activecode = 'javacode_'+o;
                $('#'+activecode).html(editors.plaincode[o]);
            }
        }
    },
    plaincode:[],
    packermode_:false,
    packermode:function(){
        $('#savethepage').addClass('editing saving');
        
        editors.codetopack = editors.codenum;
        editors.plaincode = [];
        
        var cocontent,activecode;
        for(var o=0;o<editors.codenum;o++){
            if(o==0){
                editors.plaincode[o] = $('#pagejava').html();
            }
            else{
                activecode = 'javacode_'+o;
                editors.plaincode[o] = $('#'+activecode).html();
            }
        }
        editors.packcode();
    },
    refresh:function(){
        editors.currentcode = false;
        editors.editor1 = false;
        editors.editor2 = [];
        editors.editor3 = false;
        
        editors.scrolled = [];
        editors.packermode_=false;
        
        $('#pagecss_').remove();
        for(var o=0;o<editors.codenum;o++){
            if(o==0){
                $('#pagejava').remove();
            }
            else{
                $('#javacode_'+o).remove();
            }
        }
    },
    keepscrolled:function(activecode){
        editors.currentcode = activecode;
        editors.scrolled[editors.currentcode] = editors.editor2[editors.currentcode].session.getScrollTop();
    },
    currentcode:false,
    showscrolled:function(act){
        var activecode = parseInt(act);
        editors.currentcode = activecode;
        if(typeof editors.scrolled[editors.currentcode] !== 'undefined'){
            editors.editor2[editors.currentcode].renderer.scrollToY(editors.scrolled[editors.currentcode]);
        }
    },
    sourcecode:function(){
        $(dialogbox.contentbox).find('.tablecell').html('<pre id="sourcepagecs"></pre>');
        editors.editor1 = ace.edit('sourcepagecs');
        
        editors.editor1.setOption("useWorker", false);
        editors.editor1.setTheme('ace/theme/ambiance');
        editors.editor1.session.setMode("ace/mode/html");
        editors.editor1.setFontSize(12);
        editors.editor1.$blockScrolling = Infinity;
        editors.editor1.setShowPrintMargin(false);
        
        editors.editor1.setValue(texter.pagecss_,1);
    },
    csssource:function(){
        $(dialogbox.contentbox).find('.tablecell').html('<pre id="csspagecs"></pre>');
        editors.editor3 = ace.edit('csspagecs');
        
        editors.editor3.setOption("useWorker", false);
        editors.editor3.setTheme('ace/theme/ambiance');
        editors.editor3.session.setMode("ace/mode/css");
        editors.editor3.setFontSize(12);
        editors.editor3.$blockScrolling = Infinity;
        editors.editor3.setShowPrintMargin(false);
        
        editors.editor3.setValue(texter.pagecss_,1);
        
        editors.editor3.editing = editors.editor3.getValue();
        
        
        editors.editor3.setValue(texter.pagecss_,1);
        ace.config.loadModule("ace/ext/regista_shortcuts", function(module) {
            module.init(editors.editor3);
        });
        
            ace.config.loadModule("ace/ext/keybinding_menu", function(module) {
                module.init(editors.editor3);
                editors.editor3.commands.removeCommands([{
                        name: "showKeyboardShortcuts"
                }]);
            });   
        
        editors.acom();
        
        
        editors.editor3.getSession().on('change',function(){
            editors.updateisediting(3);
        });
    },
    updateisediting:function(editoridx){
        if(editoridx==3){
            if(editors.editor3.getValue() != editors.editor3.editing){
                $('#savedontclose').addClass('editing');
                $('#savepagecss').addClass('editing');   
            }
            else{
                $('#savedontclose').removeClass('editing');
                $('#savepagecss').removeClass('editing');
            }   
            
            return;
        }
        if(editoridx==2){
            if(editors.editor2[editors.currentcode].getValue() != editors.editor2[editors.currentcode].editing){
                $(dialogbox.actionbox).children().addClass('editing');
            }
            else{
                $(dialogbox.actionbox).children().removeClass('editing');
            }   
            
            return;
        }
    },
    csssource_:function(){
        return editors.editor3.getValue();
    },
    getsource:function(){
        return editors.editor1.getValue();
    },
    getjavacode:function(){
        return editors.editor2[editors.currentcode].getValue();
    },
    adjustsize:function(){
        if(dialogbox.active){
            if(typeof $('#pagecs').attr('id') !== 'undefined'){
                if($('#pagecs').attr('class').indexOf('javasc') !== -1){
                    texter.pagecss_ = editors.getjavacode();
                    editors.setjavacode(false);
                }
            }
        }
    },
    switchcode_:function(elemid){
        if(elemid == 'addjc'){
            editors.addcode();
            return;
        }
        if(typeof $('#magnifsearch').attr('id') === 'undefined')
            $('.jcs').addClass('dormant');
        
        
        $('.jcs.active').removeClass('active');
        $('#'+elemid).addClass('active');
        
        elemid = elemid.split('_')[1];
        if(elemid=='0'){
            if(typeof $('#pagejava').attr('id') !=='undefined')
                texter.pagecss_ = $('#pagejava').html();
            else{
                texter.pagecss_ = '';
            }
        }
        else{
            if(typeof $('#javacode_'+elemid).attr('id') !== 'undefined'){
                texter.pagecss_ = $('#javacode_'+elemid).html();
            }
            else
                texter.pagecss_ = '';
        }
        editors.setjavacode(elemid);
    },
    switchcode:function(elemid){
        editors.applyjavacode(false,elemid);
    },
    applyjavacode:function(closebox,cb){
        var activecode = parseInt($('.jcs.active').attr('id').split('_')[1]);
        
        editors.keepscrolled(activecode);
        if(activecode==0){
            activecode = 'pagejava';
            
            if(typeof $('#'+activecode).attr('id')!=='undefined'){
                $('#'+activecode).html(editors.getjavacode());
            }
            else
                $('#canvaswrapper').append('<script type="text/javascript" id="pagejava">'+editors.getjavacode()+'</script>');
        }
        else{
            activecode = 'javacode_'+activecode;
            
            if(typeof $('#'+activecode).attr('id')!=='undefined'){
                $('#'+activecode).html(editors.getjavacode());
            }
            else
                $('#canvaswrapper').append('<script type="text/javascript" id="'+activecode+'">'+editors.getjavacode()+'</script>');
        }
        if(closebox){
            dialogbox.close();
            $('.regiformfoc').removeClass('regiformfoc').blur();
        }
        
        if(cb!==false){
            editors.switchcode_(cb);
        }
    },
    javaorder:function(){
        var cocontent,activecode;
        for(var o=0;o<editors.codenum;o++){
            if(o==0){
                cocontent = $('#pagejava').html();
                $('#pagejava').remove();
                $('#canvaswrapper').append('<script type="text/javascript" id="pagejava">'+cocontent+'</script>');
            }
            else{
                activecode = 'javacode_'+o;
                cocontent = $('#'+activecode).html();
                $('#'+activecode).remove();
                $('#canvaswrapper').append('<script type="text/javascript" id="'+activecode+'">'+cocontent+'</script>');
            }
        }
    },
    deletecode:function(){
        var activecode = parseInt($('.jcs.active').attr('id').split('_')[1]);
        
        if(activecode==0){
            $('#pagejava').remove();
            for(var jc=1;jc<editors.codenum;jc++){
                if(typeof $('#javacode_'+jc).attr('id') !== 'undefined'){
                    if(jc==1){
                        $('#javacode_'+jc).prop('id','pagejava');
                    }
                    else{
                        $('#javacode_'+jc).prop('id','javacode_'+(jc-1));
                    }
                }
                else{
                    break;
                }
            }
            editors.codenum -=1;
            editors.javaorder();
        }
        else{
            for(var jc=(activecode+1);jc<editors.codenum;jc++){
                if(typeof $('#javacode_'+jc).attr('id') !== 'undefined'){
                    $('#javacode_'+jc).prop('id','javacode_'+(jc-1));
                }
                else{
                    break;
                }
            }
            editors.codenum -=1;
            $('#javacode_'+activecode).remove();
            editors.javaorder();
        }
        $('#jc_'+activecode).remove();
        for(var o=(activecode+1);o<=editors.codenum;o++){
            $('#jc_'+o).html(o-1).prop('id','jc_'+(o-1));
        }
        if(typeof $('#jc_0').attr('id') === 'undefined'){
            $('#addjc').before('<span id="jc_0" class="active jcs">0</span>');
            texter.pagecss_ = '';
        }
        else{
            $('#jc_0').addClass('active');
            texter.pagecss_ = $('#pagejava').html();            
        }
        editors.setjavacode(false);
    },
    savecode:function(){
        if(dialogbox.title == 'page css'){
            editors.savethecss();
            return;
        }
        
        if(dialogbox.title == 'page java'){
            editors.savejavacode(0);
            return;
        }
    },
    savethecss:function(){
        $('#savedontclose').html('Saving...');
             
        if(texter.pagecss__){
            if(typeof $('#pagecss_').next().attr('class') !== 'undefined'){
                $('#pagecss_').remove();
                $('#canvaswrapper').append('<style id="pagecss_">'+editors.csssource_()+'</style>');
            }
            else{
                $('#pagecss_').html(editors.csssource_());   
            }
        }
        else{
            $('#canvaswrapper').append('<style id="pagecss_">'+editors.csssource_()+'</style>');
        }
        
        editors.javaorder();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'textshirt',a:'savedsaved',d:{id:texter.saved[1],content:pagesheets.thecompleteset()}}
        }).done(function(msg){
            msg=JSON.parse(msg);
            
            $(dialogbox.actionbox).find('.editing').removeClass('editing');
            
            $('#savedontclose').html('Saved!');
            setTimeout(function(){
                $('#savedontclose').html('Save');    
            },3000);
        }); 
    },
    savejavacode:function(clobo){
        editors.applyjavacode(false,false);
    
        if(!texter.saved.length){
            if(typeof $('#magnifsearch').attr('id') === 'undefined')
                $('.jcs').removeClass('dormant');
            return;
        }
        
        editors.editor2[editors.currentcode].editing = editors.editor2[editors.currentcode].getValue();
        $('#savethepage').addClass('saving');
        
        editors.javaorder();
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'textshirt',a:'savedsaved',d:{id:texter.saved[1],content:pagesheets.thecompleteset()}}
        }).done(function(msg){
            if(typeof $('#magnifsearch').attr('id') === 'undefined')
                $('.jcs').removeClass('dormant');
            
            msg=JSON.parse(msg);
            if(clobo){
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
                if($('body').attr('class').indexOf('showall') !== -1){
                    texter.showall();
                }
                return;
            }
            $(dialogbox.actionbox).find('.editing').removeClass('editing');
            setTimeout(function(){
                $('#savethepage').removeClass('saving');
            },3000);
        }); 
    },
    addcode:function(){
        $('.jcs.active').removeClass('active');
        $('#addjc').before('<span id="jc_'+editors.codenum+'" class="active jcs">'+editors.codenum+'</span>');
        
        editors.jcact($('#jc_'+editors.codenum));
        texter.pagecss_ = '';
        editors.setjavacode(editors.codenum);
        editors.codenum++;
    },
    jcact:function(elem){
        $(elem).on('click contextmenu',function(event){
            event.stopPropagation();
            
            if(event.type == 'contextmenu'){
                $('.jcs').addClass('oce');
                $(this).addClass('editoce');
                editors.oce = this;
                return;
            }
            
            if($(this).attr('class').indexOf('editoce')!== -1){
                $(this).removeClass('editoce');
                $('.jcs').removeClass('oce');
                return;
            }
            
            if($(this).attr('class').indexOf('oce') !== -1){
                editors.insertjc(this);
                return;
            }
            editors.switchcode(this.id);
        });
    },
    insertjc:function(elem){
        var max = [0,parseInt($(elem).html()),parseInt($(editors.oce).html()),[]];
        var jcorder = [];
        
        if(max[2] < max[1]){
            $.each($('.jcs'),function(ji,je){
                if($(je).attr('id')=='addjc' || $(je).html() == $(elem).html()){
                    
                }
                else if($(je).attr('class').indexOf('editoce')!==-1){
                    if(max[2] == 0){
                        jcorder[jcorder.length] = ['javacode_'+(max[1]-1),$('#pagejava').html(),ji];
                        $('#pagejava').remove();
                    }
                    else{
                        jcorder[jcorder.length] = ['javacode_'+(max[1]-1),$('#javacode_'+max[2]).html(),ji];
                        $('#javacode_'+max[2]).remove();
                    }
                }
                else{
                    max[0] = parseInt($(je).html());
                    if(max[0] > max[2]){
                        if(max[1] > max[2] && max[0] > max[1]){
                            
                        }
                        else{
                            max[0]-=1;
                            $(je).html(max[0]).prop('id','jc_'+max[0]);
                            
                            
                            if(max[0] == 0){
                                jcorder[jcorder.length] = ['pagejava',$('#javacode_'+(max[0]+1)).html(),ji];
                                $('#javacode_'+(max[0]+1)).remove();
                            }
                            else{
                                jcorder[jcorder.length] = ['javacode_'+max[0],$('#javacode_'+(max[0]+1)).html(),ji];
                                $('#javacode_'+(max[0]+1)).remove();   
                            }   
                        }
                    }   
                }
            });    
            
            max[1]-=1;
            $(elem).before('<span id="jc_'+max[1]+'" class="'+($(editors.oce).attr('class').indexOf('active') === -1 ? '' : 'active ')+'jcs">'+max[1]+'</span>');
            $(editors.oce).remove();
            $('.jcs').removeClass('oce');
            editors.jcact($('#jc_'+max[1]));
        }
        else{
            $.each($('.jcs'),function(ji,je){
                if($(je).attr('id')=='addjc'){
                    
                }
                else if($(je).attr('class').indexOf('editoce')!==-1){
                    if(max[1] == 0){
                        jcorder[jcorder.length] = ['pagejava',$('#javacode_'+(max[2])).html(),ji];
                    }
                    else{
                        jcorder[jcorder.length] = ['javacode_'+max[1],$('#javacode_'+(max[2])).html(),ji];
                    }
                    $('#javacode_'+(max[2])).remove();   
                }
                else{
                    max[0] = parseInt($(je).html());
                    if(max[0] < max[1] || max[0] > max[2]){
                        
                    }
                    else{
                        if(max[0] == 0){
                            jcorder[jcorder.length] = ['javacode_'+(max[0]+1),$('#pagejava').html(),ji];
                            $('#pagejava').remove();                               
                        }
                        else{
                            jcorder[jcorder.length] = ['javacode_'+(max[0]+1),$('#javacode_'+(max[0])).html(),ji];
                            $('#javacode_'+(max[0])).remove();                               
                        }
                        max[0]+=1;
                        $(je).html(max[0]).prop('id','jc_'+max[0]);
                    }
                }
            });  
            
            $(elem).before('<span id="jc_'+max[1]+'" class="'+($(editors.oce).attr('class').indexOf('active') === -1 ? '' : 'active ')+'jcs">'+max[1]+'</span>');
            $(editors.oce).remove();
            $('.jcs').removeClass('oce');
            editors.jcact($('#jc_'+max[1]));
        }
        
        for(var o=0;o<jcorder.length;o++){
            $('#canvas').append('<script type="text/javascript" id="'+jcorder[o][0]+'">'+jcorder[o][1]+'</script>');
            
            if(jcorder[o][0].indexOf('_') === -1){
                editors.editor2[0].setValue(jcorder[o][1]);
            }
            else{
                if(typeof editors.editor2[parseInt(jcorder[o][0].split('_')[1])] !== 'undefined'){
                    editors.editor2[parseInt(jcorder[o][0].split('_')[1])].setValue(jcorder[o][1]);
                }   
            }
        }
        editors.javaorder();
    },
    setjavacode:function(codeidx){
        if(codeidx === false){
            editors.currentcode = parseInt($('.jcs.active').attr('id').split('_')[1]);
            if(typeof $(dialogbox.contentbox).find('#pagecs_'+editors.currentcode).attr('id') !== 'undefined'){
                $(dialogbox.contentbox).find('.javasc.active').removeClass('active');
                $(dialogbox.contentbox).find('#pagecs_'+editors.currentcode).addClass('active');
            }
            else{
                $(dialogbox.contentbox).find('.javasc.active').removeClass('active');
                $(dialogbox.contentbox).find('.tablecell').html('<pre id="pagecs_'+editors.currentcode+'" class="javasc active"></pre>');
                editors.editor2[editors.currentcode] = ace.edit('pagecs_'+editors.currentcode);
            }
        }
        else{
            editors.currentcode = codeidx;
            if(typeof $(dialogbox.contentbox).find('#pagecs_'+codeidx).attr('id') !== 'undefined'){
                $(dialogbox.contentbox).find('.javasc.active').removeClass('active');
                $(dialogbox.contentbox).find('#pagecs_'+editors.currentcode).addClass('active');
            }
            else{
                $(dialogbox.contentbox).find('.javasc.active').removeClass('active');
                $(dialogbox.contentbox).find('.tablecell').append('<pre id="pagecs_'+codeidx+'" class="javasc active"></pre>');
                editors.editor2[editors.currentcode] = ace.edit('pagecs_'+codeidx);
            }
        }
        editors.editor2[editors.currentcode].setOption("useWorker", false);
        editors.editor2[editors.currentcode].setTheme('ace/theme/ambiance');
        editors.editor2[editors.currentcode].session.setMode("ace/mode/javascript");
        editors.editor2[editors.currentcode].setFontSize(13);
        editors.editor2[editors.currentcode].$blockScrolling = Infinity;
        editors.editor2[editors.currentcode].setShowPrintMargin(false);
        
        if(typeof texter.pagecss_ === 'undefined')
            texter.pagecss_ = '';
            
        editors.editor2[editors.currentcode].setValue(texter.pagecss_,1);
        
        ace.config.loadModule("ace/ext/regista_shortcuts", function(module) {
            module.init(editors.editor2[editors.currentcode]);
        });
        
            ace.config.loadModule("ace/ext/keybinding_menu", function(module) {
                module.init(editors.editor2[editors.currentcode]);
                editors.editor2[editors.currentcode].commands.removeCommands([{
                        name: "showKeyboardShortcuts"
                }]);
            });   
        
        editors.acom();
        
        editors.editor2[editors.currentcode].editing = editors.editor2[editors.currentcode].getValue();
        editors.editor2[editors.currentcode].getSession().on('change',function(){
            editors.updateisediting(2);
        });
        
        if(typeof $('#magnifsearch').attr('id') === 'undefined')
            $('.jcs').removeClass('dormant');
            
        if(texter.pagecss_ != ''){
            editors.showscrolled($('.jcs.active').attr('id').split('_')[1]);
        }
        try{
            editors.editor2[editors.currentcode].focus();
            setTimeout(function(){
                if(!editors.boxopen){
                    editors.boxopen = true;
                    
                    $('#closemessagebox_'+dialogbox.boxidx).on('click',function(event){
                        event.stopPropagation();
                        editors.boxopen = false;
                        
                        if(typeof $('#messagebox_'+dialogbox.boxidx).attr('id') === 'undefined'){
                            return;
                        }
                        var activecode = parseInt($('.jcs.active').attr('id').split('_')[1]);
                        editors.keepscrolled(activecode);
                        editors.currentcode = activecode;
                        dialogbox.close();
                        
                        if($('body').attr('class').indexOf('showall')!==-1){
                            texter.showall();
                        }
                    });
                }
            },300);
        }catch(e){console.log(e);}
    },
    boxopen:false,
    codenum:0,
    setcodenum:function(num){
        editors.codenum = num;
    },
    filtercode_:false,
    filtercode:function(){
        $('.jcs').addClass('dormant');
        $('#javamagnif').replaceWith('<input type="text" name="search" value="search" id="magnifsearch">');
        $('#magnifsearch').focus();
    },
    javacode:function(){
        $(dialogbox.actionbox).append('<span id="jc_0" class="active jcs">0</span>');
        if(texter.pagecss__){
            for(var jc=1;jc<100;jc++){
                if(typeof $('#javacode_'+jc).attr('id') !== 'undefined'){
                    $(dialogbox.actionbox).append('<span id="jc_'+jc+'" class="jcs">'+jc+'</span>');
                }
                else{
                    editors.setcodenum(jc);
                    break;
                }
            }
            if(editors.currentcode!==false){
                $('.jcs.active').removeClass('active');
                $('#jc_'+editors.currentcode).addClass('active');
            }
        }
        else{
            editors.setcodenum(1);
        }
        $(dialogbox.actionbox).append('<span id="addjc" class="jcs">+</span>');
        
        editors.setjavacode(false);
        
        $('.jcs').on('click contextmenu',function(event){
            event.stopPropagation();
            
            if(event.type == 'contextmenu'){
                $('.jcs').addClass('oce');
                $(this).addClass('editoce');
                editors.oce = this;
                return;
            }
            
            if($(this).attr('class').indexOf('editoce')!== -1){
                $(this).removeClass('editoce');
                $('.jcs').removeClass('oce');
                return;
            }
            
            if($(this).attr('class').indexOf('oce') !== -1){
                editors.insertjc(this);
                return;
            }
            
            editors.switchcode(this.id);
        });
    },
    acom:function(){
        var auto;
        
        if(dialogbox.title == 'page css'){
            auto = editors.editor3.$enableBasicAutocompletion ? false : true;
        
            editors.editor3.setOptions({
                enableBasicAutocompletion: auto,
                enableSnippets: auto,
                enableLiveAutocompletion: auto
            });
            return;
        }
        
        if(dialogbox.title == 'page java'){
            auto = editors.editor2[editors.currentcode].$enableBasicAutocompletion ? false : true;
            
            editors.editor2[editors.currentcode].setOptions({
                enableBasicAutocompletion: auto,
                enableSnippets: auto,
                enableLiveAutocompletion: auto
            });
            return;
        }
    },
    toggleautocomplete:function(){
        editors.acom();
    }
};
var photox={
    grabber:[],
    resetgrabber:function(){
        photox.grabber = [];
    },
    grabed:false,
    grabmuch:function(event){
        return;
    },
    canvasoffset:[0,0],
    refresh:function(){
        photox.canvasoffset = [0,0];
    },
    savecanvasoffset:function(left,top){
        photox.canvasoffset = [left,top];
    },
    dropcanvas:function(){
        photox.grabber[3]=[((event.clientX-photox.grabber[0][0])),((event.clientY-photox.grabber[0][1]))];
        photox.grabber[1]=[(photox.grabber[1][0]+photox.grabber[3][0]) , (photox.grabber[1][1]+photox.grabber[3][1]) ];
        
        $('#canvas').css({'top':photox.grabber[1][1]+'px'});
        $('#canvas').css({'left':photox.grabber[1][0]+'px'});
        
        photox.savecanvasoffset(photox.grabber[1][0],photox.grabber[1][1]);
        
        photox.grabber[0]=[event.clientX,event.clientY];
        $(photox.grabed).removeClass('grabbing');
        
        $(photox.grabed).replaceWith($(photox.grabed)[0].outerHTML);
        
        photox.grabed = false;
        texter.showall();
    },
    grabcanvas:function(event,elem){
        texter.showall();
        
        photox.grabed=elem;
        photox.grabber[0]=[];
        photox.grabber[1]=[0,0];
        photox.grabber[2]=['canvas'];
        photox.grabber[3]=[];
        $('#canvas').addClass('grabbing');
        if($('#canvas').css('top') !='0px'){
            photox.grabber[1]=[parseInt($('#canvas').css('left').split('px')[0]),parseInt($('#canvas').css('top').split('px')[0])];
        }
        photox.grabber[0]=[event.clientX,event.clientY];
        $('#canvas.grabbing').on('mousemove',function(event){
            event.stopPropagation();
            event.preventDefault();
            if($('#canvas').attr('class').indexOf('grabbing')===-1){
                return;
            }
            photox.grabber[3]=[((event.clientX-photox.grabber[0][0])),((event.clientY-photox.grabber[0][1]))];
            photox.grabber[1]=[(photox.grabber[1][0]+photox.grabber[3][0]) , (photox.grabber[1][1]+photox.grabber[3][1]) ];
            
            $('#canvas').css({'top':photox.grabber[1][1]+'px'});
            $('#canvas').css({'left':photox.grabber[1][0]+'px'});
            
            texter.adjustrulerpos(photox.grabber[3],2);
            
            $('#countermove').html(photox.grabber[1][0]+','+photox.grabber[1][1]);
            
            photox.grabber[0]=[event.clientX,event.clientY];
        });
    },
    grab:function(event,elem){
        uredo.newmoveinst('grabmove',0);
        uredo.cmove.elem[0] = $(elem)[0].outerHTML;
        uredo.cmove.elem[2] = $(elem).attr('id');
        
        photox.grabed=elem;
        photox.grabber[0]=[];
        photox.grabber[1]=[0,0];
        photox.grabber[2]=[texter.focusedid];
        photox.grabber[3]=[];
        $(photox.grabber[2][0]).addClass('grabbing');
        if($(photox.grabber[2][0]).css('top') !='0px'){
            photox.grabber[1]=[parseInt($(photox.grabber[2][0]).css('left').split('px')[0]),parseInt($(photox.grabber[2][0]).css('top').split('px')[0])];
        }
        photox.grabber[0]=[event.clientX,event.clientY];
        $(photox.grabed).on('mousemove',function(event){
            event.stopPropagation();
            event.preventDefault();
            if(photox.grabed===false){
                return;
            }
            photox.grabber[3]=[((event.clientX-photox.grabber[0][0])),((event.clientY-photox.grabber[0][1]))];
            photox.grabber[1]=[(photox.grabber[1][0]+photox.grabber[3][0]) , (photox.grabber[1][1]+photox.grabber[3][1]) ];
            
            $(photox.grabber[2][0]).css({'top':photox.grabber[1][1]+'px'});
            $(photox.grabber[2][0]).css({'left':photox.grabber[1][0]+'px'});
            
            if(texter.selectmerged){
                photox.movemerged();
            }
            photox.grabber[0]=[event.clientX,event.clientY];
        });
    },
    movemerged:function(){
        $.each($(photox.grabed).find('.selected'),function(gi,ge){
            $(ge).css({'top':($(ge)[0].offsetTop+photox.grabber[3][1])+'px'});
            $(ge).css({'left':($(ge)[0].offsetLeft+photox.grabber[3][0])+'px'});
        });
    },
    rulergrabedtype:0,
    rulergrab:function(event,elem){
        photox.grabed=elem;
        photox.grabber[0]=[];
        photox.grabber[1]=[0,0];
        photox.grabber[2]=[$(elem).attr('id').split('_')[1]];
        photox.grabber[3]=[];
        
        $(elem).addClass('grabbing');
        
        if($(elem).attr('class').indexOf('vertic')!==-1){
            photox.rulergrabedtype = 1;
            photox.rulerposnotif($(elem)[0].offsetLeft,1);
        }
        else{
            photox.rulergrabedtype = 0; 
            photox.rulerposnotif($(elem)[0].offsetTop,0);
        }
        photox.grabber[0]=[event.clientX,event.clientY];
        $(photox.grabed).on('mousemove',function(event){
            event.stopPropagation();
            event.preventDefault();
            if(photox.grabed===false){
                return;
            }
            if(photox.rulergrabedtype){
                $('#ruler_'+photox.grabber[2][0]).css({'left':event.clientX+'px'});
                photox.rulerposnotif(event.clientX,1);
            }
            else{
                $('#ruler_'+photox.grabber[2][0]).css({'top':event.clientY+'px'});
                photox.rulerposnotif(event.clientY,0);
            }
            photox.grabber[0]=[event.clientX,event.clientY];
        });
    },
    rulerposnotif:function(pos,vertical){
        if(vertical===false){
            
        }
        else{
            switch(vertical){
                case 0:
                    pos += -1 * ($('#canvas')[0].offsetTop);
                break;
                case 1:
                    pos += -1 * ($('#canvas')[0].offsetLeft);
                break;
            }
        }
        $('#countermove').html(pos);
    }
};
var zoomer = {
    adjustbar:function(arg){
        arg = parseFloat(arg.split('_')[1]);
        arg = 1/arg;
        
        $('#toolbar').css('height',35*arg+'px');
        $('.toolbars').css('height',35*arg+'px');
        $.each($('.toolbars').find('input[type="text"]'),function(ti,te){
            $(te).css('height',15*arg+'px');
            $(te).css('padding',3*arg+'px');
            $(te).css('font-size',13*arg+'px');
        });
        $.each($('.toolbars').find('span.btn'),function(ti,te){
            $(te).css('height',30*arg+'px');
            $(te).css('padding',(3*arg)+' '+(8*arg)+'px');
        });
        $.each($('.toolbars').find('select'),function(ti,te){
            $(te).css('height',20*arg+'px');
            $(te).css('padding',3*arg+'px');
            $(te).css('font-size',13*arg+'px');
        });
        $.each($('.toolbars').find('.sp-replacer'),function(ti,te){
            $(te).css('height',14*arg+'px');
        });
        
        $('#numberfontsize').css('height',19*arg+'px');
        $('#numberfontsize').css('width',33*arg+'px');
        $('#themovercontainer').css('height',30*arg+'px');
        $('#themovercontainer').css('bottom',2*arg+'px');
        $('#fontfamilyopt').css('width',90*arg+'px');
        $('#csstext').css('width',202*arg+'px');
        $('#changetext').css('width',350*arg+'px');
        
        $('body').css('font-size',12*arg+'px');
        $('#messagebox').css('font-size',12*arg+'px');
        $('#messagebox').css('line-height',12*arg+'px');
        
        if(!settings.defaultcss){
            settings.defaultcss = true;
            settings.elementsett[1] = document.createElement('style'); 
            settings.elementsett[1].type = "text/css";
            document.getElementsByTagName("head")[0].appendChild(settings.elementsett[1]);
            settings.elementsett[2] = settings.elementsett[1].sheet;            
        }
        stylerule = 'input, textarea, select, button{font-size:'+(13*arg)+'px}';
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
        stylerule = '.messagebox input{height:'+(27*arg)+'px}';
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
        stylerule = '.messageboxtitle{font-size:'+(14*arg)+'px}';
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
        stylerule = '#seltrans{height:'+(19*arg)+'px;font-size:'+(11*arg)+'px;}';
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
        stylerule = '.toolbars#textoptions span, .toolbars#textoptions div{height:'+(25*arg)+'px;margin-top:'+(5*arg)+'px;line-height:'+(25*arg)+'px}';
        settings.elementsett[2].insertRule(stylerule,settings.elementsett[2].cssRules.length);
    }
};
var pageaction = {
    init:function(){
        settings.initcanvas();
        
        pageaction.clicker();
        pageaction.contextmenu();
        pageaction.keydown();
        pageaction.keyup();
        pageaction.canvaswrapper();
        pageaction.blurer();
        pageaction.focuser();
        pageaction.changer();    
    
        ipcRenderer.on('asynchronous-reply', (event, arg) => {
            zoomer.adjustbar(arg);
        });
    },
    changer:function(){
        $('#fontfamilyopt').on('change',function(event){
            event.stopPropagation();
            texter.changefont();
        });
        $('#numberfontsize').on('change',function(event){
            event.stopPropagation();
            texter.fontsizeis();
        });
    },
    focuser:function(){
        $('#textshirt').on('focus',function(event){
            htmel.list(false);
        });
        $('#numberfontsize').on('focus',function(event){
            $(this).addClass('regiformfoc');
        });
    },
    blurer:function(){
        $('#numberfontsize').on('blur',function(event){
            $(this).removeClass('regiformfoc');
        });
        $('#textshirt').on('blur',function(event){
            htmel.removelist_(event);
        });
    },
    clicker:function(){
        $('#defaulttoolbar').on('click',function(event){
            event.stopPropagation();
            event.preventDefault();
        });
        $('body').delegate('.messagebox','click',function(event){
            event.stopPropagation();
            
            if(event.target.className.indexOf('closemessagebox') !== -1){
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
                if($('body').attr('class').indexOf('showall') !== -1){
                    texter.showall();
                }
                return;
            }
            if(dialogbox.title == 'Welcome To Textshirt' || (dialogbox.title == 'save' && dialogbox.content == 'saved!') || dialogbox.content == 'Copied'){
                $('.regiformfoc').removeClass('regiformfoc').blur();
                dialogbox.close();
            }
        });
        $('body').delegate('#javamagnif','click',function(event){
            event.stopPropagation();
            editors.filtercode(); 
        });
        $('body').delegate('#magnifsearch','contextmenu',function(event){
            $('.jcs').removeClass('dormant');
            $('#magnifsearch').replaceWith('<span id="javamagnif"></span>');            
        });    
        $('body').delegate('#magnifsearch','keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 27){
                $('.jcs').removeClass('dormant');
                $('#magnifsearch').replaceWith('<span id="javamagnif"></span>');
                return;
            }
            
            if(event.which == 13){
                editors.filtercode_ = $('#magnifsearch').val();
                for(var o=0;o<editors.codenum;o++){
                    if(o==0){
                        if($('#pagejava').html().indexOf(editors.filtercode_) !== -1){
                            $('#jc_'+o).removeClass('dormant');
                            if(editors.currentcode === false){
                                editors.currentcode = o;
                                $('.jcs.active').removeClass('active');
                                $('#jc_'+o).addClass('active');
                                
                                texter.pagecss_ = $('#pagejava').html();
                                editors.setjavacode(o);
                            }
                        }
                        else{
                            if(editors.currentcode == o){
                                editors.currentcode = false;
                            }
                        }
                    }
                    else{
                        if($('#javacode_'+o).html().indexOf(editors.filtercode_) !== -1){
                            $('#jc_'+o).removeClass('dormant');
                            
                            if(editors.currentcode === false){
                                editors.currentcode = o;
                                $('.jcs.active').removeClass('active');
                                $('#jc_'+o).addClass('active');
                                
                                texter.pagecss_ = $('#javacode_'+o).html();
                                editors.setjavacode(o);
                            }
                        }
                        else{
                            if(editors.currentcode == o){
                                editors.currentcode = false;
                            }
                        }
                    }
                }
                $('#magnifsearch').blur();
            }
        });
        
        $('#pagesheets').on('click',function(event){
            event.stopPropagation(); 
            pagesheets.box();
        });
        $('#pagesetup').on('click',function(event){
            event.stopPropagation(); 
            settings.box();
        });
        $('#pagesource').on('click',function(event){
            event.stopPropagation(); 
            texter.viewsource();
        });
        $('#pageid').on('click',function(event){
            event.stopPropagation();
            texter.pageview(false);
        });
        $('#bluropt').on('click',function(event){
            event.stopPropagation();
            texter.blurs();
        });
        $('#addtext').on('click',function(event){
            event.stopPropagation();
            texter.add($('#textshirt').val());
        });
        $('#canvaswrapper').delegate('#canvas','click',function(event){
            if(texteditor.editing){
                return;
            }
            event.stopPropagation();
            event.preventDefault();
            
            if($('#textofthemover').html() == 'paste'){
                cutpaste.snappaste(event);
                return;
            }
            
            if(polygon.drawingmode){
                if(event.ctrlKey){
                    polygon.posnotif(event);
                    return;
                }
                polygon.drawingmode_(event);
                return;
            }
            
            if(typeof $('#canvas').attr('class') !== 'undefined' && $('#canvas').attr('class').indexOf('animation')!==-1){
                transformer.stopanimation();
                return;
            }
            if($('#textofthemover').html() == 'selection'){
                return;
            }
            texter.blurs();
        });
        $('#canvaswrapper').delegate('.textshirt','click',function(event){
            if(texteditor.editing){
                return;
            }
            
            event.stopPropagation();
            
            if($('#textofthemover').html() == 'paste'){
                cutpaste.snappaste(event);
                return;
            }
            
            if(polygon.drawingmode){
                polygon.drawingmode_(event);
                return;
            }
            
            if(typeof $('#canvas').attr('class') !== 'undefined' && $('#canvas').attr('class').indexOf('animation')!==-1){
                transformer.stopanimation();
                return;
            }
            else{
                if($('#textofthemover').html() == 'selection'){
                    return;
                }
                if($(this).attr('class').indexOf('selected') === -1){
                    $(this).addClass('selected');
                }
                else{
                    if(texter.selectmerged){
                        texter.blurs();
                        return;
                    }
                    $(this).removeClass('selected');
                    if(texter.selections.length){
                        texter.removeselections(this);
                    }
                    return;
                }
                texter.textis(this,event);   
            }
        });
        $('#operations').on('click',function(event){
            event.stopPropagation();
            
            if(typeof $('#operationslist').attr('id') !== 'undefined'){
                $('#operationslist').remove();    
                return;
            }
            
            var ope = '<div id="operationslist">';
            ope+='<span class="opertype" id="moveoper">move</span>';
            ope+='<span class="opertype" id="cloneoper">clone</span>';
            ope+='<span class="opertype" id="selectoper">selection</span>';
            ope+='<span class="opertype" id="ruleroper">ruler</span>';
            ope+='<span class="opertype" id="canvasmoveoper">canvas</span>';
            ope+='<span class="opertype" id="lineoper">line</span>';
            ope+='<span class="opertype" id="transformoper">transform</span>';
            ope+='<span class="opertype" id="mergeoper">merge</span>';
            ope+='<span class="opertype" id="circleoper">circle</span>';
            ope+='<span class="opertype" id="rectangleoper">rectangle</span>';
            ope+='<span class="opertype" id="squareoper">square</span>';
            ope+='<span class="opertype" id="chartsoper">charts</span>';
            ope+='<span class="opertype" id="polygonoper">drawline</span>';
            ope+='<span class="opertype" id="animateoper">animate</span>';
            ope+='<span class="opertype" id="paperoper">paper</span>';
            ope+='<span class="opertype" id="texteditoroper">texteditor</span>';
            
            if(texter.focused!==false){
                if(!texter.selectmerged){
                    if($(texter.focusedid).attr('class').indexOf('imageshirt') === -1 && $(texter.focusedid).attr('class').indexOf('circleshirt') === -1 && $(texter.focusedid).attr('class').indexOf('lineshirt') == -1 && $(texter.focusedid).attr('class').indexOf('rectshirt') === -1 && $(texter.focusedid).attr('class').indexOf('squareshirt') === -1 && $(texter.focusedid).attr('class').indexOf('htmel') === -1){
                        if($(texter.focusedid).html().indexOf(' ')===-1){
                            ope+='<span class="opertype" id="anagramoper">anagram</span>';
                        }   
                    }
                }
            }
            
            ope+='</div>';
            
            $('#themover').before(ope);
            
            $('.opertype').on('click',function(event){
                event.stopPropagation();
                
                texter.opertype($(this).html());
                
                $('#operationslist').remove();   
            });
        });
        $('#pagejavascript').on('click',function(event){
            event.stopPropagation();
            
            texter.pagejava();
        });
        $('#pagecss').on('click',function(event){
            event.stopPropagation();
            
            texter.pagecss();
        });
        $('#applyclass').on('click',function(event){
            event.stopPropagation();
            
            texter.applyclass();
        });
        $('#apply').on('click',function(event){
            event.stopPropagation();
            
            texter.applycss();
        });
        $('#savetext').on('click',function(event){
            event.stopPropagation();
            
            texter.save();
        });
        $('#savedlist').on('click',function(event){
            event.stopPropagation();
            
            texter.showlist();
        });
        $('#countermove').on('click',function(event){
            event.stopPropagation();
            
            texter.selectmuchmode();
        });
        $('#theremover').on('click',function(event){
            event.stopPropagation();
            
            texter.removeselected();
        });
        $('#themover').on('click',function(event){
            event.preventDefault();
            event.stopPropagation();
            
            texter.movingmode();
        });
    },
    canvaswrapper:function(){
        $('#canvaswrapper').on('mousedown',function(event){
            if(texteditor.editing){
                return;
            }
            
            event.stopPropagation();
            event.preventDefault();
            
            if($('#textofthemover').html() == 'paste'){
                return;
            }
            
            if(polygon.drawingmode){
                return;
            }
            
            if($('#textofthemover').html() == 'canvas'){
                photox.grabcanvas(event,$('#canvas'));
                return;
            }
            if($('#textofthemover').html() != 'selection'){
                if($('#textofthemover').html() != 'move' && $('#textofthemover').html() != 'ruler'){
                    return;
                }
                
                if(photox.grabed !==false){
                    if($(photox.grabed).attr('class').indexOf('aruler') !== -1){
                        if(photox.rulergrabedtype){
                            $('#ruler_'+photox.grabber[2][0]).css({'left':event.clientX+'px'});
                            photox.rulerposnotif(event.clientX,1);
                        }
                        else{
                            $('#ruler_'+photox.grabber[2][0]).css({'top':event.clientY+'px'});
                            photox.rulerposnotif(event.clientY,0);
                        }
                            
                        $(photox.grabed).removeClass('grabbing');
                        photox.grabed = false;
                        
                        return;
                    }
                    
                    if(texter.focused !==false){
                        photox.grabber[3]=[((event.clientX-photox.grabber[0][0])),((event.clientY-photox.grabber[0][1]))];
                        photox.grabber[1]=[(photox.grabber[1][0]+photox.grabber[3][0]) , (photox.grabber[1][1]+photox.grabber[3][1]) ];
                        
                        $(photox.grabber[2][0]).css({'top':photox.grabber[1][1]+'px'});
                        $(photox.grabber[2][0]).css({'left':photox.grabber[1][0]+'px'});
                        
                        if(texter.selectmerged){
                            photox.movemerged();
                            
                            uredo.cmove.elem[1] = $(photox.grabed)[0].outerHTML;
                            uredo.cmove.elem[2] = $(photox.grabed).attr('id');
                            
                            uredo.registermove(uredo.cmove);
                        }
                        else{
                            uredo.cmove.elem[1] = $(photox.grabber[2][0])[0].outerHTML;
                            uredo.cmove.elem[2] = 'text_'+photox.grabber[2][0];
                            uredo.registermove(uredo.cmove);
                        }
                        
                        photox.grabber[0]=[event.clientX,event.clientY];
                        $(photox.grabed).removeClass('grabbing');
                        
                        $(photox.grabed).replaceWith($(photox.grabed)[0].outerHTML);
                        
                        photox.grabed = false;
                    }
                }
                return;
            }
            
            texter.selectzioncord = [event.clientX,event.clientY,event.clientX,event.clientY];
            texter.selectzionmode = true;
                
            $('#selectzion').remove();
            $('#canvaswrapper').append('<div id="selectzion" style="top:'+texter.selectzioncord[1]+'px;left:'+texter.selectzioncord[0]+'px"></div>');
        });
        $('#canvaswrapper').on('mouseup',function(event){
            if($('#textofthemover').html() == 'canvas'){
                photox.dropcanvas();
                return;
            }
            if(!texter.selectzionmode){
                return;
            }
            
            texter.selectzioncord[4] = Math.min(texter.selectzioncord[0],event.clientX)+(-1 * parseInt($('#canvas')[0].offsetLeft));
            texter.selectzioncord[5] = Math.min(texter.selectzioncord[1],event.clientY)+(-1 * parseInt($('#canvas')[0].offsetTop));
            
            texter.selectzioncord[6] = texter.selectzioncord[4]+Math.abs(texter.selectzioncord[0]-event.clientX);
            texter.selectzioncord[7] = texter.selectzioncord[5]+Math.abs(texter.selectzioncord[1]-event.clientY);
            
            $('#selectzion').remove();
            texter.selectzionmode = false;
            
            texter.blurs();
            $.each($('.textshirt'),function(ti,te){
                texter.selectzioncord[8] = parseInt($(te)[0].offsetTop);
                texter.selectzioncord[9] = parseInt($(te)[0].offsetLeft);
                
                if(texter.selectzioncord[8] > texter.selectzioncord[5] && texter.selectzioncord[8] < texter.selectzioncord[7]){
                    if(texter.selectzioncord[9] > texter.selectzioncord[4] && texter.selectzioncord[9] < texter.selectzioncord[6]){
                        texter.addselections(te);
                        $(te).addClass('selected');
                    }
                }
            });
            
            if(texter.selections.length==1){
                texter.textis(texter.selections[0],false);
            }
        });
        $('#canvaswrapper').on('mousemove',function(event){
            if(!texter.selectzionmode)
                return;
            
            $('#selectzion').css('width',Math.abs(event.clientX-texter.selectzioncord[0])+'px');
            $('#selectzion').css('height',Math.abs(event.clientY-texter.selectzioncord[1])+'px');
            
            texter.selectzioncord[3] = Math.min(event.clientY,texter.selectzioncord[1]);
            texter.selectzioncord[2] = Math.min(event.clientX,texter.selectzioncord[0]);
            
            $('#selectzion').css('top',texter.selectzioncord[3]+'px');
            $('#selectzion').css('left',texter.selectzioncord[2]+'px');
        });
        $('#canvaswrapper').on('mousewheel',function(event){
            event.stopPropagation();
            
            if($('#textofthemover').html() == 'canvas'){
                if(event.ctrlKey){
                    if(event.originalEvent.deltaY>0){
                        ipcRenderer.send('asynchronous-message', 'zoomout<edsep>');
                    }
                    else{
                        ipcRenderer.send('asynchronous-message', 'zoomin<edsep>');
                    }
                    return;
                }
                photox.canvasoffset[1] -= event.originalEvent.deltaY;
                $('#canvas').css('top',photox.canvasoffset[1]);
                
                $('#countermove').html(photox.canvasoffset[0]+','+photox.canvasoffset[1]);
            }
        });
    },
    keyup:function(){
        $('body').on('keyup',function(event){
            if(texteditor.editing){
                return;
            }
            if(event.which == 27){
                if(typeof $('#ace_settingsmenu').attr('id') !== 'undefined'){
                    $('#ace_settingsmenu').parent().parent().remove();
                    $('#javasett').removeClass('set');
                    return;
                }
                if(dialogbox.active){
                    $('.regiformfoc').removeClass('regiformfoc').blur();
                    dialogbox.close();
                    return;   
                }
                
                if(texter.focused !== false){
                    texter.blurs();
                    $('#textshirt').focus().addClass('regiformfoc');
                    return;
                }
                
                texter.showlist();
                return;
            }
            if(event.which == 70 && event.ctrlKey){
                if(dialogbox.active && dialogbox.title == 'List'){
                    texter.searchfromlist__();
                }
                return;
            }
            if(event.which == 74 && event.ctrlKey){
                texter.pagejava();
                return;
            }
            if(dialogbox.active){
                return;
            }
            if(typeof $('.regiformfoc').attr('class') !== 'undefined'){
                return;
            }
            
            if(event.which == 107 && event.ctrlKey){
                ipcRenderer.send('asynchronous-message', 'zoomin<edsep>');
                return;
            }
            
            if(event.which == 109 && event.ctrlKey){
                ipcRenderer.send('asynchronous-message', 'zoomout<edsep>');
                return;
            }
            if(event.which == 48 && event.ctrlKey){
                ipcRenderer.send('asynchronous-message', 'resetzoom<edsep>');
                return;
            }
            if(event.which == 85 && event.ctrlKey){
                texter.viewsource();   
                return;
            }
            if(event.which == 9 && event.ctrlKey){
                pagesheets.navsheet();
                return;
            }
            if(event.which == 78){
                if(event.ctrlKey){
                    if(!texter.saved.length)
                        return;
                        
                    pagesheets.newsheet();
                }
                return;
            }
            
            if(event.which == 46){
                texter.removeselected();
                return;
            }
            if(event.which == 83){
                if(event.ctrlKey){
                    if(!texter.saved.length)
                        return;
                        
                    if(dialogbox.checkexists('Saving'))
                        return;
                    
                    dialogbox.mbox(['Save Page','Saving...','']);
                    
                    editors.javaorder();
                    $.ajax({
                        url:'./',
                        type:'POST',
                        data:{app:appname,p:'textshirt',a:'savedsaved',d:{id:texter.saved[1],content:pagesheets.thecompleteset()}}
                    }).done(function(msg){
                        dialogbox.close();
                        msg=JSON.parse(msg);
                        
                        dialogbox.mbox(['save','saved!','']);
                    });
                    return;
                }
                if($('#textofthemover').html() == 'selection'){
                    texter.movingmode();
                    return;
                }
                texter.opertype('selection');
                return;
            }
            if(event.which == 68 && event.ctrlKey){
                if($('#textofthemover').html() == 'drawline'){
                    polygon.polygon();
                    return;
                }
                texter.opertype('drawline');
                return;
            }
            if(event.which == 89 && event.ctrlKey){
                uredo.redo();
                return;
            }
            if(event.which == 90 && event.ctrlKey){
                uredo.undo();
                return;
            }     
            if(event.which == 76){
                if($('#textofthemover').html() == 'line'){
                    texter.newline();
                    return;
                }
                texter.opertype('line');
                return;
            }
            if(event.which ==73){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'circle'){
                        texter.movingmode();
                        return;
                    }
                    texter.opertype('circle');
                    return;
                }
            }
            if(event.which == 67){
                if(event.ctrlKey){
                    cutpaste.copy();
                    return;
                }
                if($('#textofthemover').html() == 'clone'){
                    texter.movingmode();
                    return;
                }
                texter.opertype('clone');
                return;
            }
            if(event.which == 88){
                if(event.ctrlKey){
                    cutpaste.cut();
                    return;
                }
                
                texter.opertype('canvas');
            }
            if(event.which == 86){
                if(event.ctrlKey){
                    cutpaste.paste();
                    return;
                }
            }
            if(event.which == 77){
                event.preventDefault();
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'merge' || $('#textofthemover').html() == 'unmerge'){
                        texter.movingmode();
                        return;
                    }
                    texter.opertype('merge');
                    return;
                }
                if($('#textofthemover').html() == 'move'){
                    texter.movingmode();
                    return;
                }
                texter.opertype('move');
                return;
            }
            if(event.which == 71){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'rectangle'){
                        texter.movingmode();
                        return;
                    }
                    texter.opertype('rectangle');
                    return;
                }
            }
            if(event.which == 81 && event.ctrlKey){
                if($('#textofthemover').html() == 'square'){
                    texter.movingmode();
                    return;
                }
                texter.opertype('square');
                return;
            }
            if(event.which == 89){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'drawline'){
                        texter.movingmode();
                        return;
                    }
                    texter.opertype('drawline');
                    return;
                }
            }
            if(event.which == 69){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'animate'){
                        texter.movingmode();
                        return;
                    }
                    texter.opertype('animate');
                    return;
                }
            }
            if(event.which == 82){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'charts'){
                        charts.box();
                        return;
                    }
                    texter.opertype('charts');
                    return;
                }
                if($('#textofthemover').html() == 'ruler'){
                    theruler.mocinmode();
                    return;
                }
                texter.opertype('ruler');
                return;
            }
            if(event.which == 84){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'texteditor'){
                        texteditor.edit();
                        return;
                    }
                    texter.opertype('texteditor');
                    return;                    
                }
                if($('#textofthemover').html() == 'transform'){
                    texter.movingmode();
                    return;
                }
                texter.opertype('transform');
                return;
            }
            if(event.which == 80){
                if(event.ctrlKey){
                    if($('#textofthemover').html() == 'paper'){
                        paper.box();
                        return;
                    }
                    texter.opertype('paper');
                    return;                    
                }
            }
        });
        
        $('#textshirt').on('keyup',function(event){
            if(event.which == 13){
                texter.add($('#textshirt').val());
                return;
            }
            if(event.which == 90 && event.ctrlKey){
                if($(this).attr('class').indexOf('filled') === -1){
                    $(this).blur();
                    uredo.undo();
                    return;
                }
            }
            if(event.which == 27){
                $(this).blur();
            }
            
            htmel.list(this);
        });
        $('#changetext').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 27){
                $(this).blur();
                $('#changetext_area').remove();
                return;
            }
            texter.changetext(event);
        });
        $('body').delegate('#csstext','keyup',function(event){
            if(event.which == 13){
                texter.applycss();
                return;
            }
            
            if(event.which == 27){
                $('#cssapartone').remove();
                $(this).removeClass('focus');
                $(this).blur();
            }
        });
        $('body').delegate('#classtext','keyup',function(event){
            if(event.which == 13)
                texter.applyclass();
        });
    },
    keydown:function(){
        $('body').on('keydown',function(event){
            if((event.which == 81 || event.which == 87) && event.ctrlKey){
                event.preventDefault();
            }
            
            if(texteditor.editing){
                return;
            }
            if(event.which === 112){
                dialogbox.init();
                return;
            }
            if(!dialogbox.active && $.inArray(event.which,[83,82,81,76,65,67,77,71,89,69,68]) !== -1){
                event.preventDefault();
            }
            event.stopPropagation();
            if(!dialogbox.active && (event.which==38||event.which==40 ||event.which==39||event.which==37 || event.which == 33 || event.which == 34)){
                texter.textmovebyarrow(event.which);
                return;
            }
            if(!dialogbox.active && event.which==65 && event.ctrlKey){
                texter.selectall();
                return;
            }
            if(event.which==116){
                texter.showall();
            }
        });
    },
    contextmenu:function(){
        $('#themover').on('contextmenu',function(event){
            event.stopPropagation();
            texter.mocinmode();
        });
        $('body').delegate('#csstext','contextmenu',function(event){
            event.stopPropagation();
            
            if(texter.selectallmode){
                return;
            }
            if(texter.selectmuchmode_){
                return;
            }
            
            if(typeof $(this).prev().attr('id')==='undefined'){
                texter.cssapart();
            }
            else{
                $('#cssapartone').remove();
            }
        });
        $('.teedesc').on('contextmenu',function(event){
            event.stopPropagation();
            
            texter.gettee_source($(this).html().split('<span')[0],$(this).attr('id').split('_')[1]);
        });
        $('#changetext').on('contextmenu',function(event){
            event.stopPropagation();
            
            texter.changetext_area();
        });
        $('#canvaswrapper').delegate('.aruler','contextmenu',function(event){
            event.stopPropagation();
            
            photox.grabed = false;
            
            theruler.mocinmode_insuspense = false;
            photox.rulerposnotif(0,false);
            
            $(this).remove();
        });
        $('#canvaswrapper').delegate('.textshirt','contextmenu',function(event){
            event.stopPropagation();
            event.preventDefault();
            
            if($('#textofthemover').html() == 'paste'){
                cutpaste.snappaste(false);
                return;
            }
            
            if(typeof $('#canvas').attr('class') !== 'undefined' && $('#canvas').attr('class').indexOf('animation')!==-1){
                transformer.stopanimation();
                return;
            }
            
            if(texteditor.editing && $(this).attr('id') == texteditor.editing){
                return;
            }

            texter.blurs();
        });
        $('#canvaswrapper').delegate('#canvas','contextmenu',function(event){
            event.stopPropagation();
            
            if($('#textofthemover').html() == 'paste'){
                cutpaste.snappaste(false);
                return;
            }
            if($('#textofthemover').html() == 'drawline'){
                polygon.polygon();
                return;
            }
            if(typeof $('#canvas').attr('class') !== 'undefined' && $('#canvas').attr('class').indexOf('animation')!==-1){
                transformer.stopanimation();
                return;
            }
            texter.blurs();
        });
        $('#pageid').on('contextmenu',function(event){
            event.stopPropagation();
            texter.pageview(true);
        });
        $('#textshirt').on('contextmenu',function(event){
            texter.shifttexter();
        });
        $(dialogbox.titlebox).on('click contextmenu',function(event){
            event.stopPropagation();
            event.preventDefault();
            
            
            if(event.type == 'contextmenu'){
                $('.messagebox').css('opacity',(Math.max(0,(parseFloat($('.messagebox').css('opacity'))-0.1))));
            }
            else{
                $('.messagebox').css('opacity',(Math.min((parseFloat($('.messagebox').css('opacity'))+0.1),1)));
            }
        });
    }
};
var dialogbox = {
    box:[],
    boxidx:0,
    active:false,
    title:false,
    content:false,
    action:false,
    checkexists:function(title){
        for(var i=0;i<dialogbox.box.length;i++){
            if(dialogbox.box[i].title == title){
                dialogbox.switchactive(i);
                return true;
            }
        }
        
        return false;
    },
    switchactive:function(idx){
        if(dialogbox.boxidx == idx){
            $(dialogbox.box[idx].box).addClass('active');
        }
        else{
            for(var i=0;i<dialogbox.box.length;i++){
                if(i!=idx){
                    $(dialogbox.box[i].box).removeClass('active');
                }
                else{
                    $(dialogbox.box[i].box).addClass('active');
                }
            }
            dialogbox.boxidx = idx;   
        }
        dialogbox.actionbox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxaction')[0];
        dialogbox.titlebox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxtitle')[0];
        dialogbox.contentbox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxcontent')[0];
        
        dialogbox.title = dialogbox.box[dialogbox.boxidx].title;
        dialogbox.content = dialogbox.box[dialogbox.boxidx].content;
        dialogbox.action = dialogbox.box[dialogbox.boxidx].action;
    },
    refresh:function(){
        $('.messagebox').remove();
        dialogbox.box=[];
        dialogbox.boxidx=0;
        dialogbox.active=false;
        dialogbox.title=false;
        dialogbox.content=false;
        dialogbox.action=false;
    },
    mbox:function(boxelem,classtype,cbf){
        dialogbox.title = boxelem[0];
        dialogbox.content = typeof boxelem[1] === 'string' ? boxelem[1] : '';
        dialogbox.action = typeof boxelem[2] === 'string' ? boxelem[2] : '';
        
        dialogbox.boxidx = dialogbox.box.length;
        dialogbox.box[dialogbox.boxidx] = new messagebox();
        dialogbox.box[dialogbox.boxidx].id = dialogbox.boxidx;
        dialogbox.box[dialogbox.boxidx].box = $('#messagebox')[0];
        
        while(typeof $(dialogbox.box[dialogbox.boxidx].box).next().attr('class') !== 'undefined' && $(dialogbox.box[dialogbox.boxidx].box).next().attr('class').indexOf('messagebox')!==-1){
            dialogbox.box[dialogbox.boxidx].box = $(dialogbox.box[dialogbox.boxidx].box).next();
        }
            $(dialogbox.box[dialogbox.boxidx].box).after($('#messagebox')[0].outerHTML);
            $(dialogbox.box[dialogbox.boxidx].box).next().prop('id','messagebox_'+dialogbox.boxidx).addClass('messagebox');   
        
        $.each($('#messagebox_'+dialogbox.boxidx).children(),function(mi,me){
            $(me).addClass($(me).attr('id'));
            $(me).prop('id',$(me).attr('id')+'_'+dialogbox.boxidx);
        });
        
        $('#messagebox_'+dialogbox.boxidx).addClass('active');
        if(typeof classtype === 'string'){
            $('#messagebox_'+dialogbox.boxidx).addClass(classtype);
        }
        dialogbox.box[dialogbox.boxidx].displayfunc(dialogbox.title,dialogbox.content,dialogbox.action);
        
        dialogbox.box[dialogbox.boxidx].box = $('#messagebox_'+dialogbox.boxidx)[0];
        dialogbox.actionbox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxaction')[0];
        dialogbox.titlebox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxtitle')[0];
        dialogbox.contentbox = $('#messagebox_'+dialogbox.boxidx).children('.messageboxcontent')[0];
        
        $('#messagebox_'+dialogbox.boxidx).find('.closemessagebox').prop('id','closemessagebox_'+dialogbox.boxidx).addClass('closemessagebox');
        
        if(typeof cbf == 'function')
            cbf();
                
        dialogbox.active = true;
        
        return dialogbox.box[dialogbox.boxidx].id;
    },
    init:function(){
        messagebox.prototype.close = function(){
            $('#messagebox_'+this.id).remove();
        };
        messagebox.prototype.displayfunc = function(title,content,action){
            this.title = title;
            this.content = content;
            this.action = action;
            this.action = '<span class="closemessagebox"><span id="thexsign">X</span>Close</span>'+this.action;
        
            $('#messageboxtitle_'+this.id).html(this.title);
            $('#messageboxcontent_'+this.id).find('.tablecell').html(this.content);
            $('#messageboxaction_'+this.id).html(this.action);
            $('#messageboxmsg_'+this.id).html(this.msg).removeClass('error active');
        };
        $('body').delegate('.closemessagebox','click',function(event){
            event.stopPropagation();
            
            dialogbox.closebox(this.id.split('_')[1]);
        });

        
        var boxaction = '';
        boxaction+='<span id="helper">Help</span>';
        boxaction+='<span style="float:left;margin:0px;" id="about">About</span>';
        boxaction+='<span style="float:left;" id="license">License</span>';
        
        dialogbox.mbox(['Welcome To Textshirt','Textshirt 1.0',boxaction],'',function(){
           $('#license').on('click',function(event){
                event.stopPropagation();
                
                var lic = '<p id="licensedetail">';
                lic+='Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:';
    			lic+='<br/><br/>The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.';
    			lic+='<br/><br/><br/><br/>THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.';
    			lic+='</p>';
                dialogbox.mbox(['License',lic,''],'',function(){
                    $('#license_back').on('click',function(event){
                        event.stopPropagation();
                        
                        dialogbox.init();
                    }); 
                });
            });
            $('#helper').on('click',function(event){
                event.stopPropagation();
                
                var helper = $('#app_helper').html();
                dialogbox.mbox(['Help',helper,''],'extrawide',function(){
                    $('#helper_back').on('click',function(event){
                        event.stopPropagation();
                        
                        dialogbox.init();
                    }); 
                });
            });
            $('#about').on('click',function(event){
                event.stopPropagation();
                
                var about = $('#app_about').html();
                dialogbox.mbox(['About Textshirt',about,''],'extrawide',function(){
                    $('#about_back').on('click',function(event){
                        event.stopPropagation();
                        
                        dialogbox.init();
                    }); 
                });
            }); 
        });
    },
    close:function(){
        if(dialogbox.box.length){
            dialogbox.box[dialogbox.boxidx].close();
            dialogbox.box.splice(dialogbox.boxidx,1);
            dialogbox.boxidx--;
            
            if(dialogbox.boxidx==-1){
                dialogbox.boxidx=0;
            }
            
            if(!dialogbox.box.length){
                dialogbox.refresh();
                return;
            }
            
            dialogbox.switchactive(dialogbox.boxidx);
        }
        else{
            dialogbox.refresh();
        }
    },
    closebox:function(id){
        dialogbox.boxidx = parseInt(id);
        
        for(var i=0;i<dialogbox.box.length;i++){
            if(dialogbox.box[i].id == dialogbox.boxidx){
                dialogbox.box[i].close();
                dialogbox.box.splice(i,1);
                dialogbox.boxidx--;
                break;
            }
        }
        if(dialogbox.boxidx==-1){
            dialogbox.boxidx=0;
        }
        
        if(!dialogbox.box.length){
            dialogbox.refresh();
            return;
        }
        
        dialogbox.switchactive(dialogbox.boxidx);
    }
};
function globalacesettingsmenu(cursorx,cursory){
    if(cursorx===false && cursory===false){
        if(typeof $('#ace_settingsmenu').attr('id') !== 'undefined'){
            $('#ace_settingsmenu').parent().parent().remove();
            $('#javasett').removeClass('set');
            return;
        }
        if($('#browseview').attr('class').indexOf('maximized') !== -1){
            cursorx = $('#browseview').width()-parseInt($('#javasett').css('right'))+parseInt($('#javasett').width());
            cursory = 10;            
        }
        else{
            cursorx = $('#browser')[0].offsetLeft+$('#browseview')[0].offsetLeft+$('#browseview').width()+parseInt($('#browser').css('padding-left'))+parseInt($('#browser').css('padding-right'))-16;
            cursory = $('#browser')[0].offsetTop+parseInt($('#browser').css('margin-top'))+parseInt($('#browser').css('padding-top'))+parseInt($('#browser').css('padding-bottom'));   
        }
    }
    
    $('#javasett').addClass('set');
    cursory-=(300+27);
    cursorx-=(500+18);

    ace.config.loadModule("ace/ext/settings_menu", function(module) {
        module.init(editors.editor2[editors.currentcode]);
        editors.editor2[editors.currentcode].showSettingsMenu();
        
        $('.ace_closeButton').parent().remove();
        $('#ace_settingsmenu').css('width','100%');
        $('#ace_settingsmenu').css('height','100%');
        $('#ace_settingsmenu').parent().parent().css('width','500px');
        $('#ace_settingsmenu').parent().parent().css('height','300px');
        $('#ace_settingsmenu').parent().parent().css('top',cursory+'px');
        $('#ace_settingsmenu').parent().parent().css('left',cursorx+'px');
        
        $('#ace_settingsmenu').find('div').eq($('#ace_settingsmenu').find('div').length-1).addClass('last');
        $('#ace_settingsmenu').children('.last').css('padding','1em 0px 0px 0px');
        $('#ace_settingsmenu').css('padding-bottom','15px');
        
        $('#setFontSize').prop('type','number').val(editors.fontsize);
        $('#setFontSize').on('change',function(event){
            event.stopPropagation();
            
            editors.fontsize = parseInt($(this).val());
            editors.editor2[editors.currentcode].setFontSize(editors.fontsize);
        });
            editors.editor2[editors.currentcode].commands.removeCommands([{
                    name: "showSettingsMenu"
            }]);
    }); 
}
function globaltogglefileview(){
    if(dialogbox.title != 'page java'){
        return;
    }
    if(editors.codenum > 1){
        editors.currentcode++;
        if(editors.currentcode == editors.codenum){
            editors.currentcode = 0;
        }
        
        if($('#jc_'+editors.currentcode).attr('class').indexOf('dormant') !== -1){
            globaltogglefileview();
            return;
        }
        
        editors.switchcode('jc_'+editors.currentcode);
    }
}
function globalmaxmineditor(){
    texter.showall();
}
function globalsaveeditorfile(){
    editors.savecode();
}
function globaltoggleautocomplete(){
    editors.toggleautocomplete();
}
function registaforminputaction(elem){
    if(typeof($(elem).attr('class')) !== 'undefined' && $(elem).attr('class').indexOf('filled') !== -1){
        return;
    }
    if(typeof($(elem).attr('name')) !== 'undefined') {
        var formarray = $(elem).attr('name').indexOf('[');
        if(formarray == -1){
            formarray = ($(elem).attr('name').length);
        }
        if($(elem).val() != $(elem).attr('name')){
            $(elem).addClass('filled');
        }
    }
}
function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
    var findselect = inputtypes.split(',');
    if($.inArray('select',findselect) !==-1){
        $(containerid).delegate('select','change',function(event){
            event.stopPropagation();
            if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
                return;
            }
            if(typeof($(this).attr('name')) !== 'undefined') {
                var formarray = $(this).attr('name').indexOf('[');
                if(formarray == -1){
                    formarray = ($(this).attr('name').length);
                }
                if($(this).val() != $(this).attr('name')){
                    $(this).addClass('filled');
                }
            }
        });
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        $(this).addClass('regiformfoc');
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
        }
    });
    $(containerid).delegate(inputtypes,'keyup',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if($(this).val() != $(this).attr('name')){
                $(this).addClass('filled');
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            
            if ($(this).val() == '') {
                $(this).val($(this).attr('name').substr(0,formarray)).removeClass('filled');
            }
        }
    });
    $(containerid).delegate(inputtypes,'keydown',function(event){
        event.stopPropagation();
        
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if($(this).val() != $(this).attr('name')){
                $(this).addClass('filled');
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            $(this).removeClass('regiformfoc');
            
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text'); 
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }   
        }
    });
}