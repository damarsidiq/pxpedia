$(document).ready(
    function () {
        var cvg = $('#canvas').css('background') == '' ? '#000000' : $('#canvas').css('background');
        $('#canvas').css('background',cvg);
        
    }
);