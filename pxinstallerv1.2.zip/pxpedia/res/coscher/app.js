var confirmbox;

function editcolor(elempos,addstyleval,addstyleident){
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'ajax',a:'editstyle',d:{elempos:elempos,styleval:addstyleval,styleident:addstyleident,savedoriginalid:changetracking.savedoriginalid}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        var data = msg.data;
        var skip = false;
        var replacer = '';
        var datachanged = [];
        for(var i=0;i<data.length;i++){
            skip = false;
            $.each($('.parsedident'),function(pi,pe){
                if($(pe).html() == data[i].element){
                    if($(pe).siblings('.ctype').html() == data[i].type){
                        if($(pe).parent().siblings('.parsedcolor').html() == data[i].color){
                            skip = true;
                            return false;
                        }
                    }
                }
            });
            if(!skip){
                replacer += '<li id="'+data[i].elempos+'" class=""><div class="linenum">'+data[i].elempos.split('_')[2]+'</div><div class="oripalette"><span class="parsedelem"><span class="parsedident">'+handlecsssub(data[i])+'</span><span class="separator">|</span><span class="ctype">'+data[i].type+'</span></span><span class="editcolor">#</span><span class="delcolor">-</span><span class="addcolor">+</span><span class="cpalette" style="background:'+data[i].color+'"></span><span class="parsedcolor">'+data[i].color+'</span></div><div class="editingpalette"><input type="color" class="editedcolor" value="'+data[i].color+'"><span class="parsedcolor">'+data[i].color+'</span></span></div></li>';
            }
        }
        $('#'+elempos).replaceWith(replacer);
        if(changetracking.islive){
            var styleparam = addstyleident+'{'+addstyleval+'}';
            document.getElementById('livewebview').executeJavaScript("editstyle('"+styleparam+"')");
        }
            
        confirmbox.close(); 
    });
}

var editors = {
    editor1:false,
    editor2:false,
    oricode:function(msg){
        $('#orisourcepage').addClass('active');
        adjusttoolbar(true);
        $('#pagelabel').removeClass('hide').find('.tablecell').html('Original Source');
        
        $('#orisourcepage').html('<pre id="codeeditedori">'+msg.sourcecode+'</pre>');
        this.editor2 = ace.edit('codeeditedori');
        this.editor2.setOption("useWorker", false);
        this.editor2.setTheme('ace/theme/mono_industrial');
        this.editor2.session.setMode("ace/mode/css");
        this.editor2.setFontSize(12);
        this.editor2.$blockScrolling = Infinity;
        this.editor2.setShowPrintMargin(false); 
    },
    editedcode:function(msg){
        $('#editsourcepage').addClass('active').children().html(msg.sourcecode); 
        adjusttoolbar(true);
        $('#pagelabel').removeClass('hide').find('.tablecell').html('Edited Source');
        
        this.editor1 = ace.edit('codeedited');
            
        this.editor1.setOption("useWorker", false);
        this.editor1.setTheme('ace/theme/ambiance');
        this.editor1.session.setMode("ace/mode/css");
        this.editor1.setFontSize(12);
        this.editor1.$blockScrolling = Infinity;
        this.editor1.setShowPrintMargin(false);
    }
};

var boxfunc={
    savestyle:function(elempos){
        var addstyleval = $('#editstylestyles').val();
        var addstyleident = $('#editstyleidentifier').val();
        if(addstyleval == '' || addstyleval == 'style' || addstyleident=='' || addstyleident =='identifier'){
            return;
        }
        editcolor(elempos,addstyleval,addstyleident);
    },
    delstyle:function(elempos){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'postparsed',a:'delstyle',d:{elempos:elempos,savedoriginalid:changetracking.savedoriginalid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            displayresults(msg.data);
            if(changetracking.islive){
                for(var odx = 0;odx<datachanged.length;odx++){
                    changetracking.changelive(datachanged[odx]);
                }
            }
            confirmbox.close(); 
        });
    },
    filterlist:function(elem){
        var filterlistval = [];
        var filterlistvalidx = 0;
        $.each($(elem).parent().children('.filtercont'),function(i,e){
            filterlistvalidx = filterlistval.length;
            filterlistval[filterlistvalidx]=[];
            $.each($(e).children(),function(ii,ee){
                if($(ee).attr('class') != 'remfilter' && $(ee).attr('class') != 'addfilter'){
                    if($(ee).attr('name') != $(ee).val()){
                        if($(ee).attr('name') == 'attribute type')
                            filterlistval[filterlistvalidx].name = $(ee).val().trim();
                        else
                            filterlistval[filterlistvalidx].value = $(ee).val().trim().toLowerCase();   
                    }
                    else{
                        filterlistval.splice(filterlistvalidx,1);
                        return false;
                    }   
                }
            });
        });
        
        
        if(filterlistval.length){
            listfiltering.filterlist(filterlistval);
        }
    },
    submitliveprev:function(){
        var url = $('#liveurl').val();
        $('body').addClass('liveprev');
        $('#resultpage').before('<webview id="livewebview" src="'+url+'" class="active" plugins preload="file://localhost/media/damarsidiq/pxpedia/res/coscher/webviewipc.min.js" allowpopups disablewebsecurity webpreferences="allowRunningInsecureContent"></webview>');
        $('header').append(liveprevact.toolbardiv);
        $('.taskbox').removeClass('active');
        $('#livepreview').addClass('disabled');
        changetracking.liveurl = url;
        
            document.getElementById('livewebview').addEventListener('dom-ready', function(){
                $('#livewebview')[0].send('ping');
            });
            
            document.getElementById('livewebview').addEventListener('ipc-message', function(event){
                switch(event.channel){
                    case 'thebrohtmlcontentx':
                        changetracking.makelive();
                    break;
                }
            });
    },
    addstyle:function(elempos){
        var addstyleval = $('#addstyleval').val();
        var addstyleident = $('#addstyleident').val();
        if(addstyleval == '' || addstyleval == 'style' || addstyleident=='' || addstyleident =='identifier'){
            return;
        }
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'ajax',a:'addstyle',d:{styleval:addstyleval,styleident:addstyleident,savedoriginalid:changetracking.savedoriginalid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            var data = msg.data;
            var skip = false;
            var replacer = '';
            var datachanged = [];
            for(var i=0;i<data.length;i++){
                skip = false;
                $.each($('.parsedident'),function(pi,pe){
                    if($(pe).html() == data[i].element){
                        if($(pe).siblings('.ctype').html() == data[i].type){
                            if($(pe).parent().siblings('.parsedcolor').html() == data[i].color){
                                skip = true;
                                return false;
                            }
                        }
                    }
                });
                if(!skip){
                    replacer += '<li id="'+data[i].elempos+'" class=""><div class="linenum">'+data[i].elempos.split('_')[2]+'</div><div class="oripalette"><span class="parsedelem"><span class="parsedident">'+handlecsssub(data[i])+'</span><span class="separator">|</span><span class="ctype">'+data[i].type+'</span></span><span class="editcolor">#</span><span class="delcolor">-</span><span class="addcolor">+</span><span class="cpalette" style="background:'+data[i].color+'"></span><span class="parsedcolor">'+data[i].color+'</span></div><div class="editingpalette"><input type="color" class="editedcolor" value="'+data[i].color+'"><span class="parsedcolor">'+data[i].color+'</span></span></div></li>';
                
                    if(changetracking.islive){
                        data[i].value = data[i].color;
                        datachanged[datachanged.length] = data[i];
                    }
                }
            }
            $(elempos).after(replacer);
            if(changetracking.islive){
                for(var odx = 0;odx<datachanged.length;odx++){
                    changetracking.changelive(datachanged[odx]);
                }
            }
            
            confirmbox.close();
        });
    }
};

$(document).ready(
    function () {
        $('#loadfileurl').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which==13){
                var url = $(this).val();
                if(url!='' && url !='url')
                    fetchfileurl(url,'external');
            }
        });
        $('body').delegate('.delcolor','click',function(event){
            event.stopPropagation();
            
            var elempos = $(this).parent().parent().attr('id');
            
            var title = 'Remove Style';
            var boxcontent = '';
            var boxaction = '<span id="delstyle">Confirm</span>';
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(title,boxcontent,boxaction);
            $('#messagebox').addClass('wide');
            
            $('#delstyle').on('click',function(event){
                event.stopPropagation();
                
                boxfunc.delstyle(elempos);
            });
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'ajax',a:'getstyle',d:{elempos:elempos,savedoriginalid:changetracking.savedoriginalid}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#messageboxcontent').find('.tablecell').html('<input type="text" disabled="true" name="identifier" class="filled" value="'+msg.styleval.identifier+'" id="editstyleidentifier"><input type="text" name="style" disabled="true" class="filled" value="'+msg.styleval.styles+'" id="delstylestyles">');
            });
        });
        $('body').delegate('.addcolor','click',function(event){
            event.stopPropagation();
            
            var elempos = $(this).parent().parent();
            
            var title = 'Add Style';
            var boxcontent = '<input type="text" name="identifier" value="identifier" id="addstyleident"><input type="text" name="style" value="style" id="addstyleval">';
            var boxaction = '<span id="addstyle">confirm</span>';
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(title,boxcontent,boxaction);
            $('#messagebox').addClass('wide');
            
            $('#addstyleval').on('keyup',function(event){
                event.stopPropagation();
                if(event.which ==13){
                    boxfunc.addstyle(elempos);
                }
            });
            
            $('#addstyle').on('click',function(event){
                event.stopPropagation();
                
                boxfunc.addstyle(elempos);
            });
        });
        $('body').delegate('.parsedident','click',function(event){
            event.stopPropagation();
            
            var pc = $(this).html();
            $(this).html('<input type="text" value="'+pc+'" class="copyparsed">');
            $(this).children().focus();
        });
        $('body').delegate('.editcolor','click',function(event){
            event.stopPropagation();
            
            var elempos = $(this).parent().parent().attr('id');
            
            var title = 'Edit Style';
            var boxcontent = '';
            var boxaction = '<span id="savestyle">save</span>';
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(title,boxcontent,boxaction);
            $('#messagebox').addClass('wide');
            
            $('#savestyle').on('click',function(event){
                event.stopPropagation();
                
                boxfunc.savestyle(elempos);
            });
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'ajax',a:'getstyle',d:{elempos:elempos,savedoriginalid:changetracking.savedoriginalid}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#messageboxcontent').find('.tablecell').html('<input type="text" name="identifier" class="filled" value="'+msg.styleval.identifier+'" id="editstyleidentifier"><input type="text" name="style" class="filled" value="'+msg.styleval.styles+'" id="editstylestyles">');
                $('#editstylestyles').on('keyup',function(event){
                    event.stopPropagation();
                    
                    if(event.which == 13){
                        boxfunc.savestyle(elempos);
                    }
                });
            });
        });
        $('body').delegate('.remfilter','click',function(event){
            event.stopPropagation();
            
            if($(this).parent().parent().children('.filtercont').length >1){
                $(this).parent().remove();
                return;
            }
            
            $.each($(this).siblings('input[type="text"]'),function(u,e){
                $(e).val($(e).attr('name')).removeClass('filled');
            });
            $(this).parent().children('.filterattr').val('attribute type');
        });
        $('body').delegate('.addfilter','click',function(event){
            event.stopPropagation();
            $(this).parent().after('<div class="filtercont">'+$(this).parent().html()+'</div>');
        });
        
        
        registaforminput('body','input,textarea');
        imageuploadhandlerinit();
        $('#menu').on('click',function(event){
            event.stopPropagation();
            if($(this).attr('class').indexOf('active') === -1){
                $(this).addClass('active');
            }
            else{
                $(this).removeClass('active');
            }
        });
        $('body').on('click',function(event){
            event.stopPropagation();
            
            $('#menu').removeClass('active');
            if(focusedpalette.cobj !== false){
                $('.paletteitem.focused').removeClass('focused');
                focusedpalette.blurfocused();
            }
        });
        $('.menu.toolbar').on('click',function(event){
            event.stopPropagation();
            
            if($(this).attr('class').indexOf('disabled') !== -1){
                return;
            }
            
            switch($(this).attr('id')){
                case 'pagelabel':
                    switch($(this).find('.tablecell').html()){
                        case 'Edited Source':
                        break;
                        case 'Original Source':
                        break;
                    }
                break;
                case 'savefile':
                    changetracking.updatefile();
                break;
                case 'paletteview':
                    paletteviewpage.showpalette();
                break;
                case 'hideori':
                    listfiltering.hideori();
                break;
                case 'bulkrep':
                    if($('#bulkrepbox').attr('class').indexOf('active') === -1)
                        $('#bulkrepbox').addClass('active');
                    else
                        $('#bulkrepbox').removeClass('active');
                break;
                case 'filterlist':
                    if($('#filterlistbox').attr('class').indexOf('active') === -1)
                        $('#filterlistbox').addClass('active');
                    else
                        $('#filterlistbox').removeClass('active');
                break;
                case 'livepreview':
                    if($('#liveprevbox').attr('class').indexOf('active') !== -1){
                        $('#liveprevbox').removeClass('active');
                        return;
                    }
                    livepreviewprep();
                break;
            }
            
            $('#menu').removeClass('active');
        });
        
        $('.menuitem').on('click',function(event){
            event.stopPropagation();
            
            if($(this).attr('class').indexOf('disabled') !== -1){
                return;
            }
            
            switch($(this).html()){
                case 'Previous Sessions':
                    if(!$('#savedsessionbox').find('.sessionitem').length){
                        $.ajax({
                            url:'./',
                            type:'post',
                            data:{app:appname,p:'sessions',a:'sessionlist'}
                        }).done(function(msg){
                            msg = JSON.parse(msg);
                            $.each(msg.sessions,function(mi,me){
                                if(me == changetracking.currsession){
                                    $('#savedsessionbox').append('<div class="sessionitem current">'+me+'</div>');    
                                }
                                else{
                                    $('#savedsessionbox').append('<div class="sessionitem">'+me+'<div class="delsessitem">x</div></div>');
                                }
                            });
                            $('#savedsessionbox').addClass('active');
                        });
                    }
                    else{
                        $('#savedsessionbox').addClass('active');   
                    }
                break;
                case 'Quit':
                    ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
                break;
                case 'Upload File':
                    $('.pagecontent.active').removeClass('active');
                    $('#uploadfilepage').addClass('active');
                    adjusttoolbar(true);
                    $('#pagelabel').removeClass('hide').find('.tablecell').html('Upload File');
                break;
                case 'URL':
                    $('.pagecontent.active').removeClass('active');
                    $('#loadurl').addClass('active');
                    adjusttoolbar(true);
                    $('#pagelabel').removeClass('hide').find('.tablecell').html('File URL');
                break;
                case 'Parsed File':
                    $('.pagecontent.active').removeClass('active');
                    $('#resultpage').addClass('active');
                    adjusttoolbar(false);
                    $('#pagelabel').addClass('hide');
                break;
                case 'Relative Path':
                    $('.pagecontent.active').removeClass('active');
                    $('#loadrelative').addClass('active');
                    adjusttoolbar(true);
                    $('#pagelabel').addClass('hide');
                break;
                case 'Save Session':
                    savesessionbox();
                break;
                case 'Edited URL':
                    var title = 'Edited URl';
                    var boxcontent = '<input type="text" name="file url" value="uploads/parsed/'+changetracking.savedoriginalid+'.css">';
                    var boxaction = '';
                    
                    confirmbox = new messagebox();
                    confirmbox.displayfunc(title,boxcontent,boxaction);
                break;
                case 'Edited Source':
                    $('.pagecontent.active').removeClass('active');
                    $.ajax({
                        url:'./',
                        type:'POST',
                        data:{app:appname,p:'ajax',a:'editedsource',d:{id:changetracking.savedoriginalid}}
                    }).done(function(msg){
                        msg = JSON.parse(msg);
                        editors.editedcode(msg);
                    });
                break;
                case 'Original Source':
                    $('.pagecontent.active').removeClass('active');
                    if($('#orisourcepage').find('.tablecell').html() == ''){
                        $.ajax({
                            url:'./',
                            type:'POST',
                            data:{app:appname,p:'ajax',a:'orisource',d:{id:changetracking.savedoriginalid}}
                        }).done(function(msg){
                            msg = JSON.parse(msg);
                            
                            editors.oricode(msg);
                        });
                    }
                    else{
                        $('#orisourcepage').addClass('active');
                        adjusttoolbar(true);   
                        $('#pagelabel').removeClass('hide').find('.tablecell').html('Original Source');
                    }
                break;
            }
            
            $('#menu').removeClass('active');
        });
        
        $('.taskbox .close').on('click',function(event){
            event.stopPropagation();
            
            $(this).parent().removeClass('active');
        });
        
        $('#fetchfile').on('click',function(event){
            event.stopPropagation();
            var url = $(this).prev().val();
            if(url!='' && url !='url')
                fetchfileurl(url,'external');
        });
        
        $('body').delegate('.delsessitem','click',function(event){
            event.stopPropagation();
            
            var sessnam = $(this)[0].innerHTML.split('<')[0];
            if(changetracking.currsession == sessnam){            
                $('.sessionitem').removeClass('current');
                $(this).addClass('current');
                return;
            }
            
            var title = 'delete session';
            var boxcontent = 'delete session '+sessnam+'?';
            var boxaction = '<span id="confirmdelsession">confirm</span>';
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(title,boxcontent,boxaction);
            
            $('#confirmdelsession').on('click',function(){
                changetracking.delsession(sessnam); 
            });
        });
        $('body').delegate('.sessionitem','click',function(event){
            event.stopPropagation();
            
            if(changetracking.currsession == $(this)[0].innerHTML.split('<')[0]){
                return;
            }
            $('.sessionitem').removeClass('current');
            $(this).addClass('current');
            
            changetracking.loadsession($(this)[0].innerHTML.split('<')[0]);
            
            $('#savedsessionbox').removeClass('active');
        });
        
        $('body').delegate('.editedcolor','change',function(event){
            event.stopPropagation();
            if($(this).val() != $(this).siblings('.parsedcolor').html()){
                changetracking.logchange($(this).parent().parent().attr('id'),$(this).val(),2);
            }
            $(this).siblings('.parsedcolor').html($(this).val());
        });
        
        $('body').delegate('.parsedcolor','click',function(event){
            event.stopPropagation();
            
            if($(this).children().length){
                return;
            }
            
            var pc = $(this).html();
            $(this).html('<input type="text" value="'+pc+'" class="copyparsed">');
            $(this).children().focus();
        });
        
        $('body').delegate('.copyparsed','blur',function(event){
            event.stopPropagation();
            
            $(this).parent().html($(this).val());
        });
        $('#liveurl').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which==13){
                boxfunc.submitliveprev();
            }
        });
        
        $('body').delegate('.filterattrval','keyup',function(event){
            event.stopPropagation();
            
            if(event.which==13){
                boxfunc.filterlist($('#submitfilter'));
            }
        });
        
        $('.submittask').on('click',function(event){
            event.stopPropagation();
            
            switch($(this).attr('id')){
                case 'submitliveprev':
                   boxfunc.submitliveprev();
                break;
                case 'submitbulkrep':
                    listmodifying.bulkrep();
                break;
                case 'resetsubmitfilter':
                    listfiltering.resetfilter();
                break;
                case 'submitfilter':
                    boxfunc.filterlist(this);
                break;
            }
        });
        
        $('body').delegate('#closepreview','click',function(event){
            event.stopPropagation();
            
            $('body').removeClass('liveprev fullprev');
            $('#livepreview').removeClass('disabled');
            $('.livedevtool').addClass('hide');
        });
        
        $('body').delegate('#livedevtool','click',function(event){
            event.stopPropagation();
            
            $('#livewebview')[0].openDevTools();
        });
        $('body').delegate('#reloadprev','click',function(event){
            event.stopPropagation();
            
            $('#livewebview')[0].reload();
        });
        
        $('body').delegate('#livefullscreen','click',function(event){
            event.stopPropagation();
            
            if($('body').attr('class').indexOf('fullprev') === -1){
                $(this).find('.tablecell').html('show panel');
                $('body').addClass('fullprev');
            }
            else{
                $(this).find('.tablecell').html('hide panel');
                $('body').removeClass('fullprev');
            }
        });
        
        $('#adjustcolor').spectrum({
            move: function(color) {
                $('.paletteitem.focused').css('background-color',color.toHexString());
                $('#currentadjustcolor').find('.tablecell').html(color.toHexString());
            },
            hide: function(color) {
                $('.paletteitem.focused').css('background-color',color.toHexString());
                $('#currentadjustcolor').find('.tablecell').html(color.toHexString());
            },
            clickoutFiresChange: false,
            showInput: true,
            preferredFormat: "hex"
        });
        
        $('#paletteviewpage').delegate('.paletteitem','click',function(event){
            event.stopPropagation();
            
            if($('.paletteitem.focused').length){
                $('.paletteitem.focused').removeClass('focused');
            }
            
            $(this).addClass('focused');
            $('#adjustcolor').spectrum('set',$(this).css('background-color'));
            focusedpalette.setfocused($(this).css('background-color'));
        });
        
        $('#oriadjustcolor').on('click',function(event){
            event.stopPropagation();
            
            if($(this).find('.tablecell').children().length){
                $(this).find('.tablecell').html($(this).find('.adjustcolorhexs').val());
                return;
            }
            var cadch = $(this).find('.tablecell').html();
            $(this).find('.tablecell').html('<input type="text" value="'+cadch+'" class="adjustcolorhexs">'); 
            $(this).find('.adjustcolorhexs').focus();
        });
        
        $('#currentadjustcolor').on('click',function(event){
            event.stopPropagation();
            if($(this).find('.tablecell').children().length){
                $(this).find('.tablecell').html($(this).find('.adjustcolorhexs').val());
                return;
            }
            var cadch = $(this).find('.tablecell').html();
            $(this).find('.tablecell').html('<input type="text" value="'+cadch+'" class="adjustcolorhexs">');
            $(this).find('.adjustcolorhexs').focus();
        });
        
        $('#applypalette').on('click',function(event){
            event.stopPropagation();
            
            if(!$('#pvpcontent').children().length){
                return;
            }
            
            paletteviewpage.applychanges();
        });
        
        
        $('.adjustcolor').on('click',function(event){
            event.stopPropagation();
            
            if(focusedpalette.cobj === false){
                return;
            }
            
            switch($(this).attr('id')){
                case 'lightercolor':
                    focusedpalette.lighter();
                break;
                case 'darkercolor':
                    focusedpalette.darker();
                break;
                case 'saturate':
                    focusedpalette.saturate();
                break;
                case 'desaturate':
                    focusedpalette.desaturate();
                break;
            }
        });
        changetracking.initvar();
        
        //fetchfileurl('http://pxpedia/pxpedia/uploads/coscher/bttes.css','external');
    }
);

var focusedpalette = {
    cobj:false,
    ccobj:false,
    updatecurrentadjustcolor:function(){
        if($('#currentadjustcolor').find('.adjustcolorhexs').length){
             $('#currentadjustcolor').find('.adjustcolorhexs').val(this.ccobj.toHexString());
         }
         else{
             $('#currentadjustcolor').find('.tablecell').html(this.ccobj.toHexString());
         }
    },
    darker:function(){
        this.ccobj.darker(3);
        
         $('.paletteitem.focused').css('background-color',this.ccobj.toHexString());
         $('#adjustcolor').spectrum('set',this.ccobj.toHexString());
         
         this.updatecurrentadjustcolor();
    },
    saturate:function(){
        this.ccobj.saturate(3);
        
        $('.paletteitem.focused').css('background-color',this.ccobj.toHexString());
        $('#adjustcolor').spectrum('set',this.ccobj.toHexString());
        this.updatecurrentadjustcolor();
    },
    desaturate:function(){
        this.ccobj.desaturate(3);
        
        $('.paletteitem.focused').css('background-color',this.ccobj.toHexString());
        $('#adjustcolor').spectrum('set',this.ccobj.toHexString());
        this.updatecurrentadjustcolor();
    },
    lighter:function(){
        this.ccobj.lighter(3);
        
        $('.paletteitem.focused').css('background-color',this.ccobj.toHexString());
        $('#adjustcolor').spectrum('set',this.ccobj.toHexString());
        this.updatecurrentadjustcolor();
    },
    setfocused:function(color){
        this.cobj = new w3color(color);
        this.ccobj = new w3color(color);
        
        $('#oriadjustcolor').find('.tablecell').html(this.cobj.toHexString());
        $('#currentadjustcolor').find('.tablecell').html(this.cobj.toHexString());
    },
    blurfocused:function(){
        this.cobj = false;
        $('#oriadjustcolor').find('.tablecell').html('#');
        $('#currentadjustcolor').find('.tablecell').html('#');
    }
};

var paletteviewpage = {
    coscheme:[],
    coschemergba:[],
    coschemeori:[],
    coschemeorirgba:[],
    coschemeobj:[],
    coschemeoriobj:[],
    orischeme:[],
    editscheme:[],
    applychangesori:[],
    applychangesedit:[],
    applychanges:function(){
        paletteviewpage.applychangesori = [];
        $.each($('.paletteitem.oris'),function(pi,pe){
            paletteviewpage.applychangesori[paletteviewpage.applychangesori.length] = $(pe).css('background-color');
        });
        paletteviewpage.applychangesedit = [];
        $.each($('.paletteitem.edits'),function(pi,pe){
            paletteviewpage.applychangesedit[paletteviewpage.applychangesedit.length] = $(pe).css('background-color');
        });
        
        var changes = [];
        var changesidx = 0;
        for(var i=0;i<paletteviewpage.applychangesedit.length;i++){
            if(paletteviewpage.applychangesedit[i] != paletteviewpage.applychangesori[i]){
                changesidx = changes.length;
                changes[changesidx] = [];
                
                paletteviewpage.applychangesori[i] = new w3color(paletteviewpage.applychangesori[i]);
                paletteviewpage.applychangesori[i] = paletteviewpage.applychangesori[i].toHexString();
                paletteviewpage.applychangesedit[i] = new w3color(paletteviewpage.applychangesedit[i]);
                paletteviewpage.applychangesedit[i] = paletteviewpage.applychangesedit[i].toHexString();
                
                changes[changesidx].ori = paletteviewpage.applychangesori[i];
                changes[changesidx].edit = paletteviewpage.applychangesedit[i];
            }
        }
        if(changes.length){
            changetracking.changes[2] = [];
            for(var ci=0;ci<changes.length;ci++){
                $.each($('#parsedres').find('.editingpalette'),function(ei,ee){
                    if($(ee).parent().attr('class').indexOf('hide') === -1){
                        if($(ee).children('.parsedcolor').html().toLowerCase() == changes[ci].ori.toLowerCase()){
                            $(ee).children('.parsedcolor').html(changes[ci].edit);
                            $(ee).children('.editedcolor').val(changes[ci].edit);
                            changetracking.logchange($(ee).parent().attr('id'),changes[ci].edit,2);
                        }
                    }
                });
            }
            $('#paletteviewpage').removeClass('active');
            $('#resultpage').addClass('active');
            adjusttoolbar(false);
        }
    },
    showpalette:function(){
        if($('#paletteview').find('.tablecell').html() == 'List View'){
            $('#paletteview').find('.tablecell').html('Palette View');
            adjusttoolbar(false);
            $('.pagecontent.active').removeClass('active');
            $('#resultpage').addClass('active');
            return;
        }
        adjusttoolbar(true);
        
        this.coscheme=[];
        this.coschemergba=[];
        this.coschemeori=[];
        this.coschemeorirgba=[];
        this.coschemeobj=[];
        this.coschemeoriobj=[];
        this.orischeme=[];
        this.editscheme=[];
    
        this.getscheme();
        this.getschemergba();
        this.schemesort();
        this.pagecontent();
        
        $('.pagecontent.active').removeClass('active');
        $('#paletteviewpage').addClass('active');
        $('#paletteview').removeClass('hide').find('.tablecell').html('List View');
    },
    getschemergba:function(){
        for(var i=0;i<this.coschemeobj.length;i++){
            this.coschemergba[i] = this.coschemeobj[i].toRgb();
        }
        
        for(var i=0;i<this.coschemeoriobj.length;i++){
            this.coschemeorirgba[i] = this.coschemeoriobj[i].toRgb();
        }
    },
    schemesort:function(){
        var coori = this.coschemeoriobj.map(function(el,i){
            return { index: i, value: el.whiteness };
        });
        
        coori.sort(function(a, b) {
          if (a.value > b.value) {
            return 1;
          }
          if (a.value < b.value) {
            return -1;
          }
          return 0;
        });
        
        this.orischeme = coori.map(function(el){  return paletteviewpage.coschemeori[el.index]; });
        
        var coedit = this.coschemeobj.map(function(el,i){
            return { index: i, value: el.whiteness };
        });
        coedit.sort(function(a, b) {
          if (a.value > b.value) {
            return 1;
          }
          if (a.value < b.value) {
            return -1;
          }
          return 0;
        });
        this.editscheme = coedit.map(function(el){  return paletteviewpage.coscheme[el.index]; });
    },
    pagecontent:function(){
        $('#pvpcontent').html('');
        
        var schemestr = '<h3>Original Scheme</h3><div id="schemepaletteori">';
        var pirow = '';
        for(var i=0;i<this.orischeme.length;i++){
            if(i%10 == 0 && i!=0){
                schemestr+='<div class="pirowseparator"></div>';
                pirow = pirow == '' ? ' odd' : '';
            }
            schemestr+='<div class="oris paletteitem'+pirow+'" style="background-color:'+this.orischeme[i]+'"></div>';
        }
        schemestr+='</div>';
        
        $('#pvpcontent').append(schemestr);
        
        schemestr = '<h3>Editing Scheme</h3><div id="schemepalette">';
        pirow = '';
        for(var i=0;i<this.editscheme.length;i++){
            if(i%10 == 0 && i!=0){
                schemestr+='<div class="pirowseparator"></div>';
                pirow = pirow == '' ? ' odd' : '';
            }
            schemestr+='<div class="edits paletteitem'+pirow+'" style="background-color:'+this.editscheme[i]+'"></div>';
        }
        schemestr+='</div>';
        
        $('#pvpcontent').append(schemestr);
    },
    getscheme:function(){
        $.each($('#parsedres').children(),function(oi,oe){
            if($(oe).attr('class').indexOf('hide') === -1){
                if($.inArray($(oe).children('.oripalette').children('.parsedcolor').html(),paletteviewpage.coschemeori) === -1){
                    paletteviewpage.coschemeori[paletteviewpage.coschemeori.length] = $(oe).children('.oripalette').children('.parsedcolor').html();    
                    paletteviewpage.coschemeoriobj[paletteviewpage.coschemeoriobj.length] = new w3color(paletteviewpage.coschemeori[paletteviewpage.coschemeori.length-1]);
                }
                if($.inArray($(oe).children('.editingpalette').children('.parsedcolor').html(),paletteviewpage.coscheme) === -1){
                    paletteviewpage.coscheme[paletteviewpage.coscheme.length] = $(oe).children('.editingpalette').children('.parsedcolor').html();
                    paletteviewpage.coschemeobj[paletteviewpage.coschemeobj.length] = new w3color(paletteviewpage.coscheme[paletteviewpage.coscheme.length-1]);
                }
            }
        });    
    }
}
function adjusttoolbar(hidemode){
    $('#pagelabel').addClass('hide');
    if(hidemode){
        $('.toolbar').addClass('hide');
        return;
    }
    $('.toolbar').removeClass('hide');
    
    if(changetracking.islive && $('body').attr('class').indexOf('liveprev') !==-1){
        $('.livedevtool').removeClass('hide');
    }
    else{
        $('.livedevtool').addClass('hide');    
    }
    
}

listmodifying={
    bulkrep:function(){
        var type = $('#bulkrepbox').find('.filterattr').val().trim();
        var oldval = $('#bulkrepbox').find('.filterattrval').val().trim();
        var newval = $('#bulkrepbox').find('.filterattrvalnew').val().trim();
        
        $('#bulkrepbox').removeClass('active');
        
        if(type == 'attribute type' || oldval =='value' || newval=='replace with'){
            return;
        }
        
        if(listfiltering.listwasfiltered){
            if(listfiltering.orihide){
                $.each($('#parsedres').children(),function(oi,oe){
                    if($(oe).attr('class').indexOf('hide') === -1){
                        switch(type){
                            case 'identifier':
                                if($(oe).find('.parsedelem').children().eq(0).html() == oldval){
                                    $(oe).find('.parsedelem').children().eq(0).html(newval);
                                    changetracking.logchange($(oe).attr('id'),newval,0);
                                }
                            break;
                            case 'styleattr':
                                if($(oe).find('.parsedelem').children().eq(2).html() == oldval){
                                    $(oe).find('.parsedelem').children().eq(2).html(newval);
                                    changetracking.logchange($(oe).attr('id'),newval,1);
                                }
                            break;
                            case 'styleval':
                                if($(oe).find('.parsedcolor').eq(1).html() == oldval){
                                    $(oe).find('.parsedcolor').eq(1).html(newval);
                                    $(oe).find('.parsedcolor').eq(1).siblings().val(newval);
                                    
                                    changetracking.logchange($(oe).attr('id'),newval,2);
                                }
                            break;
                        }
                    }
                });   
            }
            else{
                $.each($('#parsedres').children(),function(oi,oe){
                    if($(oe).attr('class').indexOf('hide') === -1){
                        switch(type){
                            case 'identifier':
                                if($(oe).find('.parsedelem').children().eq(0).html() == oldval){
                                    $(oe).find('.parsedelem').children().eq(0).html(newval);
                                    changetracking.logchange($(oe).attr('id'),newval,0);
                                }
                            break;
                            case 'styleattr':
                                if($(oe).find('.parsedelem').children().eq(2).html() == oldval){
                                    $(oe).find('.parsedelem').children().eq(2).html(newval);
                                    changetracking.logchange($(oe).attr('id'),newval,1);
                                }
                            break;
                            case 'styleval':
                                if($(oe).find('.parsedcolor').eq(0).html() == oldval || $(oe).find('.parsedcolor').eq(1).html() == oldval){
                                    $(oe).find('.parsedcolor').eq(1).html(newval);
                                    $(oe).find('.parsedcolor').eq(1).siblings().val(newval);
                                    
                                    changetracking.logchange($(oe).attr('id'),newval,2);
                                }
                            break;
                        }
                    }
                });
            }
        }
        else{
            if(listfiltering.orihide){
                $.each($('#parsedres').children(),function(oi,oe){
                    switch(type){
                        case 'identifier':
                            if($(oe).find('.parsedelem').children().eq(0).html() == oldval){
                                $(oe).find('.parsedelem').children().eq(0).html(newval);
                                changetracking.logchange($(oe).attr('id'),newval,0);
                            }
                        break;
                        case 'styleattr':
                            if($(oe).find('.parsedelem').children().eq(2).html() == oldval){
                                $(oe).find('.parsedelem').children().eq(2).html(newval);
                                changetracking.logchange($(oe).attr('id'),newval,1);
                            }
                        break;
                        case 'styleval':
                            if($(oe).find('.parsedcolor').eq(1).html() == oldval){
                                $(oe).find('.parsedcolor').eq(1).html(newval);
                                $(oe).find('.parsedcolor').eq(1).siblings().val(newval);
                                
                                changetracking.logchange($(oe).attr('id'),newval,2);
                            }
                        break;
                    }
                });   
            }
            else{
                $.each($('#parsedres').children(),function(oi,oe){
                    switch(type){
                        case 'identifier':
                            if($(oe).find('.parsedelem').children().eq(0).html() == oldval){
                                $(oe).find('.parsedelem').children().eq(0).html(newval);
                                changetracking.logchange($(oe).attr('id'),newval,0);
                            }
                        break;
                        case 'styleattr':
                            if($(oe).find('.parsedelem').children().eq(2).html() == oldval){
                                $(oe).find('.parsedelem').children().eq(2).html(newval);
                                changetracking.logchange($(oe).attr('id'),newval,1);
                            }
                        break;
                        case 'styleval':
                            if($(oe).find('.parsedcolor').eq(0).html() == oldval || $(oe).find('.parsedcolor').eq(1).html() == oldval){
                                $(oe).find('.parsedcolor').eq(1).html(newval);
                                $(oe).find('.parsedcolor').eq(1).siblings().val(newval);
                                
                                changetracking.logchange($(oe).attr('id'),newval,2);
                            }
                        break;
                    }
                });
            }
        }
    }
};

listfiltering={
    orihide:false,
    listwasfiltered:false,
    resetfilter:function(){
        $('#parsedres').children().removeClass('hide');
        $('#submitfilter').parent().removeClass('active');
        this.listwasfiltered = false;
    },
    filterlist:function(filterlistval){
        this.listwasfiltered = true;
        $('#parsedres').children().removeClass('hide');
        $('#submitfilter').parent().removeClass('active');
        var hide;
        $.each($('#parsedres').children(),function(oi,oe){
            hide = filterlistval.length;
            for(var i=0;i<filterlistval.length;i++){
                switch(filterlistval[i].name){
                    case 'identifier':
                        if($(oe).find('.parsedelem').children().eq(0).html().indexOf(filterlistval[i].value) !== -1){
                            hide -= 1;
                        }
                    break;
                    case 'styleattr':
                        if(filterlistval[i].value == $(oe).find('.parsedelem').children().eq(2).html()){
                            hide -= 1;
                        }
                    break;
                    case 'styleval':
                        if(listfiltering.orihide){
                            if($(oe).find('.parsedcolor').eq(1).html().toLowerCase() == filterlistval[i].value){
                                hide -= 1;
                            }
                        }
                        else{
                            if($(oe).find('.parsedcolor').eq(0).html().toLowerCase() == filterlistval[i].value || $(oe).find('.parsedcolor').eq(1).html().toLowerCase() == filterlistval[i].value){
                                hide -= 1;
                            }   
                        }
                    break;
                }
            }
            if(hide){
                $(oe).addClass('hide');
            }
        });
    },
    hideori:function(){
        if(this.orihide){
            this.orihide = false;
            $('#parsedres').find('.oripalette').children('.parsedcolor').removeClass('hide').siblings('.cpalette').removeClass('hide');
            $('#hideori').find('.tablecell').html('Hide Original');
            return;
        }
        
        $('#hideori').find('.tablecell').html('Show Original');
        this.orihide = true;
        $('#parsedres').find('.oripalette').children('.parsedcolor').addClass('hide').siblings('.cpalette').addClass('hide');
    }
};
function savesessionbox(){
    var title = 'save session';
    var boxcontent = '<input type="text" name="session name" value="session name" id="thesessionname">';
    var boxaction = '<span id="savesession">save</span>';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(title,boxcontent,boxaction);
    
    $('#thesessionname').on('keyup',function(event){
        event.stopPropagation();
        
        if(event.which == 13){
            changetracking.savesession($('#thesessionname').val());
            confirmbox.close();
        }
    });
    
    $('#savesession').on('click',function(event){
        event.stopPropagation();
        
        changetracking.savesession($('#thesessionname').val());
        confirmbox.close();
    });
}
var liveprevact = {
    toolbardiv:'<span id="livefullscreen" class="livedevtool menu active right toolbar"><span class="menulabel"><div class="table"><div class="tablecell">hide panel</div></div></span></span><span id="livedevtool" class="livedevtool menu active right toolbar"><span class="menulabel"><div class="table"><div class="tablecell">devtool</div></div></span></span><span id="closepreview" class="livedevtool menu active right toolbar"><span class="menulabel"><div class="table"><div class="tablecell">exit preview</div></div></span></span><span id="reloadprev" class="livedevtool menu active right toolbar"><span class="menulabel"><div class="table"><div class="tablecell">refresh</div></div></span></span>'
};
function livepreviewprep(){
    if($('#resultpage').prev().attr('id') != 'livewebview'){
        $('#liveprevbox').addClass('active');
    }
    else{
        $('#livepreview').addClass('disabled');
        $('.livedevtool').removeClass('hide');
        $('body').addClass('liveprev');
    }
}
var changetracking = {
    islive:false,
    liveurl:false,
    savedoriginalid:false,
    originalsource:false,
    originalsourcetype:false,
    changes:[],
    loggedchanges:[],
    changestopostidx:0,
    currsession:false,
    makelive:function(){
        this.islive = true;
        if(this.changes[2].length){
            for(var e=0;e<this.changes[2].length;e++){
                this.changelive(this.changes[2][e]);
            }
        }
    },
    delsession:function(sessname){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'sessions',a:'delsession',d:{name:sessname}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result){
                return;
            }
            
            $.each($('.sessionitem'),function(si,se){
                if($(se)[0].innerHTML.split('<')[0] == sessname){
                    $(se).remove();
                    return false;
                }
            });
        });
    },
    loadsession:function(sessname){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'sessions',a:'loadsession',d:{name:sessname}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result){
                return;
            }
            changetracking.currsession = sessname;
            changetracking.savedoriginalid = msg.originalid;
            changetracking.originalsource = msg.originalsource;
            changetracking.originalsourcetype = msg.originalsourcetype;
            
            $('#orisource').removeClass('disabled');    
            
            changetracking.liveurl = msg.liveurl;
            if(changetracking.liveurl != 'false'){
                changetracking.islive = true;
                $('body').addClass('liveprev');
                if($('#resultpage').prev()[0].tagName != 'webview'){
                    $('#resultpage').before('<webview id="livewebview" src="'+changetracking.liveurl+'" class="active" plugins preload="file://localhost/media/damarsidiq/pxpedia/res/coscher/webviewipc.min.js" allowpopups disablewebsecurity webpreferences="allowRunningInsecureContent"></webview>');                    
                }
                $('header').append(liveprevact.toolbardiv);
                $('#livepreview').addClass('disabled');
                
                    document.getElementById('livewebview').addEventListener('dom-ready', function(){
                        $('#livewebview')[0].send('ping');
                    });
                    
                    document.getElementById('livewebview').addEventListener('ipc-message', function(event){
                        switch(event.channel){
                            case 'thebrohtmlcontentx':
                                changetracking.islive = true;
                                document.getElementById('livewebview').executeJavaScript("stylefile('"+changetracking.savedoriginalid+"')");
                            break;
                        }
                    });
            }
            displayresults(msg.data);
        });
    },
    savesession:function(sessname){
        if(sessname == 'session name'){
            return;
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'postparsed',a:'savesession',d:{liveurl:changetracking.liveurl,mode:changetracking.originalsourcetype,originalid:changetracking.savedoriginalid,name:sessname,oriurl:changetracking.originalsource}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result){
                return;
            }
            changetracking.currsession = sessname+'.txt';
        });
    },
    changelive:function(changeelem){
        var styletype = $('#'+changeelem.elempos).find('.ctype').html();
        var styleval = changeelem.value;
        var styleident = $('#'+changeelem.elempos).find('.parsedident').html();
        
        switch(styletype){
            case 'border':
            case 'border-top':
            case 'border-bottom':
            case 'border-left':
            case 'border-right':
                styletype = 'border-color';
            break;
            case 'color':
                styletype = 'color';
            break;
            case 'background':
                styletype='background-color';
            break;
            
        }
        
        var styleparam = styletype+'|'+styleval+'|'+styleident;
        if(styleparam.indexOf('::') === -1){
            document.getElementById('livewebview').executeJavaScript("stylechange('"+styleparam+"')");
        }
    },
    initvar:function(){
        this.changes[0] = [];/*identifier*/
        this.changes[1] = [];/*styleattr*/
        this.changes[2] = [];/*styleval*/
    },
    exist:function(elempos,type){
        if(!this.changes[type].length){
            return false;
        }
        
        for(var i=0;i<this.changes[type].length;i++){
            if(this.changes[type][i].elempos == elempos){
                return i;
            }
        }
        return false;
    },
    logchange:function(elempos,val,type){
        var e = this.exist(elempos,type);
        if(e!== false){
            this.changes[type][e].value = val;
            if(this.islive)
                this.changelive(this.changes[type][e]);
            return;
        }
        
        var cidx = this.changes[type].length;
        this.changes[type][cidx] = [];
        this.changes[type][cidx].value = val;
        this.changes[type][cidx].elempos = elempos;
        
        if(this.islive)
            this.changelive(this.changes[type][cidx]);
        
        $('#savefile').removeClass('disabled');
    },
    changestopost:function(type){
        var postdata = '';
        for(var i=0;i<this.changes[type].length;i++){
            if(i>0){
                postdata+= '~';
            }
            postdata+=this.changes[type][i].elempos+'|'+this.changes[type][i].value;
        }
        return postdata;
    },
    updatefile:function(){
        changetracking.loggedchanges = [];
        var loggedchangesidx = 0;
        for(var i=0;i<this.changes.length;i++){
            if(this.changes[i].length){
                loggedchangesidx = changetracking.loggedchanges.length;
                changetracking.loggedchanges[loggedchangesidx] = [];
                changetracking.loggedchanges[loggedchangesidx].type = i;
            }
        }
        this.submitupdate();
    },
    applychanges:function(){
        var i=2;
        if(this.changes[2].length){
            for(var cc=0;cc<this.changes[i].length;cc++){
                $('#parsedres').children('#'+this.changes[i][cc].elempos).find('.parsedcolor').html(this.changes[i][cc].value).siblings('.cpalette').css('background',this.changes[i][cc].value);
            }
        }
        changetracking.changes[0] = [];/*identifier*/
        changetracking.changes[1] = [];/*styleattr*/
        changetracking.changes[2] = [];/*styleval*/
    },
    submitupdate:function(){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'postparsed',a:'savechanges',d:{mode:changetracking.originalsourcetype,originalid:changetracking.savedoriginalid,changes:changetracking.changestopost(changetracking.loggedchanges[0].type),ctype:changetracking.loggedchanges[0].type}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result){
                return;
            }
            
            changetracking.loggedchanges.splice(0,1);
            if(changetracking.loggedchanges.length){
                changetracking.submitupdate();
            }
            else{
                $('#editsource').removeClass('disabled');
                $('#editurl').removeClass('disabled');
                $('#savefile').addClass('disabled');
                changetracking.applychanges(); 
            }
        });
    }
}
function fetchfileurl(url,mode){
    changetracking.originalsource = url;
    changetracking.originalsourcetype = mode;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'home',a:'parseurl',d:{url:url,mode:mode}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        
        if(!msg.results){
            return;
        }
        $('#mainmenuid').children().eq(0).removeClass('disabled');
        $('#orisource').removeClass('disabled');    
        
        changetracking.savedoriginalid = msg.savedfile;
        displayresults(msg.data);
    });
}
function handlecsssub(data){
    if(typeof data.isasub === 'undefined'){
        return data.element;
    }
    
    return data.isasub+data.element; 
}
function displayresults(data){
    var parsed = '<ul id="parsedres">';
    for(var i=0;i<data.length;i++){
        parsed += '<li id="'+data[i].elempos+'" class=""><div class="linenum">'+data[i].elempos.split('_')[2]+'</div><div class="oripalette"><span class="parsedelem"><span class="parsedident">'+handlecsssub(data[i])+'</span><span class="separator">|</span><span class="ctype">'+data[i].type+'</span></span><span class="editcolor">#</span><span class="delcolor">-</span><span class="addcolor">+</span><span class="cpalette" style="background:'+data[i].color+'"></span><span class="parsedcolor">'+data[i].color+'</span></div><div class="editingpalette"><input type="color" class="editedcolor" value="'+data[i].color+'"><span class="parsedcolor">'+data[i].color+'</span></span></div></li>';
    }
    parsed += '</ul>';
    $('#resultpage').html(parsed);
    
    $('.pagecontent.active').removeClass('active');
    $('#resultpage').addClass('active');
    
    adjusttoolbar(false);
    $('#pagelabel').addClass('hide');
    
    $('#editsource').removeClass('disabled');
    $('#hideori').removeClass('disabled');
    $('#livepreview').removeClass('disabled');
    $('#filterlist').removeClass('disabled');
    $('#bulkrep').removeClass('disabled');
    $('#savesession').removeClass('disabled');
    $('#paletteview').removeClass('disabled');
}
function uploadcss(){
    var holder = $('#uploadfilepage').find('.holder');
    imageuploader.workerparams = {workeraction:'uploadfiles',app:appname,p:'home',a:'uploadcss',d:''};
    imageuploader.formData.append('app',appname);
    imageuploader.formData.append('p','home');
    imageuploader.formData.append('a','uploadcss');
    imageuploader.formData.append('file', imageuploader.thefiles);
    imageuploader.formData.append('d','');
    
    imageuploader.startupload();
}
function imageuploadhandlerinit(){
    imageuploader = new filetool();
    imageuploader.filereadersupport  = $('#uploadfilepage').find('.filereader');
    imageuploader.formdatasupport    = $('#uploadfilepage').find('.formdata');
    imageuploader.progresssupport    = $('#uploadfilepage').find('.progress');
    imageuploader.holder             = $('#uploadfilepage').find('.holder');
    imageuploader.progress           = $('#uploadfilepage').find('.uploadprogress');
    imageuploader.fileupload         = $('#uploadfilepage').find('.upload');
    imageuploader.enduploadcallback = function(msg){
                
        $(holder).siblings('progress').addClass('hidden');
        $(holder).siblings('.goupload').removeClass('hidden');
        $(holder).parent().removeClass('imagecontainer');
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'home',a:'parsedfile',d:''}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
        });
    };
    imageuploader.init();
}
function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            
            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text'); 
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }   
        }
    });
}