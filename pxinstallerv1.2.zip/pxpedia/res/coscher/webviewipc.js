const {ipcRenderer} = require('electron');

var css = false;
var stylesheet = false;
ipcRenderer.on('ping', () => {
    if (document.readyState === 'complete') {
        ipcRenderer.sendToHost('thebrohtmlcontentx','');      
    }
    else{
        document.onreadystatechange = () => {
          if (document.readyState === 'complete') {
            ipcRenderer.sendToHost('thebrohtmlcontentx','');      
          }
        };
    }
});
global.stylechange = (styledata) => {
    if(css===false){
        inlinestyle();
    }
    
    var styledatax = styledata.split('|');
    var styleident = styledatax[2];
    var stylerule = styleident+'{'+styledatax[0]+':'+styledatax[1]+'}';
    
    stylesheet.insertRule(stylerule,stylesheet.cssRules.length);
};
global.editstyle = (styletext) => {
    if(css===false){
        inlinestyle();
    }
    
    stylesheet.insertRule(styletext,stylesheet.cssRules.length);
};
global.inlinestyle = () => {
    css = document.createElement('style');
    
    css.type = "text/css";
    
    document.getElementsByTagName("head")[0].appendChild(css);
    stylesheet = css.sheet;
    
};
global.stylefile = (srcfile) => {
    var css = document.createElement('link');
    
    
    css.type = "text/css";
    css.rel = "stylesheet";
    css.href = 'http://pxpedia/pxpedia/uploads/coscher/parsed/'+srcfile+'.css';
    
    document.getElementsByTagName("head")[0].appendChild(css);
};