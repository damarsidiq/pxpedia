CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT 'untitled',
  `category` int(11) NOT NULL DEFAULT 1,
  `content` text CHARACTER SET utf8 NOT NULL,
  `excerpt` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `blogattribute` (
  `id` int(11) NOT NULL,
  `blogid` int(11) NOT NULL,
  `attrkey` varchar(255) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `blogcat` (
  `id` int(11) NOT NULL,
  `parent` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `bloggallery` (
  `id` int(11) NOT NULL,
  `blogid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sortorder` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogattribute`
--
ALTER TABLE `blogattribute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogcat`
--
ALTER TABLE `blogcat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloggallery`
--
ALTER TABLE `bloggallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `blogattribute`
--
ALTER TABLE `blogattribute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `blogcat`
--
ALTER TABLE `blogcat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bloggallery`
--
ALTER TABLE `bloggallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
