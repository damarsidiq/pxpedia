var lang;
var pageloaded          = [];
var currentappid        = false;
var registapageloggedin = false;
var scriptsloaded       = [];
var scriptsloadedtype   = [];
var resources           = [];
var themeresources      = [];
var syncprogressfile    = false;
var syncurl             = false;
var syncing             = false;
var timeoutid           = false;
$(document).ready(
    function () {
        $.ajax({
             url:"./",
             data:{app:appname,admin:1,p:'ajax',v:'ajax',a:'loadlang'},
             type:"POST"
         }).done(function(msg){
                lang = $.parseJSON(msg);
                lang = $.parseJSON(lang.pagecontent);
         });

        if(typeof($('#sidebar').attr('id')) != 'undefined'){
            registapagechange();
        }
        registaforminput('body','input[type="text"],input[type="password"],textarea,select');

        if($('body').attr('class').indexOf('loggedinadmin') === -1){
            var loggedinuser = localstoragefunc.getVal('registaadminemail');
            if(loggedinuser != 'false'){
                loggedinremembered(loggedinuser);
            }else{
                $('body').addClass('ready');
            }
        }
    }
);
var localstoragefunc = {
    localstorage:null,
    getLocalStorage:function(){
        if (typeof localStorage == "object"){
            this.localstorage =  localStorage;
        } else if (typeof globalStorage == "object"){
            this.localstorage = globalStorage[location.host];
        } else {
            this.localstorage = false;
        }
    },
    setVal:function (sessionvar){
        if(this.localstorage === null){
            this.getLocalStorage();
        }
        if(this.localstorage !== false){
            this.localstorage.setItem(sessionvar.name,sessionvar.value);
        }
    },
    getVal:function(varname){
        if(this.localstorage === null){
            this.getLocalStorage();
        }
        var val = false;
        if(this.localstorage !== false){
            val = this.localstorage.getItem(varname);
        }
        return val;
    }
};
function globalacesettingsmenu(cursorx,cursory){
    if(cursorx===false && cursory===false){
        if(typeof $('#ace_settingsmenu').attr('id') !== 'undefined'){
            $('#ace_settingsmenu').parent().parent().remove();
            $('#settheace').removeClass('set');
            return;
        }
        if($('#browseview').attr('class').indexOf('maximized') !== -1){
            cursorx = $('#browseview').width()-parseInt($('#settheace').css('right'))+parseInt($('#settheace').width());
            cursory = 10;            
        }
        else{
            cursorx = $('#browser')[0].offsetLeft+$('#browseview')[0].offsetLeft+$('#browseview').width()+parseInt($('#browser').css('padding-left'))+parseInt($('#browser').css('padding-right'))-16;
            cursory = $('#browser')[0].offsetTop+parseInt($('#browser').css('margin-top'))+parseInt($('#browser').css('padding-top'))+parseInt($('#browser').css('padding-bottom'));   
        }
    }
    
    $('#settheace').addClass('set');
    cursory+=$('#settheace')[0].offsetTop+$('#settheace').height();
    cursorx-=(500-parseInt($('#settheace').css('right')));
    var editorindex = editors.editorindex();

    ace.config.loadModule("ace/ext/settings_menu", function(module) {
        module.init(editors.editor[editorindex]);
        editors.editor[editorindex].showSettingsMenu();
        
        $('.ace_closeButton').parent().remove();
        $('#ace_settingsmenu').css('width','100%');
        $('#ace_settingsmenu').css('height','100%');
        $('#ace_settingsmenu').parent().parent().css('width','500px');
        $('#ace_settingsmenu').parent().parent().css('height','300px');
        $('#ace_settingsmenu').parent().parent().css('top',cursory+'px');
        $('#ace_settingsmenu').parent().parent().css('left',cursorx+'px');
        
        $('#ace_settingsmenu').find('div').eq($('#ace_settingsmenu').find('div').length-1).addClass('last');
        $('#ace_settingsmenu').children('.last').css('padding','1em 0px 0px 0px');
        $('#ace_settingsmenu').css('padding-bottom','15px');
        
        $('#setFontSize').prop('type','number');
        $('#setFontSize').on('change',function(event){
            event.stopPropagation();
            
            editors.fontsize = parseInt($(this).val());
            editors.editor[editors.editorindex()].setFontSize(editors.fontsize);
        });
            editors.editor[editorindex].commands.removeCommands([{
                    name: "showSettingsMenu"
            }]);
    }); 
}
function globalsaveeditorfile(){
    if($('#savecodechanges').attr('class').indexOf('loading') === -1){
        $('#savecodechanges').addClass('loading');
        editors.saveChanges();
        
        var ext = browsercontent.contents[editors.filelist[editors.currentfileidx]].name.split('.');
        ext = ext[ext.length-1];
        if(ext == 'js'){
            $('#jspacker').addClass('loading');
            editors.packjs();
        }
    }
}
function globaltoggleautocomplete(){
    if($('#autocompleteace').attr('class').indexOf('on') === -1){
        $('#autocompleteace').addClass('on');
    }
    else{
        $('#autocompleteace').removeClass('on');
    }
    editors.toggleautocomplete();
}
function globalmaxmineditor(){
    if($('#browseview').attr('class').indexOf('maximized') === -1){
        editors.maximize();
        editors.reneweditor('codeeditor_'+editors.currentfileidx);
        return;
    }
    editors.minimize();
    editors.reneweditor('codeeditor_'+editors.currentfileidx);
}
function globalremovefilefreditor(){
    editors.removefile();
}
function globaltogglefileview(){
    if(editors.filelist.length > 1){
        var teditidx = parseInt(editors.currentfileidx);
        if((teditidx+2) <= editors.filelist.length){
            teditidx++;
            
            editors.selectfromfilelist($('#filelist_'+teditidx));
            globaltogglefileview_();
            return;
        }
            
            teditidx = 0;
            editors.selectfromfilelist($('#filelist_'+teditidx));
            globaltogglefileview_();
    }
}
function globaltogglefileview_(){
    if(timeoutid !== false)
        clearTimeout(timeoutid);
    
    $('#editorfilelist').addClass('dropdown').find('.availfileitem').removeClass('hide');
    timeoutid = setTimeout(function(){
        $('#editorfilelist').removeClass('dropdown');
        $('#editorfilelist').find('.availfileitem').addClass('hide');
        $('#editorfilelist').find('.availfileitem.active').removeClass('hide');
    },2000);
}
var editors = {
    gosearchcode:false,
    searchresindex:false,
    editorkbshortcut:false,
    editorsettingspage:false,
    editor: [false],
    filelist:[],
    fontsize:(mobile?24:14),
    currentfileidx:false,
    setautocomplete:function(){
        var auto = editors.editor[this.currentfileidx].$enableBasicAutocompletion ? true : false;
        editors.editor[this.currentfileidx].setOptions({
            enableBasicAutocompletion: auto,
            enableSnippets: auto,
            enableLiveAutocompletion: auto
        });
        
        if(auto){
            $('#autocompleteace').addClass('on');
            return;
        }
        $('#autocompleteace').removeClass('on');
    },
    toggleautocomplete:function(){
        if(this.currentfileidx === false)
            return;
            
        var auto = editors.editor[this.currentfileidx].$enableBasicAutocompletion ? false : true;
        editors.editor[this.currentfileidx].setOptions({
            enableBasicAutocompletion: auto,
            enableSnippets: auto,
            enableLiveAutocompletion: auto
        });
    },
    packjs:function(){
        if(this.currentfileidx !== false)
        browsercontent.contents[this.filelist[this.currentfileidx]].packfile(this.editor[this.editorindex()].getValue(),function(msg){
            if(typeof msg.msg !== 'undefined'){
                return;
            }
            browsercontent.contents[editors.filelist[editors.currentfileidx]].packcb(msg);
            
            var exists = browsercontent.searchcontent(browsercontent.contents[editors.filelist[editors.currentfileidx]].app,browsercontent.contents[editors.filelist[editors.currentfileidx]].path,false,msg.filename);

            if(exists === false){
                var contentobj = new contentobject(browsercontent.contents[editors.filelist[editors.currentfileidx]].app,'file',msg.filename,0,browsercontent.contents[editors.filelist[editors.currentfileidx]].path,browsercontent.contents[editors.filelist[editors.currentfileidx]].pathtype,browsercontent.contents.length);
                browsercontent.addcontent(contentobj);

                if(currentpath == browsercontent.contents[editors.filelist[editors.currentfileidx]].path && currentpathtype == browsercontent.contents[editors.filelist[editors.currentfileidx]].pathtype){
                    $('#browserlists').find('.createfile').before(contentobj.toBrowserString());
                }
                $('#browseview').removeClass('loading');
            }
            else{
                browsercontent.contents[exists].content = 0;
                var revived = false;
                if(browsercontent.contents[exists].type == 'deleted'){
                    browsercontent.contents[exists].type = 'file';
                    revived = true;
                }
                if(currentpath == browsercontent.contents[editors.filelist[editors.currentfileidx]].path && currentpathtype == browsercontent.contents[editors.filelist[editors.currentfileidx]].pathtype){
                    if(revived){
                        $('#browserlists').find('.createfile').before(browsercontent.contents[editors.filelist[editors.currentfileidx]].toBrowserString());
                    }
                }
                $('#browseview').removeClass('loading');
            }

            $('#editormessage').html(browsercontent.contents[editors.filelist[editors.currentfileidx]].name +' successfully packed');
            $('#editormessage').addClass('incoming');
            setTimeout(function(){
                $('#editormessage').animate({'opacity':'0'},'slow',function(){
                    $('#editormessage').removeClass('incoming');
                    $('#editormessage').css('opacity','1');
                });
            },5000);
            $('.jspacker').removeClass('loading');
        });
    },
    saveChanges:function(){
        if(this.currentfileidx !== false)
        browsercontent.contents[this.filelist[this.currentfileidx]].saveChanges(this.editor[this.editorindex()].getValue(),currentappid,function(msg){
            msg = $.parseJSON(msg);
            if(typeof msg.msg !== 'undefined'){
                return;
            }
            
            browsercontent.contents[editors.filelist[editors.currentfileidx]].editing = browsercontent.contents[editors.filelist[editors.currentfileidx]].content;
             $('#editorfilelist').removeClass('editing');   
             
            $('#editormessage').html(browsercontent.contents[editors.filelist[editors.currentfileidx]].name +' successfully saved');
            $('#editormessage').addClass('incoming');
            setTimeout(function(){
                $('#editormessage').animate({'opacity':'0'},'slow',function(){
                    $('#editormessage').removeClass('incoming');
                    $('#editormessage').css('opacity','1');
                });
            },5000);
            $('#savecodechanges').removeClass('loading');
        });
    },
    setfilemode:function(name){
        if(name.indexOf('.php') !== -1)
            this.updatesessionmode("php");
        else if(name.indexOf('.js') !== -1){
            this.updatesessionmode("javascript");
        }
        else if(name.indexOf('.css') !== -1){
            this.updatesessionmode("css");
        }
        else if(name.indexOf('.html') !== -1){
            this.updatesessionmode("html");
        }
        else if(name.indexOf('.sql') !== -1){
            this.updatesessionmode("mysql");
        }
        else if(name.indexOf('.pxsync') !== -1 || name.indexOf('.progress') !== -1){
            this.updatesessionmode("html");
        }
    },
    existineditor:function(fileidx){
        return $.inArray(fileidx,this.filelist);
    },
    addfile:function(contentidx){
        if(this.gosearchcode !== false){
            if(this.searchresindex !== false){
                this.filelist[this.searchresindex] = contentidx;
            }
            else{
                this.filelist[this.filelist.length] = contentidx;
                this.searchresindex = this.filelist.length-1;
            }
            $('#searchcoderesult').children('.codeeditor').remove();
            $('#searchcoderesult').append('<pre id="codeeditor_searchresult'+this.searchresindex+'" class="codeeditor searchrescodeeditor"></pre>');
            this.reneweditor('codeeditor_searchresult'+this.searchresindex);
            return;
        }
        else{
            try{editors.defaulteditortheme = editors.editor[editors.editorindex()].getTheme();}catch(e){}
        }
        try{
            browsercontent.contents[this.filelist[this.currentfileidx]].content = this.editor[this.editorindex()].getValue();
        }
        catch(e){}
        
        var opened = this.existineditor(contentidx);
        if(opened !== -1){
            this.currentfileidx = opened;
        }
        else{
            this.filelist[this.filelist.length] = contentidx;
            this.currentfileidx = this.filelist.length-1;

            $('#codeeditor_'+this.currentfileidx).remove();
            $('#browseview').append('<pre id="codeeditor_'+this.currentfileidx+'" class="codeeditor"></pre>');

            var filetype = this.getfiletype(this.filelist[this.currentfileidx]);
            switch(filetype){
                case 'jpg':
                case 'png':
                case 'gif':
                case 'ico':
                    this.editor[this.editorindex()] = false;
                    var pageimage = new Image();
                    pageimage.src = browsercontent.contents[this.filelist[this.currentfileidx]].path+'/'+browsercontent.contents[this.filelist[this.currentfileidx]].name;
                    pageimage.onload = function(){
                        var imageholder = '<div class="table"><div class="tablecell"></div></div>';
                        $('#codeeditor_'+editors.editorindex()).html(imageholder).addClass('media').children().children().append(this);
                    };
                    this.updatefileselection();
                break;
                case 'mp4':
                break;
                case 'mp3':
                break;
                case 'pdf':
                break;
                default:
                    this.reneweditor('codeeditor_'+this.currentfileidx);
            }
            return;
        }
        this.updatefileselection();
    },
    removefile:function(){
        this.filelist.splice(this.currentfileidx,1);
        if((this.searchresindex !== false && this.filelist.length >1) || (this.searchresindex === false && this.filelist.length > 0) ){
            editors.editor.splice(this.currentfileidx,1);
            $('#codeeditor_'+this.currentfileidx).remove();
        }
        else{
            editors.editor[this.currentfileidx] === false;
            $('#codeeditor_'+this.currentfileidx).html('');
        }
        for(var ci=this.currentfileidx;ci<this.filelist.length;ci++){
            if(this.filelist[ci] == -9){
                $('#codeeditor_searchresult'+(parseInt(ci)+1)).prop('id','codeeditor_searchresult'+(ci));
                this.searchresindex = (ci);
            }
            else{
                $('#codeeditor_'+(parseInt(ci)+1)).prop('id','codeeditor_'+(ci));
            }
        }

        if(this.currentfileidx == this.filelist.length){
            if(this.filelist.length){
                if(this.searchresindex === false)
                    this.currentfileidx = this.filelist.length-1;
                else{
                    for(var ci=(this.filelist.length-1);ci>=0;ci--){
                        if(ci!=this.searchresindex){
                            this.currentfileidx = ci;
                            break;
                        }
                    }
                    if(this.currentfileidx == this.filelist.length){
                        if(editors.editor[this.currentfileidx] === false){
                            $('#codeeditor_'+this.currentfileidx).html('');
                        }
                        else
                            editors.editor[this.currentfileidx].setValue('',1);

                        this.currentfileidx = false;
                        this.updatefileselection();
                        return;
                    }
                }
            }
            else{
                this.currentfileidx = false;
                this.updatefileselection();
                return;
            }
        }
        else{
            if(this.filelist.length == 1 && this.searchresindex !== false){
                this.currentfileidx = false;
                this.updatefileselection();
                return;
            }
            for(var ci=(this.filelist.length-1);ci>=0;ci--){
                if(ci!=this.searchresindex){
                    this.currentfileidx = ci;
                    break;
                }
            }
        }
        this.updatefileselection();
        editors.reneweditor('codeeditor_'+editors.currentfileidx);
    },
    defaulteditortheme:"ace/theme/mono_industrial",
    reneweditor:function(editorid){
        var editorindex;
        if(this.gosearchcode === false){
            var filetype = this.getfiletype(this.filelist[this.currentfileidx]);
            if(filetype == 'ico' || filetype == 'jpg' || filetype == 'jpeg' || filetype == 'png' || filetype == 'gif'){
                return;
            }
            if(filetype == 'js' || filetype =='css'){
                $('.jspacker').removeClass('hide');
            }
            else{
                $('.jspacker').addClass('hide');
            }
            editorindex = this.editorindex();
        }
        else{
            editorindex = this.searchreseditorindex();
        }
        
        editors.editor[editorindex] = ace.edit(editorid);
        this.editor[editorindex].setOption("useWorker", false);
        this.editor[editorindex].setTheme(editors.defaulteditortheme);
        this.editor[editorindex].setFontSize(editors.fontsize);
        this.editor[editorindex].$blockScrolling = Infinity;
        this.editor[editorindex].setShowPrintMargin(false);
            
            ace.config.loadModule("ace/ext/regista_shortcuts", function(module) {
                module.init(editors.editor[editorindex]);
            });
            ace.config.loadModule("ace/ext/keybinding_menu", function(module) {
                module.init(editors.editor[editorindex]);
                editors.editor[editorindex].showKeyboardShortcuts();
                    $('#kbshortcutmenu').find('h1').after('<div class="ace_optionsMenuEntry"><span class="ace_optionsMenuCommand">saveFile</span> : <span class="ace_optionsMenuKey">Ctrl-S</span></div><div class="ace_optionsMenuEntry"><span class="ace_optionsMenuCommand">toggleAutoComplete</span> : <span class="ace_optionsMenuKey">Ctrl-Shift-A</span></div><div class="ace_optionsMenuEntry"><span class="ace_optionsMenuCommand">fullScreen</span> : <span class="ace_optionsMenuKey">Ctrl-Shift-Z</span></div><div class="ace_optionsMenuEntry"><span class="ace_optionsMenuCommand">toggleFile</span> : <span class="ace_optionsMenuKey">Ctrl-Alt-Z</span></div><div class="ace_optionsMenuEntry"><span class="ace_optionsMenuCommand">closeFile</span> : <span class="ace_optionsMenuKey">Ctrl-W</span></div>');
                editors.editorkbshortcut = $('#kbshortcutmenu').html();
                $('#kbshortcutmenu').parent().parent().remove();
                editors.editor[editorindex].commands.removeCommands([{
                        name: "showKeyboardShortcuts"
                }]);
            });   
        

        if(this.gosearchcode !== false){
            this.editor[this.searchreseditorindex()].setValue(this.gosearchcode,1);
            $('#codeeditor_searchresult'+this.searchreseditorindex()).addClass('active');
            $('#searchcoderesult').children('.hidecodeeditor').addClass('active');
            try{this.editor[this.searchreseditorindex()].focus();}catch(e){}
            
            return;
        }
        else{
            try{this.editor[editorindex].focus();}catch(e){}
            editors.setautocomplete();
        }
        this.updatefileselection();
        
        $('#'+editorid).removeClass('media');
    },
    maximize:function(){
        try{
            browsercontent.contents[this.filelist[this.currentfileidx]].content = this.editor[this.editorindex()].getValue();
        }
        catch(e){}
        $('#browseview').addClass('maximized');
        $('#editormaxmin').addClass('maximized');
        $('#sidebar').addClass('hide');
        $('#tree').addClass('maximized');
    },
    minimize:function(){
        try{
            browsercontent.contents[this.filelist[this.currentfileidx]].content = this.editor[this.editorindex()].getValue();
        }
        catch(e){}
        $('#browseview').removeClass('maximized');
        $('#editormaxmin').removeClass('maximized');
        $('#sidebar').removeClass('hide');
        $('#tree').removeClass('maximized');
    },
    selectfromfilelist:function(elem){
        var fileidx = $(elem).attr('id');
        fileidx     = fileidx.substr(fileidx.indexOf('_')+1);
        
        if(this.currentfileidx != fileidx){
            if($('#codeeditor_'+this.currentfileidx).attr('class').indexOf('media') === -1)
                browsercontent.contents[this.filelist[this.currentfileidx]].content = editors.editor[this.currentfileidx].getValue();
                
            try{editors.defaulteditortheme = editors.editor[editors.editorindex()].getTheme();}catch(e){}
            this.currentfileidx =  fileidx;
            $('#editorfilelist').removeClass('dropdown');
            this.updatefileselection();
            editors.reneweditor('codeeditor_'+editors.currentfileidx);
        }
    },
    editorindex:function(){
        return this.currentfileidx === false ? (this.searchresindex === 0 ? 1 : 0) : this.currentfileidx;
    },
    searchreseditorindex:function(){
        return this.searchresindex === false ? 0 : this.searchresindex;
    },
    updatefileselectionClass:function(){
        if(this.filelist.length === 0 || (this.filelist.length == 1 && this.searchresindex !== false) ){
            if($('#browseview').attr('class').indexOf('maximized') !== -1){
                editors.minimize();
            }
            $('#editorfilelist').html('<ul id="availfilelist"></ul>');
            if(editors.currentfileidx === false || typeof $('#codeeditor_'+editors.currentfileidx).attr('class') !== 'undefined'){
                $('.editormenu').removeClass('active');
                $('#helpwithace').addClass('singleactive');
                $('#savecodechanges').addClass('singleactive');
                if(editors.currentfileidx !== false && $('#codeeditor_'+editors.editorindex()).attr('class').indexOf('ace') === -1)
                    $('#codeeditor_'+editors.editorindex()).addClass('active media');
            }
            return true;
        }
        if($('#codeeditor_'+editors.editorindex()).length || ($('#codeeditor_'+editors.editorindex()).length && $('#codeeditor_'+editors.editorindex()).attr('class').indexOf('active') !== -1)){
            $('#helpwithace').removeClass('singleactive');
            $('#savecodechanges').removeClass('singleactive');
            $('#editorfilelist').addClass('active');
        }
        return false;
    },
    updatefileselection:function(){
        if(this.updatefileselectionClass())
            return;
            
        this.updatecontent(browsercontent.contents[this.filelist[this.currentfileidx]]);
        $('#browseview').children('.codeeditor').removeClass('active');
        $('#codeeditor_'+this.currentfileidx).addClass('active');

        var fileselection = '';
        for(var fileidxidx=0;fileidxidx<this.filelist.length;fileidxidx++){
            if(typeof(browsercontent.contents[this.filelist[fileidxidx]]) !== 'undefined'){
                var itemclass=' hide';
                if(editors.currentfileidx == fileidxidx){
                    itemclass=' active';
                }
                var listitem = '<li class="availfileitem'+itemclass+'" id="filelist_'+fileidxidx+'">'+browsercontent.contents[this.filelist[fileidxidx]].name+'</li>';
                
                fileselection+= listitem;
            }
        };
        fileselection = '<ul id="availfilelist">'+fileselection+'</ul>';
        $('#editorfilelist').html(fileselection);

        if((this.searchresindex !== false && this.filelist.length > 2) || (this.searchresindex === false && this.filelist.length > 1) ){
            $('#editorfilelist').addClass('multiple');
        }
        else{
            $('#editorfilelist').removeClass('multiple');
        }
        
        $('#editorfilelist').removeClass('editing');
        if(typeof browsercontent.contents[editors.filelist[editors.currentfileidx]].editing !== 'undefined'){
            if(browsercontent.contents[editors.filelist[editors.currentfileidx]].editing != editors.editor[editors.editorindex()].getValue())
                $('#editorfilelist').addClass('editing');
        }
    },
    updatecontent:function(content){
        if(this.editor[this.editorindex()] === false){
            return;
        }
        var filetype = this.getfiletype(this.filelist[this.currentfileidx]);
        if(filetype == 'ico' || filetype == 'jpg' || filetype == 'jpeg' || filetype == 'png' || filetype == 'gif'){
            return;
        }
            if(typeof content === 'string'){
                if(this.editor[this.editorindex()].getValue() !== content){
                    this.editor[this.editorindex()].setValue(content,1);
                }
            }
            else{
                if(this.editor[this.editorindex()].getValue() !== content.content){
                    this.editor[this.editorindex()].setValue(content.content,1);
                    this.setfilemode(content.name);
                }
            }
        editors.editor[editors.editorindex()].getSession().on('change',function(){
            editors.updateisediting();
        });
    },
    updateisediting:function(){
        if(browsercontent.contents[editors.filelist[editors.currentfileidx]].content != editors.editor[editors.editorindex()].getValue()){
            if(typeof browsercontent.contents[editors.filelist[editors.currentfileidx]].editing !== 'undefined'){
                if(browsercontent.contents[editors.filelist[editors.currentfileidx]].editing == editors.editor[editors.editorindex()].getValue()){
                    $('#editorfilelist').removeClass('editing');
                }
                else{
                    $('#editorfilelist').addClass('editing');
                }
            }
            else{
                browsercontent.contents[editors.filelist[editors.currentfileidx]].editing = browsercontent.contents[editors.filelist[editors.currentfileidx]].content;
                $('#editorfilelist').addClass('editing');   
            }
        }
        else{
            if(typeof browsercontent.contents[editors.filelist[editors.currentfileidx]].editing !== 'undefined'){
                if(browsercontent.contents[editors.filelist[editors.currentfileidx]].editing == editors.editor[editors.editorindex()].getValue()){
                    $('#editorfilelist').removeClass('editing');
                }
                else{
                    $('#editorfilelist').addClass('editing');
                }
            }
            else{
                $('#editorfilelist').removeClass('editing');  
            }
        }
    },
    updatesessionmode:function(mode){
        if(this.gosearchcode !== false){
            this.gosearchcode = false;
            this.editor[this.searchreseditorindex()].session.setMode("ace/mode/"+mode);
            return;
        }
        this.editor[this.editorindex()].session.setMode("ace/mode/"+mode);
    },
    getfiletype:function(fileidx){
        var filetype = browsercontent.contents[fileidx].name.split('.');
        filetype = filetype[filetype.length-1];
        return filetype;
    }
};
function modalsboxmsg(elem,msg,fadeaway,callback){
    $(elem).find('.modalmsg').html(msg).addClass('active');
    if(fadeaway){
        setTimeout(function(){
            $(elem).find('.modalmsg').animate({'opacity':0},'slow',function(){
                $(elem).find('.modalmsg').removeClass('active');
                $(elem).find('.modalmsg').css('opacity','1');
            });
        },6000);
    }
    if(callback !== false){
        callback();
    }
}
function registapagemsg(msg,fadeaway){
    var cpheader = $('.thepageitcontains.active').find('.pageheader');
    if($(cpheader).children('.registapagemsg').length === 0){
        var msgcontained = '<div class="registapagemsg"></div>';
        $(cpheader).find('.ptitle').after(msgcontained);
    }

    var rpm = $(cpheader).find('.registapagemsg');
    $(rpm).html(msg).addClass('incoming');
    $(rpm)[0].scrollIntoView();
    if(fadeaway){
        setTimeout(function(){
            $(rpm).animate({'opacity':0},'slow',function(){
                $(rpm).removeClass('incoming');
                $(rpm).css('opacity','1');
            });
        },6000);
    }
}
function currentdatestring(){
    var cdate = new Date();
    var doubledigitmonth = (cdate.getMonth()+1);
    if(doubledigitmonth < 10){
        doubledigitmonth = '0'+doubledigitmonth;
    }
    var doubledigitdate = cdate.getDate();
    if(doubledigitdate < 10){
        doubledigitdate = '0'+doubledigitdate;
    }
    var doubledigithours = cdate.getHours();
    if(doubledigithours < 10){
        doubledigithours = '0'+doubledigithours;
    }
    var cdatestring = cdate.getFullYear()+'-'+doubledigitmonth+'-'+doubledigitdate+' '+doubledigithours+':'+cdate.getMinutes()+':'+cdate.getSeconds();

    return cdatestring;
}
function switchapp(administerthis,msg){
    resources       = [];
    themeresources  = [];

    currentthemeresourcepath    = [];
    currentresourcepath         = [];

    currentresourcepath[0]          = 'resources';
    currentthemeresourcepath[0]     = 'theme';

    var apppagecontent,apptoswitchto;

    $('#menucontainer').html(msg.menu);
    var administerappspan = $('.elemid.current').parent().find('.administerapp');
    $(administerappspan).removeClass('loading');
    $(administerappspan).children().eq(0).html('administer');
    $('.elemid.current').removeClass('current');

    $(administerthis).parent().parent().siblings('.elemid').eq(0).addClass('current');
    $(administerthis).html('');
    $(administerthis).parent().removeClass('loading');

    apptoswitchto = $('.elemid.current').html();

    if(pagecontents.length > 1){
        for(var i=0;i<pagecontents.length;i++){
            if(pagecontents[i].pagename == 'Apps'){
                apppagecontent = pagecontents[i];
            }
            else{
                if(pagecontents[i].appid == activeapp){
                    pagecontents[i].content = '<div class="thepageitcontains" id="thepageitcontains_'+i+'">'+$('#thepageitcontains_'+i).html()+'<div>';
                    $('#thepageitcontains_'+i).remove();
                }
                else if(pagecontents[i].appid==apptoswitchto){
                    $('#thepagecontainer').append(pagecontents[i].content);
                }
            }
        }
    }
    activeapp = apptoswitchto;
}
var pagecontents = [];
var currentcontentidx = 0;
var pageloadmsg = [];
var onreceivingpage = function(){
    if(typeof pageloadmsg.countscript === 'undefined'){
        var pageurl = window.location.href.split('&p=');
        pageurl = pageurl[pageurl.length-1].split('&');
        pageloadmsg.countscript = 0;
        pageloadmsg.pagename = pageurl[0];
    }
    pageloadmsg.countscript--;
    if(typeof this.src !== 'undefined' && this.src.indexOf('/ace.js') !== -1){
        var srcpath = this.src;
        srcpath = srcpath.split('/');
        srcpath.splice(srcpath.length-1,1);
        srcpath = srcpath.join('/');

        var scriptarr= [];
        scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/ext-language_tools.js';
		scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/theme-mono_industrial.js';
        scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/mode-javascript.js';
        scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/mode-css.js';
        scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/mode-php.js';
        scriptarr[scriptarr.length] = document.createElement('script');
        scriptarr[scriptarr.length-1].src = srcpath+'/mode-mysql.js';

        for(var i=0;i<scriptarr.length;i++){
         	document.getElementsByTagName("head")[0].appendChild(scriptarr[i]);
            if ("onreadystatechange" in scriptarr[i]) {
    			scriptarr[i].onreadystatechange = function() {
    				if (/loaded|complete/.test(scriptarr[i].readyState)) {
    				    onreceivingpage();
    				}
    			};
    		} else {
    			scriptarr[i].onload = onreceivingpage;
    		}
        }
        pageloadmsg.countscript+=6;
    }
    if(pageloadmsg.countscript<=0){
        if(typeof pageloadmsg.view === 'undefined' ||  pageloadmsg.view !== '404'){
	        switch(pageloadmsg.pagename.toLowerCase()){
                case 'apps':
                    appspage();
                break;
                case 'settings':
                    settingspage();
                break;
                case 'blog':
                    blogpage();
                break;
                case 'contacts':
                    contactform();
                break;
                case 'users':
                    userspage();
                break;
                case 'plugins':
                    pluginspage();
                break;
            }
	    }
        $('.pagecontainer').removeClass('loading');    }
};

var pluginsnavproto = function(){

};

pluginsnavproto.prototype.newresults = function(){

};

var appspluginindex = 0;
var pluginsdata     = [];
function pluginspage(){
      if($.inArray('pluginspage',pageloaded) !== -1){
        appspluginindex = false;
        for(var i=0;i<pluginsdata.length;i++){
            if(pluginsdata[i].appid == activeapp){
                appspluginindex = i;
            }
        }
        if(appspluginindex === false){
            pluginsdata[pluginsdata.length] = [];
            pluginsdata[pluginsdata.length-1].appid         = activeapp;
            pluginsdata[pluginsdata.length-1].pluginsnav      = new pluginsnavproto();

            appspluginindex = pluginsdata.length-1;
        }
        pluginsdata[appspluginindex].pluginsnav.newresults();
        return;
    }
    else{
        pageloaded[pageloaded.length] = 'pluginspage';

        pluginsdata[pluginsdata.length] = [];
        pluginsdata[pluginsdata.length-1].appid         = activeapp;
        pluginsdata[pluginsdata.length-1].pluginsnav      = new pluginsnavproto();

        appspluginindex = pluginsdata.length-1;

        pluginsdata[appspluginindex].pluginsnav.newresults();
    }

    $('#thepagecontainer').delegate('.pluginaddorremove a','click',function(event){
        event.stopPropagation();
        var urlpost = $(this).prop('href');
        var thelink = this;
        $.ajax({
            url:urlpost,
            type:'POST'
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.msg){
                if($(thelink).html().indexOf('deact') !== -1){
                    deactivateplugin(thelink,msg);
                }
                else{
                    activateplugin(thelink,msg);
                }
            }
        });
        return false;
    });

    function deactivateplugin(thelink,msg){
        removeadminmenu(msg.pluginurl);
        $(thelink).html('+ activate').prop('href',msg.url);
    }
    function activateplugin(thelink,msg){
        var pluginname = $(thelink).parent().siblings('.pluginname').html();
        addadminmenu(msg.pluginurl,pluginname);
        $(thelink).html('- deactivate').prop('href',msg.url);
    }
    function addadminmenu(link,name){
        var adminmenuitems = $('.adminmenuitem');
        var adminmenuname;
        var following;
        for(var i=0;i<adminmenuitems.length;i++){
            adminmenuname = $(adminmenuitems[i]).children().html();
            following = i;
            if(adminmenuname > name){
                break;
            }
        }
        $(adminmenuitems[following]).before('<li class="adminmenuitem"><a href="javascript:void(0);" id="'+link+'">'+name+'</a></li>');
    }
    function removeadminmenu(link){
        var adminmenuitems = $('.adminmenuitem');
        var menulink;
        for(var i=0;i<adminmenuitems.length;i++){
            menulink = $(adminmenuitems[i]).children().attr('id');
            if(menulink == link){
                $(adminmenuitems[i]).remove();
                break;
            }
        }
    }

    var pluginfileuploader = new filetool();
    pluginfileuploader.enduploadcallback = function(msg){
        msg = $.parseJSON(msg);
        if(msg.result){
            registapagemsg('plugin submitted successfully...',true);
        }
        else{
            registapagemsg(msg.msg,true);
        }
    };
    pluginfileuploader.init();

    $('#thepagecontainer').delegate('.submitpluginzip','click',function(event){
        event.stopPropagation();

        if($('#pluginzipedfiles')[0].files.length){
            var files = $('#pluginzipedfiles')[0].files;
            pluginfileuploader.fileuploaderhandle(files,false,pluginfileuploader);
        }

        if(pluginfileuploader.filecount > 0){
            var workerparams = {workeraction:'uploadfiles',app:'regista',p:'plugins',a:'submitPlugin',d:$('#pluginsubmitname').val()};

            pluginfileuploader.workerparams = workerparams;
            pluginfileuploader.formData.append('app',appname);
            pluginfileuploader.formData.append('p',workerparams.p);
            pluginfileuploader.formData.append('a',workerparams.a);
            pluginfileuploader.formData.append('d',workerparams.d);
            pluginfileuploader.formData.append('files', pluginfileuploader.thefiles);
            pluginfileuploader.startupload();
        }

    });
}
function registapagechange(){
    if(!registapageloggedin){
        registapagemenu();
    }

    pageloaded      = [];
    currentappid    = false;
    pagecontents    = [];
    currentcontentidx = 0;
    pageloadmsg = [];

    pagecontents[0] = [];
    pagecontents[0].pagelink = $('#menucontainer').find('.current').children('a').attr('id');
    pagecontents[0].pagename = $('#menucontainer').find('.current').children('a').html();
    pagecontents[0].appid    = activeapp;
    pagecontents[0].content  = $('#thepagecontainer').html();

    $('.pagecontainer').addClass('loading');
    if(typeof($('#appspage').attr('id')) != 'undefined'){
        appspage();
    }
    else if(typeof($('#dbsetting').attr('id')) != 'undefined'){
        settingspage();
    }
    else if(typeof($('#pastentries').attr('id')) !== 'undefined'){
        pageloadmsg.pagename = 'Blog';
        pageloadmsg.countscript = 0;
    }
    else if(typeof($('#contactmessages').attr('id')) !== 'undefined'){
        contactform();
    }
    else if(typeof($('#userlist').attr('id')) !== 'undefined'){
        userspage();
    }
    else if(typeof $('#pluginslist').attr('id') !== 'undefined'){
        pluginspage();
    }
    $('.pagecontainer').removeClass('loading');

    $('#thepagecontainer').delegate('.adminmenus li','click',function(event){
        event.stopPropagation();
        var target = event.target;
        $(target).parent().find('li').removeClass('active');
        $(target).addClass('active');
        var pagecontentid = target.id.substr(10);

        $('#thepageitcontains_'+currentcontentidx).find('.pagecontent_'+$(target).parent().attr('id')).removeClass('active');
        $('#'+pagecontentid).addClass('active');

    });

    $('#thepagecontainer').delegate('#settingsseg li','click',function(event){
        event.stopPropagation();
        var target = event.target;
        $('.settingsseg').find('li').removeClass('active');
        $('.settingssegment').removeClass('active');
        $(target).addClass('active');
        var pagecontentid = target.id;
        $('.settingscontainer').removeClass('active');
        $('#container_'+pagecontentid).addClass('active');
    });
    $('#thepagecontainer').delegate('.modallink','click',function(event){
        event.stopPropagation();
        var modalid = this.id.substr(this.id.indexOf('_')+1);
        $('#'+modalid).addClass('active');

        blurcontent();
    });
    $('#thepagecontainer').delegate('.closemodal','click',function(event){
        event.stopPropagation();
        var modalmsg = $(this).parent().find('.modalmsg').removeClass('active').html();
        if(modalmsg !== '' && modalmsg.indexOf('please complete') === -1){
            registapagemsg(modalmsg,true);
        }
        $(this).parent().removeClass('active');
        blurmodal();
    });
}
function registapagemenu(){
    registapageloggedin = true;

    $('body').delegate('.adminmenuitem','click',function(event){
    	event.stopPropagation();
    	$('.adminmenuitem').removeClass('current');
    	$(this).addClass('current');

        var downloaded = false;
        var pagelink = $(this).children('a').attr('id');
        var pagename = $(this).children('a').html();

    	if(pagelink == pagecontents[currentcontentidx].pagelink){
    		return;
    	}
    	$('.pagecontainer').addClass('loading');
        $('#thepageitcontains_'+currentcontentidx).removeClass('active');

        $.each(pagecontents,function(pi,pe){
            if(pagename =='Apps' && pe.pagename =='Apps'){
                downloaded = pi;
                return false;
            }
            if(pe.pagelink == pagelink && pe.appid == activeapp){
                downloaded = pi;
                return false;
            }
        });
        if(downloaded === false){
            $.ajax({
                url:pagelink,
                type:'POST',
                data:{app:appname,d:{ajax:true}}
            }).done(function(msg){
                pageloadmsg = msg = $.parseJSON(msg);
                pageloadmsg.pagename = pagename;
                pageloadmsg.countscript = 0;

                currentcontentidx = pagecontents.length;
                var pagecontent = '<div class="thepageitcontains active" id="thepageitcontains_'+currentcontentidx+'">'+msg.pagecontent+'</div>';

                pagecontents[pagecontents.length] = [];
                pagecontents[pagecontents.length-1].pagelink = pagelink;
                pagecontents[pagecontents.length-1].pagename = pagename;
                pagecontents[pagecontents.length-1].appid = activeapp;
                pagecontents[pagecontents.length-1].content = pagecontent;

                $('#thepagecontainer').append(pagecontent);

                if(typeof msg.scripts !== 'undefined' && msg.scripts.length){
        			pageloadmsg.countscript = msg.scripts.length;
        			var scriptarr = [];
        			$.each(msg.scripts,function(scriptname,scriptsrc){
        			    if(scriptsrc.indexOf('.css') !== -1){
        			        scriptarr[scriptarr.length] = document.createElement('link');
                            scriptarr[scriptarr.length-1].rel = 'stylesheet';
                            scriptarr[scriptarr.length-1].type = 'text/css';
                            scriptarr[scriptarr.length-1].href = scriptsrc;
        			    }
        			    else{
        			        scriptarr[scriptarr.length] = document.createElement('script');
        			        scriptarr[scriptarr.length-1].src = scriptsrc;
        			    }
        			    if($.inArray(scriptarr[scriptarr.length-1].src,scriptsloaded) === -1){
        			        scriptsloaded[scriptsloaded.length] = scriptarr[scriptarr.length-1].src;
        			        scriptsloadedtype[scriptsloadedtype.length] = pagelink.indexOf('[plugindata]') == -1 ? 'regista' : 'plugin';

        			        document.getElementsByTagName("head")[0].appendChild(scriptarr[scriptarr.length-1]);

        			        if ("onreadystatechange" in scriptarr[scriptarr.length-1]) {
                				scriptarr[scriptarr.length-1].onreadystatechange = function() {
                					if (/loaded|complete/.test(scriptarr[scriptarr.length-1].readyState)) {
                					    onreceivingpage();
                					}
                				};
                			} else {
                				scriptarr[scriptarr.length-1].onload = onreceivingpage;
                			}
        			    }
        			    else{
        			        pageloadmsg.countscript--;
        			    }
        			});
        			if(pageloadmsg.countscript == 0){
        			    onreceivingpage();
        			}
        		}
        		else{
        		    onreceivingpage();
        		}
            });
        }
        else{
		    currentcontentidx = downloaded;
		    if($('#thepageitcontains_'+currentcontentidx).length == 0){
		          $('#thepagecontainer').append(pagecontents[currentcontentidx].content);
		    }
		    if(pagecontents[currentcontentidx].pagename == 'Blog'){
                tinythentinynow();
            }
            else if(pagecontents[currentcontentidx].pagename == 'Users'){
                userspage();
            }
            $('#thepageitcontains_'+currentcontentidx).addClass('active');
            $('#thepagecontainer').removeClass('loading');
        }
    });
    $('body').delegate('#logout','click',function(){
       logoutuser();
    });
    if(mobile){
        $('#logo').on('touchstart',function(event){
            event.stopPropagation();
            if($('#sidebar').attr('class').indexOf('docked') !== -1){
                $('#sidebar').removeClass('docked');
                $('#thepagecontainer').removeClass('docked');
            }
            else{
                $('#sidebar').addClass('docked');
                $('#thepagecontainer').addClass('docked');
            }
        });
    }
    else{
        $('#logo').on('click',function(event){
            event.stopPropagation();
            if($('#sidebar').attr('class').indexOf('docked') !== -1){
                $('#sidebar').removeClass('docked');
                $('#thepagecontainer').removeClass('docked');
            }
            else{
                $('#sidebar').addClass('docked');
                $('#thepagecontainer').addClass('docked');
            }
        });   
    }
    $('#roundr').on('click',function(event){
        event.stopPropagation();
        if(isanelectronapp){
            ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        }
    });
}
function blurcontent(){
    $('.thepageitcontains.active').children('.pagecontent').addClass('opaque');
    $('.thepageitcontains.active').children('.pageheader').addClass('opaque');
}
function blurmodal(){
    $('.thepageitcontains.active').children('.pagecontent').removeClass('opaque');
    $('.thepageitcontains.active').children('.pageheader').removeClass('opaque');
}
function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }

            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password');
            }

            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text');
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }
        }
    });
}
function loggedinremembered(email){
    $('#login').addClass('loggingin');
    $('#login').val('');
    var postdata = {email:email};
    $.ajax({
        url:"./",
        data:{app:appname,p:'ajax',a:'loggedinremembered',d:postdata},
        type:"POST"
    }).done(function(msg){
        result = JSON.parse(msg);
        $('#login').removeClass('loggingin');
        $('#login').val('Login');
        if(result.login != 2){
            $('#logmessage').html(lang.loginerr[result]);
        }
        else{
            $('#registabody').remove();
            $('body').addClass('loggedinadmin');
            $('#opaquebg').after(result.pagecontent);
            activeapp = currentappid = result.activeapp;
            registapagechange();
        }
    });
}
function loginuser() {
    $('#login').addClass('loggingin');
    $('#login').val('');
    var postdata = {email:$('#loginemail').val(),passwd:$('#loginpasswd').val()};
    $.ajax({
        url:"./",
        data:{app:appname,p:'ajax',a:'loginadmin',d:Array(postdata.email,postdata.passwd)},
        type:"POST"
    }).done(function(msg){
        result = JSON.parse(msg);
        $('#login').removeClass('loggingin');
        $('#login').val('Login');
        if(result.login != 2){
            $('#logmessage').html(lang.loginerr[result.login]);
        }
        else{
            $('#registabody').remove();
            $('body').addClass('loggedinadmin');
            $('#opaquebg').after(result.pagecontent);
            activeapp = currentappid = result.activeapp;

            var adminemail={name:'registaadminemail',value:postdata.email};
            localstoragefunc.setVal(adminemail);

            registapagechange();
        }
    });
}
function logoutuser(){
    $('#opaquebg').addClass('active');
    $.ajax({
        url:"./",
        data:{app:appname,ajax:1,p:'home',a:'logout'},
        type:"POST"
    }).done(function(msg){
        result = $.parseJSON(msg);

        $('#thepagecontainer').remove();
        $('#sidebar').remove();

        $('body').removeClass('loggedinadmin').addClass('ready');
        $('#opaquebg').after(result.pagecontent);
        $('#opaquebg').removeClass('active');

        var clearlogin = {name:'registaadminemail',value:false};
        localstoragefunc.setVal(clearlogin);
    });
}
var contentobject = function(app,type,name,content,path,pathtype,idx){
    this.app=app;
    this.type=type;
    this.name=name;
    this.content=content;
    this.path=path;
    this.pathtype=pathtype;
    this.idx = idx;
};
contentobject.prototype.toBrowserString = function(){
    switch(this.type){
        case 'flag':
            return '<div class="browserfileelem emptyfolder" id="browserfileelem_'+this.idx+'">'+this.name+'</div>';
        break;
        case 'deleted':
            return '';
        break;
        default:
            var extclass= '';
            if(this.name.indexOf('.js') !== -1){
                extclass = ' js';
            }
            else if(this.name.indexOf('.css') !== -1){
                extclass = ' css';
            }
            else if(this.name.indexOf('.php') !== -1){
                extclass = ' php';
            }
            else if(this.name.indexOf('.sql') !== -1){
                extclass = ' sql';
            }
            else if(this.name.indexOf('.pxsync') !== -1){
                extclass = ' pxsync';
            }
            else if(this.name.indexOf('.progress') !== -1){
                extclass = ' progress';
            }
            return '<div class="browserfileelem'+extclass+'" id="browserfileelem_'+this.idx+'">'+this.name+'<span class="browserfileelemaction"><span class="rename"></span><span class="delete"></span></span></div>';
        break;
    }
};
contentobject.prototype.edit = function(callback,currentappid){
    if(this.content !== 0){
        callback(this.content,this.idx);
    }
    else{
        var thisobj = this;
        if(this.name.indexOf('.ico') !== -1 || this.name.indexOf('.png') !== -1 || this.name.indexOf('.jpg') !== -1 || this.name.indexOf('.gif') !== -1){
            callback(false,this.idx);
            return;
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'browser',a:'completeStub',d:{pathtype:this.pathtype,path:this.path,appid:this.app,file:this.name}}
        }).done(function(msg){
            msg = $.parseJSON(msg);
            if(msg === false)
                return;

            thisobj.content = msg;
            callback(thisobj.content,thisobj.idx);
        });
    }
};
contentobject.prototype.saveChanges = function(content,currentappid,callback){
    this.content = content;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'browser',a:'saveFile',d:{pathtype:this.pathtype,path:this.path,appid:this.app,file:this.name,content:content}}
    }).done(function(msg){
        msg = $.parseJSON(msg);
        callback(msg);
    });
};
contentobject.prototype.packcb = function(msg){
    if(typeof msg.content === 'undefined' || msg.packmode != 'jspackerdeco'){
        return;
    }
    editors.editor[editors.editorindex()].setValue(msg.content,1);
    this.content = msg.content;
    $('#editorfilelist').removeClass('editing');  
};
contentobject.prototype.packfile = function(content,callback){
    var packmode=$('.jspacker.loading').attr('id');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'browser',a:'packfile',d:{packmode:packmode,pathtype:this.pathtype,path:this.path,appid:this.app,file:this.name,content:content}}
    }).done(function(msg){
        msg = $.parseJSON(msg);
        msg.packmode = packmode;
        callback(msg);
    });
};

    var currentpath     = false;
    var currentpathtype = false;
    var browsercontent = {
        trees:[],
        renamefile:function(newname,fileidx,msgbox){
            $('#browseview').addClass('loading');

             $.ajax({
                type:'POST',
                url:'./',
                data:{app:appname,p:'browser',a:'renamefile',d:{newname:newname,pathtype:currentpathtype,appid:currentappid,file:browsercontent.contents[fileidx].name,path:currentpath}}
            }).done(function(msg){
                if(msg === 'false'){
                    msgbox.errormsg('error renaming file',false);
                    return;
                }
                browsercontent.contents[fileidx].name = newname;
                $('#browserfileelem_'+fileidx).replaceWith(browsercontent.contents[fileidx].toBrowserString());
                msgbox.close();
                $('#browseview').removeClass('loading');
            });
        },
        addfile:function(filename,msgbox){
            $('#browseview').addClass('loading');
            $.ajax({
                type:'POST',
                url:'./',
                data:{app:appname,p:'browser',a:'createfile',d:{pathtype:currentpathtype,appid:currentappid,file:filename,path:currentpath}}
            }).done(function(msg){
                if(msg === 'false'){
                    msgbox.errormsg('error creating file',false);
                    return;
                }
                msgbox.close();
                var contentobj = new contentobject(currentappid,'file',filename,0,currentpath,currentpathtype,browsercontent.contents.length);
                browsercontent.addcontent(contentobj);
                $('#browserlists').find('.createfile').before(contentobj.toBrowserString());
                if($('.emptyfolder').length){
                    var flagid = $('.emptyfolder').attr('id').substr(16);
                    browsercontent.removefile(flagid);
                }
                $('#browseview').removeClass('loading');
            });
        },
        removefile:function(objidx){
            if(this.contents[objidx].type !== 'flag'){
                var filename = this.contents[objidx].name;
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'browser',a:'deletefile',d:{pathtype:currentpathtype,appid:currentappid,file:filename,path:currentpath}},
                }).done(function(msg){
                    if(msg !== 'false'){
                        browsercontent.contents[objidx].type = 'deleted';
                        $('#browserfileelem_'+objidx).remove();
                        if($('#browserlists').find('.browserfileelem').length == 1){
                            var contentobj = new contentobject(currentappid,'flag','emptyfolder',0,currentpath,currentpathtype,browsercontent.contents.length);
                            browsercontent.addcontent(contentobj);
                            $('.browserfileelem.createfile').before(contentobj.toBrowserString());
                        }
                    }
                   $('#browseview').removeClass('loading');
                });
                return;
            }
            this.contents[objidx].type = 'deleted';
            $('#browserfileelem_'+this.contents[objidx].idx).remove();
            $('#browseview').removeClass('loading');
        },
        addtree:function(treehtml,appid){
            var tidx = this.gettreeidx(appid);
            if(tidx !== false){
                this.trees[tidx].thetree = treehtml;
                return;
            }
            this.trees[this.trees.length] = [];
            this.trees[this.trees.length-1].appid = appid;
            this.trees[this.trees.length-1].thetree = treehtml;
        },
        gettreeidx:function(appid){
            var treeidx = false;
            $.each(this.trees,function(tix,telem){
                if(telem.appid === appid){
                    treeidx = tix;
                    return false;
                }
            });
            return treeidx;
        },
        gettree:function(appid){
            if(this.trees.length === 0)
                return false;

            var treehtml = this.gettreeidx(appid);
            if(treehtml !== false){
                treehtml = this.trees[treehtml].thetree;
            }
            return treehtml;
        },
        changeappname:function(appid,newappname,oldname){
            var treehtml = this.gettreeidx(appid);
            if(treehtml !== false){
                var map = this.contentappmap.getmap(appid,'app',false);

                for(var i=0;i<map.length;i++){
                    this.contents[map[i]].path = this.contents[map[i]].path.replace(oldname+'/',newappname+'/');
                }

                if(currentappid == appid){
                    $.each($('#browser').find('.treeitem'),function(ti,te){
                        var teclass = $(te).attr('class');
                        $(te).prop('class',teclass.replace(oldname+'/',newappname+'/'));
                    });
                }
                else{
                    this.trees.splice(treehtml,1);
                }
            }
        },
        contents:[],
        contentappmap:{
            map:[],
            addmap:function(idx,contentobj){
                var appid = contentobj.app;
                var mapidx = false;
                if(this.map.length){
                    $.each(this.map,function(mapix,mapelem){
                        if(mapelem.appid == appid){
                            mapidx = mapix;
                            return false;
                        }
                    });
                    if(mapidx === false){
                        mapidx = this.map.length;
                        this.map[mapidx] = [];
                        this.map[mapidx].appid = appid;
                        this.map[mapidx].map = [];
                        this.map[mapidx].pathmap = [];
                    }
                }
                else{
                    mapidx = 0;
                    this.map[mapidx] = [];
                    this.map[mapidx].appid = appid;
                    this.map[mapidx].map = [];
                    this.map[mapidx].pathmap = [];
                }

                this.map[mapidx].map[this.map[mapidx].map.length] = idx;

                var pathmapidx = false;
                if(this.map[mapidx].pathmap.length){
                    $.each(this.map[mapidx].pathmap,function(pmi,pmelem){
                        if(pmelem.path == contentobj.path){
                            pathmapidx = pmi;
                            return false;
                        }
                    });
                    if(pathmapidx === false){
                        pathmapidx = this.map[mapidx].pathmap.length;
                        this.map[mapidx].pathmap[pathmapidx] = [];
                        this.map[mapidx].pathmap[pathmapidx].path = contentobj.path;
                        this.map[mapidx].pathmap[pathmapidx].map = [];
                    }
                }
                else{
                    pathmapidx = 0;
                    this.map[mapidx].pathmap[pathmapidx] = [];
                    this.map[mapidx].pathmap[pathmapidx].path = contentobj.path;
                    this.map[mapidx].pathmap[pathmapidx].map = [];
                }
                this.map[mapidx].pathmap[pathmapidx].map[this.map[mapidx].pathmap[pathmapidx].map.length] = idx;
            },
            getmap:function(appid,maptype,typeval){
                var themap = false;
                if(this.map.length){
                    $.each(this.map,function(mapix,mapelem){
                        if(mapelem.appid == appid){
                            switch(maptype){
                                case 'app':
                                    themap = mapelem.map;
                                break;
                                case 'path':
                                    themap = mapelem.pathmap;
                                    var amap = false;
                                    $.each(themap,function(tmi,tmelem){
                                        if(tmelem.path == typeval){
                                            amap = tmelem.map;
                                            return false;
                                        }
                                    });
                                    themap = amap;
                                break;
                            }
                            return false;
                        }
                    });
                    return themap;
                }
                else{
                    return false;
                }
            }
        },
        searchcontent:function(app,path,type,keyword){
            var result = false;
            if(type=== false && keyword === false){
                result = this.contentappmap.getmap(app,'path',path);
            }
            else{
                var searchres = this.contentappmap.getmap(app,'path',path);
                for(var i=0;i<searchres.length;i++){
                    if(this.contents[searchres[i]].name == keyword){
                        return searchres[i];
                    }
                }
            }
            return result;
        },
        addcontent:function(contentobj){
            this.contents[contentobj.idx]   = contentobj;
            this.drawmap(contentobj.idx,contentobj);
        },
        drawmap:function(idx,contentobj){
            this.contentappmap.addmap(idx,contentobj);
        },
        savecontent:function(itemobj){
            this.contents[itemobj.idx] = itemobj;
        }
    };

function beginappssync(){
    $('#gosyncapp').addClass('loading');
    syncing = true;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'sync',a:'beginsyncsession'}
    }).done(function(msg){
        $('#gosyncapp').removeClass('loading');
        if(msg != '9'){
            var errormsg = new messagebox();
            switch(msg){
                case '0':
                    errormsg.title = 'Failed Creating New Directories';
                    errormsg.content = 'Please check file permission';
                    errormsg.action = '';
                    errormsg.display();
                break;
                case '1':
                    errormsg.title = 'Failed Creating New Database/Table, Please Input Database User Credentials';
                    errormsg.content = '<div class="row"><input type="text" value="username" id="dbcreduser"></div><div class="row"><input type="text" name="password" value="password" id="dbcredpasswd"></div>';
                    errormsg.action = '<span id="dbcredconfirm">Confirm</span>';
                    errormsg.display();
                    
                    $('#dbcredconfirm').on('click',function(event){
                        event.stopPropagation();
                        
                        var username = $('#dbcreduser').val();
                        username = username == $('#dbcreduser').attr('name') ? false : username;
                        var passwd = $('#dbcredpasswd').val();
                        passwd = passwd == $('#dbcredpasswd').attr('name') ? false : passwd;
                        
                        if(username === false || passwd === false){
                            return;
                        }
                        
                        
                        $('#messageboxmsg').html('Processing...').addClass('active');
                        $.ajax({
                            url:'./',
                            type:'POST',
                            data:{app:appname,p:'sync',a:'dbcred',d:{username:username,passwd:passwd}}
                        }).done(function(msg){
                            if(msg == '1'){
                                beginappssync();
                                dispsyncprogress();
                            }
                            else if(msg == '5'){
                                $('#messageboxmsg').html('unauthorized account').addClass('error');
                            }
                            else{
                                $('#messageboxmsg').html('Error creating database').addClass('error');
                            }
                        });
                    });
                break;
                default:
                    errormsg.title = 'Unknown Error';
                    errormsg.content = 'Unknown error occured :'+msg;
                    errormsg.action = '';
                    errormsg.display();
                break;
            }
        }
        syncing = false;
    });
}
function readsyncprogress(){
    var xhr = window.ActiveX ? new ActiveXObject("Microsoft.XMLHTTP"): new XMLHttpRequest();
    var sdata = new FormData();
    sdata.append('app', appname);
    sdata.append('p','sync');
    sdata.append('a','readprogress');
    sdata.append('progressfile', syncprogressfile);

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200){
            var response = JSON.parse(xhr.responseText);
            if(response.progress != 'false'){
                if(response.progress.indexOf('end of syncing app:') !== -1){
                    var endappsync = response.progress.split('end of syncing app:');
                    endappsync = endappsync[1].split('.');
                    endappsync = endappsync[0];
                    $('#syncapp').find('#syncapp_'+endappsync).children('.syncconfig').html('done');
                    
                    var endofnewapp = true;
                    $.each($('#appspage').find('.appname'),function(i,e){
                       if($(e).children().html() == endappsync){
                           endofnewapp = false;
                           return false;
                       }
                    });
                    if(endofnewapp){
                        $.ajax({
                            url:'./',
                            type:'POST',
                            data:{app:appname,p:'apps',a:'appelements',d:{noa:endappsync}}
                        }).done(function(msg){
                            msg = JSON.parse(msg);
                            var newapprow = '<div class="appelements" id="app_'+msg.id+'">'
                                +'<div class="appelem elemid">'+msg.id+'</div>'
                                +'<div class="appelem appname actionsspan"><a href="'+msg.link+'" target="_blank">'+msg.name+'</a></div>'
                                +'<div class="appelem">'+msg.createdon+'</div>'
                                +'<div class="appelem elemcreator">'+msg.creator+'</div>'
                                +'<div class="appelem administer">'
                                    +'<span class="deleteapp redfont actionsspan"><a class="deleteappbtn" id="deleteappbtn_'+msg.id+'" href="'+msg.deletelink+'">delete</a></span>'
                                    +'<span class="browseapp actionsspan"><a href="javascript:void(0);" class="browseapplink" id="browseapp_'+msg.id+'">browse</a></span>'
                                    +'<span class="administerapp actionsspan"><a href="'+msg.administerlink+'">administer</a></span>'
                                +'</div>'
                            +'</div>';
            
                            $('#appspage').append(newapprow); 
                        });   
                    }
                }
                $('#syncprogress').append(response.progress);
            }

            if(syncing){
                setTimeout(function(){
                    readsyncprogress();
                },4000);
            }
        }
        else if (xhr.readyState === 4) {

        }
    };
    xhr.open('POST',syncurl,true);
    xhr.send(sdata);
}

function dispsyncprogress(){
    setTimeout(function(){
        readsyncprogress();
    },4000);
}
function appspage(){
    $('#thepagecontainer').delegate('.syncconfigedit','keyup',function(event){
        event.stopPropagation();
        
        if(event.which == 13){
            $(this).parent().next().children().children().prop('checked','checked');
            
            var syncconfigedit = $(this).val() == '' ? $(this).attr('name') : $(this).val();
            $(this).parent().html(syncconfigedit);
        }
    });
    $('#thepagecontainer').delegate('.syncconfigedit','blur',function(event){
        event.stopPropagation();

        var syncconfigedit = $(this).val() == '' ? $(this).attr('name') : $(this).val();
        $(this).parent().html(syncconfigedit);
    });
    $('#thepagecontainer').delegate('.syncconfig','click',function(event){
        event.stopPropagation();
        if($(this).children().length){
            return;
        }

        var syncconfigedit = $(this).html();
        $(this).html('<input type="text" value="'+syncconfigedit+'" class="syncconfigedit">');

        $(this).children().focus();
    });
    $('#thepagecontainer').delegate('#syncappurl','blur',function(){
        setTimeout(function(){
            $('.syncaux').remove();
        },300);
    });
    $('#thepagecontainer').delegate('#syncappurl','click focus',function(){
        gsappaux(this);
    });
    $('#thepagecontainer').delegate('#syncappurl','keyup',function(event){
        event.stopPropagation();
        
        if(event.which == 13){
            gsapp($(this).next());
            return;
        }
        
        gsappaux(this);
    });
    $('#thepagecontainer').delegate('#goresetsyncapp','click',function(event){
        event.stopPropagation();

        $('#syncapp').children('.appelements').remove();
        $('#syncapp').children('.clearline.appline').remove();
        $('#syncapp').children('.appelemhead').remove();
        $('#syncapp').children('#syncprogress').remove();


        $('#gosyncapp').prev().val($('#gosyncapp').prev().attr('name')).removeClass('filled');
        $('#gosyncapp').val('Request to Sync');
        $(this).addClass('hide');
        $(this).prev().addClass('hide');
        syncappstage = 0;
    });
    $('#thepagecontainer').delegate('#syncapprefresh','click',function(event){
        event.stopPropagation();

        $('#syncapp').children('.appelements').remove();
        $('#syncapp').children('.clearline.appline').remove();
        $('#syncapp').children('.appelemhead').remove();
        $('#syncapp').children('#syncprogress').remove();
        syncappstage = 0;
        
        gsapp($(this).prev());
    });
    function gsappaux(elem){
        if(typeof $(elem).prev().attr('class') ==='undefined'){
            var syncurl = localstoragefunc.getVal('syncurl');
            if(syncurl=='false'||syncurl==false||syncurl==null){
                return;
            }
            syncurl = JSON.parse(syncurl);
            var syncaux = '<ul class="syncaux">';
            for(var i=0;i<syncurl.length;i++){
                syncaux += '<li>'+syncurl[i].addr+'</li>';
            }
            syncaux+='</ul>';
            $(elem).before(syncaux);
            $('.syncaux li').on('click',function(event){
                event.stopPropagation();
                $(this).parent().next().val($(this).html());
                $(this).parent().remove();
            });
        }
    }
    function gsapp(gsappbtn){
        switch(syncappstage){
            case 0:
                $(gsappbtn).siblings('.syncaux').remove();
                syncurl = $(gsappbtn).prev().val();
                if(syncurl == '' || syncurl == $(gsappbtn).prev().attr('name')){
                    return;
                }
                $(gsappbtn).addClass('loading');

                $(gsappbtn).prop('value','Sync Selected');
                $(gsappbtn).next().removeClass('hide');
                $(gsappbtn).next().next().removeClass('hide');
                syncappstage = 1;
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'sync',a:'reqsyncprep',d:{url:syncurl}}
                }).done(function(msg){
                    msg = JSON.parse(msg);
                    var applist = '<div class="appelemhead appname">Name</div><div class="appelemhead">Last Modified</div><div class="appelemhead syncconfig">Sync Configuration</div><div class="appelemhead actions administer">Sync</div>';
                    var cmi =0;
                    $.each(msg,function(msi,msv){
                        cmi++;
                        applist += '<div class="clearline appline"></div><div class="appelements" id="syncapp_'+msv.name+'">'
                                     +       '<div class="appelem appname actionsspan">'+msv.name+'</div>'
                                     +       '<div class="appelem">'+msv.modified+'</div>'
                                      +      '<div class="appelem syncconfig">'+msv.syncconfig+'</div>'
                                       +     '<div class="appelem administer">'
                                        +        '<span class="syncappcheck actionsspan"><input type="checkbox"  class="syncappcheckbox" id="syncappcheck_'+msv.name+'"></span>'
                                         +   '</div>'
                                    +'</div>';
                    });   
                    if(cmi){
                        var surls = localstoragefunc.getVal('syncurl');
                        if(surls!='false' && surls!==false && surls!==null){
                            surls = JSON.parse(surls);
                            for(var i=0;i<surls.length;i++){
                                if(surls[i].addr == syncurl){
                                    surls.splice(i,1);
                                    break;
                                }
                            }
                        }
                        else{
                            surls = [];
                        }
                        surls[surls.length] = {addr:syncurl};
                        surls = JSON.stringify(surls);
                        localstoragefunc.setVal({name:'syncurl',value:surls});   
                    }
                    $('#syncapp').children('.appelements').remove();
                    $('#syncapp').children('.clearline.appline').remove();
                    $('#syncapp').append(applist);

                    $('#gosyncapp').removeClass('loading');
                });
            break;
            case 1:
                var apptosync = [];
                $.each($('#syncapp').find('.syncappcheckbox'),function(ci,cv){
                    if($(cv).prop('checked')){
                        apptosync[apptosync.length] = $(cv).attr('id').substr(parseInt($(cv).attr('id').indexOf('_'))+1);
                    }
                });

                if(!apptosync.length)
                    return;


                $('#syncapp').find('.clearline.appline').addClass('hide');

                var appsyncconfig = [];
                for(var i=0;i<apptosync.length;i++){
                    appsyncconfig[appsyncconfig.length] = $('#syncapp_'+apptosync[i]).children('.syncconfig').html();
                    $('#syncapp_'+apptosync[i]).addClass('waitingtosync');
                    $('#syncapp_'+apptosync[i]).children('.syncconfig').html('processing...');
                    $('#syncapp_'+apptosync[i]).children('.administer').html('');

                    $('#syncapp_'+apptosync[i]).next().removeClass('hide');
                }
                $('#syncapp').children('.appelements').addClass('hide');
                $('#syncapp').children('.waitingtosync').removeClass('hide');
                $('#syncapp').find('.appelemhead.syncconfig').html('status');
                $('#syncapp').find('.appelemhead.syncconfig').next().html('');

                $('#syncapp').find('.appelemhead.appname').prev().after('<div id="syncprogress"></div><div class="clearline"></div>');
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'sync',a:'beginsyncsession',d:{apptosyncarr:apptosync.join('<edsep>'),appsyncconfigarr:appsyncconfig.join('<edsep>')}}
                }).done(function(msg){
                    msg = JSON.parse(msg);

                    syncprogressfile = msg.progressfile;
                    syncurl = msg.syncurl;

                    beginappssync();
                    dispsyncprogress();
                });
            break;
        }
    }
    var syncappstage = 0;
    $('#thepagecontainer').delegate('#gosyncapp','click',function(event){
        event.stopPropagation();
        
        gsapp(this);
    });
    var clickedonappoption = false;
    $('#thepagecontainer').delegate('.appoptions','click focus',function(event){
        event.stopPropagation();
        $(this).val('').next().addClass('active').children().show().removeClass('selected');
    });
    $('#thepagecontainer').delegate('.appoptions','keyup',function(event){
        event.stopPropagation();
        
        var appopt = this;
        if(event.which == 38){
            if(typeof $(this).next().children('.selected').attr('class') === 'undefined')
            for(var i=$(this).next().children().length-1;i>=0;i--){
                if($(this).next().children().eq(i).css('display') != 'none'){
                    $(this).next().children().eq(i).addClass('selected');
                    break;
                }
            }
            else{
                var ce = $(this).next().children('.selected');
                $(ce).removeClass('selected');
                ce = $(ce).prev();
                while(typeof $(ce).prev().attr('class') !== 'undefined' && $(ce).css('display') == 'none'){
                    ce = $(ce).prev();
                }
                if($(ce).css('display') == 'none'){
                    for(var i=$(this).next().children().length-1;i>=0;i--){
                        if($(this).next().children().eq(i).css('display') != 'none'){
                            $(this).next().children().eq(i).addClass('selected');
                            break;
                        }
                    }
                }
                else{
                    $(ce).addClass('selected');
                }
            } 
            return;
        }
        else if(event.which == 40){
            if(typeof $(this).next().children('.selected').attr('class') === 'undefined')
            $.each($(this).next().children(),function(ci,ce){
                if($(ce).css('display') != 'none'){
                    $(ce).addClass('selected');
                    return false;
                }
            });
            else{
                var ce = $(this).next().children('.selected');
                $(ce).removeClass('selected');
                ce = $(ce).next();
                while(typeof $(ce).next().attr('class') !== 'undefined' && $(ce).css('display') == 'none'){
                    ce = $(ce).next();
                }
                if($(ce).css('display') == 'none'){
                    $.each($(this).next().children(),function(cix,cex){
                        if($(cex).css('display') != 'none'){
                            $(cex).addClass('selected');
                            return false;
                        }
                    });
                }
                else{
                    $(ce).addClass('selected');
                }
            }            
            return;
        }
        else if(event.which == 13){
            if(typeof $(this).next().children('.selected').attr('class') !== 'undefined'){
                clickedonappoption = this;
                $(this).next().next().focus();
            }
            return;
        }
        
        $(this).next().children('.selected').removeClass('selected');
        
        var keyw = $(this).val();
        $.each($(this).next().children(),function(ci,ce){
            if($(ce).html().indexOf(keyw) !== -1){
                $(ce).show();
            }
            else{
                $(ce).hide();
            }
        });
    });
    $('#thepagecontainer').delegate('.appoptions','blur',function(event){
        event.stopPropagation();

        var bluredappoption = this;
        setTimeout(function(){
            if(clickedonappoption !== false){
                var selected = $(clickedonappoption).next().children('.selected').length ? $(clickedonappoption).next().children('.selected').html() : 'All';
                $(clickedonappoption).val(selected).next().removeClass('active');

                clickedonappoption = false;
            }
            else{
                $(bluredappoption).val('app name').next().removeClass('active');
            }
        },200);
    });
    $('#thepagecontainer').delegate('.selectappfromlist','click',function(event){
        event.stopPropagation();

        clickedonappoption = $(this).parent().prev();
        $(this).parent().children().removeClass('selected');
        $(this).addClass('selected');
    });
    $('#thepagecontainer').delegate('#searchcodekey','keyup',function(event){
        event.stopPropagation();

        if(event.which == 13){
            gosearchcode();
        }
    });
    $('#thepagecontainer').delegate('#gosearchcode','click',function(event){
        event.stopPropagation();

        gosearchcode();
    });
    function searchresultcodeview(elem){
        $('#searchcoderesult').addClass('loading');
        $('#searchcoderesult').children('.loadingnotification').addClass('active');

        var apptosearch = parseInt($('#apptosearch').next().children('.selected').attr('id'));
        var pathtofile = $(elem).attr('class').split(' ');
        pathtofile = pathtofile[pathtofile.length-1];
        var filename  = $(elem).html();

        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'browser',a:'searchrescontent',d:{appid:apptosearch,path:pathtofile,file:filename}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            editors.gosearchcode = msg;
            editors.addfile(-9);

            $('#searchcoderesult').removeClass('loading');
            $('#searchcoderesult').children('.loadingnotification').removeClass('active');
            editors.setfilemode(filename);
        });
    }
    function gosearchcode(){
        var keyword = $('#searchcodekey').val();
        if(keyword == '')
            return;

        var disbutton = $('#gosearchcode');

        $(disbutton).addClass('loading');
        var apptosearch = $('#apptosearch').val();
        if(apptosearch == $('#apptosearch').attr('name') || apptosearch == '' || apptosearch == 'All'){
            apptosearch = '';
            $.each($('#apptosearch').next().children(),function(ci,ce){
                if($(ce).html() !== 'All')
                    apptosearch += $(ce).html()+'|';
            });
        }

        var typetosearch='';
        $.each($(disbutton).parent().prev().find('.typetosearch'),function(ci,ce){
            if($(ce).prop('checked')){
                typetosearch+=$(ce).attr('id')+'|';
            }
        });

        $('#searchreslist').html('');
        $('#searchresbrowserlists').html('');

        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'browser',a:'searchcode',d:{keyword:keyword,type:typetosearch,apptosearch:apptosearch}}
        }).done(function(msg){
            msg = JSON.parse(msg);

            var msic =0;
                $.each(msg,function(msi,msv){
                    msic++;
                    elemlist = '';
                    celemlist = 0;
                    $.each(msv,function(msvi,msve){
                        celemlist+=1;
                        var filetypex = msve.name.split('.');
                        elemlist+='<div class="browserfileelem searchres hide searchof'+msi+' '+filetypex[filetypex.length-1]+' '+msve.path+'" id="browserfilesearchreselem_'+msi+'_'+msvi+'">'+msve.name+'</div>';
                    });
                    $('#searchresbrowserlists').append(elemlist);

                    $('#searchreslist').append('<li class="browsertree"><span class="searchtreeitem" id="searchtreeof_'+msi+'">'+msi+' ('+celemlist+')</span></li>');
                });
                if(msic){
                    var csearchof = $('#searchreslist').children().eq(0).children().attr('id').split('_')[1];
                    $('#searchresbrowserlists').find('.searchof'+csearchof).removeClass('hide');
                }
                $('#searchreslist').children().eq(0).children().addClass('selected');


            $('#gosearchcode').removeClass('loading');
            $('#searchcoderesultbrowser').addClass('active');
        });
    }
    $('#thepagecontainer').delegate('.searchtreeitem','click',function(event){
        event.stopPropagation();

        $(this).parent().parent().find('.selected').removeClass('selected');
        $(this).addClass('selected');

        var csearchof = $(this).attr('id').split('_')[1];
        $('#searchresbrowserlists').children().addClass('hide');
        $('#searchresbrowserlists').find('.searchof'+csearchof).removeClass('hide');
    });
    $('#thepagecontainer').delegate('.administerapp a','click',function(event){
        event.stopPropagation();
        var administerthis = this;
        $(this).parent().addClass('loading');
        $('.elemid.current').siblings('.administer').children('.administerapp').addClass('loading');
        $.ajax({
            url:$(this).attr('href'),
            type:'GET'
        }).done(function(msg){
            if(msg !== 'false'){
                msg = $.parseJSON(msg);
                switchapp(administerthis,msg);
            }
        });
        return false;
    });
    $('#createnewapp').on('click',function(){
        var newappname = $('#newappname').val();
        if(newappname == '' || newappname=='new app name'){
            return;
        }
        $(this).addClass('loading');
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'apps',a:'pageInit',d:{new_app_name:newappname,createnewapp:true}}
        }).done(function(msg){
            if(msg !== 'false'){
                msg = $.parseJSON(msg);
                var newapprow = '<div class="appelements" id="app_'+msg.id+'">'
                                    +'<div class="appelem elemid">'+msg.id+'</div>'
                                    +'<div class="appelem appname actionsspan"><a href="'+msg.link+'" target="_blank">'+msg.name+'</a></div>'
                                    +'<div class="appelem">'+msg.createdon+'</div>'
                                    +'<div class="appelem elemcreator">'+msg.creator+'</div>'
                                    +'<div class="appelem administer">'
                                        +'<span class="deleteapp redfont actionsspan"><a class="deleteappbtn" id="deleteappbtn_'+msg.id+'" href="'+msg.deletelink+'">delete</a></span>'
                                        +'<span class="browseapp actionsspan"><a href="javascript:void(0);" class="browseapplink" id="browseapp_'+msg.id+'">browse</a></span>'
                                        +'<span class="administerapp actionsspan"><a href="'+msg.administerlink+'">administer</a></span>'
                                    +'</div>'
                                +'</div>';

                $('#appspage').append(newapprow);
                registapagemsg(newappname+' successfully created',true);
                $('#createnewapp').removeClass('loading');
            }
        });
    });
    $('#adminmenu_addapp').on('click',function(){
        $('#browser').addClass('hidenow');
    });
    $('#adminmenu_appspage').on('click',function(){
        $('#browser').removeClass('hidenow');
    });
    $('#thepagecontainer').delegate('.deleteappbtn','click',function(event){
        event.stopPropagation();
	    var target = event.target;
        var appnameelem = $(target).parent().parent().parent().children('.appname').children('a');
        var appname = $(appnameelem).html();
        var deletelink = $(target).attr('href');
        var boxtitle = 'Confirm App Deletion';
        var boxcontent = '<span style="font-size:19px;">Delete '+appname+' ?</span>';
        var boxaction = '<span id="deleteappconfirm"><a href="'+deletelink+'">Confirm</a></span><span id="canceldeleteapp">Cancel</span>';

        var confirmbox = new messagebox();
        confirmbox.displayfunc(boxtitle,boxcontent,boxaction);

        $('#canceldeleteapp').on('click',function(){
            confirmbox.close();
        });

        return false;
    });
    function reloadpath(path,elem){
        path = $(elem).html().split('<')[0]+'/'+path;
        var ulelem = $(elem).parent().parent();
        if($(ulelem).attr('class').indexOf('dotree') !== -1){
            if(typeof $(ulelem).prev()[0] !== 'undefined' && $(ulelem).prev()[0].tagName == 'SPAN'){
                path = $(ulelem).prev().html().split('<')[0]+'/'+path;
            }
            else{
                path = reloadpath(path,$(ulelem).prev().children());   
            }
        }
        return path;
    }
    $('#thepagecontainer').delegate('.reloadti','click',function(event){
        event.stopPropagation();
        var reloadtielem,path;
        if(typeof $(this).parent().parent().next().attr('class') !== 'undefined' && $(this).parent().parent().next().attr('class').indexOf('dotree') !== -1){
            $(this).parent().parent().next().remove();
            reloadtielem = $(this).parent().parent();
            path = reloadpath('',$(this).parent());
        }
        else if(typeof $(this).parent().next()[0] !== 'undefined' && $(this).parent().next()[0].tagName == 'UL' && $(this).parent().next().attr('class').indexOf('dotree') !== -1){
            $(this).parent().next().remove();
            
            reloadtielem = $(this).parent();
            path = reloadpath('',$(this).parent());
            
        }
        else{
            reloadtielem = $(this).parent();
            path = reloadpath('',$(this).parent());
        }
        var oldcontent = '';
        if($('#browserlists').children().length > 1){
            $.each($('#browserlists').children(),function(bi,be){
                if($(be).attr('class').indexOf('createfile') === -1 && $(be).attr('class').indexOf('emptyfolder') === -1){
                    if(oldcontent != ''){
                        oldcontent+='<edsep>';
                    }
                    oldcontent+=$(be).html().split('<')[0];
                }
            });
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'browser',a:'updatetree',d:{appid:currentappid,treestruct:true,path:path,oldcontent:oldcontent}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.tree.length){
                var reloaded = browsertree(msg.tree,0);
                $(reloadtielem).after(reloaded);
            }
            if(msg.content.length){
                if($('#browserlists').children('.emptyfolder').length){
                    browsercontent.removefile(parseInt($('#browserlists').children('.emptyfolder').attr('id').substr(16)));
                }
                $.each(msg.content,function(mi,me){
                    var contentobj = new contentobject(currentappid,'file',me.name,0,currentpath,currentpathtype,browsercontent.contents.length);
                    browsercontent.addcontent(contentobj);
                    $('#browserlists').children().eq($('#browserlists').children().length-1).before(contentobj.toBrowserString());
                });
            }
            
            if(msg.obsolete.length){
                $.each(msg.obsolete,function(oi,oe){
                    if(oe != ''){
                        $.each($('#browserlists').children('.browserfileelem'),function(bi,be){
                            if($(be).html().split('<')[0] == oe){
                                browsercontent.removefile(parseInt($(be).attr('id').substr(16)));
                                $(be).remove();
                            }
                        });   
                    }
                });
            }
        });
    });
    $('#thepagecontainer').delegate('.browseapplink','click',function(event){
    	event.stopPropagation();
    	var target = event.target;
    	if($(target).attr('class') !== 'browseapplink')
    		return;

        if($(target).html() == 'close'){
            $('#browser').removeClass('active');
            $('#appspage').find('.appelements').show();
            $('#appspage').find('.clearline').show();
            hidecodeeditor();
            $(target).html('browse');
            return;
        }
        var appid = $(target).parent().parent().parent().attr('id').substr(4);
        currentappid = appid;

        $('#appspage').find('.appelements').hide();
        $('#appspage').find('.clearline').hide();
        $('#app_'+appid).show();

        var tree = browsercontent.gettree(currentappid);

        if(tree === false){
            $('#browserlists').html('');
            $.ajax({
               url:"./",
               data:{app:appname,ajax:1,p:'browser',a:'browser',d:{appid:appid}},
               type:"POST"
           }).done(function(msg){
               msg = $.parseJSON(msg);
               $('#tree').replaceWith(msg.pagecontent);

               var csub = '',msub='',vsub='',rsub='',usub='',psub='';
               csub = browsertree(msg.controllers,0);
               if(csub !== ''){
                    $('#c_controllers').append(csub);
               }

               msub = browsertree(msg.models,0);
               if(msub !== ''){
                    $('#m_models').append(msub);
               }

               vsub = browsertree(msg.views,0);
               if(vsub !== ''){
                    $('#v_views').append(vsub);
               }

               rsub = browsertree(msg.resources,0);
               if(rsub !== ''){
                    $('#res_resources').append(rsub);
               }

                usub = browsertree(msg.uploads,0);
                if(usub !== ''){
                    $('#u_uploads').append(usub);
                }

                psub = browserplugintree(msg.plugins,0);
                if(psub !== ''){
                    $('#pl_plugins').append(psub);
                }

                $('#browseapp_'+appid).html('close');
                $('#browser').addClass('active');

                var contentobj = new contentobject(currentappid,'file','app.php',0,'app','app',browsercontent.contents.length);
                browsercontent.addcontent(contentobj);

                browsercontent.addtree($('#tree').html(),currentappid);
               $('#tree').html(browsercontent.gettree(currentappid));
           });
        }
        else{
            $('#tree').html(tree);
            $('#browserlists').html('');
            $('#browser').addClass('active');
            $('#browseapp_'+appid).html('close');
            $('#browser').css('height',$('#tree').height()+'px');
        }
    });
    function browserplugintree(tree,pluginid){
        if(!($.isArray(tree) && tree.length)){
            return '';
        }
        var descendant = '<ul>';
        $.each(tree,function(tix,telem){
            if(pluginid !== 1){
                descendant  += '<li><span class="treeitem '+telem.path+'/'+telem.name+'">'+telem.name+'</span></li>';
            }

            if(telem.sub !== false){
                descendant += browserplugintree(telem.sub,(pluginid+1));
            }
        });
        descendant += '</ul>';
        return descendant;
    }
    function browsertree(tree,depth){
        if(!($.isArray(tree) && tree.length)){
            return '';
        }
        var descendant = depth == 0 ? '<ul class="dotree_'+depth+' active">' : '<ul class="dotree_'+depth+'">';
        $.each(tree,function(tix,telem){
            descendant+= '<li><span class="treeitem '+telem.path+'/'+telem.name+'">'+telem.name+'<span class="reloadti"></span></span></li>';
            if(telem.sub !== false){
                descendant += browsertree(telem.sub,(depth+1));
            }
        });
        descendant += '</ul>';
        return descendant;
    }
    function showeditor(){
        $('#hidecodeeditor').addClass('active');
        $('#codeeditor_'+editors.editorindex()).addClass('active');
        $('#browseview').addClass('minify');
        $('.editormenu').addClass('active');
        editors.updatefileselectionClass();
    }

    function completecodestub(content,fileidxid){
        editors.addfile(fileidxid);
        showeditor();
        $('#browseview').removeClass('loading');
    }
     $('#thepagecontainer').delegate('.browserfileelem .delete','click',function(event){
	    event.stopPropagation();
        var confirmdeletefile = new messagebox();
        confirmdeletefile.title = 'Confirm deleting file';
        confirmdeletefile.content = 'Delete file?';
        confirmdeletefile.action = '<span id="canceldelete">Cancel</span><span id="deletethefile">Delete</span>';

        confirmdeletefile.display();

        var deleteid = $(this).parent().parent().attr('id').substr(16);
        $('#canceldelete').on('click',function(event){
            event.stopPropagation();
            confirmdeletefile.close();
        });
        $('#deletethefile').on('click',function(event){
            event.stopPropagation();
            $('#browseview').addClass('loading');
            confirmdeletefile.close();
            browsercontent.removefile(deleteid);
        });
    });
    $('#thepagecontainer').delegate('.browserfileelem .rename','click',function(event){
	    event.stopPropagation();
        var renamefiledialog = new messagebox();
        renamefiledialog.title = 'Rename file';
        renamefiledialog.content = '<input type="text" name="file name" id="filenewname" value="file name">';
        renamefiledialog.action = '<span id="cancelrename">Cancel</span><span id="renamethefile">Rename</span>';
        renamefiledialog.display();

        var renamefileid = $(this).parent().parent().attr('id').substr(16);
        $('#cancelrename').on('click',function(event){
            event.stopPropagation();
            renamefiledialog.close();
        });
        $('#filenewname').on('keyup',function(key){
                event.stopPropagation();
                if(key.which == 13){
                    var newname = $('#filenewname').val();
                    if(newname === '' || newname == $('#filenewname').attr('name')){
                        renamefiledialog.errormsg('please fill in the filename',false);
                        return;
                    }
                    browsercontent.renamefile(newname,renamefileid,renamefiledialog);
                }
        });
        $('#renamethefile').on('click',function(event){
            event.stopPropagation();
            var newname = $('#filenewname').val();
            if(newname === '' || newname == $('#filenewname').attr('name')){
                renamefiledialog.errormsg('please fill in the filename',false);
                return;
            }
            browsercontent.renamefile(newname,renamefileid,renamefiledialog);
        });
    });
    $('#thepagecontainer').delegate('.browserfileelem','click',function(event){
	    event.stopPropagation();
	    if($(this).attr('class').indexOf('searchres') !== -1){
	        searchresultcodeview(this);
	        return;
	    }

	    if($(this).attr('class').indexOf('emptyfolder') !== -1){
	        return;
	    }
	    if($(this).attr('class').indexOf('createfile') !== -1){
	        var createfiledialog        = new messagebox();
            createfiledialog.title      = 'New file';
            createfiledialog.content    = '<input type="text" name="file name" id="createfilename" value="file name">';
            createfiledialog.action     = '<span id="cancelcreate">Cancel</span><span id="createthefile">Create</span>';
            createfiledialog.display();

            $('#cancelcreate').on('click',function(event){
                event.stopPropagation();
                createfiledialog.close();
            });
            $('#createfilename').on('keyup',function(key){
                event.stopPropagation();
                if(key.which == 13){
                    var newname = $('#createfilename').val();
                    if(newname === '' || newname == $('#createfilename').attr('name')){
                        createfiledialog.errormsg('please fill in the filename',false);
                        return;
                    }
                    browsercontent.addfile(newname,createfiledialog);
                }
            });
            $('#createthefile').on('click',function(event){
                event.stopPropagation();
                var newname = $('#createfilename').val();
                if(newname === '' || newname == $('#createfilename').attr('name')){
                    createfiledialog.errormsg('please fill in the filename',false);
                    return;
                }
                browsercontent.addfile(newname,createfiledialog);
            });

	        return;
	    }
	    $('#browseview').addClass('loading');
        var fileidxid = this.id.substr(16);
        browsercontent.contents[fileidxid].edit(completecodestub,currentappid);
    });
    $('#thepagecontainer').delegate('#editormaxmin','click',function(event){
	    event.stopPropagation();
        if($('#browseview').attr('class').indexOf('maximized') === -1){
            editors.maximize();
            editors.reneweditor('codeeditor_'+editors.currentfileidx);
            return;
        }
        editors.minimize();
        editors.reneweditor('codeeditor_'+editors.currentfileidx);
    });
    $('#thepagecontainer').delegate('#settheace','click',function(event){
	    event.stopPropagation();
        if(typeof $('#ace_settingsmenu').attr('id') === 'undefined'){
            globalacesettingsmenu(event.clientX,event.clientY);
        }
        else{
            $('#settheace').removeClass('set');
            $('#ace_settingsmenu').parent().parent().remove();
        }
    });
    $('#thepagecontainer').delegate('#helpwithace','click',function(event){
	    event.stopPropagation();
        if($('#aceshortcut').attr('class').indexOf('active') === -1)
            $('#aceshortcut').html(editors.editorkbshortcut).addClass('active');
        else
            $('#aceshortcut').removeClass('active');
    });
    $('#thepagecontainer').delegate('#savecodechanges','click',function(event){
	    event.stopPropagation();
        if($(this).attr('class').indexOf('loading') === -1){
            $(this).addClass('loading');
            editors.saveChanges();
        }
    });
    $('#thepagecontainer').delegate('#autocompleteace','click',function(event){
	    event.stopPropagation();
        if($(this).attr('class').indexOf('on') === -1){
            $(this).addClass('on');
        }
        else{
            $(this).removeClass('on');
        }
        editors.toggleautocomplete();
    });
    $('#thepagecontainer').delegate('.jspacker','click',function(event){
	    event.stopPropagation();
        if($(this).attr('class').indexOf('loading') === -1){
            $(this).addClass('loading');
            editors.packjs();
        }
    });
    $('#thepagecontainer').delegate('#hidesearchrescodeeditor','click',function(event){
	    event.stopPropagation();
        if($(this).attr('class').indexOf('active') === -1){
            showsearchreseditor();
            return;
        }
        hidesearchrescodeeditor();
    });
    $('#thepagecontainer').delegate('#hidecodeeditor','click',function(event){
	    event.stopPropagation();
        if($('#codeeditor_'+editors.editorindex()).attr('class').indexOf('active') === -1){
            showeditor();
            return;
        }
        hidecodeeditor();
    });
    $('#thepagecontainer').delegate('.availfileitem','click',function(event){
        event.stopPropagation();
        if($(this).siblings().length){
            if($('#editorfilelist').attr('class').indexOf('dropdown') === -1){
                showcodefilelist();
            }
            else{
                editors.selectfromfilelist(this);
            }
        }
    });
    $('#thepagecontainer').delegate('#closefile','click',function(event){
	    event.stopPropagation();
        editors.removefile();
    });
    $('#thepagecontainer').delegate('#editorfilelist','click',function(event){
        event.stopPropagation();
        if($(this).find('.availfileitem').length > 1){
            if($('#editorfilelist').attr('class').indexOf('dropdown') === -1){
                showcodefilelist();
            }
            else{
                hidecodefilelist();
            }
        }
    });
    function showcodefilelist(){
       $('#editorfilelist').addClass('dropdown');
        $('.availfileitem').removeClass('hide');

        $('#editorfilelist').children('#availfilelist').on('mouseout',function(event){
            event.stopPropagation();
            if(typeof event.toElement !== 'undefined' && event.toElement.id !== 'editorfilelist' && event.toElement.className.indexOf('availfileitem') === -1){
                $('#editorfilelist').removeClass('dropdown');
                $('.availfileitem').addClass('hide');
                $('.availfileitem.active').removeClass('hide');
            }
        });
    }
    function hidecodefilelist(){
        $('#editorfilelist').removeClass('dropdown');
        $('.availfileitem').addClass('hide');
        $('.availfileitem.active').removeClass('hide');
    }

    function hidecodeeditor(){
        $('#browseview').find('.codeeditor').removeClass('active');
        $('#hidecodeeditor').removeClass('active');
        $('#browseview').removeClass('minify');
        $('#editormessage').removeClass('incoming');
        $('.editormenu').removeClass('active singleactive');
    }
    function hidesearchrescodeeditor(){
        $('.searchrescodeeditor').removeClass('active');
        $('#hidesearchrescodeeditor').removeClass('active');
        $('#searchcoderesult').removeClass('minify');
    }
    function showsearchreseditor(){
        $('#hidesearchrescodeeditor').addClass('active');

        $('#searchcoderesult').children('.codeeditor').addClass('active');
        $('#searchcoderesult').addClass('minify');
    }
    function togglesubtree(listitem){
        var subtree = false;
        if(typeof $(listitem).next().attr('class') !== 'undefined' && $(listitem).next().attr('class').indexOf('dotree') !== -1){
            subtree = $(listitem).next();
        }
        if(subtree === false)
            return;
        
        if($(subtree).attr('class').indexOf('active') === -1)
            $(subtree).addClass('active');
    }

    function getPathtype(elem){
        while(typeof $(elem).attr('class') === 'undefined' || $(elem).attr('class').indexOf('browsetree') === -1){
            elem = $(elem).parent();
        }
        return $(elem).attr('id').substr( $(elem).attr('id').indexOf('_')+1);
    }
    $('#thepagecontainer').delegate('.treeitem','click',function(event){
    	event.stopPropagation();
    	var target = event.target;
        $(target).removeClass('selected');
        currentpath = $(target).attr('class').substr($(target).attr('class').indexOf(' ')+1);
        
        if($('#tree').find('li span.selected').length)
            $('#tree').find('li span.selected').removeClass('selected');
            
        $(target).addClass('selected');

        if(currentpath === 'app'){
            var appphp = browsercontent.searchcontent(currentappid,'app',false,false);
            $.each(appphp,function(elmidx,elem){
                browsercontent.contents[elem].edit(completecodestub,currentappid);
            });
            return;
        }

        hidecodeeditor();

        currentpathtype = getPathtype(target);
        $('#browseview').addClass('loading');
        
        togglesubtree($(target).parent());


        var exists = browsercontent.searchcontent(currentappid,currentpath,false,false);
        if(!exists){
            $.ajax({
                url:"./",
                type:'POST',
                data:{app:appname,p:'browser',a:'getFiles',d:{path:currentpath,appid:currentappid}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var browserhtml = '';
                if(msg.length){
                    var definingpath;
                    $.each(msg,function(fileidx,filedesc){
                        definingpath = currentpath == 'uploads' ? filedesc.path : currentpath;
                        var contentobj = new contentobject(currentappid,'file',filedesc.name,0,definingpath,currentpathtype,browsercontent.contents.length);
                        browsercontent.addcontent(contentobj);
                        browserhtml += contentobj.toBrowserString();
                    });
                    browserhtml += '<div class="browserfileelem createfile"></div>';
                }
                else{
                    var contentobj = new contentobject(currentappid,'flag','emptyfolder',0,currentpath,currentpathtype,browsercontent.contents.length);
                    browsercontent.addcontent(contentobj);
                    browserhtml += contentobj.toBrowserString();
                    browserhtml += '<div class="browserfileelem createfile"></div>';
                }
                $('#browserlists').html(browserhtml);
                $('#browseview').removeClass('loading');
            });
        }
        else{
            var browserhtml = '';
            $.each(exists,function(elmidx,elem){
                browserhtml += browsercontent.contents[elem].toBrowserString();
            });
            if(browserhtml === ''){
                var contentobj = new contentobject(currentappid,'flag','emptyfolder',0,currentpath,currentpathtype,browsercontent.contents.length);
                browsercontent.addcontent(contentobj);
                browserhtml += contentobj.toBrowserString();
            }
            browserhtml += '<div class="browserfileelem createfile"></div>';
            $('#browserlists').html(browserhtml);
            $('#browseview').removeClass('loading');
        }
    });
}

var findresourcecontent = function(resource,resname){
    var contentloaded   = false;
    var resourceidx     = false;
    if(typeof resname == 'string'){
        $.each(resource,function(residx,resval){
            if(resval.name == resname){
                resourceidx = residx;
                if(typeof resval.content !== 'undefined'){
                    contentloaded = resval;
                }
                return false;
            }
        });
    }
    else{
        var curlevel = resource;
        for(var i=0;i<resname.length;i++){
            $.each(curlevel,function(residx,resval){
                if(resval.name == resname[i+1]){
                    resourceidx = residx;
                    if(typeof resval.content !== 'undefined'){
                        contentloaded = resval.content;
                        curlevel = contentloaded;
                    }
                    return false;
                }
            });
        }
    }
    return Array(contentloaded,resourceidx);
};
function settingspage(){
    if($.inArray('settingspage',pageloaded) !== -1){
        return;
    }
    pageloaded[pageloaded.length] = 'settingspage';

    var currentresourcepath         = [];
    var currentthemeresourcepath    = [];
    var browsebutton                = false;
    var fileuploadcount             = 0;
    var fileuploadelem              = [];
    var headcount                   = 0;
    var footcount                   = 0;
    var sourcename                  = [];
    var sourcefilepath              = [];

    currentresourcepath[0]          = 'resources';
    currentthemeresourcepath[0]     = 'theme';


    var resourcefileuploader = new filetool();
    resourcefileuploader.enduploadcallback = function(msg){
        msg = $.parseJSON(msg);
        if(msg.upload){
            $(fileuploadelem[fileuploadcount-1]).val(msg.path);
            fileuploadcount -= 1;
            resourcefileuploader.filecount -= 1;
            if(fileuploadcount === 0){
                fileuploadelem  = [];
                saveglobalsett();
            }
        }
    };
    resourcefileuploader.init();

    function saveglobalsett(){
        headcount                   = 0;
        footcount                   = 0;
        sourcename                  = [];
        sourcefilepath              = [];

        $.each($('#container_headsource').find('.forminput'),function(forminputidx,forminputelem){
            if($(forminputelem).children('.sourcename').attr('class').indexOf('filled') != -1){
                headcount++;
                sourcename[sourcename.length] = $(forminputelem).children('.sourcename').val();
                sourcefilepath[sourcefilepath.length] = $(forminputelem).children('.sourcefilepath').val();
            }
        });
        $.each($('#container_footsource').find('.forminput'),function(forminputidx,forminputelem){
            if($(forminputelem).children('.sourcename').attr('class').indexOf('filled') != -1){
                footcount++;
                sourcename[sourcename.length] = $(forminputelem).children('.sourcename').val();
                sourcefilepath[sourcefilepath.length] = $(forminputelem).children('.sourcefilepath').val();
            }
        });

        var submitparam = {app:'regista',p:'settings',a:'savesettings'};
        submitparam.d   = {headcount:headcount,footcount:footcount,sourcefilepath:sourcefilepath,sourcename:sourcename};

        submitparam.d['newappname'] = $('#settings_appname').val();
        submitparam.d['newkeywords'] = $('#settings_keywords').val();

        $.ajax({
            url:'./',
            type:'POST',
            data:submitparam
        }).done(function(msg){
            msg = JSON.parse(msg);
            registapagemsg('saved',true);
            var appspage = $('#thepagecontainer').find('#appspage');
            if(appspage.length){
                var anchorelem = $(appspage).find('#app_'+activeapp).children('.appname').children();
                $(anchorelem).html(submitparam.d['newappname']);
                var applink = $(anchorelem).attr('href').split('?app=');
                applink[1] = submitparam.d['newappname'];
                applink = applink.join('?app=');
                $(anchorelem).prop('href',applink);
            }

            var pathchanging = false;
            if(typeof msg.headpath !== 'undefined'){
                pathchanging = true;
                $.each(msg.headpath,function(hi,he){
                    $('#container_headsource').find('.sourcefilepath').eq(he.idx).val(he.path);
                });
            }
            if(typeof msg.footpath !== 'undefined'){
                pathchanging = true;
                $.each(msg.footpath,function(hi,he){
                    $('#container_footsource').find('.sourcefilepath').eq(he.idx).val(he.path);
                });
            }
            if(pathchanging){
                browsercontent.changeappname(msg.appid,submitparam.d['newappname'],msg.oldname);

                if(resources.length)
                $.each(resources,function(ri,re){
                    if(re.name == msg.oldname){
                        re.name = submitparam.d['newappname'];
                        return false;
                    }
                });
                if(currentresourcepath.length){
                   $.each(currentresourcepath,function(ri,re){
                        if(re == msg.oldname){
                            re = submitparam.d['newappname'];
                            return false;
                        }
                    });

                    if($('#resourcelist').length){
                        $.each($('#resourcelist').children(),function(ri,re){
                            if($(re).children('span').html() == msg.oldname){
                                $(re).children('span').html(submitparam.d['newappname']);
                                return false;
                            }
                        });
                    }
                }
            }
        });
    }

    function savedbsett(){
        var submitparam = {app:'regista',p:'settings',a:'savedbsetting'};
        submitparam.d   = {};

        $.each($('#dbsetting').find('input'),function(idx,elem){
            if($(elem).attr('type') !== 'button'){
                var value = $(elem).attr('name') !== $(elem).val() ? $(elem).val() : '';
                submitparam.d[$(elem).attr('name')]  = value;
            }
        });

        $.ajax({
            url:'./',
            type:'POST',
            data:submitparam
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg == 'false')
                registapagemsg('update failed',true);
            else
                registapagemsg('saved',true);
        });
    }

    $('#thepagecontainer').delegate('.adminmenu_savesettings','click',function(event){
        event.stopPropagation();

        registapagemsg('saving changes...',false);

        if($(this).attr('class').indexOf('db') !== -1){
            savedbsett();
            return;
        }

        $.each($('#container_headsource').find('.forminput'),function(forminputidx,forminputelem){
            if($(forminputelem).children('.sourcename').attr('class').indexOf('filled') != -1){
                if($(forminputelem).children('.uploadresource')[0].files.length){
                    fileuploadelem[fileuploadcount] = $(forminputelem).children('.sourcefilepath')[0];
                    fileuploadcount +=1;
                    var files = $(forminputelem).children('.uploadresource')[0].files;
                    resourcefileuploader.fileuploaderhandle(files,false,resourcefileuploader);
                }
            }
            else{
                if($(forminputelem).parent().siblings().length){
                    $(forminputelem).remove();
                }
                else{
                    $.each($(forminputelem).children(),function(idx,elem){
                        if($(elem).attr('type') !== 'button'){
                            if($(elem).attr('type') == 'file'){
                                $(elem).val('');
                            }
                            else
                                $(elem).val($(elem).attr('name').substr(0,$(elem).attr('name').indexOf('['))).removeClass('filled');
                        }
                    });
                }
            }
        });
        $.each($('#container_footsource').find('.forminput'),function(forminputidx,forminputelem){
            if($(forminputelem).children('.sourcename').attr('class').indexOf('filled') != -1){
                if($(forminputelem).children('.uploadresource')[0].files.length){
                    fileuploadelem[fileuploadcount] = $(forminputelem).children('.sourcefilepath')[0];
                    fileuploadcount +=1;
                    var files = $(forminputelem).children('.uploadresource')[0].files;
                    resourcefileuploader.fileuploaderhandle(files,false,resourcefileuploader);
                }
            }
            else{
                if($(forminputelem).parent().siblings().length){
                    $(forminputelem).remove();
                }
                else{
                    $.each($(forminputelem).children(),function(idx,elem){
                        if($(elem).attr('type') !== 'button'){
                            if($(elem).attr('type') == 'file'){
                                $(elem).val('');
                            }
                            else
                                $(elem).val($(elem).attr('name').substr(0,$(elem).attr('name').indexOf('['))).removeClass('filled');
                        }
                    });
                }
            }
        });


        if(resourcefileuploader.filecount > 0){
            var workerparams = {workeraction:'uploadfiles',app:'regista',p:'settings',a:'uploadfiles',d:sourcename.join('|')};

            resourcefileuploader.workerparams = workerparams;
            resourcefileuploader.formData.append('app',appname);
            resourcefileuploader.formData.append('p',workerparams.p);
            resourcefileuploader.formData.append('a',workerparams.a);
            resourcefileuploader.formData.append('d',workerparams.d);
            resourcefileuploader.formData.append('files', resourcefileuploader.thefiles);
            resourcefileuploader.startupload();
        }
        else{
            saveglobalsett();
        }
    });

    $('#thepagecontainer').delegate('.settingscontainer .addcontent.browse','click',function(){
        currentresourcepath.splice(1,currentresourcepath.length-1);
        browsebutton = this;
        if(resources.length){
            var reslist = '<h3 class="">resources<span class="refreshresource"></span></h3><ul id="resourcelist">';
             $.each(resources,function(residx,resval){
                if(resval.type == 'folder')
                    reslist += '<li class="resourceitem folder"><span>'+resval.name+'</span></li>';
                else
                    reslist += '<li class="resourceitem"><span>'+resval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
            });
            reslist += '</ul>';
            $('#browseresources').children('.listcontent').eq(0).html(reslist).addClass('active');
            $('#browseresources').children('.listcontent').eq(1).removeClass('active');

            $('#resourcesbrowse').addClass('active');
            $('#themebrowse').removeClass('active');

            $('#browseresources').removeClass('loading');

            $('#browseresources').addClass('active');
        }
        else{
            $('#browseresources').addClass('active loading');
            $.ajax({
                url:'./',
                type:'post',
                data:{app:appname,p:'settings',a:'getresources',v:'ajax'}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var reslist = '<h3 class="">resources<span class="refreshresource"></span></h3><ul id="resourcelist">';
                $.each(msg,function(residx,resval){
                    resources[resources.length] = resval;
                    if(resval.type == 'folder')
                        reslist += '<li class="resourceitem folder"><span>'+resval.name+'</span></li>';
                    else
                        reslist += '<li class="resourceitem"><span>'+resval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
                });
                reslist += '</ul>';
                $('#browseresources').children('.listcontent').eq(0).html(reslist).addClass('active');
                $('#browseresources').children('.listcontent').eq(1).removeClass('active');

                $('#resourcesbrowse').addClass('active');
                $('#themebrowse').removeClass('active');

                $('#browseresources').removeClass('loading');
            });
        }
    });
    $('#thepagecontainer').delegate('#closebrowseresources','click',function(){
        $('#browseresources').removeClass('active');
    });

    $('#thepagecontainer').delegate('#resourcesbrowse','click',function(){
        $(this).addClass('active');
        $(this).siblings().removeClass('active');

        $('#browseresources').children('.listcontent').eq(0).addClass('active');
        $('#browseresources').children('.listcontent').eq(1).removeClass('active');
    });

    $('#thepagecontainer').delegate('#themebrowse','click',function(){
        currentthemeresourcepath.splice(1,currentthemeresourcepath.length-1);
        $(this).addClass('active');
        $(this).siblings().removeClass('active');

        if(themeresources.length){
            var reslist = '<h3 class="">theme resources<span class="refreshresource"></span></h3><ul id="themeresourcelist">';
            $.each(themeresources,function(residx,resval){
                if(resval.type == 'folder')
                    reslist += '<li class="resourceitem folder"><span>'+resval.name+'</span></li>';
                else
                    reslist += '<li class="resourceitem"><span>'+resval.name+'</span></a><a href="javascript:void(0);" class="addreso"></a></li>';
            });
            reslist += '</ul>';

            $('#browseresources').addClass('active');

            $('#browseresources').children('.listcontent').eq(1).html(reslist).addClass('active');
            $('#browseresources').children('.listcontent').eq(0).removeClass('active');
        }
        else{
            $('#browseresources').addClass('active loading');
            $.ajax({
                url:'./',
                type:'post',
                data:{app:appname,p:'settings',a:'getThemesResources',v:'ajax'}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var reslist = '<h3 class="">theme resources<span class="refreshresource"></span></h3><ul id="themeresourcelist">';
                $.each(msg,function(residx,resval){
                    themeresources[themeresources.length] = resval;
                    if(resval.type == 'folder')
                        reslist += '<li class="resourceitem folder"><span>'+resval.name+'</span></li>';
                    else
                        reslist += '<li class="resourceitem"><span>'+resval.name+'</span></a><a href="javascript:void(0);" class="addreso"></a></li>';
                });
                reslist += '</ul>';
                $('#browseresources').children('.listcontent').eq(1).html(reslist).addClass('active');
                $('#browseresources').children('.listcontent').eq(0).removeClass('active');
                $('#browseresources').removeClass('loading');
            });
        }
    });

    $('#thepagecontainer').delegate('.settingscontainer .addrow','click',function(event){
	    event.stopPropagation();
        var newrow = '<div class="row bottomless"><div class="forminput"><input type="text" name="sourcename[]" value="sourcename" class="sourcename"><input type="text" value="sourcefilepath" class="sourcefilepath" name="sourcefilepath[]"/><input type="file" name="sourcefile[]" value="sourcefile" class="uploadresource"><input type="button" name="uploadfile" class="uploadfile" value="upload"><input type="button" name="addfilecontent" class="addcontent  browse" value="browse"><input type="button" name="addcontent" class="addcontent addrow" value="+"><input type="button" name="removecontent" class="removecontent" value="-"></div></div>';
        $(this).parent().parent().after(newrow);
    });

    $('#thepagecontainer').delegate('.settingscontainer .removecontent','click',function(){
        if($(this).parent().parent().siblings().length){
            $(this).parent().parent().remove();
        }
        else{
            $.each($(this).parent().children(),function(idx,elem){
                if($(elem).attr('type') !== 'button'){
                    if($(elem).attr('type') == 'file'){
                        $(elem).val('');
                    }
                    else
                        $(elem).val($(elem).attr('name').substr(0,$(elem).attr('name').indexOf('['))).removeClass('filled');
                }
            });
        }
    });

    $('#thepagecontainer').delegate('.settingscontainer .uploadresource','change',function(){
        $(this).prev().val($(this).val());
        $(this).prev().addClass('active filled');

        var filenamex,filename;
        if($(this).val().indexOf('/') !== -1){
            filenamex = $(this).val().split('/');
            filename = filenamex[filenamex.length-1];
            if(filename.indexOf('.') != -1){
                filenamex = filename.split('.');
                filenamex.splice(filenamex.length-1,1);
                filename = filenamex.join('.');
            }
        }
        else if($(this).val().indexOf(backslash) !== -1){
            filenamex = $(this).val().split(backslash);
            filename = filenamex[filenamex.length-1];

            if(filename.indexOf('.') != -1){
                filenamex = filename.split('.');
                filenamex.splice(filenamex.length-1,1);
                filename = filenamex.join('.');
            }
        }
        else if($(this).val().indexOf('') !== -1){
            filenamex = $(this).val().split('');
            filename = filenamex[filenamex.length-1];

            if(filename.indexOf('.') != -1){
                filenamex = filename.split('.');
                filenamex.splice(filenamex.length-1,1);
                filename = filenamex.join('.');
            }
        }
        $(this).parent().children('.sourcename').val(filename).addClass('active filled');
    });

    $('#thepagecontainer').delegate('#browseresources .resourcecontent.folder','click',function(event){
	    event.stopPropagation();
        var loaded,foldername,resourccontent;
        if($('#resourcesbrowse').attr('class').indexOf('active') == -1){
            loaded = false;
            foldername = $(this).children('span').html();
            currentthemeresourcepath[currentthemeresourcepath.length] = foldername;
            loaded = findresourcecontent(themeresources,currentthemeresourcepath);
                resourccontent = '<h3 class="">'+$(this).html()+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="themeresourcelist">';
                $.each(loaded[0],function(contentidx,contentval){

                        if(contentval.type == 'folder')
                            resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                        else
                            resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';

                });
                resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(1).html(resourccontent);
                $('#browseresources').removeClass('loading');
        }
        else{
            loaded = false;
            foldername = $(this).children('span').html();
            currentresourcepath[currentresourcepath.length] = foldername;
            loaded = findresourcecontent(resources,currentresourcepath);
                resourccontent = '<h3 class="">'+$(this).html()+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';
                $.each(loaded[0],function(contentidx,contentval){
                        if(contentval.type == 'folder')
                            resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                        else
                            resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';

                });
                resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(0).html(resourccontent);
                $('#browseresources').removeClass('loading');
        }
    });
    $('#thepagecontainer').delegate('#browseresources .resourceitem.folder','click',function(event){
	    event.stopPropagation();
        $('#browseresources').addClass('loading');
        var resourcename    = $(this).children('span').html();
        var loaded          = false;
        var resourccontent;

        if($('#resourcesbrowse').attr('class').indexOf('active') != -1){
            loaded              = findresourcecontent(resources,resourcename);
            currentresourcepath[currentresourcepath.length] = resourcename;

            if(loaded[0] !== false){
                resourccontent = '<h3 class="">'+resourcename+'<span class="refreshresource"></span><span class="uptree">&larr;</span></h3><ul id="resourcelist">';

                $.each(loaded[0].content,function(contentidx,contentval){
                    if(contentval.type == 'folder')
                        resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                    else
                        resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
                });
                resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(0).html(resourccontent);
                $('#browseresources').removeClass('loading');
            }
            else{
                $.ajax({
                   url:'./',
                   type:'post',
                   data:{app:appname,p:'settings',a:'resourcecontent',d:{resourcename:resourcename}}
                }).done(function(msg){
                   resourccontent= '<h3 class="">'+resourcename+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';
                   msg = $.parseJSON(msg);
                   resources[loaded[1]].content = msg;
                   $.each(msg,function(contentidx,contentval){
                       if(contentval.type == 'folder')
                           resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                       else
                           resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
                   });
                   resourccontent += '</ul>';

                    $('#browseresources').children('.listcontent').eq(0).html(resourccontent);
                    $('#browseresources').removeClass('loading');
                });
            }
        }
        else{
            loaded              = findresourcecontent(themeresources,resourcename);
            currentthemeresourcepath[currentthemeresourcepath.length] = resourcename;

            if(loaded[0] !== false){
                resourccontent = '<h3 class="">'+resourcename+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';

                $.each(loaded[0].content,function(contentidx,contentval){
                    if(contentval.type == 'folder')
                        resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                    else
                        resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
                });
                resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(1).html(resourccontent);
                $('#browseresources').removeClass('loading');
            }
            else{
                $.ajax({
                   url:'./',
                   type:'post',
                   data:{app:appname,p:'settings',a:'themesresourcecontent',d:{resourcename:resourcename}}
                }).done(function(msg){
                   resourccontent= '<h3 class="">'+resourcename+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';
                   msg = $.parseJSON(msg);
                   themeresources[loaded[1]].content = msg;
                   $.each(msg,function(contentidx,contentval){
                       if(contentval.type == 'folder')
                           resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                       else
                           resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
                   });
                   resourccontent += '</ul>';

                    $('#browseresources').children('.listcontent').eq(1).html(resourccontent);
                    $('#browseresources').removeClass('loading');
                });
            }
        }
    });
    $('#thepagecontainer').delegate('#browseresources .refreshresource','click',function(event){
	    event.stopPropagation();
        $('#browseresources').addClass('loading');
        var resourcename;
        var loaded;
        var resourccontent;

        if($('#resourcesbrowse').attr('class').indexOf('active') != -1){
            if(currentresourcepath.length == 1){
                var resourcenamex     = $('#browseresources').find('.listcontent').eq(0).children('h3').html();
                resourcename = resourcenamex.substr(0,resourcenamex.indexOf('<'));

                loaded = [];
                loaded[0] = resources;
                loaded[1] = resources.length;
            }
            else{
                resourcename     = currentresourcepath[1];
                loaded      = findresourcecontent(resources,currentresourcepath);
            }


            $.ajax({
               url:'./',
               type:'post',
               data:{app:appname,p:'settings',a:'resourcecontent',d:{resourcename:resourcename}}
            }).done(function(msg){
               resourccontent= '<h3 class="">'+resourcename+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';
               msg = $.parseJSON(msg);
               resources[loaded[1]].content = msg;
               $.each(msg,function(contentidx,contentval){
                   if(contentval.type == 'folder')
                       resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                   else
                       resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
               });
               resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(0).html(resourccontent);
                $('#browseresources').removeClass('loading');
            });
        }
        else{
            if(currentthemeresourcepath.length == 1){
                var resourcenamex     = $('#browseresources').find('.listcontent').eq(1).children('h3').html();
                resourcename = resourcenamex.substr(0,resourcenamex.indexOf('<'));

                loaded = [];
                loaded[0] = themeresources;
                loaded[1] = themeresources.length;
            }
            else{
                resourcename     = currentthemeresourcepath[1];

                loaded      = findresourcecontent(themeresources,currentthemeresourcepath);
            }


            $.ajax({
               url:'./',
               type:'post',
               data:{app:appname,p:'settings',a:'themesresourcecontent',d:{resourcename:resourcename}}
            }).done(function(msg){
               resourccontent= '<h3 class="">'+resourcename+'<span class="uptree">&larr;</span><span class="refreshresource"></span></h3><ul id="resourcelist">';
               msg = $.parseJSON(msg);
               themeresources[loaded[1]].content = msg;
               $.each(msg,function(contentidx,contentval){
                   if(contentval.type == 'folder')
                       resourccontent += '<li class="resourcecontent folder"><span>'+contentval.name+'</span></li>';
                   else
                       resourccontent += '<li class="resourcecontent"><span>'+contentval.name+'</span><a href="javascript:void(0);" class="addreso"></a></li>';
               });
               resourccontent += '</ul>';

                $('#browseresources').children('.listcontent').eq(1).html(resourccontent);
                $('#browseresources').removeClass('loading');
            });
        }

    });
    $('#thepagecontainer').delegate('#browseresources .uptree','click',function(event){
	    event.stopPropagation();
        $('#browseresources').addClass('loading');
        var loaded,listclass,resname,resourccontent;

        if($('#resourcesbrowse').attr('class').indexOf('active') != -1){
            resname     = currentresourcepath[currentresourcepath.length-2];
            currentresourcepath.splice(currentresourcepath.length-1,1);
            if(currentresourcepath.length == 1){
                loaded = [];
                loaded[0] = resources;
            }
            else
                loaded      = findresourcecontent(resources,currentresourcepath);

            resourccontent = '<h3 class="">'+resname;
            if(currentresourcepath.length > 1){
                listclass = 'resourcecontent';
                resourccontent += '<span class="uptree">&larr;</span><span class="refreshresource"></span></h3>';
            }
            else{
                listclass = 'resourceitem';
                resourccontent += '<span class="refreshresource"></span></h3>';
            }

            resourccontent += '<ul id="resourcelist">';

            $.each(loaded[0],function(contentidx,contentval){
                if(contentval.type == 'folder')
                    resourccontent += '<li class="'+listclass+' folder"><span>'+contentval.name+'</span></li>';
                else
                    resourccontent += '<li class="'+listclass+'">'+contentval.name+'<a href="javascript:void(0);" class="addreso"></a></li>';
            });
            resourccontent += '</ul>';

            $('#browseresources').children('.listcontent').eq(0).html(resourccontent);
            $('#browseresources').removeClass('loading');
        }
        else{
            resname     = currentthemeresourcepath[currentthemeresourcepath.length-2];
            currentthemeresourcepath.splice(currentthemeresourcepath.length-1,1);
            if(currentthemeresourcepath.length == 1){
                loaded  = [];
                loaded[0]   = themeresources;
            }
            else
                loaded      = findresourcecontent(themeresources,currentthemeresourcepath);

            resourccontent = '<h3 class="">'+resname;
            if(currentthemeresourcepath.length > 1){
                listclass = 'resourcecontent';
                resourccontent += '<span class="uptree">&larr;</span><span class="refreshresource"></span></h3>';
            }
            else{
                listclass = 'resourceitem';
                resourccontent += '<span class="refreshresource"></span></h3>';
            }

            resourccontent += '<ul id="themeresourcelist">';

            $.each(loaded[0],function(contentidx,contentval){
                if(contentval.type == 'folder')
                    resourccontent += '<li class="'+listclass+' folder"><span>'+contentval.name+'</span></li>';
                else
                    resourccontent += '<li class="'+listclass+'">'+contentval.name+'<a href="javascript:void(0);" class="addreso"></a></li>';
            });
            resourccontent += '</ul>';

            $('#browseresources').children('.listcontent').eq(1).html(resourccontent);
            $('#browseresources').removeClass('loading');
        }
    });
    $('#thepagecontainer').delegate('#browseresources .addreso','click',function(event){
	    event.stopPropagation();
        var path            ='';
        var sourcename      ='';
        var sourcenamex     ='';
        var sourcefilename  = '';

        if($('#resourcesbrowse').attr('class').indexOf('active') != -1){
            $.each(currentresourcepath,function(cidx,cval){
                if(cidx !== 0)
                path += cval+'/';
            });
            path    += $(this).parent().children('span').html();


            sourcenamex     = path.split('/');
            sourcename      = sourcenamex[0]+'_';
            sourcefilename  = sourcenamex[sourcenamex.length-1];

            if(sourcefilename.indexOf('.') !== -1){
                sourcefilenamex = sourcefilename.split('.');
                for(var i= 0;i<sourcefilenamex.length;i++){
                    sourcename += sourcefilenamex[i];
                }

            }
            else{
                sourcename += sourcefilename;
            }

            $(browsebutton).siblings('.sourcename').val(sourcename).addClass('filled active');
            $(browsebutton).siblings('.sourcefilepath').val(path).addClass('filled active');
            $('#browseresources').removeClass('active');
        }
        else{
            $.each(currentthemeresourcepath,function(cidx,cval){
                if(cidx !== 0)
                path += cval+'/';
            });
            path+= $(this).parent().children('span').html();


            sourcenamex = path.split('/');
            sourcename = sourcenamex[0]+'_';
            sourcefilename = sourcenamex[sourcenamex.length-1];

            if(sourcefilename.indexOf('.') !== -1){
                sourcename += sourcefilename.substr(0,sourcefilename.indexOf('.'));
            }
            else{
                sourcename += sourcefilename;
            }

            $(browsebutton).siblings('.sourcename').val(sourcename).addClass('filled active');
            $(browsebutton).siblings('.sourcefilepath').val(path).addClass('filled active');
            $('#browseresources').removeClass('active');
        }
    });
}
var contactsnavproto = function(){

};

contactsnavproto.prototype.newresults = function(){

};

var appscontactformindex = 0;
var appscontacts = [];
function contactform(){
    if($.inArray('contactform',pageloaded) !== -1){
        appscontactformindex = false;
        for(var i=0;i<appscontacts.length;i++){
            if(appscontacts[i].appid == activeapp){
                appscontactformindex = i;
            }
        }
        if(appscontactformindex === false){
            appscontacts[appscontacts.length] = [];
            appscontacts[appscontacts.length-1].appid         = activeapp;
            appscontacts[appscontacts.length-1].contactsnav   = new contactsnavproto();

            appscontactformindex = appscontacts.length-1;
        }
        appscontacts[appscontactformindex].contactsnav.newresults();
        return;
    }
    else{
        pageloaded[pageloaded.length] = 'contactform';

        appscontacts[appscontacts.length] = [];
        appscontacts[appscontacts.length-1].appid         = activeapp;
        appscontacts[appscontacts.length-1].contactsnav   = new contactsnavproto();

        appscontactformindex = appscontacts.length-1;

        appscontacts[appscontactformindex].contactsnav.newresults();
    }

    $('#thepagecontainer').delegate('#contactmessages .deletemessage','click',function(event){
        event.stopPropagation();
        var confirmdelete = new messagebox();
        var subject = $(this).parent().siblings('.messagesubject').html();
        var sender = $(this).parent().siblings('.sendername').html();
        var msgid = $(this).attr('id').substr(17);

        confirmdelete.title = 'Confirm Message Deletion';
        confirmdelete.content = 'Delete message "'+subject+'" from '+sender+'?';
        confirmdelete.action = '<span id="confirmcontactmsgdel">Confirm</span>';

        confirmdelete.display();

        $('#thepagecontainer').delegate('#confirmcontactmsgdel','click',function(event){
		event.stopPropagation();
            confirmdelete.close();

            $.ajax({
                url:'',
                type:'POST',
                data:{app:appname,p:'contacts',a:'deletemessage',d:{msgid:msgid}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                if(msg.deleted){
                    confirmdelete.title = 'Delete Successful';
                    confirmdelete.content = 'Message was sucessfully deleted';
                    confirmdelete.action = '';

                    confirmdelete.display();
                }
            });
        });
    });
}


function tinythentinynow(){
    var tinymcesetting = {
        theme: "modern",
		plugins: [
			"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
			"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
			"save table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker codesample"
		],
		toolbar1: "styleselect formatselect fontselect fontsizeselect | bold italic underline strikethrough alignleft aligncenter alignright alignjustify cut copy paste pastetext searchreplace outdent indent blockquote undo redo",
		toolbar2: "link unlink anchor image media code insertdatetime preview forecolor backcolor table hr removeformat  subscript superscript  charmap emoticons  print fullscreen ltr rtl spellchecker visualchars visualblocks pagebreak insertfile insertimage codesample bullist numlist",
		menubar: false,
        toolbar_items_size: 'small',
		style_formats: [
			{title: 'Bold text', inline: 'b'},
			{title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
			{title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
			{title: 'Example 1', inline: 'span', classes: 'example1'},
			{title: 'Example 2', inline: 'span', classes: 'example2'},
			{title: 'Table styles'},
			{title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
		]
    };

    tinymcesetting.selector = 'textarea#blogcontenttext';
    var testiny = tinymce.init(tinymcesetting);
    testiny.then(function(){
        tinymcesetting.selector = 'textarea#blogexcerpt';
        tinymce.init(tinymcesetting);

        tinymcesetting.selector = 'textarea#editblogcontenttext';
        tinymce.init(tinymcesetting);

        tinymcesetting.selector = 'textarea#editblogexcerpt';
        tinymce.init(tinymcesetting);
    },function(error){
    });
}

var pastentrynavproto = function(){
       this.filteredresults = [];
       this.currentfilteredresultidx = 0;
};
pastentrynavproto.prototype.newfilter = function(keywords,category,status,endofpage,result){
    var filtervals = {
        keywords:$('#searchpastentrykeywords').val(),
        category: category,
        status:status
    };

    this.currentfilteredresultidx = this.filteredresults.length;
    this.filteredresults[this.currentfilteredresultidx] = new filteredentriesproto(filtervals,result,endofpage,this.currentfilteredresultidx);

    this.filteredresults[this.currentfilteredresultidx].display();
};
pastentrynavproto.prototype.newresults = function(){
    var category    = $('#editblogcategorylistfilter').children('.selected').length ? $('#editblogcategorylistfilter').children('.selected').attr('id').substr(16) : ($('#searchincategory').val() == 'category' ? 0 : false);
    if(category === false)
        return;

    var status = $('#searchinstatus').val();
    if(status == 'status' || status == 'All Status'){
        status = -1;
    }
    else if(status == 'published'){
        status = 1;
    }
    else{
        status = 0;
    }
    var filtervals = {
        keywords:$('#searchpastentrykeywords').val(),
        category: category,
        status:status
    };
    var result = [];
    $.each($('#pastentries').children('.row'),function(idx,elem){
        if($(elem).attr('class').indexOf(' head') === -1 && $(elem).attr('class').indexOf(' prepagemenu') === -1){
            var resultidx = result.length;
            result[resultidx] = [];
            result[resultidx].id = $(elem).find('.deleteblog').attr('id').substr(11);
            result[resultidx].row = '<div class="row">'+$(elem).html()+'</div>';
        }
    });

    this.filteredresults[this.currentfilteredresultidx] = new filteredentriesproto(filtervals,result,defaultfilterblogpagenum,this.currentfilteredresultidx);
};
pastentrynavproto.prototype.addresults = function(result,offset){
    this.filteredresults[this.currentfilteredresultidx].additems(result,offset);
};
pastentrynavproto.prototype.currentfilter = function(){
    return this.filteredresults[this.currentfilteredresultidx].filtervals;
};
pastentrynavproto.prototype.updateblogrow = function(status,category,blogobj){
    for(var i=0;i<this.filteredresults.length;i++){
        var rowstatus = this.filteredresults[i].updateblogrow(status,category,blogobj);
        if(i==this.currentfilteredresultidx){
            this.filteredresults[this.currentfilteredresultidx].display();
        }
    }
};
pastentrynavproto.prototype.deleteblog = function(blogobj){
  for(var i=0;i<this.filteredresults.length;i++){
      var filtered = this.filteredresults[i].filterblog(blogobj);
      var rowstatus = this.filteredresults[i].deleteblog(blogobj.id,filtered);
      if(i == this.currentfilteredresultidx && rowstatus !== false){
        this.filteredresults[this.currentfilteredresultidx].display();
      }
  }
};
pastentrynavproto.prototype.searchfilteredpage = function(postdata){
    for(var i=0;i<this.filteredresults.length;i++){
        if(this.filteredresults[i].comparefilter(postdata)){
            this.currentfilteredresultidx = i;
            this.filteredresults[this.currentfilteredresultidx].display();

            return true;
        }
    }
    return false;
};

var blogdata = function(){
    this.uploadingstatus = false;
    this.edited = false;
    this.editeddata = [];
    this.id = 0;
    this.title = '';
    this.status = 0;
    this.category = 0;
    this.date = '';
    this.excerpt = false;
    this.content = false;

    this.attributekeys = [];
    this.attributevals = [];
    this.featimage = '';
};

blogdata.prototype.rowdata = function(id,title,category,status){
    this.id = id;
    this.title = title;
    this.category = category;
    this.status = status == 'published' ? 1 : 0;
};

blogdata.prototype.saveedited = function(compareobj,type,index){
    var saved = false;
    $.each(this.editeddata,function(edix,edelem){
        if(edelem.type == type && edelem.index == index){
            saved = edix;
            return false;
        }
    });
    if(saved === false){
        this.editeddata[this.editeddata.length] = [];
        this.editeddata[this.editeddata.length-1].type = type;
        this.editeddata[this.editeddata.length-1].index = index;
        this.editeddata[this.editeddata.length-1].value = compareobj;

        if(compareobj == '<*delete*>'){
            for(var i=this.editeddata.length-1;i>=0;i--){
                if(this.editeddata[i].index == index && this.editeddata[i].type == 'attrval'){
                    this.editeddata.splice(i,1);
                }
            }
        }
    }
    else{
        this.editeddata[saved].value = compareobj;
        if(compareobj == '<*delete*>'){
            for(var i=this.editeddata.length-1;i>=0;i--){
                if(this.editeddata[i].index == index && this.editeddata[i].type == 'attrval'){
                    this.editeddata.splice(i,1);
                }
            }
        }
    }
};

blogdata.prototype.saveChanges = function(callbackfunc){
    if(!this.editeddata.length || this.uploadingstatus)
        return;

    this.uploadingstatus = true;
    var thisblog = this;
    var editeddata = '';
    $.each(this.editeddata,function(idx,elem){
        if(elem.type == 'featimage'){
            var tempval = elem.value.split('<*featimage*>');
            for(var ti=0;ti<tempval.length;ti++){
                tempval[ti] = tempval[ti].split('<e>');
                tempval[ti][0] ='';
                tempval[ti] = tempval[ti].join('<e>');
            }
            tempval = tempval.join('<*featimage*>');

            elem.value = tempval;
        }
        editeddata += elem.type+'<*edelemsep*>'+elem.index+'<*edelemsep*>'+elem.value+'<*edsep*>';
    });
    var postdata = {app:appname,p:'blog',a:'saveChanges',d:{id:thisblog.id,changes:editeddata}};
    
    $.ajax({
        url:'./',
        type:'POST',
        data:postdata
    }).done(function(msg){
        thisblog.uploadingstatus = false;
        if(msg !== false){
            for(var i =thisblog.editeddata.length-1;i>=0;i--){
                if(thisblog.editeddata[i].value == '<*delete*>'){
                    thisblog.attributekeys.splice(thisblog.editeddata[i].index,1);
                    thisblog.attributevals.splice(thisblog.editeddata[i].index,1);
                }
            }
            thisblog.editeddata = [];
        }
        callbackfunc(msg);
    });
};

blogdata.prototype.wasedited = function(compareobj,type,index){
    var edited = false;
    index = parseInt(index);
    switch(type){
        case 'title':
        case 'status':
        case 'category':
            if(this[type] != compareobj){
                this[type] = compareobj;
                edited = true;
            }
        case 'excerpt':
        case 'content':
            if(this[type] != compareobj){
                this[type] = compareobj;
                edited = true;
            }
        break;
        case 'attrkey':
            if(index < this.attributekeys.length){
                if(this.attributekeys[index] != compareobj){
                    this.attributekeys[index] = compareobj;
                    edited = true;
                }
            }
            else{
                this.attributekeys[this.attributekeys.length] = compareobj;
                edited = true;
            }
        break;
        case 'attrval':
             if(index < this.attributevals.length){
                if(this.attributevals[index] != compareobj){
                    this.attributevals[index] = compareobj;
                    edited = true;
                }
             }
            else{
                this.attributevals[this.attributevals.length] = compareobj;
                edited = true;
            }
        break;
        case 'featimage':
            index = 0;
            if(this.featimage != compareobj){
                this.featimage = compareobj;
                edited = true;
            }
        break;
    }
    if(edited){
        this.edited = true;
        this.saveedited(compareobj,type,index);
    }
    return this.edited;
};

blogdata.prototype.setData = function(value,type,index){
      switch(type){
        case 'title':
        case 'status':
        case 'category':
        case 'date':
        case 'excerpt':
        case 'content':
            this[type] = value;
        break;
        case 'attrkey':
            if(index < this.attributekeys.length){
                this.attributekeys[index] = value;
            }
            else{
                this.attributekeys[this.attributekeys.length] = value;
            }
        break;
        case 'attrval':
             if(index < this.attributevals.length)
                this.attributevals[index] = value;
            else{
                this.attributevals[this.attributevals.length] = value;
            }
        break;
    }
};

blogdata.prototype.resetData = function(){
    this.uploadingstatus = false;
    this.edited = false;
    this.editeddata = [];
    this.id = 0;
    this.title = '';
    this.status = 0;
    this.category = 0;
    this.date = '';
    this.excerpt = '';
    this.content = '';

    this.attributekeys = [];
    this.attributevals = [];
    this.featimage = '';
};

blogdata.prototype.populatedata = function(data){
    this.excerpt = data.excerpt;
    this.content = data.content;
    this.status = data.status;
    this.date = data.date;

    var tempattr = [];
    var tempattrk = [];
    $.each(data.attributes,function(idx,value){
        tempattr[tempattr.length] = value.value;
        tempattrk[tempattrk.length] = value.attrkey;
    });
    this.attributekeys = tempattrk;
    this.attributevals = tempattr;

    this.featimage = data.featimage;
};

blogdata.prototype.copy = function(blogelem){
    this.uploadingstatus = blogelem.uploadingstatus;
    this.id = blogelem.id;
    this.title = blogelem.title;
    this.status = blogelem.status;
    this.category = blogelem.category;
    this.date = blogelem.date;
    this.excerpt = blogelem.excerpt;
    this.content = blogelem.content;


    var tempattr = [];
    var tempattrk = [];
    $.each(blogelem.attributevals,function(idx,value){
        tempattr[tempattr.length] = value;
        tempattrk[tempattrk.length] = blogelem.attributekeys[idx];
    });

    this.attributekeys = tempattrk;
    this.attributevals = tempattr;

    this.featimage = blogelem.featimage;
};

blogdata.prototype.populateform = function(whichform){
    var formprefix = 'newentry';
    var blogcategorylist = 'selectcat_';
    var blogattributecontainer = 'blogattributes';
    var blogimagecontainer = 'blogimage';
    var editprefix = '';
    if(whichform == 'editblog'){
        formprefix = 'editblogcontainer';
        blogcategorylist = 'editselectcat_';
        blogattributecontainer = 'editblogattributes';
        blogimagecontainer = 'editblogimage';
        editprefix = 'edit';
    }

    $('#'+formprefix).find('.blogtitle').val(this.title).addClass('filled');

    $('#'+blogcategorylist+this.category).addClass('selected');
    $('#'+formprefix).find('.blogcategoryselect').val($('#'+blogcategorylist+this.category).children('.catname')[0].innerText).addClass('filled');

    if(this.status === 1)
        $('#'+formprefix).find('.updateblogstatus').val('Unpublish');
    else
        $('#'+formprefix).find('.updateblogstatus').val('Publish');


    tinymce.get('editblogcontenttext').setContent(this.content);
    tinymce.get('editblogexcerpt').setContent(this.excerpt);
    this.content = tinymce.get('editblogcontenttext').getContent();
    this.excerpt = tinymce.get('editblogexcerpt').getContent();

    $('#'+blogattributecontainer).html('');

    if(this.attributekeys.length){
        var attributevals = this.attributevals;
        $.each(this.attributekeys,function(attidx,attval){
            var attributeform = '<div class="row"><input type="text" id="'+editprefix+'blogattrname_'+attidx+'" name="attribute name[]" value="'+attval+'" class="blogattr filled"><ul class="blogattrkeyoptprovider"></ul><input id="blogattrval_'+attidx+'" type="text" name="attribute value[]" value="'+attributevals[attidx]+'" class="blogattrval filled"><input type="button" class="addblogattr" value="+"><input type="button" class="minblogattr" value="-"></div>';
            $('#'+blogattributecontainer).append(attributeform);
        });
    }
    else{
        var attributeform = '<div class="row"><input type="text" id="'+editprefix+'blogattrname_0" name="attribute name[]" value="attribute name" class="blogattr"><ul class="blogattrkeyoptprovider"></ul><input type="text" name="attribute value[]" value="attribute value" class="blogattrval" id="blogattrval_0"><input type="button" class="addblogattr" value="+"><input type="button" class="minblogattr" value="-"></div>';
        $('#'+blogattributecontainer).append(attributeform);
    }

    if(this.featimage.indexOf('<*featimage*>') !== false){
        var imagestring = '';
        var images = this.featimage.split('<*featimage*>');
        for(var ix=0;ix<images.length;ix++){
            if(images[ix] != ''){
                var imageelem = images[ix].split('<e>');
                var imageid = imageelem[1];
                var imageurl = imageelem[0];
                var imagename = imageelem[2];
                imagestring += '<div class="imagestills">'
                                  +'<div class="imagebox"><img src="'+imageurl+'"><span class="editimagename"></span><div class="imageid">'+imageid+'</div></div>'
                                  +'<span class="stillurl">'+imagename+'<input type="text" class="stillurlpos" value="'+imageurl+'"></span>'
                                  +'<input type="button" class="deletestill" value="delete" id="deletestill_'+imageid+'">'
                                +'</div>';
            }
        }
        $('#'+blogimagecontainer).find('.holdercontainer').after(imagestring);
    }
};

var blogsdataproto = function(){
    this.blogs = [];
    this.currentedit        = false;
    this.currentnew         = false;
    this.tempcurrentedit    = false;
    this.tempcurrentnew     = false;
};
blogsdataproto.prototype.wasedited = function(content,type,index,mode){
    if(mode == 'edit'){
        this.blogs[this.tempcurrentedit].wasedited(content,type,index);
    }
    else{
        this.blogs[this.tempcurrentnew].wasedited(content,type,index);
    }
};

blogsdataproto.prototype.addblog = function(blog,mode){
    if(mode === 'edit'){
        this.blogs[this.blogs.length] =  new blogdata();
        this.currentedit = this.blogs.length-1;
        this.blogs[this.currentedit].copy(blog);
        if(this.tempcurrentedit === false){
            this.blogs[this.blogs.length] = new blogdata();
            this.tempcurrentedit = this.blogs.length-1;
            this.blogs[this.tempcurrentedit].copy(blog);
        }
        else{
            this.blogs[this.tempcurrentedit].copy(blog);
        }
        this.blogs[this.tempcurrentedit].populateform('editblog');
    }
    else if(mode === 'new'){
        blog.date = currentdatestring();
        this.currentnew =0;
        this.blogs[this.currentnew] = new blogdata();
        this.blogs[this.currentnew].copy(blog);

        this.blogs[this.blogs.length] = new blogdata();
        this.tempcurrentnew = this.blogs.length-1;
        this.blogs[this.tempcurrentnew].copy(this.blogs[this.currentnew]);
    }
};
blogsdataproto.prototype.find = function(id){
    var found = false;
    if(this.blogs.length){
        var thislist = this;
        $.each(this.blogs,function(blogidx,blogelem){
            if(blogelem.id == id){
                if(thislist.tempcurrentedit === false){
                    thislist.blogs[thislist.blogs.length] = new blogdata();
                    thislist.tempcurrentedit = thislist.blogs.length-1;
                }
                thislist.blogs[thislist.tempcurrentedit].copy(blogelem);
                thislist.currentedit = blogidx;
                found = true;
                return false;
            }
        });
    }
    return found;
};
blogsdataproto.prototype.editingnew = function(mode){
    var edited = false;
    if(mode == 'edit'){
        if(this.blogs[this.tempcurrentedit].wasedited){
            var origedit = this.blogs[this.currentedit];
            $.each(this.blogs[this.tempcurrentedit].editeddata,function(edix,edelem){
                switch(edelem.type){
                    case 'title':
                    case 'status':
                    case 'category':
                    case 'excerpt':
                    case 'content':
                        if(origedit[edelem.type] != edelem.value)
                            edited = true;
                    break;
                    case 'attrkey':
                        if(edelem.index < origedit.attributekeys.length){
                            if(origedit.attributekeys[edelem.index] !== edelem.value)
                                edited = true;
                        }
                        else{
                            if(edelem.value !== '<*delete*>'){
                                edited = true;
                            }
                        }
                    break;
                    case 'attrval':
                        if(edelem.index < origedit.attributevals.length){
                            if(origedit.attributevals[edelem.index] !== edelem.value)
                                edited = true;
                        }
                        else{
                            edited = true;
                        }
                    break;
                    case 'featimage':
                        if(origedit[edelem.type] != edelem.value)
                            edited = true;
                    break;
                }
            });
        }
    }
    else{
        if(this.blogs[this.tempcurrentnew].wasedited){
            var orignew = this.blogs[this.currentnew];
            $.each(this.blogs[this.tempcurrentnew].editeddata,function(edix,edelem){
                switch(edelem.type){
                    case 'title':
                    case 'status':
                    case 'category':
                    case 'excerpt':
                    case 'content':
                        if(orignew[edelem.type] != edelem.compareobj)
                            edited = true;
                    break;
                    case 'attrkey':
                        if(edelem.index < orignew.attributekeys.length){
                            if(orignew.attributekeys[edelem.index] !== edelem.compareobj)
                                edited = true;
                        }
                        else{
                            if(edelem.value !== '<*delete*>'){
                                edited = true;
                            }
                        }
                    break;
                    case 'attrval':
                        if(edelem.index < orignew.attributevals.length){
                            if(orignew.attributevals[edelem.index] !== edelem.compareobj)
                                edited = true;
                        }
                        else{
                            edited = true;
                        }
                    break;
                    case 'featimage':
                        if(orignew[edelem.type] != edelem.compareobj)
                            edited = true;
                    break;
                }
            });
        }
    }
    return edited;
};

var filteredentriesproto = function(filtervals,items,endofpage,objidx){
    this.filtervals = filtervals;
    this.items = items;
    this.currentpage = 1;
    this.endofpage = endofpage;
    this.objidx = objidx;
    this.pastentriesnumperpage = pastentriesnumperpage;
    this.completefiltervals();
};

filteredentriesproto.prototype.completefiltervals = function(){
    this.filtervals.catdescendants = this.getdescendants(this.filtervals.category);
};
filteredentriesproto.prototype.additems = function(newitems,offset){
    if(this.items.length < offset){
        var currenttotal = this.items.length;
        for(var d=currenttotal;d<offset;d++)
        {
            this.items[d] = false;
        }
        this.items = this.items.concat(newitems);
    }
    else if(this.items.length > offset){
        for(var i=0;i<newitems.length;i++){
            this.items[offset+i] = newitems[i];
        }
    }
    else{
        this.items = this.items.concat(newitems);
    }
};

filteredentriesproto.prototype.clearpage = function(){
    var currentlist = $('#pastentries').children('.row');
    $.each(currentlist,function(idx,elem){
        if($(elem).attr('class').indexOf('head') === -1 && $(elem).attr('class').indexOf('prepagemenu') === -1){
            $(elem).remove();
        }
    });
};
filteredentriesproto.prototype.getdescendants = function(categoryid){
    var descendants = $('#editblogcategorylistfilter').children('.parent_'+categoryid);
    var descendantsids = [];
    if(descendants.length){
        descendantsids = this._getdescendants(categoryid,descendantsids);
    }
    return descendantsids;
};
filteredentriesproto.prototype._getdescendants = function(categoryid,descendants){
    var _descendants = $('#editblogcategorylistfilter').children('.parent_'+categoryid);
    if(_descendants.length){
        for(var di=0;di<_descendants.length;di++){
            descendants[descendants.length] = parseInt($(_descendants[di]).attr('id').substr(16));
            descendants = this._getdescendants(descendants[descendants.length-1],descendants);
        }
    }
    return descendants;
};
filteredentriesproto.prototype.filterblog = function(blogobj){
    var filteredpass = true;
    if(!(this.filtervals.category == 0 && this.filtervals.status == -1 && this.filtervals.keywords == 'search')){
        if(this.filtervals.category != 0 && blogobj.category != this.filtervals.category && $.inArray(blogobj.category,this.filtervals.catdescendants) == -1){
            filteredpass = false;
        }
        else{
            if(this.filtervals.status != -1 && blogobj.status != this.filtervals.status){
                filteredpass = false;
            }
            else{
                if(blogobj.content === false){
                    filteredpass = false;
                }
                else if(this.filtervals.keywords != 'search'){
                    var keyfound = false;
                    if(blogobj.content.indexOf(this.filtervals.keywords) === -1){
                        for(var o=0;o<blogobj.attributevals.length;o++){
                            if(blogobj.attributekeys[o].indexOf(this.filtervals.keywords) !==-1){
                                keyfound = true;
                                break;
                            }
                            if(blogobj.attributevals[o].indexOf(this.filtervals.keywords) !==-1){
                                keyfound = true;
                                break;
                            }
                        }
                    }
                    else{
                        keyfound =true;
                    }
                    if(!keyfound){
                        filteredpass = false;
                    }
                }
            }
        }
    }
    return filteredpass;
};
filteredentriesproto.prototype.updateblogrow = function(status,category,blogobj){
    var rowstatus = 'updated';
    var inthelist = false;
    for(var c=0;c<this.items.length;c++){
        if(this.items[c] !== false && this.items[c].id == blogobj.id){
            inthelist = true;
            var filteredpass = this.filterblog(blogobj);
            if(filteredpass){
                 var newblogrow = '<div class="row"><div class="blognum">'+(c+1)+'</div>'
                        +'<div class="blogid">'+blogobj.id+'</div>'
                        +'<div class="blogtitle">'+blogobj.title+'</div>'
                        +'<div class="blogcategory blogcategory_'+blogobj.category+'">'+category+'</div>'
                        +'<div class="blogstatus">'+status+'</div>'
                        +'<div class="blogdate">'+blogobj.date+'</div>'
                        +'<div class="blogaction">'
                          +'<span class="deleteblog redfont" id="deleteblog_'+blogobj.id+'">delete</span>'
                          +'<span class="editblog" id="editblog_'+blogobj.id+'">edit</span>'
                        +'</div>'
                      +'</div>';
                this.items[c].row = newblogrow;
            }
            else{
                rowstatus = this.deleteblog(blogobj.id,false);
            }
            break;
        }
    }
    if(inthelist === true){
        return rowstatus;
    }
    else{
        if(this.filterblog(blogobj)){
            rowstatus = this.searchblogposition(blogobj);
        }
        return rowstatus;
    }
};
filteredentriesproto.prototype.searchblogposition = function(blogobj){
    var startpageoffset,endofpageoffset,thisthepage,thisthepagedead,endofitem,positionstatus;
    startpageoffset = 0;
    thisthepagedead = [];
    thisthepage     = -1;
    endofitem       = false;
    positionstatus  = '';

    for(var p=1;p<=Math.ceil(this.endofpage);p++){
        startpageoffset = (this.pastentriesnumperpage * (p-1));
        endofpageoffset = (startpageoffset + this.pastentriesnumperpage) -1;

        thisthepagedead[p-1] = -1;
        if(this.items === false){
            endofitem = true;
            thisthepage = p;
            break;
        }
        else{
            for(var checkpage=startpageoffset;checkpage<=endofpageoffset;checkpage++){
                if(this.items.length == checkpage){
                    endofitem = true;
                    if(thisthepagedead[p-1] > 0){
                        thisthepage = p;
                    }
                    break;
                }
                if(this.items[checkpage] !== false && parseInt(this.items[checkpage].id) < parseInt(blogobj.id)){
                    thisthepagedead[p-1]+=1;
                    thisthepage = p;
                    break;
                }
                else{
                    if(this.items[checkpage] !== false){
                        thisthepagedead[p-1]+=1;
                    }
                }
            }
            if(thisthepage > -1 || endofitem)
                break;
        }
    }

    if(thisthepage === -1 && !endofitem){
        thisthepage = (Math.ceil(this.endofpage)+1);
        thisthepagedead[thisthepage-1] = false;
        startpageoffset = (this.pastentriesnumperpage * (thisthepage-1))
    }

    if(this.items === false || thisthepagedead[thisthepage-1] === false || (thisthepagedead[thisthepage-1] >= 0 && (thisthepage > -1 || endofitem )) ){
        var newitem = [];
        newitem.id = blogobj.id;
        var statusstring = ['draft','published'];
        var blognum = ((startpageoffset+1)+thisthepagedead[thisthepage-1]);
        newitem.row = '<div class="row"><div class="blognum">'+blognum+'</div>'
                        +'<div class="blogid">'+blogobj.id+'</div>'
                        +'<div class="blogtitle">'+blogobj.title+'</div>'
                        +'<div class="blogcategory blogcategory_'+blogobj.category+'">'+ $('#filterpastentry_'+blogobj.category).find('.catname').html()+'</div>'
                        +'<div class="blogstatus">'+statusstring[blogobj.status]+'</div>'
                        +'<div class="blogdate">'+blogobj.date+'</div>'
                        +'<div class="blogaction">'
                          +'<span class="deleteblog redfont" id="deleteblog_'+blogobj.id+'">delete</span>'
                          +'<span class="editblog" id="editblog_'+blogobj.id+'">edit</span>'
                        +'</div>'
                      +'</div>';

        if(this.items === false){
            this.items = [];
            this.items[0] = newitem;
        }
        else{
            if(this.items.length % this.pastentriesnumperpage == 0){
                this.addpage();
                if(thisthepagedead[thisthepage-1] === false){
                    thisthepagedead[thisthepage-1] = 0;
                }
            }
            this.items.splice((startpageoffset+thisthepagedead[thisthepage-1]),0,newitem);
            for(var u=startpageoffset+thisthepagedead[thisthepage-1];u<this.items.length;u++){
                if(this.items[u] !== false)
                    this.items[u].row = this.items[u].row.replace('<div class="blognum">'+u+'</div>','<div class="blognum">'+(u+1)+'</div>');
            }
        }
        positionstatus = 'newentryadded';
    }
    if(positionstatus == ''){
        this.endofpage = this.endofpage + (1/this.pastentriesnumperpage);
        if(this.endofpage % 1 === 0){
            this.addpage();
        }
    }
    return positionstatus;
};
filteredentriesproto.prototype.addpage = function(){
    this.endofpage = Math.ceil(this.endofpage)+1;
    if(this.objidx == appsblogsdata[appsblogindex].pastentrynav.currentfilteredresultidx){
        $('#bloggotopage').append('<option value="'+this.endofpage+'" selected="selected">page '+this.endofpage+'</option>');
    }
};
filteredentriesproto.prototype.deleteblog = function(id,filtered){
    var deleted = false;
    for(var c=0;c<this.items.length;c++){
        if(deleted){
            if(this.items[c] !== false)
                this.items[c].row = this.items[c].row.replace('<div class="blognum">'+(c+2)+'</div>','<div class="blognum">'+(c+1)+'</div>');
        }
        else{
            if(this.items[c] !== false && this.items[c].id == id){
                this.items.splice(c,1);
                c--;
                deleted = true;
            }
        }
    }
    if(deleted){
        deleted = 'deleted';
        if(this.items.length % this.pastentriesnumperpage == 0){
            this.endofpage = this.endofpage - (1/this.pastentriesnumperpage);

            if(this.items.length == 0)
                this.items = false;
        }
        if(this.currentpage > Math.ceil(this.endofpage)){
            this.currentpage--;
        }
    }
    else{
        if(filtered){
            deleted = 'deleted';
            this.endofpage = this.endofpage - (1/this.pastentriesnumperpage);
            if(this.currentpage > Math.ceil(this.endofpage)){
                this.currentpage--;
            }
        }
    }
    return deleted;
};
filteredentriesproto.prototype.comparefilter = function(postdata){
    if(postdata.keywords == this.filtervals.keywords && postdata.category == this.filtervals.category && postdata.status == this.filtervals.status){
        return true;
    }
    return false;
};
filteredentriesproto.prototype.emptypage = function(){
    this.newgoto();
};
filteredentriesproto.prototype.newgoto = function(){
    var newgoto = '';
    var mingoto = Math.ceil(this.endofpage);
    mingoto = mingoto == 0 ? 1 : mingoto;

    for(var c = 1;c<=mingoto;c++){
        if(this.currentpage ==c)
            newgoto += '<option value="'+c+'" selected="selected">page '+c+'</option>';
        else
            newgoto += '<option value="'+c+'">page '+c+'</option>';
    }
    $('#bloggotopage').html(newgoto);
};
filteredentriesproto.prototype.display = function(){
    this.clearpage();
    var cupage = this.currentpage;
    this.currentpage = -1;

    if(this.items === false){
        this.currentpage = 1;
        this.emptypage();
        return;
    }
    this.jumppage(cupage);
};
filteredentriesproto.prototype.prevpage = function(){
    this.jumppage(parseInt(this.currentpage) - 1);
};
filteredentriesproto.prototype.nextpage = function(){
    this.jumppage(parseInt(this.currentpage) + 1);
};
filteredentriesproto.prototype.jumppage = function(pagenum){
    if(pagenum == this.currentpage){
        return -1;
    }
    $('#pastentries').addClass('loading');
    var skip    = (pagenum -1) * this.pastentriesnumperpage;
    var offset  = false;
    var limit   = this.pastentriesnumperpage;

    if(this.items.length > skip){
        var pageitems = this.items.slice(skip,(skip+this.pastentriesnumperpage));
        if(pageitems.length < this.pastentriesnumperpage && pagenum < Math.ceil(this.endofpage)){
            for(var pc=pageitems.length;pc<this.pastentriesnumperpage;pc++){
                pageitems[pc] = false;
            }
        }
        for(var pc=0;pc<pageitems.length;pc++){
            if(pageitems[pc] === false && offset === false){
                offset = skip+pc;
            }
            else{
                limit--;
            }
        }
    }
    else{
        offset = skip;
        limit = this.pastentriesnumperpage;
    }

    if(offset === false){
        this.currentpage = pagenum;
        this.clearpage();
        this.newgoto();
        for(var c=0;c<pageitems.length;c++){
            var blogrow = pageitems[c].row;
            $('#editblogcontainer').before(blogrow);
        }
        $('#pastentries').removeClass('loading');

        var maxpage = $('#bloggotopage').children().length;
        if(this.currentpage == maxpage || maxpage == 1){
            $('#nextblognav').addClass('disabled');
            if(maxpage == 1){
                $('#prevblognav').addClass('disabled');
            }
            else{
                $('#prevblognav').removeClass('disabled');
            }
        }
        else if(this.currentpage == 1){
            $('#prevblognav').addClass('disabled');
            if(maxpage > 1){
                $('#nextblognav').removeClass('disabled');
            }
        }
        else if(this.currentpage < maxpage){
            $('#nextblognav').removeClass('disabled');
            $('#prevblognav').removeClass('disabled');
        }
        else if(this.currentpage > 1){
            $('#nextblognav').removeClass('disabled');
            $('#prevblognav').removeClass('disabled');
        }

        return;
    }


    var thisfilteredpage    = this;
    var postdata            = {offset:offset,limit:limit,keywords:this.filtervals.keywords,category: this.filtervals.category,status:this.filtervals.status};
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'blog',a:'blogpage',d:postdata}
    }).done(function(msg){
        msg = $.parseJSON(msg);
        if(msg.blog === false){
            thisfilteredpage.endofpage = msg.pagenum;
            pagenum = Math.ceil(msg.pagenum);
            thisfilteredpage.currentpage=pagenum;
            thisfilteredpage.display();
            return;
        }

        thisfilteredpage.endofpage = msg.pagenum;

        var blognum = offset+1;
        var statusstring = ['draft','published'];
        var result = [];
        $.each(msg.blog,function(blogidx,blogelem){
            var newrow = '<div class="row"><div class="blognum">'+blognum+'</div>'
                        +'<div class="blogid">'+blogelem.id+'</div>'
                        +'<div class="blogtitle">'+blogelem.title+'</div>'
                        +'<div class="blogcategory blogcategory_'+blogelem.category+'">'+$('#filterpastentry_'+blogelem.category).find('.catname').html()+'</div>'
                        +'<div class="blogstatus">'+statusstring[blogelem.status]+'</div>'
                        +'<div class="blogdate">'+blogelem.created+'</div>'
                        +'<div class="blogaction">'
                          +'<span class="deleteblog redfont" id="deleteblog_'+blogelem.id+'">delete</span>'
                          +'<span class="editblog" id="editblog_'+blogelem.id+'">edit</span>'
                        +'</div>'
                      +'</div>';
            blognum++;

            var resultidx = result.length;
            result[resultidx] = [];
            result[resultidx].id = blogelem.id;
            result[resultidx].row = newrow;
        });

        thisfilteredpage.additems(result,offset);
        thisfilteredpage.jumppage(pagenum);
        thisfilteredpage.newgoto();
    });
};


var appsblogsdata       = [];
var appsblogindex       = 0;
function blogpage(){
    if($.inArray('blogpage',pageloaded) !== -1){
        appsblogindex = false;
        for(var i=0;i<appsblogsdata.length;i++){
            if(appsblogsdata[i].appid == currentappid){
                appsblogindex = i;
            }
        }
        if(appsblogindex === false){
            appsblogsdata[appsblogsdata.length] = [];
            appsblogsdata[appsblogsdata.length-1].appid         = currentappid;
            appsblogsdata[appsblogsdata.length-1].pastentrynav  = new pastentrynavproto();
            appsblogsdata[appsblogsdata.length-1].blogsdata     = new blogsdataproto();

            appsblogindex = appsblogsdata.length-1;
        }
        appsblogsdata[appsblogindex].pastentrynav.newresults();
        return;
    }
    else{
        appsblogsdata[appsblogsdata.length] = [];
        appsblogsdata[appsblogsdata.length-1].appid         = currentappid;
        appsblogsdata[appsblogsdata.length-1].pastentrynav  = new pastentrynavproto();
        appsblogsdata[appsblogsdata.length-1].blogsdata     = new blogsdataproto();

        appsblogsdata[appsblogsdata.length-1].pastentrynav.newresults();

        pageloaded[pageloaded.length] = 'blogpage';
    }


    tinythentinynow();
    $('#thepagecontainer').on('click',function(event){
        $('.blogcategorylist').removeClass('active');
        $('.blogstatusselection').removeClass('active');
        $('.blogattrkeyoptprovider').removeClass('active');
    });

    var blogimageuploader = new filetool();
    blogimageuploader.filereadersupport  = $('#blogimage').find('.filereader');
    blogimageuploader.formdatasupport    = $('#blogimage').find('.formdata');
    blogimageuploader.progresssupport    = $('#blogimage').find('.progress');
    blogimageuploader.holder             = $('#blogimage').find('.holder');
    blogimageuploader.progress           = $('#blogimage').find('.uploadprogress');
    blogimageuploader.fileupload         = $('#blogimage').find('.upload');
    blogimageuploader.enduploadcallback = function(msg){
        msg = $.parseJSON(msg);
        if(msg.upload)
        {
            var imagename = $(this.holder).siblings('.imagename').val();
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].featimage += '<*featimage*>'+msg.image+'<e>'+msg.imageid+'<e>'+imagename;
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].featimage += '<*featimage*>'+msg.image+'<e>'+msg.imageid+'<e>'+imagename;

            $(this.holder).find('img').remove();
            var newstill = '<div class="imagestills"><div class="imagebox"><img src="'+msg.image+'"><span class="editimagename"></span><div class="imageid">'+msg.imageid+'</div></div><span class="stillurl">'+imagename+'<input type="text" class="stillurlpos" value="'+msg.image+'"></span><input type="button" class="deletestill" value="delete" id="deletestill_'+msg.imageid+'"></div>';
            $(this.holder).parent().after(newstill);
            $(this.holder).siblings('progress').addClass('hidden');
            $(this.holder).siblings('.goupload').removeClass('hidden');
            $(this.holder).parent().removeClass('imagecontainer');
        }
        if(typeof msg.blogid !== 'undefined'){
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id = parseInt(msg.blogid);
            if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].title ==''){
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].title = 'untitled';
                $('#newentry').children('#blogtitle').val('untitled');

                appsblogsdata[appsblogindex].blogsdata.wasedited('untitled','title',false,'new');
            }
            if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].category == 0){
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].category = 1;

                $('#newentry').find('#blogcategoryselect').val('uncategorized');
                $('#newentry').find('#blogcategorylist').children().eq(0).addClass('selected');

                appsblogsdata[appsblogindex].blogsdata.wasedited(1,'category',false,'new');
            }

            if(appsblogsdata[appsblogindex].blogsdata.editingnew('new')){
                registapagemsg('saving...',false);

                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].saveChanges(function(response){
                    if(response !== false){
                        addpastentries();
                        registapagemsg('changes was successfully saved',true);
                    }
                    else{
                        registapagemsg('failed saving data',true);
                    }
                });
            }
            else{
                addpastentries();
            }
        }
    };

    blogimageuploader.init();

    var editblogimageuploader = new filetool();
    editblogimageuploader.filereadersupport  = $('#editblogimage').find('.filereader');
    editblogimageuploader.formdatasupport    = $('#editblogimage').find('.formdata');
    editblogimageuploader.progresssupport    = $('#editblogimage').find('.progress');
    editblogimageuploader.holder             = $('#editblogimage').find('.holder');
    editblogimageuploader.progress           = $('#editblogimage').find('.uploadprogress');
    editblogimageuploader.fileupload         = $('#editblogimage').find('.upload');
    editblogimageuploader.enduploadcallback = function(msg){
        msg = $.parseJSON(msg);
        if(msg.upload){
            var imagename = $(this.holder).siblings('.imagename').val();
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentedit].featimage += '<*featimage*>'+msg.image+'<e>'+msg.imageid+'<e>'+imagename;

            $(this.holder).find('img').remove();
            var newstill = '<div class="imagestills"><div class="imagebox"><img src="'+msg.image+'"><span class="editimagename"></span><div class="imageid">'+msg.imageid+'</div></div><span class="stillurl">'+imagename+'<input type="text" class="stillurlpos" value="'+msg.image+'"></span><input type="button" class="deletestill" value="delete" id="deletestill_'+msg.imageid+'"></div>';
            $(this.holder).parent().after(newstill);
            $(this.holder).siblings('progress').addClass('hidden');
            $(this.holder).siblings('.goupload').removeClass('hidden');
            $(this.holder).parent().removeClass('imagecontainer');
        }
    };

    editblogimageuploader.init();


    function uploadblogimage(mode){
        var workerparams = {workeraction:'uploadfiles',app:'regista',p:'blog',a:'uploadblogimage'};
        switch(mode){
            case 'edit':
                workerparams.d = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].id+'|'+$(editblogimageuploader.holder).siblings('.imagename').val();

                editblogimageuploader.workerparams = workerparams;
                editblogimageuploader.formData.append('app',appname);
                editblogimageuploader.formData.append('p',workerparams.p);
                editblogimageuploader.formData.append('a',workerparams.a);
                editblogimageuploader.formData.append('file', editblogimageuploader.thefiles);
                editblogimageuploader.formData.append('d',editblogimageuploader.workerparams.d);

                editblogimageuploader.startupload();
            break;
            default:
                workerparams.d = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id+'|'+$(blogimageuploader.holder).siblings('.imagename').val();
                workerparams.a = 'uploadblogimage';

                blogimageuploader.workerparams = workerparams;
                blogimageuploader.formData.append('app',appname);
                blogimageuploader.formData.append('p',workerparams.p);
                blogimageuploader.formData.append('a',workerparams.a);
                blogimageuploader.formData.append('file', blogimageuploader.thefiles);
                blogimageuploader.formData.append('d',blogimageuploader.workerparams.d);

                blogimageuploader.startupload();
            break;
        }
    }
    var blogimageoldname;
    $('#thepagecontainer').delegate('.editimagename','click',function(event){
        event.stopPropagation();
        var urlbox = $(this).parent().siblings('.stillurl');
        blogimageoldname = $(urlbox).html().substr(0,$(urlbox).html().indexOf('<'));

        $(urlbox).addClass('active');
        $(urlbox).children('input').removeClass('copying').val(blogimageoldname).focus();
    });
    var blogimagetomove = false;
    $('#thepagecontainer').delegate('.imagestills','click',function(event){
        event.stopPropagation();
        var container = $(this).parent();
        if($(container).attr('class').indexOf('moveimage') === -1){
            $(this).addClass('tomove');
            $(container).addClass('moveimage');
            blogimagetomove = $(this);
            return;
        }

        $(container).removeClass('moveimage');
        if($(this).attr('class').indexOf('tomove') !== -1){
            $(this).removeClass('tomove');
            blogimagetomove = false;

            return;
        }

        var tomove = $(container).children('.tomove');
        var tomovehtml = '<div class="imagestills">'+$(tomove).html()+'</div>';


        var waseditedimage = [];
        stillurlelem = $(this).find('.stillurl');
        waseditedimage[0] = $(this).find('img').attr('src')+'<e>'+$(this).find('.imageid').html()+'<e>'+$(stillurlelem).html().substr(0,$(stillurlelem).html().indexOf('<input'));
        var stillurlelem = $(tomove).find('.stillurl');
        waseditedimage[1] = $(tomove).find('img').attr('src')+'<e>'+$(tomove).find('.imageid').html()+'<e>'+$(stillurlelem).html().substr(0,$(stillurlelem).html().indexOf('<input'));

        $(tomove).remove();

        $(this).before(tomovehtml);
        moveblogimage(waseditedimage);
    });
    function moveblogimage(waseditedimage){
        var images;
        if($('#adminmenu_pastentries').attr('class').indexOf('active') !== -1){
            images = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].featimage.split('<*featimage*>');
        }
        else{
            images = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].featimage.split('<*featimage*>');
        }

        var imageidx = false;
        var spliceidx = false;
        for(var ix=0;ix<images.length;ix++){
            if(images[ix] != ''){
                if(images[ix] == waseditedimage[1]){
                    spliceidx = ix;
                }
                else if(images[ix] == waseditedimage[0]){
                    imageidx = ix;
                }
            }
        }

        images.splice(imageidx,0,waseditedimage[1]);
        if(spliceidx > imageidx){
            spliceidx++;
        }
        images.splice(spliceidx,1);

        var imagestr = '';
        for(var ix = 0;ix<images.length;ix++){
            if(images[ix] != '')
                imagestr+= '<*featimage*>'+images[ix];
        }

        if($('#adminmenu_pastentries').attr('class').indexOf('active') !== -1){
            appsblogsdata[appsblogindex].blogsdata.wasedited(imagestr,'featimage',false,'edit');
        }
        else{
            appsblogsdata[appsblogindex].blogsdata.wasedited(imagestr,'featimage',false,'new');
        }
    }
    $('#thepagecontainer').delegate('.stillurl','click',function(event){
        event.stopPropagation();

        var imageurl = $(this).prev().children().eq(0).prop('src');
        imageurl = imageurl.split('_thumb');
        imageurl = imageurl.join('_medium');
        $(this).addClass('active');
        $(this).children('input').addClass('copying').val(imageurl).focus();
    });
    $('#thepagecontainer').delegate('.stillurlpos','click',function(event){
        event.stopPropagation();
    });
    $('#thepagecontainer').delegate('.stillurlpos','blur',function(event){
        event.stopPropagation();
        var urlbox = $(this).parent();
        var imageurl = $(this).parent().prev().children().eq(0).attr('src');

        if($(this).attr('class').indexOf('copying') !== -1){
            $(this).parent().removeClass('active');
            return;
        }

        if($(this).val() !== blogimageoldname){
            var imageid = $(this).parent().prev().children('.imageid').html();
            var newname = $(this).val();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'blog',a:'blogimageupdate',d:{newname:newname,imageid:imageid}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                if(msg.result != false){
                    $(urlbox).html($(urlbox).html().replace(blogimageoldname+'<',newname+'<'));
                    editblogimages(imageurl+'|'+imageid+'|'+newname,imageurl);
                }
                $(urlbox).removeClass('active');
            });
        }
        else{
            $(urlbox).removeClass('active');
        }
    });
    $('#thepagecontainer').delegate('#blogimage .imagename','keyup',function(event){
        event.stopPropagation();
        if(event.which != 13){
            return;
        }
        if (blogimageuploader.formData !== false) {
            $(this).siblings('.goupload').addClass('hidden');
            $(this).siblings('progress').removeClass('hidden');
            uploadblogimage('new');
        }
    });
    $('#thepagecontainer').delegate('#editblogimage .imagename','keyup',function(event){
        event.stopPropagation();
        if(event.which != 13){
            return;
        }
        if (editblogimageuploader.formData !== false) {
            $(this).siblings('.goupload').addClass('hidden');
            $(this).siblings('progress').removeClass('hidden');
            uploadblogimage('edit');
        }
    });
    $('#thepagecontainer').delegate('#blogimage .goupload','click',function(event){
        event.stopPropagation();
        if (blogimageuploader.formData !== false) {
            $(this).addClass('hidden');
            $(this).siblings('progress').removeClass('hidden');
            uploadblogimage('new');
        }
    });
    $('#thepagecontainer').delegate('#editblogimage .goupload','click',function(event){
        event.stopPropagation();
        if (editblogimageuploader.formData !== false) {
            $(this).addClass('hidden');
            $(this).siblings('progress').removeClass('hidden');
            uploadblogimage('edit');
        }
    });

    function submitblogsearchfilter(){
        $('.pagecontainer').addClass('loading');
        var postdata        = {offset:0,limit:false};
        postdata.keywords   = $('#searchpastentrykeywords').val() === '' ? 'search' : $('#searchpastentrykeywords').val();
        postdata.category   = $('#editblogcategorylistfilter').children('.selected').length ? $('#editblogcategorylistfilter').children('.selected').attr('id').substr(16) : ($('#searchincategory').val() == 'category' ? 0 : false);
        postdata.status     = $('#searchinstatus').val();

        if(postdata.status == 'status' || postdata.status == 'All Status' || postdata.status == ''){
            postdata.status = -1;
        }
        else if(postdata.status == 'Published'){
            postdata.status = 1;
        }
        else{
            postdata.status = 0;
        }

        var downloaded = appsblogsdata[appsblogindex].pastentrynav.searchfilteredpage(postdata);

        if(downloaded){
            $('.pagecontainer').removeClass('loading');
           return;
        }

        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'blog',a:'blogpage',d:postdata}
        }).done(function(msg){
            msg = $.parseJSON(msg);

           var result = [];
            if(msg.blog.length){
                var blognum = postdata.offset+1;
                var statusstring = ['draft','published'];

                $.each(msg.blog,function(blogidx,blogelem){
                    var newrow = '<div class="row"><div class="blognum">'+blognum+'</div>'
                                +'<div class="blogid">'+blogelem.id+'</div>'
                                +'<div class="blogtitle">'+blogelem.title+'</div>'
                                +'<div class="blogcategory blogcategory_'+blogelem.category+'">'+$('#filterpastentry_'+blogelem.category).find('.catname').html()+'</div>'
                                +'<div class="blogstatus">'+statusstring[blogelem.status]+'</div>'
                                +'<div class="blogdate">'+blogelem.created+'</div>'
                                +'<div class="blogaction">'
                                  +'<span class="deleteblog redfont" id="deleteblog_'+blogelem.id+'">delete</span>'
                                  +'<span class="editblog" id="editblog_'+blogelem.id+'">edit</span>'
                                +'</div>'
                              +'</div>';
                    blognum++;

                    var resultidx = result.length;
                    result[resultidx] = [];
                    result[resultidx].id = blogelem.id;
                    result[resultidx].row = newrow;
                });
            }
            else{
                result = false;
            }
            appsblogsdata[appsblogindex].pastentrynav.newfilter(postdata.keywords,postdata.category,postdata.status,msg.pagenum,result);
            $('.pagecontainer').removeClass('loading');
        });
    }
    $('#thepagecontainer').delegate('#searchblogsubmit','click',function(event){
        event.stopPropagation();
        submitblogsearchfilter();
    });
    $('#thepagecontainer').delegate('#searchinstatus','click focus',function(event){
        event.stopPropagation();
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
        $(this).next().addClass('active');
    });
    var clickedonstatusoption = false;
    $('#thepagecontainer').delegate('#searchinstatus','blur',function(event){
        event.stopPropagation();
        if($(this).val() === ''){
            $(this).val($(this).attr('name')).removeClass('filled');
        }
        var blurthis = this;
        setTimeout(function(){
            if(!clickedonstatusoption){
                $(blurthis).next().removeClass('active');
            }
        },200);
    });
    $('#thepagecontainer').delegate('#searchinstatus','keyup',function(key){
         var attropt = $(this).next();
         var selected = $(attropt).children('.selected');
         selected = selected.length ? selected[0] : false;
         var curselected = selected;
         switch(key.which){
            case 13:
                if(selected === false){
                    return;
                }
                if($(attropt).attr('class').indexOf('active') === -1){
                    submitblogsearchfilter();
                    return;
                }
                $(this).val($(selected).html());
                $(attropt).removeClass('active');
            break;
            case 40:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).next();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('blogstatusselect') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected[0].scrollIntoView();
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(attropt).children().eq(0).addClass('selected');
                }
            break;
            case 38:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).prev();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('blogstatusselect') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected[0].scrollIntoView();
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(attropt).children().eq($(attropt).children().length-1).addClass('selected');
                }
            break;
            default:
                $(attropt).addClass('active');
                filterattropt(attropt,$(this).val());
            break;
         }
    });
    $('#thepagecontainer').delegate('.blogstatusselection li','click',function(event){
        clickedonstatusoption = true;
        event.stopPropagation();

        $(this).parent().removeClass('active');
        $(this).parent().prev().val($(this).html()).addClass('filled');
        clickedonstatusoption = false;
    });


    $('#thepagecontainer').delegate('#bloggotopage','change',function(){
        appsblogsdata[appsblogindex].pastentrynav.filteredresults[appsblogsdata[appsblogindex].pastentrynav.currentfilteredresultidx].jumppage(this.value);
    });


    $('#thepagecontainer').delegate('#prevblognav','click',function(){
        if($(this).attr('class').indexOf('disabled') === -1)
            appsblogsdata[appsblogindex].pastentrynav.filteredresults[appsblogsdata[appsblogindex].pastentrynav.currentfilteredresultidx].prevpage();
    });
    $('#thepagecontainer').delegate('#nextblognav','click',function(){
        if($(this).attr('class').indexOf('disabled') === -1)
            appsblogsdata[appsblogindex].pastentrynav.filteredresults[appsblogsdata[appsblogindex].pastentrynav.currentfilteredresultidx].nextpage();
    });

    resetblogpage = function(pagetype){
        if(pagetype == 'new'){
            $.each($('#newentry').find('input[type="text"],textarea'),function(formelemidx,formelem){
                if(typeof($(formelem).attr('name')) !== 'undefined') {
                    var formarray = $(formelem).attr('name').indexOf('[');
                    if(formarray == -1){
                        formarray = ($(formelem).attr('name').length);
                    }
                    $(formelem).val($(formelem).attr('name').substr(0,formarray));
                    $(formelem).removeClass('filled');
                }
            });

            $('#blogimage').find('.imagestills').remove();
            $('#blogcategorylist').children().removeClass('selected');
            $('#newupdateblogstatus').val('Publish');
            tinymce.get('blogcontenttext').setContent('');
            tinymce.get('blogexcerpt').setContent('');

            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].content = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].content = tinymce.get('blogcontenttext').getContent();
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].excerpt = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].excerpt = tinymce.get('blogexcerpt').getContent();
        }
        else{
            $('#editblogimage').find('.imagestills').remove();
            $('#editblogcategorylist').children().removeClass('selected');
        }
    };

    $('#thepagecontainer').delegate('#pastentries input[type="text"],#newentry input[type="text"]','blur',function(){
        var pagemode = 'edit';
        if($('#newentry').attr('class').indexOf('active') !== -1){
            pagemode = 'new';
        }
        var elem        = this;
        var content     = false;
        var index       = false;
        var thisclass   = $(this).attr('class');
        thisclass       = typeof thisclass === 'undefined' ? false : thisclass.split(' ')[0];
        if(thisclass === false){return;}

        switch(thisclass){
            case 'blogtitle':
                content = $(elem).val();
                appsblogsdata[appsblogindex].blogsdata.wasedited(content,'title',false,pagemode);
            break;
            case 'blogcategoryselect':
                if($(elem).attr('id') === 'searchincategory'){
                    if($(elem).val() == 'category' || $(elem).val() == ''){
                        $(elem).next().children().removeClass('selected');
                    }
                    return;
                }


                content = $(elem).val();
                if(content == $(elem).attr('name') || content === ''){
                    return;
                }

                var catlist = $(elem).next('.blogcategorylist').find('.catname');
                var newcat = true;
                $.each(catlist,function(cidx,celem){
                    if($(celem).html() == content){
                        $(celem).parent().addClass('selected');
                        var listedcat = $(celem).parent();
                        newcat = false;
                        content = $(listedcat).attr('id').substr($(listedcat).attr('id').indexOf('_')+1);
                        return false;
                    }
                });
                if(newcat){
                   $.ajax({
                        url:'./',
                        type:'POST',
                        data:{app:appname,p:'blog',a:'saveblogcategory',d:{parent:0,name:content,description:''}}
                    }).done(function(msg){
                        if(msg !== false){
                            newblogcatupdate(msg,content,0,'','false');
                            if(pagemode == 'edit'){
                                $('#editblogcategorylist').children().removeClass('selected');
                                $('#editblogcategorylist').children().eq($('#editblogcategorylist').children().length-1).addClass('selected');
                                $('#editblogcategorylist').removeClass('active');
                            }
                            else{
                                $('#blogcategorylist').children().removeClass('selected');
                                $('#blogcategorylist').children().eq($('#blogcategorylist').children().length-1).addClass('selected');
                                $('#blogcategorylist').removeClass('active');
                            }
                            appsblogsdata[appsblogindex].blogsdata.wasedited(msg,'category',false,pagemode);
                        }
                    });
                }
                else{
                    appsblogsdata[appsblogindex].blogsdata.wasedited(content,'category',false,pagemode);
                }
            break;
            case 'blogattr':
                content = $(elem).val();

                if(content != '' &&  content != $(elem).attr('name').substr(0,$(elem).attr('name').indexOf('['))){
                    index = $(elem).attr('id').substr($(elem).attr('id').indexOf('_')+1);
                    appsblogsdata[appsblogindex].blogsdata.wasedited(content,'attrkey',index,pagemode);
                }
            break;
            case 'blogattrval':
                content = $(elem).val();
                if(content != '' && content != $(elem).attr('name').substr(0,$(elem).attr('name').indexOf('['))){
                    index = $(elem).attr('id').substr($(elem).attr('id').indexOf('_')+1);
                    appsblogsdata[appsblogindex].blogsdata.wasedited(content,'attrval',index,pagemode);
                }
            break;
            case 'statusoption':
            break;
            default:
            break;
        }
    });

    function deleteblog(blogobj){
        appsblogsdata[appsblogindex].pastentrynav.deleteblog(blogobj);
    }
    function editblogimages(mode,matchingstring){
        if($('#adminmenu_pastentries').attr('class').indexOf('active') !== -1){
            images = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].featimage.split('<*featimage*>');
        }
        else{
            images = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].featimage.split('<*featimage*>');
        }

        var imageidx = false;
        for(var ix=0;ix<images.length;ix++){
            if(images[ix] != ''){
                var imageelem = images[ix].split('<e>');

                if(imageelem[0] == matchingstring){
                    imageidx = ix;
                    break;
                }
            }
        }

        if(mode == 'delete'){
            images.splice(imageidx,1);
        }
        else{
            images[imageidx] = mode;
        }

        var imagestr = '';
        for(var ix = 0;ix<images.length;ix++){
            if(images[ix] !== '')
                imagestr+= '<*featimage*>'+images[ix];
        }

        if($('#adminmenu_pastentries').attr('class').indexOf('active') !== -1){
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].featimage = imagestr;
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentedit].featimage = imagestr;
        }
        else{
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].featimage = imagestr;
        }
    }


    $('#thepagecontainer').delegate('.deletestill','click',function(event){
        event.stopPropagation();
        var blogimageid = this.id.substr(12);
        var imagethis = this;
        $(this).parent().addClass('loading');

        var confirmimagedelete = new messagebox();
        confirmimagedelete.title = 'Delete Image';
        confirmimagedelete.content = 'Delete Image?';
        confirmimagedelete.action = '<span id="cancelimagedelete">Cancel</span><span id="confirmimagedelete">Yes</span>';

        confirmimagedelete.display();

        $('#cancelimagedelete').on('click',function(){
            confirmimagedelete.close();
        });

        $('#confirmimagedelete').on('click',function(){
            confirmimagedelete.close();

            registapagemsg('deleting...',false);

            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'blog',a:'deleteblogimage',d:{blogimageid:blogimageid}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                if(msg.delete){
                    var images;
                    var imagestilldiv = $(imagethis).siblings('.stillurl');
                    var imageurldeleted = $(imagethis).parent().children('img').attr('src');

                    editblogimages('delete',imageurldeleted);
                    $(imagethis).parent().remove();

                    registapagemsg('image deleted',true);
                }
                else{
                    $(imagethis).parent().removeClass('loading');
                    registapagemsg('error deleting...',true);
                }
            });
        });
    });
    $('#thepagecontainer').delegate('#pastentries .editblog','click',function(event){
        event.stopPropagation();

        var blogid = $(this).attr('id').substr(9);
        if(appsblogsdata[appsblogindex].blogsdata.find(blogid) === false){
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'blog',a:'editblog',d:{blogid:blogid}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                var editblog     = new blogdata();
                editblog.populatedata(msg);
                editblog.id = blogid;
                editblog.title = $('#editblog_'+blogid).parent().siblings('.blogtitle').html();
                editblog.status = $('#editblog_'+blogid).parent().siblings('.blogstatus').html() == 'published' ? 1: 0;
                editblog.date = $('#editblog_'+blogid).parent().siblings('.blogdate').html();
                var categoryclass = $('#editblog_'+blogid).parent().siblings('.blogcategory').attr('class');
                editblog.category = parseInt(categoryclass.substr(categoryclass.indexOf('_')+1));


                appsblogsdata[appsblogindex].blogsdata.addblog(editblog,'edit');

                $('#editblogcontainer').addClass('active');
                $('#pastentries').addClass('editing');
            });
        }
        else{
            if(typeof appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew] !== 'undefined' && appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].id == appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id){
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].resetData();
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].resetData();

                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].date = currentdatestring();
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].date = currentdatestring();
                resetblogpage('new');
            }
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].populateform('editblog');
            $('#editblogcontainer').addClass('active');
            $('#pastentries').addClass('editing');
        }
    });

    function updatepastentries(){
        var editrow = $('#editblog_'+appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].id).parent().parent();
        var categoryname = $('#selectcat_'+appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].category).children('.catname').html();
        var status = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].status == 1 ? 'published' : 'draft';

        appsblogsdata[appsblogindex].pastentrynav.updateblogrow(status,categoryname,appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit]);
    }
    function addpastentries(){
        var categoryname = $('#selectcat_'+appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].category).children('.catname').html();
        var status = appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].status == 1 ? 'published' : 'draft';

        appsblogsdata[appsblogindex].pastentrynav.updateblogrow(status,categoryname,appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew]);
    }

    closeeditpage = function(updatelist){
        if(updatelist){
            updatepastentries();
        }

        $('#editblogcontainer').removeClass('active');
        $('#pastentries').removeClass('editing');
    };

    $('#thepagecontainer').delegate('#blogattributes .addblogattr','click',function(event){
	    event.stopPropagation();
        var newattridx = $(this).parent().parent().children().length;
        var newattr = '<div class="row"><input type="text" name="attribute name[]" value="attribute name" class="blogattr" id="blogattrname_'+newattridx+'"><ul class="blogattrkeyoptprovider"></ul><input type="text" name="attribute value[]" value="attribute value" class="blogattrval" id="blogattrval_'+newattridx+'"><input type="button" class="addblogattr" value="+"><input type="button" class="minblogattr" value="-"></div>';
        $(this).parent().after(newattr);


        appsblogsdata[appsblogindex].blogsdata.wasedited('','attrkey',newattridx,'new');
        appsblogsdata[appsblogindex].blogsdata.wasedited('','attrval',newattridx,'new');
    });

    $('#thepagecontainer').delegate('#blogattributes .minblogattr','click',function(event){
	    event.stopPropagation();
        var blogattrname = $(this).parent().children('.blogattr');
        var attridx = parseInt($(blogattrname).attr('id').substr(13));

        appsblogsdata[appsblogindex].blogsdata.wasedited('<*delete*>','attrkey',attridx,'new');

        if($(this).parent().siblings().length){
            $(this).parent().remove();
        }
        else{
            $.each($(this).siblings('input[type="text"]'),function(inputidx,inputelem){
                var placeholder = $(inputelem).attr('name');
                if(placeholder.indexOf('[') !== -1){
                    placeholder = placeholder.substr(0,placeholder.indexOf('['));
                }
                $(inputelem).val(placeholder).removeClass('filled');
            });
        }
    });

    $('#thepagecontainer').delegate('#editblogattributes .addblogattr','click',function(event){
	event.stopPropagation();
        var newattridx = $(this).parent().parent().children().length;
        var newattr = '<div class="row"><input type="text" name="attribute name[]" value="attribute name" class="blogattr" id="editblogattrname_'+newattridx+'"><ul class="blogattrkeyoptprovider"></ul><input type="text" name="attribute value[]" value="attribute value" class="blogattrval" id="editblogattrval_'+newattridx+'"><input type="button" class="addblogattr" value="+"><input type="button" class="minblogattr" value="-"></div>';
        $(this).parent().after(newattr);

        appsblogsdata[appsblogindex].blogsdata.wasedited('','attrkey',newattridx,'edit');
        appsblogsdata[appsblogindex].blogsdata.wasedited('','attrval',newattridx,'edit');
    });
    $('#thepagecontainer').delegate('#editblogattributes .minblogattr','click',function(event){
	    event.stopPropagation();
        var blogattrname = $(this).parent().children('.blogattr');
        var attridx;

        attridx = parseInt($(blogattrname).attr('id').substr(17));
        appsblogsdata[appsblogindex].blogsdata.wasedited('<*delete*>','attrkey',attridx,'edit');

        if($(this).parent().siblings().length){
            $(this).parent().remove();
        }
        else{
            $.each($(this).siblings('input[type="text"]'),function(inputidx,inputelem){
                var placeholder = $(inputelem).attr('name');
                if(placeholder.indexOf('[') !== -1){
                    placeholder = placeholder.substr(0,placeholder.indexOf('['));
                }
                $(inputelem).val(placeholder).removeClass('filled');
            });
        }
    });

    $('#thepagecontainer').delegate('#adminmenu_newentry','click',function(event){
        if(appsblogsdata[appsblogindex].blogsdata.currentnew === false){
            var newblog     = new blogdata();
            appsblogsdata[appsblogindex].blogsdata.addblog(newblog,'new');
            resetblogpage('new');
        }
    });

    $('#thepagecontainer').delegate('.updateblogstatus','click',function(event){
        event.stopPropagation();
        var mode = this.id == 'newupdateblogstatus' ? 'new' : 'edit';
        var status = this.value == 'Publish' ? 1 : 0;

        $(this).addClass('loading');
        registapagemsg(this.value+'ing...',false);

        if(mode == 'new'){
            appsblogsdata[appsblogindex].blogsdata.wasedited(status,'status',false,'new');
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].saveChanges(function(msg){
               if(msg !== false){
                   registapagemsg('saved...',true);

                   appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].id = msg;
                   appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].status = status;
                   addpastentries();
                }
                else{
                    registapagemsg('error saving data...',true);
                    status = status == 1 ? 0 : 1;
                    appsblogsdata[appsblogindex].blogsdata.wasedited(status,'status',false,'new');
                }
                $('#'+mode+'updateblogstatus').removeClass('loading');
                if($('#'+mode+'updateblogstatus').val() == 'Publish'){
                    $('#'+mode+'updateblogstatus').val('Unpublish');
                }
                else{
                    $('#'+mode+'updateblogstatus').val('Publish');
                }
            });
        }
        else{
            appsblogsdata[appsblogindex].blogsdata.wasedited(status,'status',false,'edit');
            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].saveChanges(function(msg){
               if(msg !== false){
                   registapagemsg('saved...',true);
                   updatepastentries();
                   appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentedit].status = status;
                }
                else{
                    registapagemsg('error saving data...',true);
                    status = status == 1 ? 0 : 1;
                    appsblogsdata[appsblogindex].blogsdata.wasedited(status,'status',false,'edit');
                }
                $('#'+mode+'updateblogstatus').removeClass('loading');
                if($('#'+mode+'updateblogstatus').val() == 'Publish'){
                    $('#'+mode+'updateblogstatus').val('Unpublish');
                }
                else{
                    $('#'+mode+'updateblogstatus').val('Publish');
                }
            });
        }
    });


    $('#thepagecontainer').delegate('#editresetdraft','click',function(event){
	    event.stopPropagation();

        if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].uploadingstatus){
            closeeditpage(true);
            return;
        }
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('editblogcontenttext').getContent(),'content',false,'edit');
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('editblogexcerpt').getContent(),'excerpt',false,'edit');

            if(appsblogsdata[appsblogindex].blogsdata.editingnew('edit')){
                var confirmdoneedit = new messagebox();
                confirmdoneedit.title = 'Done Editing';
                confirmdoneedit.content = 'Discard all changes?';
                confirmdoneedit.action = '<span id="savebeforedoneedit">Save</span><span id="confirmdoneedit">Yes</span>';

                confirmdoneedit.display();

                $('#confirmdoneedit').on('click',function(){
                    closeeditpage(false);

                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].resetData();
                    confirmdoneedit.close();
                    resetblogpage('edit');
                });

                $('#savebeforedoneedit').on('click',function(){
                    confirmdoneedit.close();
                    registapagemsg('saving...',false);
                    closeeditpage(true);

                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].saveChanges(function(response){
                        $('#editresetdraft').removeClass('loading');
                        if(response !== false){
                            registapagemsg('changes was successfully saved',true);
                            resetblogpage('edit');

                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentedit].copy(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit]);
                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].resetData();
                        }
                        else{
                            resetblogpage('edit');
                            registapagemsg('failed saving data',true);
                            closeeditpage(true);
                        }
                    });

                });
            }
            else{
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].resetData();
                closeeditpage(false);
                resetblogpage('edit');
            }
    });

    $('#thepagecontainer').delegate('#resetdraft','click',function(event){
        event.stopPropagation();

        if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].uploadingstatus){
            resetblogpage('new');
            return;
        }
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('blogcontenttext').getContent(),'content',false,'new');
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('blogexcerpt').getContent(),'excerpt',false,'new');

            if(appsblogsdata[appsblogindex].blogsdata.editingnew('new')){
                var confirmdoneedit = new messagebox();
                confirmdoneedit.title = 'Done Editing';
                confirmdoneedit.content = 'Discard all changes?';
                confirmdoneedit.action = '<span id="savebeforereset">Save</span><span id="confirmreset">Yes</span>';

                confirmdoneedit.display();

                $('#confirmreset').on('click',function(){
                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].resetData();
                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].resetData();

                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].date = currentdatestring();
                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].date = currentdatestring();

                    confirmdoneedit.close();
                    resetblogpage('new');
                });

                $('#savebeforereset').on('click',function(){
                    confirmdoneedit.close();
                    registapagemsg('saving...',false);
                    resetblogpage('new');

                    appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].saveChanges(function(response){
                        if(response !== false){
                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id = parseInt(response);

                            registapagemsg('changes was successfully saved',true);
                            addpastentries();

                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].resetData();
                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.blogs.length] = new blogdata();
                            appsblogsdata[appsblogindex].blogsdata.tempcurrentnew = appsblogsdata[appsblogindex].blogsdata.blogs.length-1;

                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].date = currentdatestring();
                            appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].date = currentdatestring();
                        }
                        else{
                            registapagemsg('failed saving data',true);
                            if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id !== 0){
                                addpastentries();
                            }
                        }
                    });
                });
            }
            else{
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].resetData();
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].resetData();

                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentnew].date = currentdatestring();
                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].date = currentdatestring();
                resetblogpage('new');
            }
    });

    $('#thepagecontainer').delegate('#editsavedraft','click',function(event){
	    event.stopPropagation();
        if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].uploadingstatus){
            return;
        }
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('editblogcontenttext').getContent(),'content',false,'edit');
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('editblogexcerpt').getContent(),'excerpt',false,'edit');

            if(appsblogsdata[appsblogindex].blogsdata.editingnew('edit')){
                registapagemsg('saving...',false);
                $('#editsavedraft').addClass('loading');

                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit].saveChanges(function(response){
                    $('#editsavedraft').removeClass('loading');
                    if(response !== false){
                        updatepastentries();
                        registapagemsg('changes was successfully saved',true);

                        appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.currentedit].copy(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentedit]);
                    }
                    else{
                        registapagemsg('failed saving data',true);
                    }
                });
            }
            else{
                registapagemsg('no changes made',true);
            }
    });

    $('#thepagecontainer').delegate('#savedraft','click',function(event){
	    event.stopPropagation();
        if(appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].uploadingstatus){
            return;
        }
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('blogcontenttext').getContent(),'content',false,'new');
        appsblogsdata[appsblogindex].blogsdata.wasedited(tinymce.get('blogexcerpt').getContent(),'excerpt',false,'new');

            if(appsblogsdata[appsblogindex].blogsdata.editingnew('new')){
                registapagemsg('saving...',false);

                appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].saveChanges(function(response){
                    if(response !== false){
                        appsblogsdata[appsblogindex].blogsdata.blogs[appsblogsdata[appsblogindex].blogsdata.tempcurrentnew].id = parseInt(response);
                        addpastentries();
                        registapagemsg('changes was successfully saved',true);
                    }
                    else{
                        registapagemsg('failed saving data',true);
                    }
                });
            }
            else{
                registapagemsg('no changes made',true);
            }
    });

    function oldblogcatupdate(cid,catname,catdesc){
        $.each($('.blogcategorylist'),function(idx,elem){
            var pref = $(elem).children().eq(0).attr('id').split('_')[0]+'_';
            $(elem).children('#'+pref+cid).find('.catname').html(catname);
        });

        var catrow = $('#editblogcat_'+cid).parent().parent();
        $(catrow).find('.catname').html(catname);
        $(catrow).find('.blogcatlistdescription').html(catdesc);
    }

    function newblogcatupdate(cid,catname,newparent,catdesc,parentisdescendant){
        if(newparent === 0){
            $.each($('.blogcategorylist'),function(idx,elem){
                var childrens = [];
                var padddiff = [];
                var pref = $(elem).children().eq(0).attr('id').split('_')[0]+'_';
                var saidelem = $(elem).children('#'+pref+cid);
                var paddingnum = $(saidelem).find('.subpseudopadding').length;
                if(paddingnum > 0){
                    while(typeof $(saidelem).next().attr('class') !== 'undefined'){
                        if($(saidelem).next().find('.subpseudopadding').length > paddingnum){
                            padddiff[padddiff.length] = $(saidelem).next().find('.subpseudopadding').length-paddingnum;
                            $(saidelem).next().find('.subpseudopadding').remove();
                            childrens[childrens.length] = '<li id="'+$(saidelem).next().attr('id')+'" class="'+$(saidelem).next().attr('class')+'">'+$(saidelem).next().html()+'</li>';
                            $(saidelem).next().remove();
                        }
                        else{
                            break;
                        }
                    }
                }
                $(saidelem).remove();
                $(elem).append('<li id="'+pref+cid+'" class="categoryselectionopt parent_0"><span class="catname">'+catname+'</span></li>');

                var curpadding = 0;
                if(childrens.length){
                    for(var i=0;i<=childrens.length-1;i++){
                        $(elem).append(childrens[i]);
                        var subpseudopadd = '';
                        for(var o=(padddiff[i]+curpadding);o>0;o--){
                            subpseudopadd+='<span class="subpseudopadding"></span>';
                        }
                        $(elem).children().eq($(elem).children().length-1).find('.catname').before(subpseudopadd);
                    }
                }
            });

            var childrens   = [];
            var padddiff    = [];
            var saidelem    = $('#editblogcat_'+cid).parent().parent();
            var paddingnum  = $(saidelem).find('.subpseudopadding').length;

            while(typeof $(saidelem).next().attr('class') !== 'undefined'){
                if($(saidelem).next().find('.subpseudopadding').length > paddingnum){
                    padddiff[padddiff.length] = $(saidelem).next().find('.subpseudopadding').length-paddingnum;
                    $(saidelem).next().find('.subpseudopadding').remove();
                    childrens[childrens.length] = '<div class="row">'+$(saidelem).next().html()+'</div>';
                    $(saidelem).next().remove();
                }
                else{
                    break;
                }
            }

            $(saidelem).remove();

            $('#blogcatman').append('<div class="row"><div class="blogcatlistid">'+cid+'</div><div class="blogcatlistname"><span class="catname">'+catname+'</span></div><div class="blogcatlistparent hidden">0</div><div class="blogcatlistdescription hidden"></div><div class="blogcatlistaction"><span class="editblogcat actionsspan" id="editblogcat_'+cid+'">edit</span><span class="deleteblogcat actionsspan redfont" id="deleteblogcat_'+cid+'">delete</span></div></div>');

            if(childrens.length){
                var curpadding = 0;
                for(var i=0;i<=childrens.length-1;i++){
                    $('#blogcatman').append(childrens[i]);
                    var subpseudopadd = '';
                    for(var o=(padddiff[i]+curpadding);o>0;o--){
                        subpseudopadd+='<span class="subpseudopadding"></span>';
                    }
                    $('#blogcatman').children().eq($('#blogcatman').children().length-1).find('.catname').before(subpseudopadd);
                }
            }
        }
        else{
            var childrens   = [];
            var padddiff    = [];
            var saidelem    = $('#editblogcat_'+cid).parent().parent();
            var paddingnum  = $(saidelem).find('.subpseudopadding').length;

            if(parentisdescendant != 'false'){
                if(paddingnum == 0){
                    cidparent = 0;
                }
                else{
                    var cidparent = $('#editblogcat_'+cid).parent().parent().prev();
                    if($(cidparent).attr('class').split(' ')[1] == 'head'){
                        cidparent = 0;
                    }
                    else{
                        while($(cidparent).find('.subpseudopadding').length >= paddingnum){
                            cidparent = $(cidparent).prev();
                        }
                        cidparent = parseInt($(cidparent).find('.blogcatlistid').html());
                    }
                }
                newblogcatupdate(newparent,$('#editblogcat_'+newparent).parent().parent().find('.catname').html(),cidparent,$('#editblogcat_'+newparent).parent().parent().find('.blogcatlistdescription').html(),'false')
            }

            while(typeof $(saidelem).next().attr('class') !== 'undefined'){
                if($(saidelem).next().find('.subpseudopadding').length > paddingnum){
                    if($(saidelem).next().find('blogcatlistid').html() == newparent)
                        continue;

                    padddiff[padddiff.length] = $(saidelem).next().find('.subpseudopadding').length-paddingnum;
                    $(saidelem).next().find('.subpseudopadding').remove();
                    childrens[childrens.length] = '<div class="row">'+$(saidelem).next().html()+'</div>';
                    $(saidelem).next().remove();
                }
                else{
                    break;
                }
            }

            $(saidelem).remove();

            var curpadding = $('#editblogcat_'+newparent).parent().parent().find('.subpseudopadding').length+1;

            var subpseudopadd = '';
            for(var o=curpadding;o>0;o--){
                subpseudopadd+='<span class="subpseudopadding"></span>';
            }
            var newelemhtml = '<div class="row"><div class="blogcatlistid">'+cid+'</div><div class="blogcatlistname">'+subpseudopadd+'<span class="catname">'+catname+'</span></div><div class="blogcatlistparent hidden">'+newparent+'</div><div class="blogcatlistdescription hidden">'+catdesc+'</div><div class="blogcatlistaction"><span class="editblogcat actionsspan" id="editblogcat_'+cid+'">edit</span><span class="deleteblogcat actionsspan redfont" id="deleteblogcat_'+cid+'">delete</span></div></div>';

            saidelem = $('#editblogcat_'+newparent).parent().parent();
            $(saidelem).after(newelemhtml);

            if(childrens.length){
                for(var i=0;i<=childrens.length-1;i++){
                    saidelem = $(saidelem).next();
                    $(saidelem).after(childrens[i]);
                    var subpseudopadd = '';

                    for(var o=(padddiff[i]+curpadding);o>0;o--){
                        subpseudopadd+='<span class="subpseudopadding"></span>';
                    }
                    $(saidelem).next().find('.catname').before(subpseudopadd);
                }
            }


            $.each($('.blogcategorylist'),function(idx,elem){
                var childrens = [];
                var padddiff = [];
                var pref = $(elem).children().eq(0).attr('id').split('_')[0]+'_';
                var saidelem = $(elem).children('#'+pref+cid);
                var paddingnum = $(saidelem).find('.subpseudopadding').length;

                while(typeof $(saidelem).next().attr('class') !== 'undefined'){
                    if($(saidelem).next().find('.subpseudopadding').length > paddingnum){
                        if($(saidelem).next().attr('id').split('_')[1] == newparent)
                            continue;

                        padddiff[padddiff.length] = $(saidelem).next().find('.subpseudopadding').length-paddingnum;
                        $(saidelem).next().find('.subpseudopadding').remove();
                        childrens[childrens.length] = '<li id="'+$(saidelem).next().attr('id')+'" class="'+$(saidelem).next().attr('class')+'">'+$(saidelem).next().html()+'</li>';
                        $(saidelem).next().remove();
                    }
                    else{
                        break;
                    }
                }

                $(saidelem).remove();

                var curpadding = $(elem).children('#'+pref+newparent).find('.subpseudopadding').length+1;

                var subpseudopadd = '';
                for(var o=curpadding;o>0;o--){
                    subpseudopadd+='<span class="subpseudopadding"></span>';
                }

                var newelemhtml = '<li id="'+pref+cid+'" class="categoryselectionopt parent_'+newparent+'">'+subpseudopadd+'<span class="catname">'+catname+'</span></li>';
                $(elem).children('#'+pref+newparent).after(newelemhtml);

                saidelem = $(elem).children('#'+pref+newparent).next();

                if(childrens.length){
                    for(var i=0;i<=childrens.length-1;i++){
                        $(saidelem).after(childrens[i]);
                        var subpseudopadd = '';
                        for(var o=(padddiff[i]+curpadding);o>0;o--){
                            subpseudopadd+='<span class="subpseudopadding"></span>';
                        }
                        $(saidelem).next().find('.catname').before(subpseudopadd);
                        saidelem = $(saidelem).next();
                    }
                }
            });
        }
    }
    $('#thepagecontainer').delegate('#addnewcategorysubmit','click',function(event){
        event.stopPropagation();

        $('#addblogcatmsg').html('').removeClass('active');
        var pcat = $('#newblogcategoryparent').attr('name') == $('#newblogcategoryparent').val() ? 0 : ($('#parentcatforadding').children('.selected').length == 1 ? parseInt($('#parentcatforadding').children('.selected').attr('id').substr(25)) : $('#newblogcategoryparent').val());
        var catname = $('#newblogcategoryname').val() == $('#newblogcategoryname').attr('name') ? false : $('#newblogcategoryname').val();
        var catdesc = $('#newblogcategorydescription').val() == $('#newblogcategorydescription').attr('name') ? '' : $('#newblogcategorydescription').val();
        var cid = $('#submitcategoryid').val();

        if(catname === false){
            $('#addblogcatmsg').html('please complete the required form').addClass('active');
            return;
        }

        $('#addblogcatmsg').html('saving...').addClass('active');

        var newparent = typeof(pcat) === 'string' ? true : false;

        $.ajax({
           url:'./',
           type:'POST',
           data:{app:appname,p:'blog',a:'updatecategory',d:{cid:cid,name:catname,description:catdesc,parent:pcat,newparent:newparent}}
        }).done(function(msg){
           if(msg === false){
               if($('#addcategorycontainer').attr('class').indexOf('active')!==-1){
                    $('#addblogcatmsg').html('failed saving data');
                    setTimeout(function(){
                        $('#addblogcatmsg').animate({'opacity':0},'slow',function(){
                            $('#addblogcatmsg').removeClass('active');
                            $('#addblogcatmsg').css('opacity','1');
                        });
                    },5000);
               }
               else{
                   registapagemsg('failed saving data',true);
               }
           }
            else{
                msg = msg+'';
                msg = msg.split(',');
                if(msg[1] == -1){
                    if($('#addcategorycontainer').attr('class').indexOf('active')!==-1){
                        $('#addblogcatmsg').html('no changes made');
                    }
                    else{
                       registapagemsg('no changes made',true);
                    }
                    return;
                }
                var newelem = false;
                if(cid == 0){
                    newelem = true;
                    cid = msg[1];
                }
                if(newparent){
                    newparent = msg[0];

					if(!newelem){
					    newelem = true;
					}
                }
                else{
                    newparent = pcat;
                    if(!newelem){
                        var cparent = parseInt($('#editblogcat_'+cid).parent().parent().find('.blogcatlistparent').html());
                        if(cparent != newparent){
                            newelem = true;
                        }
                    }
                }

                if(cid == newparent){
                    newparent = 0;
                }

                if(newelem){
                    newblogcatupdate(cid,catname,newparent,catdesc,msg[2]);
                }
                else{
                    oldblogcatupdate(cid,catname,catdesc);
                }

               if($('#addcategorycontainer').attr('class').indexOf('active')!==-1){
                    $('#addblogcatmsg').html('category saved');
                    setTimeout(function(){
                        $('#addblogcatmsg').animate({'opacity':0},'slow',function(){
                            $('#addblogcatmsg').removeClass('active');
                            $('#addblogcatmsg').css('opacity','1');
                        });
                    },5000);
               }
               else{
                   registapagemsg('category saved',true);
               }
            }
        });
    });

    $('#thepagecontainer').delegate('#blogcatman .editblogcat','click',function(event){
        event.stopPropagation();
        var catid = parseInt($(this).parent().siblings('.blogcatlistid').html());
        var catname = $(this).parent().siblings('.blogcatlistname').children('.catname').html();
        var catparent = parseInt($(this).parent().siblings('.blogcatlistparent').html());
        var catdesc = $(this).parent().siblings('.blogcatlistdescription').html();

        $('#submitcategoryid').val(catid);
        $('#newblogcategoryname').val(catname).addClass('filled');
        $('#newblogcategoryparent').val($('#selectparentcatforadding_'+catparent).children('.catname').html()).addClass('filled');
        $('#parentcatforadding li').removeClass('selected');
        $('#selectparentcatforadding_'+catparent).addClass('selected');
        $('#newblogcategorydescription').val(catdesc).addClass('filled');


        $('#addcategorycontainer').addClass('active').children('h3').html('Edit Blog Category');
        blurcontent();
    });

    function filterattropt(elem,typed){
        typed = typed.toLowerCase();
        var selected = false;
        $(elem).children().removeClass('selected');
        $.each($(elem).children(),function(elemidx,elemval){
            if($(elemval).html().toLowerCase().indexOf(typed) === -1){
                $(elemval).addClass('hidden');
            }
            else{
                if(!selected){
                    $(elemval).removeClass('hidden').addClass('selected');
                    selected = true;
                }
                else{
                    $(elemval).removeClass('hidden');
                }
            }
        });
    }

     $('#thepagecontainer').delegate('.blogattr','click focus',function(event){
         event.stopPropagation();
         var attropt = $(this).next();
         $(attropt).html($('#distinctattributekey').html());

         var thisval = $(this).val();
         if(thisval !== ''){
             if(thisval == $(this).attr('name').substr(0,$(this).attr('name').indexOf('['))){
                 $(this).val('');
                 $(attropt).children().removeClass('hidden');
             }
             else{
                 filterattropt(attropt,thisval);
             }
         }
         else{
             $(attropt).children().removeClass('hidden');
             $(attropt).children().eq(0).addClass('selected');
         }
         $('.blogattrkeyoptprovider').removeClass('active');
         $(attropt).addClass('active');
     });
     var clickedonattrname = false;
    $('#thepagecontainer').delegate('.blogattr','blur',function(event){
         event.stopPropagation();
         var blurthis = this;
         setTimeout(function(){
            if(clickedonattrname === false){
                 var attropt = $(blurthis).next();
                 var thisval = $(blurthis).val();
                 if(thisval == ''){
                     $(blurthis).val($(blurthis).attr('name').substr(0,$(blurthis).attr('name').indexOf('[')));
                 }
                 else{
                     if($('#distinctattributekey').html().indexOf(thisval) === -1){
                         $('#distinctattributekey').append('<li class="attributekeyopt" id="blogattr_'+$('#distinctattributekey').children().length+'">'+thisval+'</li>');
                     }
                     $(blurthis).addClass('filled');
                 }
                 $(attropt).removeClass('active');
             }
         },200);
     });
     $('#thepagecontainer').delegate('.blogattr','keyup',function(key){
         var attropt = $(this).next();
         var selected = $(attropt).children('.selected');
         selected = selected.length ? selected[0] : false;
         var curselected = selected;
         switch(key.which){
            case 13:
                if(selected === false){
                    return;
                }
                $(this).val($(selected).html());
                $(attropt).removeClass('active');
            break;
            case 40:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).next();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('attributekeyopt') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected[0].scrollIntoView();
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(attropt).children().eq(0).addClass('selected');
                }
            break;
            case 38:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).prev();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('attributekeyopt') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected[0].scrollIntoView();
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(attropt).children().eq($(attropt).children().length-1).addClass('selected');
                }
            break;
            default:
                $(attropt).addClass('active');
                filterattropt(attropt,$(this).val());
            break;
         }
     });
     $('#thepagecontainer').delegate('.attributekeyopt','click',function(event){
         clickedonattrname = true;
         event.stopPropagation();
         var inputbox = $(this).parent().prev();

         $(inputbox).val($(this).html());
         $(this).parent().removeClass('active');
         var content = $(this).html();

         var mode = $('#pastentries').attr('class').indexOf('active') !== -1 ? 'edit' : ($('#newentry').attr('class').indexOf('active') !== -1 ? 'new' : false);
         index = $(inputbox).attr('id').substr($(inputbox).attr('id').indexOf('_')+1);

         appsblogsdata[appsblogindex].blogsdata.wasedited(content,'attrkey',index,mode);

         clickedonattrname = false;
     });

    $('#thepagecontainer').delegate('#addcategory','click',function(event){
        event.stopPropagation();
        $.each($('#addcategorycontainer').find('input[type="text"],textarea'),function(inputidx,inputelem){
            var placeholder = $(inputelem).attr('name');
            if(placeholder.indexOf('[') !== -1){
                placeholder = placeholder.substr(placeholder.indexOf('['));
            }
            $(inputelem).val(placeholder).removeClass('filled');
        });

        $('#submitcategoryid').val(0);

        $('#addcategorycontainer').addClass('active').children('h3').html('Add Blog Category');
        blurcontent();
    });

    $('#thepagecontainer').delegate('#blogcatman .deleteblogcat','click',function(event){
        event.stopPropagation();
        var categoryid = parseInt($(this).parent().siblings('.blogcatlistid').html());
        var categoryname = $(this).parent().siblings('.blogcatlistname').children('.catname').html();

        var confirmdeletecat = new messagebox();
        confirmdeletecat.title = 'Confirm Blog Category Deletion';
        confirmdeletecat.content = 'Delete Category "<b>'+categoryname+'</b>"?';
        confirmdeletecat.action = '<span id="confirmdeleteblogcat">Delete</span>';

        confirmdeletecat.display();

        $('#confirmdeleteblogcat').on('click',function(event){
            confirmdeletecat.close();
            registapagemsg('deleting...',false);
            event.stopPropagation();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'blog',a:'deletecategory',d:{categoryid:categoryid}}
            }).done(function(msg){
                msg = $.parseJSON(msg);
                $('#deleteblogcat_'+categoryid).parent().parent().remove();
                registapagemsg('category deleted',true);
            });
        });
    });


    $('#thepagecontainer').delegate('#searchpastentrykeywords','keyup',function(key){
        if(key.which !==13)
            return;

        submitblogsearchfilter();
    });

    $('#thepagecontainer').delegate('.blogcategoryselect','keyup',function(key){
        event.stopPropagation();
        var optprovider;
        if($(this).attr('id') == 'newblogcategoryparent'){
            optprovider = $(this).parent().next().children('.blogcategorylist');
        }
        else
            optprovider = $(this).siblings('.blogcategorylist');

         var selected = $(optprovider).children('.selected');
         selected = selected.length ? selected[0] : false;
         var curselected = selected;
         switch(key.which){
            case 13:
                if(selected === false){
                    return;
                }
                $(this).val($(selected).children('.catname').html()).addClass('filled');

                if($(this).attr('id') === 'searchincategory'){
                    if($(optprovider).attr('class').indexOf('active') === -1){
                        submitblogsearchfilter();
                    }
                    $(optprovider).removeClass('active');
                    return;
                }
                $(optprovider).removeClass('active');

                var catelem = selected;
                var content = parseInt($(catelem).attr('id').substr($(catelem).attr('id').indexOf('_')+1));
                var mode = $('#pastentries').attr('class').indexOf('active') !== -1 ? 'edit' : ($('#newentry').attr('class').indexOf('active') !== -1 ? 'new' : false);

                if(mode !== false)
                    appsblogsdata[appsblogindex].blogsdata.wasedited(content,'category',false,mode);
            break;
            case 40:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).next();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('categoryselectionopt') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(optprovider).children().eq(0).addClass('selected');
                }
            break;
            case 38:
                if(selected !== false){
                    while(selected !== false){
                        selected = $(selected).prev();
                        if(typeof $(selected).attr('class') !== 'undefined' ){
                            if($(selected).attr('class').indexOf('categoryselectionopt') !== -1){
                                if($(selected).attr('class').indexOf('hidden') === -1){
                                    $(curselected).removeClass('selected');
                                    $(selected).addClass('selected');
                                    selected = false;
                                }
                            }
                            else{
                                selected = false;
                            }
                        }
                        else{
                            selected = false;
                        }
                    }
                }
                else{
                    $(optprovider).children().eq($(optprovider).children().length-1).addClass('selected');
                }
            break;
            default:
                $(optprovider).addClass('active');
                filterattropt(optprovider,$(this).val());
            break;
         }

    });

    $('#thepagecontainer').delegate('.blogcategoryselect','click focus',function(event){
        event.stopPropagation();
        var optprovider;
        if($(this).attr('id') == 'newblogcategoryparent'){
            optprovider = $(this).parent().next().children('.blogcategorylist');
        }
        else
            optprovider = $(this).siblings('.blogcategorylist');

         var thisval = $(this).val();
        if(thisval !== ''){
             if(thisval == $(this).attr('name')){
                 $(this).val('');
                 $(optprovider).children().removeClass('hidden');
             }
             else{
                 filterattropt(optprovider,thisval);
             }
         }
         else{
             $(optprovider).children().removeClass('hidden');
             $(optprovider).children().eq(0).addClass('selected');
         }
         $(optprovider).addClass('active');
    });
    $('#thepagecontainer').delegate('.blogcategoryselect','blur',function(event){
        event.stopPropagation();
        var blurthis = this;
        setTimeout(function(){
            if(clickedoncategoryopt === false){
                if($(blurthis).val() == ''){
                    $(blurthis).val($(blurthis).attr('name'));
                    $(blurthis).removeClass('filled');
                }
                else{
                    $(blurthis).addClass('filled');
                }

                if($(blurthis).attr('id') == 'newblogcategoryparent'){
                    $(blurthis).parent().next().children('.blogcategorylist').removeClass('active');
                }
                else
                    $(blurthis).siblings('.blogcategorylist').removeClass('active');
            }
        },200);
    });

    var clickedoncategoryopt = false;
    $('#thepagecontainer').delegate('.blogcategorylist li','click',function(event){
        clickedoncategoryopt = true;
        event.stopPropagation();
        $(this).parent().children().removeClass('selected');
        $(this).addClass('selected');
        $(this).parent().removeClass('active');


        var inputbox = $(this).parent().prev();
        if(typeof $(inputbox).attr('class') === 'undefined'){
            inputbox = $(this).parent().parent().prev().children();
        }
        $(inputbox).val($(this).children('.catname')[0].innerText);

        $(inputbox).addClass('filled');

        if($(inputbox).attr('id') === 'searchincategory'){
            clickedoncategoryopt = false;
            return;
        }
        var catelem = this;
        var content = parseInt($(catelem).attr('id').substr($(catelem).attr('id').indexOf('_')+1));
        var mode = $('#pastentries').attr('class').indexOf('active') !== -1 ? 'edit' : ($('#newentry').attr('class').indexOf('active') !== -1 ? 'new' : false);

        if(mode !== false)
            appsblogsdata[appsblogindex].blogsdata.wasedited(content,'category',false,mode);

        clickedoncategoryopt = false;
    });

  $('#thepagecontainer').delegate('#pastentries .deleteblog','click',function(event){
        event.stopPropagation();
        var deletebtnelem =this;
        var blogid = parseInt($(this).attr('id').substr(11));
        var blogtitle = $(this).parent().parent().children('.blogtitle').html();
        var blogcategory = parseInt($(this).parent().parent().children('.blogcategory').attr('class').substr(26));
        var blogstatus = $(this).parent().parent().children('.blogstatus').html();

        var confirmdelete = new messagebox();
        confirmdelete.title = 'Confirm Blog Entry Deletion';
        confirmdelete.content = 'Delete blog entry "'+ blogtitle +'" ?';
        confirmdelete.action = '<span id="confirmdeleteblog">Confirm</span>';

        confirmdelete.display();

        $('#confirmdeleteblog').on('click',function(event){
            event.stopPropagation();
            confirmdelete.close();
            $.ajax({
                url:"./",
                data:{app:appname,p:'blog',a:'deleteblog',d:{blogid:blogid}},
                type:'POST'
            }).done(function(msg){
                msg = $.parseJSON(msg);
                if(msg.deleted){
                    registapagemsg('Blog entry "'+ blogtitle +'" was successfully deleted',true);

                    $(deletebtnelem).parent().parent().remove();
                    var blogtodelete = new blogdata();
                    blogtodelete.rowdata(blogid,blogtitle,blogcategory,blogstatus);
                    deleteblog(blogtodelete);
                }
            });
        });
    });
}


/*users lists pages*/
var usersnavproto = function(){
     this.userlist = [];
     this.currentlistidx = false;
     this.newlist();
};
usersnavproto.prototype.reqpagecb = function(msg){
    this.userlist[this.currentlistidx].reqpagecb(msg);
};
usersnavproto.prototype.newlist = function(){
    this.currentlistidx = this.userlist.length;
    this.userlist[this.currentlistidx] = new userslistproto(this.getuserfilter(),defaultfilteruserpagenum,this.currentlistidx);
};
usersnavproto.prototype.newresults = function(){
    this.userlist[this.currentlistidx].adddisplayedtolist();
};
usersnavproto.prototype.saveediteddatacallback = function(uobj,msg,mode){
    if(msg.result){
        uobj.id = msg.result;
        uobj.edited = false;
        uobj.editeddata = [];   
        
        var adjustedpage = false;
        for(var i=0;i<this.userlist.length;i++){
            adjustedpage = this.userlist[i].usermatchfilter(uobj,mode);
            if(adjustedpage && i==this.currentlistidx){
                this.userlist[i].jumppage();
            }
        }
    }
    switch(mode){
        case 0:
            if($('#adduser').attr('class').indexOf('active') !== -1){
                modalsboxmsg($('#adduser'),msg.msg,true,false);
            }
            else{
                registapagemsg(msg.msg,true);
            }
        break;
        case 1:
            if($('#edituserform').attr('class').indexOf('active') !== -1){
                modalsboxmsg($('#edituserform'),msg.msg,true,false);
            }
            else{
                registapagemsg(msg.msg,true);
            }
        break;
    }
};
usersnavproto.prototype.submituser = function(postdata,mode){
    this.userlist[this.currentlistidx].submituser(postdata,mode);
};
usersnavproto.prototype.nextpage = function(){
    this.userlist[this.currentlistidx].nextpage();
};
usersnavproto.prototype.usersgotopage = function(page){
    this.userlist[this.currentlistidx].usersgotopage(page);
};
usersnavproto.prototype.filteruser = function(){
    $('#addfilteruser').removeClass('active');
    blurmodal();
    var submittedfilter = this.getuserfilter();
    for(var i=0;i<this.userlist.length;i++){
        if(this.userlist[i].filtermatch(submittedfilter)){
            this.currentlistidx = i;
            this.userlist[this.currentlistidx].jumppage();
            return;
        }
    }
    this.newlist();
    this.userlist[this.currentlistidx].jumppage();
};
usersnavproto.prototype.prevpage = function(){
    this.userlist[this.currentlistidx].prevpage();
};
usersnavproto.prototype.jumppage = function(){
    this.userlist[this.currentlistidx].jumppage();
};
usersnavproto.prototype.getuser = function(userid){
    this.userlist[this.currentlistidx].getuser(userid);
};
usersnavproto.prototype.editform = function(){
    this.userlist[this.currentlistidx].editform();
};
usersnavproto.prototype.getuserfilter = function(){
    var filters = [];
    $.each($('#addfilteruser').find('.metakey'),function(idx,elem){
        if($(elem).val() != '' && $(elem).val() !== 'meta key' && $(elem).siblings('.metavalue').val() != '' && $(elem).siblings('.metavalue').val() != 'meta value'){
            filters[filters.length] = [];
            filters[filters.length-1].key = $(elem).val();
            filters[filters.length-1].val = $(elem).next().val();
        }
    });
    return filters;
};

/*list of current filtered users*/
var userslistproto = function(filters,pagenum,objidx){
    this.users = [];
    this.endofpage = Math.max(pagenum,1);
    this.cpage = 1;
    this.userperpage = 3;
    this.filters = filters;
    this.objidx = objidx;
    this.tempcurrentedit = false;
    
    this.adjustnav();
};
userslistproto.prototype.usermatchfilter =  function(uobj,mode){
    var filterpass = true;
    if(this.filters.length){
        for(var i=0;i<this.filters.length;i++){
            switch(this.filters[i].key){
                case 'ID':
                    if(this.filters[i].val != uobj.id){
                        filterpass = false;
                    }
                break;
                case 'username':
                    if(this.filters[i].val != uobj.username){
                        filterpass = false;
                    }
                break;
                case 'email':
                    if(this.filters[i].val != uobj.email){
                        filterpass = false;
                    }
                break;
                case 'registered date from':
                    if(this.filters[i].val > uobj.registered){
                        filterpass = false;
                    }
                break;
                case 'registered date end':
                    if(this.filters[i].val < uobj.registered){
                        filterpass = false;
                    }
                break;
                default:
                    if(!uobj.metadata.length){
                        filterpass = false;
                    }
                    else{
                        var match = false;
                        for(var o=0;o<uobj.metadata.length;o++){
                            if(uobj.metadata[o].key == this.filters[i].key && uobj.metadata[o].value == this.filters[i].val){
                                match=true;
                                break;
                            }
                        }
                        if(!match){
                            filterpass = match;
                        }
                    }
                break;
            }
            if(!filterpass){
                break;
            }
        }
    }
    
    if(filterpass){
        if(mode ==0){
            this.users.unshift(uobj);
            this.endofpage = ((this.endofpage * this.userperpage)+1)/this.userperpage;
            
            return this.adjustpage(0,false);
        }
        else{
            var exi = false;
            var cest = false;
            var tempcest = false;
            var cestidx = false;
            for(var i=0;i<this.users.length;i++){
                if(this.users[i].id == uobj.id){
                    exi = i;
                    break;
                }
                else{
                    if(cestidx === false){
                        cestidx = i;
                        cest = Math.abs(this.users[i].id-uobj.id);
                    }
                    else{
                        tempcest = Math.min(Math.abs(this.users[i].id-uobj.id),cest);
                        if(cest != tempcest){
                            cest = tempcest;
                            cestidx = i;
                        }
                    }
                }
            }
            if(exi===false){
                this.endofpage = ((this.endofpage * this.userperpage)+1)/this.userperpage;
                if(this.users[cestidx].id > uobj.id){
                    cestidx+=1;
                }
                this.users.splice(cestidx,0,uobj);
                
                return this.adjustpage(cestidx,true);
            }
            else{
                this.users[i] = uobj;
                return this.adjustpage(cestidx,true);
            }
        }
    }
    else{
        if(mode){
            var exi = false;
            for(var i=0;i<this.users.length;i++){
                if(this.users[i].id == uobj.id){
                    exi = i;
                    break;
                }
            }
            if(exi!==false){
                this.endofpage = ((this.endofpage * this.userperpage)-1)/this.userperpage;
                this.users.splice(exi,1);
                
                return this.adjustpage(exi,true);
            }
        }
    }
    return false;
};
userslistproto.prototype.adjustpage = function(w,zerow){
    var compage = [];
    while(w<this.users.length){
        if(w%this.userperpage==0){
            if(!zerow){
                if(w!=0){
                    compage[compage.length] = w;
                }
            }
            else{
                compage[compage.length] = w;   
            }
        }
        else{
            if(this.users[w]==false){
                if(compage.length && this.users[compage[compage.length-1]] !== false){
                    this.users[compage[compage.length-1]] = false;
                }
            }
        }
        w++;
    }
    return true;
};
userslistproto.prototype.filtermatch = function(filtercomp){
    if(this.filters.length != filtercomp.length){
        return false;
    }
    for(var i=0;i<this.filters.length;i++){
        var matching = false;
        for(var ww=0;ww<filtercomp.length;ww++){
            if(filtercomp[ww].key == this.filters[i].key && filtercomp[ww].val == this.filters[ww].val){
                matching = true;
                break;
            }
        }
        if(!matching){
            return false;
        }
    }
    return true;
    
};
userslistproto.prototype.reqpagecb = function(msg){
    var users = msg.users;
    if(typeof msg.pagenum !== 'undefined'){
        this.endofpage = msg.pagenum;
    }
        
    var sidx = (this.cpage-1)*this.userperpage;
    if(this.users.length<sidx){
        for(var i=this.users.length;i<sidx;i++){
            this.users[i] = false;
        }
    }
    for(var i=0;i<users.length;i++){
        this.users[this.users.length] = new userobjectproto(users[i].id,users[i].username,users[i].email,false,false,users[i].registered);
    }
    this.jumppage();
};
userslistproto.prototype.adddisplayedtolist = function(){
    var users = $('#userlistcontainer').children();
    users.splice(0,1);
    for(var i=0;i<users.length;i++){
        this.users[this.users.length] = new userobjectproto($(users[i]).children('.userid').html(),$(users[i]).children('.username').html(),$(users[i]).children('.email').html(),false,false,$(users[i]).children('.registered').html());
    }
};
userslistproto.prototype.adjustnav = function(){
    if(this.cpage == Math.ceil(this.endofpage)){
        $('#nextuserpage').addClass('disabled');
        if(this.cpage == 1){
            $('#prevuserpage').addClass('disabled');
        }
        else{
            $('#prevuserpage').removeClass('disabled');
        }
    }
    else{
        if(this.cpage==1){
            $('#prevuserpage').addClass('disabled');
        }
        else{
            $('#prevuserpage').removeClass('disabled');
        }
            if(Math.ceil(this.endofpage) > this.cpage){
                $('#nextuserpage').removeClass('disabled');
            }
    }
    $('#usersgotopage').val(this.cpage);
};
userslistproto.prototype.nextpage = function(){
    this.cpage+=1;  
    this.jumppage();
};
userslistproto.prototype.usersgotopage = function(page){
    this.cpage=page;  
    this.jumppage();
};
userslistproto.prototype.prevpage = function(){
    this.cpage-=1;  
    this.jumppage();
};
userslistproto.prototype.jumppage = function(){
    if(this.users.length<((this.userperpage*(this.cpage-1))+1) || this.users[(this.cpage-1) * this.userperpage] == false){
        this.reqpage();
        return;
    }
    $('#userlistcontainer').html('<div class="useritem head row"><span class="userid">ID</span><span class="username">Username</span><span class="email">Email</span><span class="registered">Registered</span><span class="appelemhead actions">Actions</span></div>');
    for(var i=(this.userperpage*(this.cpage-1));i<(this.userperpage*this.cpage);i++){
        if(typeof this.users[i] === 'undefined'){
            break;
        }
        $('#userlistcontainer').append('<div class="useritem row"><span class="userid">'+this.users[i].id+'</span><span class="username">'+this.users[i].username+'</span><span class="email">'+this.users[i].email+'</span><span class="registered">'+this.users[i].registered+'</span><span class="actions"><span class="actionsspan deleteuser"><a href="javascript:void(0);">delete</a></span><span class="actionsspan edituser"><a href="javascript:void(0);">edit</a></span></span></div>');
    }
    this.adjustnav();
};
userslistproto.prototype.filterstopost = function(){
    var filterstr = '';
    for(var i=0;i<this.filters.length;i++){
        filterstr+=this.filters[i].key+'<fe>'+this.filters[i].val+'<f>';
    }
    return filterstr;
};
userslistproto.prototype.reqpage = function(){
    var reqpagenum = this.cpage-1;
    var pagecondi = this.filterstopost();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'users',a:'reqpage',d:{page:reqpagenum,condi:pagecondi}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(msg.result){
            usersdata[appsusersindex].usersnav.reqpagecb(msg);
        }
    });
};
userslistproto.prototype.getuser = function(userid){
    for(var o=0;o<this.users.length;o++){
        if(this.users[o].id == userid){
            this.tempcurrentedit = this.users[o];
            break;
        }
    }
};
userslistproto.prototype.editform = function(){
    if(this.tempcurrentedit.role === false){
        var thislist = this;
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'users',a:'usereditform',d:{appid:activeapp,userid:this.tempcurrentedit.id}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            thislist.tempcurrentedit.role = msg.role;
            thislist.tempcurrentedit.addmetadata(msg.meta,false);

            if(msg.role != false)
            thislist.editform();
        });
        return;
    }

    $('#edituserform').find('input,select').removeClass('filled');
    $('#edituserform').find('#editusername').addClass('filled').val(this.tempcurrentedit.username);
    $('#edituserform').find('#editemail').addClass('filled').val(this.tempcurrentedit.email);
    $('#edituserform').find('.userrole').addClass('filled').val(this.tempcurrentedit.role);

    var metadatainput = $('#edituserform').find('.metadata');
    var metadatarow = '<div class="row bottomless inputrow metadata">'+$(metadatainput[0]).html()+'</div>';
    if(metadatainput.length <this.tempcurrentedit.metadata.length){
        for(var i=metadatainput.length;i<this.tempcurrentedit.metadata.length;i++){
            $(metadatainput[i-1]).after(metadatarow);
            metadatainput[i] = $(metadatainput[i-1]).next();
        }
    }
    var ix;
    for(ix=0;ix<this.tempcurrentedit.metadata.length;ix++){
        $(metadatainput[ix]).children('.metakey').addClass('filled').val(this.tempcurrentedit.metadata[ix].key);
        $(metadatainput[ix]).children('.metavalue').addClass('filled').val(this.tempcurrentedit.metadata[ix].value);
    }

    for(ix=ix;ix<metadatainput.length;ix++){
        $(metadatainput[ix]).remove();
        metadatainput.splice(ix,1);
        ix--;
    }
    if(!metadatainput.length){
        $('#edituserform').find('.submitrow').before(metadatarow);
    }
    $('#edituserform').removeClass('loading');
};
userslistproto.prototype.submituser = function(postdata,mode){
    var thislist = this;
    var ajaxpostdata = '';
    var newuserdata = [];
    var metaidx = 0;
    $.each(postdata,function(ix,iv){
        iv.name = iv.name == 'userole' ? 'role' : iv.name;
        ajaxpostdata += iv.name+'<*edelem*>'+iv.value+'<*edelemsep*>';
        newuserdata[iv.name] = iv.value;
    });

    var newentry;

    switch(mode){
        case 0:/*add*/
            newentry = new userobjectproto(0,newuserdata.username,newuserdata.email,newuserdata.password,newuserdata.role,currentdatestring());
            newentry.addmetadata(postdata,true);

            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'users',a:'submitnewuser',d:{submitdata:ajaxpostdata}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                usersdata[appsusersindex].usersnav.saveediteddatacallback(newentry,msg,0);
            });

        break;
        default:/*edit*/
            newentry = new userobjectproto(0,newuserdata.username,newuserdata.email,newuserdata.password,newuserdata.role,false);
            newentry.addmetadata(postdata,true);

            this.tempcurrentedit.editingnew(newentry);
            if(this.tempcurrentedit.edited){
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'users',a:'submitedituser',d:{submitdata:this.tempcurrentedit.editeddatapost()}}
                }).done(function(msg){
                    msg = JSON.parse(msg);
                    usersdata[appsusersindex].usersnav.saveediteddatacallback(thislist.tempcurrentedit,msg,1);
                });
            }
            else{
                modalsboxmsg($('#edituserform'),'no changes made',true,false);
            }
        break;
    }
};

/*user object*/
var userobjectproto = function(id,username,email,password,role,registered){
    this.id         = parseInt(id);
    this.username   = username;
    this.email      = email;
    this.password   = password;
    this.registered = registered;
    this.role       = role;
    this.metadata   = [];
    this.editeddata = [];
    this.edited     = false;
};
userobjectproto.prototype.addmetadata = function(postdata,form){
    var primarydata =  ['username','password','repeat password','role','email'];
    var metadata    = [];

    if(form){
        var metaidx = 0;
        $.each(postdata,function(idx,val){
            if($.inArray(val.name,primarydata) === -1){
                switch(val.name){
                    case 'meta key':
                        metadata[metaidx] = [];
                        metadata[metaidx].key =  val.value;
                    break;
                    case 'meta value':
                        metadata[metaidx].value =  val.value;
                        metaidx++;
                    break;
                }
            }
        });
    }
    else{
        $.each(postdata,function(idx,val){
            if($.inArray(val.name,primarydata) === -1){
                metadata[metadata.length] = [];
                metadata[metadata.length-1].key =  val.metakey;
                metadata[metadata.length-1].value = val.metavalue;
            }
        });
    }

    this.metadata = metadata;
};
userobjectproto.prototype.editingnew = function(newentry){
    if(this.username != newentry.username){
        this.saveedited('username',newentry.username);
    }
    if(newentry.password != 'password' && this.password != newentry.password){
        this.saveedited('password',newentry.password);
    }
    if(this.email != newentry.email){
        this.saveedited('email',newentry.email);
    }
    if(this.role != newentry.role){
        this.saveedited('role',newentry.role);
    }
        var tempometa = this.metadata;
        var existmeta = false;
        for(var i=0;i<newentry.metadata.length;i++){
            existmeta = false;
            for(var ii=0;ii<tempometa.length;ii++){
                if(tempometa[ii].key == newentry.metadata[i].key){
                    if(tempometa[ii].value == newentry.metadata[i].value){
                        existmeta = true;
                    }
                    tempometa.splice(ii,1);
                    if(existmeta){
                        break;
                    }
                }
            }
            if(!existmeta){
                this.edited = true;
                
                this.editeddata[this.editeddata.length] = [];
                this.editeddata[this.editeddata.length-1].name = 'metadataentry';
                this.editeddata[this.editeddata.length-1].value = newentry.metadata[i].key+'<*edelem*>'+newentry.metadata[i].value;
            }
        }
        if(tempometa.length){
            this.edited = true;
            for(var i=0;i<tempometa.length;i++){
                this.editeddata[this.editeddata.length] = [];
                this.editeddata[this.editeddata.length-1].name = 'metadatadel';
                this.editeddata[this.editeddata.length-1].value = tempometa[i].key+'<*edelem*>'+tempometa[i].value;
            }
        }
        this.metadata = newentry.metadata;
};
userobjectproto.prototype.saveedited = function(name,value){
    this[name] = value;
    this.edited = true;

    this.editeddata[this.editeddata.length] = [];
    this.editeddata[this.editeddata.length-1].name = name;
    this.editeddata[this.editeddata.length-1].value = value;
};
userobjectproto.prototype.editeddatapost = function(){
    var postdata = '';
    for(var i=0;i<this.editeddata.length;i++){
        if(this.editeddata[i].name == 'metadata'){
            for(var oo=0;oo<this.editeddata[i].value.length;oo++){
                postdata += 'metadata<*edelem*>'+this.editeddata[i].value[oo].key+'<*edelem*>'+this.editeddata[i].value[oo].value+'<*edelemsep*>';
            }
        }
        else
            postdata += this.editeddata[i].name+'<*edelem*>'+this.editeddata[i].value+'<*edelemsep*>';
    }
    postdata+='userid<*edelem*>'+this.id+'<*edelemsep*>';
    return postdata;
};

var usersdata       = [];
var appsusersindex  = 0;
function userspage(){
    if($.inArray('userspage',pageloaded) !== -1){
        appsusersindex = false;
        for(var i=0;i<usersdata.length;i++){
            if(usersdata[i].appid == activeapp){
                appsusersindex = i;
            }
        }
        if(appsusersindex === false){
            usersdata[usersdata.length] = [];
            
            appsusersindex = usersdata.length-1;
            usersdata[appsusersindex].appid         = activeapp;
            usersdata[appsusersindex].usersnav      = new usersnavproto();

            
            usersdata[appsusersindex].usersnav.newresults();
        }
        return;
    }
    else{
        pageloaded[pageloaded.length] = 'userspage';

        usersdata[usersdata.length] = [];
        appsusersindex = usersdata.length-1;
        usersdata[appsusersindex].appid         = activeapp;
        usersdata[appsusersindex].usersnav      = new usersnavproto();

        usersdata[appsusersindex].usersnav.newresults();
    }

    var userpageaction = {
        postdata:[],
        submitting:false,
        debug:false,
        checksubmitnow:function(elem,containerclassorid,classorid){
            var container = this.getcontainer(elem,containerclassorid,classorid);
            var submitnow = true;
            this.postdata = [];
            var cpostdata = [];
            var debug = this.debug;

            $(container).find('.modalmsg').html('sending request...').addClass('active');
            $.each($(container).find('input,select,textarea'),function(idx,reqelem){
                if(typeof $(reqelem).prop('type') !== 'undefined' && $(reqelem).prop('type') !== 'button' && $(reqelem).prop('type') !== 'submit'){
                    var theval = $(reqelem).val();
                    if(($(reqelem).attr('name') ==  theval || theval == '') && $(reqelem).attr('class').indexOf('required') !== -1 && !debug){
                        $(container).find('.modalmsg').html('please complete the required form').addClass('active');
                        submitnow = false;
                        return false;
                    }
                    else{
                        if($(reqelem).attr('name') == 'repeat password'){
                            if(cpostdata[cpostdata.length-1].value != 'password' && theval != cpostdata[cpostdata.length-1].value){
                                $(container).find('.modalmsg').html('repeat password didnt match').addClass('active');
                                submitnow = false;
                                return false;
                            }
                        }
                        cpostdata[cpostdata.length] = [];
                        cpostdata[cpostdata.length-1].name = $(reqelem).attr('name');
                        cpostdata[cpostdata.length-1].value = $(reqelem).val();   
                        
                        if(cpostdata[cpostdata.length-1].name == 'meta key' && cpostdata[cpostdata.length-1].value=='meta key' || cpostdata[cpostdata.length-1].name == 'meta value' && cpostdata[cpostdata.length-1].value=='meta value'){
                            cpostdata.splice(cpostdata.length-1);
                        }
                        else if(cpostdata[cpostdata.length-1].name == 'settings key[]' && cpostdata[cpostdata.length-1].value=='settings key' || cpostdata[cpostdata.length-1].name == 'settings value[]' && cpostdata[cpostdata.length-1].value=='settings value'){
                            cpostdata.splice(cpostdata.length-1);
                        }
                    }
                }
            });
            this.postdata = cpostdata;
            return submitnow;
        },
        checksiblings:function(rowelem){
            if($(rowelem).next().attr('class').indexOf('submitrow') !== -1 && $(rowelem).prev().attr('class').indexOf('inputrow') === -1 ){
                return false;
            }
            return true;
        },
        getcontainer:function(elem,containerclassorid,classorid){
            var elemsparent = $(elem).parent();
            switch(classorid){
                case 'id':
                    while(typeof $(elemsparent).attr('id') !== 'undefined'){
                        if($(elemsparent).attr('id') == containerclassorid){
                            break;
                        }
                        elemsparent = $(elemsparent).parent();
                    }
                break;
                case 'class':
                    while(typeof $(elemsparent).attr('class') !== 'undefined'){
                        if($(elemsparent).attr('class').indexOf(containerclassorid) !== -1){
                            break;
                        }
                        elemsparent = $(elemsparent).parent();
                    }
                break;
            }
            return elemsparent;
        },
        edituser:function(elem){
            blurcontent();
            $('#edituserform').addClass('active loading');
            usersdata[appsusersindex].usersnav.getuser($(elem).parent().siblings('.userid').html());
            usersdata[appsusersindex].usersnav.editform();
        },
        addusersubmit:function(elem){
            var submitnow = this.checksubmitnow(elem,'modals','class');
            if(submitnow){
                usersdata[appsusersindex].usersnav.submituser(this.postdata,0);
            }
        },
        editusersubmit:function(elem){
            var submitnow = this.checksubmitnow(elem,'modals','class');
            if(submitnow){
                usersdata[appsusersindex].usersnav.submituser(this.postdata,1);
            }
        },
        addrolesubmit:function(elem){
            var submitnow = this.checksubmitnow(elem,'modals','class');
            if(submitnow){
                var ajaxpostdata = '';
                $.each(this.postdata,function(ix,iv){
                    ajaxpostdata += iv.name+'<*edelem*>'+iv.value+'<*edelemsep*>';
                });
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'rolec',a:'newrole',d:{ajaxpostdata:ajaxpostdata}}
                }).done(function(msg){
                    msg = JSON.parse(msg);
                    if(msg.result){
                        $('#rolelistcontainer').append('<div class="roleitem row"><span class="roleid">'+msg.role.id+'</span><span class="rolename">'+msg.role.rolename+'</span><span class="actions"><span class="actionsspan deleterole"><a href="javascript:void(0);">delete</a></span><span class="actionsspan editrole"><a href="javascript:void(0);">edit</a></span></span></div>');
                    }
                    if($('#addrole').attr('class').indexOf('active') !== -1){
                        modalsboxmsg($('#addrole'),msg.msg,true,false);
                    }
                    else{
                        registapagemsg(msg.msg,true);
                    }
                });
            }
        },
        filteruser:function(){
            usersdata[appsusersindex].usersnav.filteruser();
        },
        prevpage:function(){
            usersdata[appsusersindex].usersnav.prevpage();
        },
        nextpage:function(){
            usersdata[appsusersindex].usersnav.nextpage();
        },
        usersgotopage:function(elem){
            usersdata[appsusersindex].usersnav.usersgotopage($(elem).val());
        },
        deleteuser:function(elem){

        },
        editrole:function(){
            blurcontent();
            $('#editrolemodal').addClass('active');
        },
        deleterole:function(elem){},
        addmetadata:function(elem){
            var row = $(elem).parent();
            $(row).after('<div class="row bottomless inputrow">'+$(row).html()+'</div>');

            $.each($(row).next().children(),function(idx,childelem){
               $(childelem).removeClass('filled');
            });
        },
        minmetadata:function(elem){
            var row = $(elem).parent();
            if(this.checksiblings(row)){
                $(row).remove();
                return;
            }

            $.each($(row).children(),function(idx,childelem){
                if($(childelem).prop('type') !== 'button'){
                    var formarr = $(childelem).attr('name').indexOf('[');
                    formarr = formarr == -1 ? $(childelem).attr('name').length : formarr;
                    $(childelem).val($(childelem).attr('name').substr(0,formarr)).removeClass('filled');
                }
            });
        },
        metakeyselectionopt:function(elem){
            var nextin = $(elem).next();
            if($(nextin).attr('class') !== 'undefined' && $(nextin).attr('class').indexOf('umetakeyopt') !== -1){
                return;
            }
            $(elem).after('<ul class="umetakeyopt active">'+$('#distinctusermetakey').html()+'</ul>');

            nextin = $(elem).next();
            if($(elem).attr('class').indexOf('extras') !== -1){
                for(var i=0;i<5;i++){
                    $(nextin).children().eq(0).remove();
                }
            }

            $(nextin).css('width',($(elem).width()+10)+'px');
        },
        metakeyselected:function(elem){
            var nextin = $(elem).next();
            if($(nextin).attr('class') !== 'undefined' && $(nextin).attr('class').indexOf('umetakeyopt') !== -1){
                $(nextin).remove();
            }

            var elemval = $(elem).val();
            if(elemval === ''){
                $(elem).val($(elem).attr('name')).removeClass('filled');
                return;
            }
            $(elem).addClass('filled');

            var indistinct = false;
            $.each($('#distinctusermetakey').children(),function(di,del){
                if(elemval == $(del).html()){
                    indistinct = true;
                    return false;
                }
            });
            if(!indistinct){
                $('#distinctusermetakey').append('<li class="usermetakeyopt">'+elemval+'</li>');
            }
        },
        selectmetakeyselected:function(elem){
            $(elem).parent().prev().val($(elem).html()).addClass('filled');
            $(elem).parent().remove();
        },
        filterumetakeyopt:function(elem){
            elemval = $(elem).val().toLowerCase();
            $.each($(elem).next().children(),function(i,e){
                if($(e).html().toLowerCase().indexOf(elemval) === -1){
                    $(e).addClass('hide');
                }
                else{
                    $(e).removeClass('hide');
                }
            });
        },
        hoverumetakeyopt:function(elem,upordown){
            this.metakeyselectionopt(elem);
            var theopt      = $(elem).next();
            var selected    = $(theopt).children('.selected');
            if(selected.length){
                var realselected  = selected = selected[0];
                switch(upordown){
                    case 40:
                        while(typeof $(selected).next().attr('class') !== 'undefined'){
                            if($(selected).next().attr('class').indexOf('hide') == -1){
                                $(realselected).removeClass('selected');
                                $(selected).next().addClass('selected');
                                break;
                            }
                            else{
                                selected = $(selected).next();
                            }
                        }
                    break;
                    case 13:
                        $(elem).val($(selected).html()).addClass('filled');
                        $(elem).next().remove();
                    break;
                    case 38:
                        while(typeof $(selected).prev().attr('class') !== 'undefined'){
                            if($(selected).prev().attr('class').indexOf('hide') == -1){
                                $(realselected).removeClass('selected');
                                $(selected).prev().addClass('selected');
                                break;
                            }
                            else{
                                selected = $(selected).prev();
                            }
                        }
                    break;
                }
            }
            else{
                switch(upordown){
                    case 40:
                        selected = $(theopt).children().eq(0);
                        while($(selected).attr('class') !== 'undefined'){
                            if($(selected).attr('class').indexOf('hide') == -1){
                                $(selected).addClass('selected');
                                break;
                            }
                            else{
                                selected = $(selected).next();
                            }
                        }
                    break;
                    case 13:
                    break;
                    case 38:
                        selected = $(theopt).children().eq($(theopt).children().length-1);
                        while($(selected).attr('class') !== 'undefined'){
                            if($(selected).attr('class').indexOf('hide') == -1){
                                $(selected).addClass('selected');
                                break;
                            }
                            else{
                                selected = $(selected).prev();
                            }
                        }
                    break;
                }
            }
        }
    };

    function handlelink(){
        $('#thepagecontainer').delegate('.usermetakeyopt','click',function(event){
            userpageaction.selectmetakeyselected(this);
        });
        $('#thepagecontainer').delegate('.metakey','keyup',function(event){
            if(event.which == 40 || event.which == 38 || event.which == 13){
                userpageaction.hoverumetakeyopt(this,event.which);
                return;
            }
            userpageaction.filterumetakeyopt(this);
        });
        $('#thepagecontainer').delegate('.metakey','click focus',function(event){
            userpageaction.metakeyselectionopt(this);
        });
        $('#thepagecontainer').delegate('.metakey','blur',function(event){
            event.stopPropagation();

            var thiselem = this;
            setTimeout(function(){
                   userpageaction.metakeyselected(thiselem);
            },300);
        });
        $('#thepagecontainer').delegate('#filteruser','click',function(event){
            event.stopPropagation();
            userpageaction.filteruser(this);
        });
        $('#thepagecontainer').delegate('#addusersubmit','click',function(event){
            event.stopPropagation();
            userpageaction.addusersubmit(this);

        });
        $('#thepagecontainer').delegate('#editusersubmit','click',function(event){
            event.stopPropagation();
            userpageaction.editusersubmit(this);
        });
        $('#thepagecontainer').delegate('#addrolesubmit','click',function(event){
            event.stopPropagation();
            userpageaction.addrolesubmit(this);
        });
        $('#thepagecontainer').delegate('#prevuserpage','click',function(event){
            event.stopPropagation();
            if($(this).attr('class').indexOf('disabled')===-1)
                userpageaction.prevpage();
        });
        $('#thepagecontainer').delegate('#nextuserpage','click',function(event){
            event.stopPropagation();
            if($(this).attr('class').indexOf('disabled')===-1)
                userpageaction.nextpage();
        });
        $('#thepagecontainer').delegate('#usersgotopage','change',function(event){
            event.stopPropagation();
            userpageaction.usersgotopage(this);
        });
        $('#thepagecontainer').delegate('.edituser','click',function(event){
            event.stopPropagation();
            userpageaction.edituser(this);
        });
        $('#thepagecontainer').delegate('.deleteuser','click',function(event){
            event.stopPropagation();
            userpageaction.deleteuser(this);
        });
        $('#thepagecontainer').delegate('.editrole','click',function(event){
            event.stopPropagation();
            userpageaction.editrole(this);
        });
        $('#thepagecontainer').delegate('.deleterole','click',function(event){
            event.stopPropagation();
            userpageaction.deleterole(this);
        });
        $('#thepagecontainer').delegate('.addrolessetting','click',function(event){
            event.stopPropagation();
            userpageaction.addmetadata(this);
        });
        $('#thepagecontainer').delegate('.minrolessetting','click',function(event){
            event.stopPropagation();
            userpageaction.minmetadata(this);
        });
        $('#thepagecontainer').delegate('.addusermeta','click',function(event){
            event.stopPropagation();
            userpageaction.addmetadata(this);
        });
        $('#thepagecontainer').delegate('.minusermeta','click',function(event){
            event.stopPropagation();
            userpageaction.minmetadata(this);
        });
    };
    handlelink();
}