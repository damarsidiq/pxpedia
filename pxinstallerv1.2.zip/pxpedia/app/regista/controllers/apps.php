<?php

Class Apps extends Controller{
    function __construct() {
        parent::__construct();
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
		    $this->addheadfootsrc(false,array('mobileregista'=>App::getConfig('appviews').'/styles/mobileregista.css'));
		}
		else{
		    $this->setPagevar('mobile','false');
		}
    }
	public function checkpage(){
		return true;
	}
	public function appelements($data){
	    $response = array('id'=>App::getappid($data['noa']));
	    $av = $this->model('appslist')->appsdesc($response['id']);
	    $av['creator']      = App::getUser()['username'];
	    $av['createdon']    = date('l, F jS Y H:i:s',strtotime($av['createdon']));
	    $response = array_merge($response,$av);
	    $response['link'] = App::appurl($data['noa']);
	    $response['deletelink'] = str_replace('a=appelements','a=pageInit',$this->appactionlink($av,'delete'));
	    $response['administerlink'] = str_replace('a=appelements','a=pageInit',$this->appactionlink($av,'administer'));
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
    public function pageInit($data=null,$view='apps'){
        if(!App::isLoggedin()){
	        $login = App::loginuser(1);
	    }
	    
		if(!App::isLoggedin()){
			return 'login';
		}
		if($data !== null){
			if(isset($data['switchapp'])){
				App::switchApp($data['switchapp']);
			
			    $response = array();
				$menu='';
				foreach(App::adminmenu() as $idx=>$elem){
					  $currentmenuclass = $elem['current'] ? ' current' : '';
					  $menu .='<li class="adminmenuitem'. $currentmenuclass .'"><a href="javascript:void(0);" id="'. $elem['link'] .'">'. $elem['name'] .'</a></li>';
				}
                $response['menu'] = $menu;
				
				$this->setPagevar('response',$response);
				return 'ajax';
			}
			if(isset($data['createnewapp'])){
				$response = $this->model('appslist')->createApp($data['new_app_name']);
				if($response !== false){
				    $response = array('id'=>$response);
				    $av = $this->model('appslist')->appsdesc($response['id']);
				    $av['creator']      = App::getUser()['username'];
				    $av['createdon']    = date('l, F jS Y H:i:s',strtotime($av['createdon']));
				    $response = array_merge($response,$av);
				    $response['link'] = App::appurl($data['new_app_name']);
				    $response['deletelink'] = $this->appactionlink($av,'delete');
				    $response['administerlink'] = $this->appactionlink($av,'administer');
				}
				$this->setPagevar('response',$response);
				return 'ajax';
			}
			if(isset($data['delete'])){
				$this->model('appslist')->deleteApp($data['delete']);
				if(App::currentRole()['appid'] == $data['delete']){
					App::switchApp(3);
				}
				header('Location:'.Pxpedia::appurl('',array('p'=>'apps')));
			}
		}
		$uapp = $this->model('appslist')->userApps();
		foreach($uapp as $apk=>$apv){
			$uapp[$apk]['creator'] = $this->model('user')->username($apv['creator']);
		}
		$this->setPagevar('currentapp',Pxpedia::currentRole()['appid']);
		$this->setPagevar('appslist',$uapp);

		if(App::checkPermission($this->getPagevar('currentapp'))){
			$this->addheadfootsrc(false,array('aceeditor'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/ace.js'));
			$this->addheadfootsrc(false,array('aceeditorlangtool'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/ext-language_tools.js'));
			$this->addheadfootsrc(false,array('aceeditortheme'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/theme-mono_industrial.js'));
			$this->addheadfootsrc(false,array('aceeditormodejs'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/mode-javascript.js'));
			$this->addheadfootsrc(false,array('aceeditormodecss'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/mode-css.js'));
			$this->addheadfootsrc(false,array('aceeditormodephp'=>Pxpedia::getConfig('resources').'ace/src-min-noconflict/mode-php.js'));
		}
		else{
			$view = 'appslist';
		}
		
		if(isset($data['ajax'])){
		    $this->setPagevar('ajax',true);
			$response = array();
			if($view == 'apps')
				$response['scripts'][] = Pxpedia::getConfig('resources').'ace/src-min-noconflict/ace.js';

			$this->setPagevar('response',$response);
		}
		return $view;
    }
    
    public function appactionlink($data,$type,$retainlink=true){
	    $link  = '';
	    switch($type){
	        case 'delete':
	            $link = Pxpedia::appurl('',array('d'=>array('delete'=>$data['id'])),$retainlink);
	        break;
	        case 'administer':
	            $link = Pxpedia::appurl('',array('d'=>array('switchapp'=>$data['id'])),$retainlink);
	        break;
	    }
	    return $link;
	}
}
?>