<?php 
Class RoleC extends Controller{
	function __construct(){
		parent::__construct();
	}
	public function checkpage(){
		return false;
	}
	public function newrole($data){
	    $roledata = explode('<*edelemsep*>',$data['ajaxpostdata']);
	    $setidx = 0;
	    foreach($roledata as $rk=>$rv){
	        if($rv !=''){
	            $elem = explode('<*edelem*>',$rv);
	            switch($elem[0]){
	               case 'rolename':
	                   $roleobj['rolename'] = $elem[1];
	               break;
	               case 'settings key[]':
	                   $roleobj['rolesettings'][$setidx]['key'] = $elem[1];
	               break;
	               case 'settings value[]':
	                   $roleobj['rolesettings'][$setidx]['value'] = $elem[1];
	               break;
	            }
	        }
	    }
	    $roleobj['rolesettings'] = json_encode($roleobj['rolesettings']);
	    $roleobj['id'] = $this->model('role')->addrole($roleobj);
	    $response['result'] = $roleobj['id'];
	    if($roleobj['id']){
	        unset($roleobj['rolesettings']);
	        $response['role'] = $roleobj;
	        $response['msg'] = 'new role added';
	    }
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
}
