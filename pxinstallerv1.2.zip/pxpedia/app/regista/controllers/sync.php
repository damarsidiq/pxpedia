<?php
Class Sync extends Controller{
    var $progressfile;
    var $filearr;
    var $filesyncmode;
    var $filesynceval;
    var $syncurl;
    var $appsyncconfig;
    var $isdependencyfile;

    var $apptosync;
    var $apptosyncid;

    var $appsyncconfigarr;
    var $apptosyncarr;


    var $appdb;
    var $tablesyncrowlimit;
    var $tablerowsyncedcount;
    var $exitnow=false;
	function __construct(){
		parent::__construct();
		$this->filearr = array();
		$this->tablesyncrowlimit = 12;
	}
	public function checkpage(){
		return false;
	}
	public function readprogress($data){
	    header('Access-Control-Allow-Origin: *');
	    $progressedfile = App::getConfig('uploads').$data['progressfile'].'.progress';
	    $response['progress'] = 'false';
	    if(file_exists($progressedfile) && filesize($progressedfile) > 0){
    	    $progressed = @fopen($progressedfile,'rb');
    	    $progressedcontent = fread($progressed,filesize($progressedfile));

    	    /*truncate the file*/
    	    $progressed = @fopen($progressedfile,'w+');
    	    fclose($progressed);
    	    $response['progress'] = $progressedcontent;
	    }

	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function writeprogress($data){
	    $this->setsyncsession($data,'server');

	    $progressed = @fopen($this->progressfile,'ab');
	    $wrote      = @fwrite($progressed,$data['result']);

	    fclose($progressed);
	    echo $wrote;
	    return 'plain';
	}
	public function reportprogress($results){
	    if(strlen($results) > 1000){
	        $results = substr($results,0,1000);
	    }
	    $report = @file_get_contents($this->syncurl.'?app=regista&p=sync&a=writeprogress&d[result]='.urlencode($results).'&d[progress]='.$this->progressfile);
	    if(!$report){
	        echo $this->syncurl.'?app=regista&p=sync&a=writeprogress&d[result]='.$results;
	    }
	    return $report;
	}
    public function fixurl($data){
        if(substr($data['url'],0,4) !== 'http'){
            $data['url'] = 'http://'.$data['url'];
        }
        if(substr($data['url'],-1) !== '/'){
            $data['url'] .= '/';
        }
        $this->setsyncsession($data);
        return $data;
	}
	public function testdb($data=false){
	    App::createnewdb('testes');
	}
	public function testoutput($data){
	    echo '===';
	    return 'plain';
	}
	public function dbcred($data){
	    $username = $data['username'];
	    $passwd = $data['passwd'];

	    if(App::createdbcreator($username,$passwd)){
	        echo App::createnewdb(App::getSessionVar('apptosync'));
	        return 'plain';
	    }

	    echo '5';
	    return 'plain';
	}
	public function setsyncsession($data,$mode='client'){
	    if($data === false){
            $this->apptosync = App::getSessionVar('apptosync');
            $this->apptosyncid = App::getSessionVar('apptosyncid');
    	    $this->appsyncconfig = App::getSessionVar('appsyncconfig');

            $this->syncurl = App::getSessionVar('syncurl');

            $this->apptosyncarr = App::getSessionVar('apptosyncarr');
            $this->appsyncconfigarr = App::getSessionVar('appsyncconfigarr');
            $this->progressfile = App::getSessionVar('progressfile');

            if($mode !=='client' && $this->progressfile === false){
                $this->progressfile = App::getConfig('uploads').'syncapp'.time().'.progress';
                App::setSessionVar('progressfile',$this->progressfile);

                $h = @fopen($this->progressfile,'wb');
                fclose($h);
            }

	        return;
	    }
	    foreach($data as $k=>$v){
	        switch($k){
	            case 'apptosync':
	                $this->apptosync = $data['apptosync'];
	                App::setSessionVar('apptosync',$this->apptosync);

	                $this->apptosyncid = App::getappid($this->apptosync);
	                if(!$this->apptosyncid){
	                    App::setSessionVar('newapp',true);
	                    $this->apptosyncid = $this->model('appslist')->createApp($this->apptosync,true);
	                    if($this->apptosyncid == false){
	                        echo '0';exit();
	                    }
	                }
	                else{
	                    App::setSessionVar('newapp',false);
	                }
	                App::setSessionVar('apptosyncid',$this->apptosyncid);
	            break;
	            case 'appsyncconfig':
            	    $this->appsyncconfig = $data['appsyncconfig'];
            	    App::setSessionVar('appsyncconfig',$this->appsyncconfig);
	            break;
	            case 'url':
	                $this->syncurl = $data['url'];
                    App::setSessionVar('syncurl',$this->syncurl);
	            break;
	            case 'apptosyncarr':
	                App::setSessionVar('apptosyncarr',$v);
	            break;
	            case 'progress':
	                if($mode == 'client'){
	                    $this->progressfile = $data['progress'];
	                    App::setSessionVar('progressfile',$this->progressfile);
	                }
	                else{
	                 	$this->progressfile = App::getConfig('uploads').$data['progress'].'.progress';
	                    App::setSessionVar('progressfile',$this->progressfile);
	                }
	            break;
	            case 'appsyncconfigarr':
	                App::setSessionVar('appsyncconfigarr',$v);
	            break;
	            default:
	           break;
	        }
	    }
	}
	public function appsyncsession(){
	    $atsa = App::getSessionVar('apptosyncarr');
	    if($atsa === false)
	        return false;

	    $appsessx = explode('<edsep>',$atsa);
	    if($appsessx[0] === ''){
	        App::setSessionVar('apptosyncarr',false);
	        return false;
	    }

	    $ascax = explode('<edsep>',App::getSessionVar('appsyncconfigarr'));
	    $data = array('apptosync'=>$appsessx[0],'appsyncconfig'=>$ascax[0]);

	    $this->setsyncsession($data);
	}
	public function beginsyncsession($data){
	    if(count($data) != 0){
	        App::setSessionVar('syncstagetable',false);
	        App::setSessionVar('tabletosync',false);
	        App::setSessionVar('syncstageextra',false);
	        App::setSessionVar('newapp',false);

	        $this->setsyncsession($data);
	        $this->reqsyncsession();

	        $response['syncurl'] = App::getSessionVar('syncurl');
	        $response['progressfile'] = $this->progressfile;

	        $this->setPagevar('response',$response);
	        return 'ajax';
	    }

	    while($this->appsyncsession() !==false){
	        $this->setsyncsession(false);
	        $this->reqtosync();
	    }
	    echo '9';
	    return 'plain';
	}
	public function reqsyncsession(){
	    $url = App::getSessionVar('syncurl').'?app=regista&p=sync&a=handlesyncsessionreq';
	    $data['progress'] = @file_get_contents($url);

	    $this->setsyncsession($data);
	}
	public function handlesyncsessionreq($data){
	    $this->setsyncsession(false,'server');
	    echo str_replace(array('.progress',App::getConfig('uploads')),array('',''),$this->progressfile);

	    return 'plain';
	}
	public function reqtosync(){
	    $ascx = explode(',',$this->appsyncconfig);
        switch(App::getSessionVar('syncstage')){
            case false:
            case 'filesync':
                $this->reportprogress('starting app sync:'.$this->apptosync.'...<br/><br/>');
                if(in_array('app',$ascx) || in_array('apps',$ascx) || in_array('res',$ascx) || in_array('upload',$ascx) || in_array('uploads',$ascx) || in_array('view',$ascx) || in_array('views',$ascx) || in_array('dep',$ascx) || in_array('deps',$ascx) ){
                    $this->reqsyncfiles();
        	   	}
               App::setSessionVar('syncstage','appconfig');
               $this->reqtosync();
            break;
            case 'appconfig':
                if(in_array('appconfig',$ascx)){
        	   	    $this->reqsyncdb();
        	   	}
        	   App::setSessionVar('syncstage','appdb');
               $this->reqtosync();
            break;
            case 'appdb':
                if(in_array('appdb',$ascx)){
                    $tabletosyncarr = array();
                    foreach($ascx as $ascxk=>$ascxv){
                        if(strpos($ascxv,'dbtable:') !==false){
                            $tabletosyncarr[] = str_replace('dbtable:','',$ascxv);
                        }
                    }
                    if(count($tabletosyncarr)>0){
                        App::setSessionVar('tabletosync',implode('|',$tabletosyncarr));
                    }
                    else{
                        App::setSessionVar('tabletosync',false);
                    }
                    if(App::getSessionVar('newapp')){
                        App::setSessionVar('newapp',false);
                        $newdb = App::createnewdb($this->apptosync);
	                    if($newdb === 0){
	                        echo '1';exit();
	                    }
            	        $appdbvars = App::getAppDbVars();
            	        $appdbvars['dbname'] = $this->apptosync;
	                    $this->model('setting')->savedb($appdbvars,$this->apptosyncid);
                    }
        	   	    $this->reqsyncappdb();
        	   	}
        	   App::setSessionVar('syncstage','extra');
               $this->reqtosync();
            break;
            case 'extra':
               	foreach($ascx as $ascxk=>$ascxv){
        	   	    if(strpos($ascxv,'extra:') !== false){
        	   	        $this->appsyncconfig = str_replace('extra:','',$ascxv);
        	   	        if(App::getSessionVar('syncstageextra') !== false){
        	   	            if($this->appsyncconfig == App::getSessionVar('syncstageextra')){
        	   	                $this->extrasyncfn();
        	   	            }
        	   	        }
        	   	        else{
        	   	            App::setSessionVar('syncstageextra',$this->appsyncconfig);
        	   	            $this->extrasyncfn();
        	   	        }
        	   	    }
        	   	}
        	   	App::setSessionVar('syncstage','cleaninganappsession');
        	   	$this->reqtosync();
            break;
            case 'cleaninganappsession':
                $atsa =  explode('<edsep>',App::getSessionVar('apptosyncarr'));
        	   	$ascax = explode('<edsep>',App::getSessionVar('appsyncconfigarr'));

        	   	unset($atsa[0]);
        	   	unset($ascax[0]);

        	   	App::setSessionVar('apptosyncarr',implode('<edsep>',$atsa));
        	   	App::setSessionVar('appsyncconfigarr',implode('<edsep>',$ascax));

        	   	App::setSessionVar('syncstage',false);

        	   	$this->reportprogress('<br/>end of syncing app:'.$this->apptosync.'.<br/>');
            break;
            default:
            break;
        }
	}
	public function reqsyncprep($data){
	    $data   = $this->fixurl($data);
	    $url    = $data['url'].'?app=regista&p=sync&a=handlesyncprepreq';

	    $response = file_get_contents($url);
	    echo $response;
	    return 'plain';
	}
	public function handlesyncprepreq($data){
	    $applist = $this->model('appslist')->getrecords(null,array('name','modified'),array('modified','desc'));
	    foreach($applist as $ak=>$av){
	        $syncappfile = App::getConfig('resources').$av['name'].'/config.pxsync';
	        if(file_exists($syncappfile)){
	            $applist[$ak]['syncconfig'] = file_get_contents($syncappfile);
	        }
	        else{
	            unset($applist[$ak]);
	        }
	    }
	    $this->setPagevar('response',$applist);
	    return 'ajax';
	}
	public function fileinfolder($path,$ftype,$basepath){
	    $opendir = opendir($path);
        if($opendir){
            while(($file = readdir($opendir)) !== false){
                if($file == '.' || $file == '..'){
                    continue;
                }
                if(is_dir($path.'/'.$file)){
                    if($file != 'pxarchive'){
                        $this->fileinfolder($path.'/'.$file,$ftype,$basepath);
                    }
                }
                else{
                    $filearridx = count($this->filearr);
                    $this->filearr[$filearridx] = array();
                    $this->filearr[$filearridx]['floc'] = str_replace($basepath,'',$path).'/'.$file;
                    $this->filearr[$filearridx]['ftype'] = $ftype;
                    $this->filearr[$filearridx]['fsize'] = filesize($path.'/'.$file);
                    $this->filearr[$filearridx]['dpn'] = $this->isdependencyfile;
                }
            }
            closedir($opendir);
        }
	}
	public function handlesyncfilesreq($data){
	    $this->setsyncsession($data);
	    $ftypedefault       = array('app','res','upload','view','dep');
	    $ftypeconfig        = explode(',',$this->appsyncconfig);
	    $ftype              = array();
	    if($data['newapp']){
	        $ftype = $ftypedefault;
	        $ftype[] = 'dep';
	    }
	    else
    	    foreach($ftypedefault as $k=>$v){
    	        if(in_array($v,$ftypeconfig) || in_array($v.'s',$ftypeconfig)){
    	           $ftype[] = $v;
    	        }
    	    }
    	    
	    $this->filearr      = array();
	    foreach($ftype as $fk=>$fv){
	        switch($fv){
	            case 'app':
	                $path = App::getConfig('approot').$this->apptosync.'/';
	            break;
	            case 'res':
	                $path = App::getConfig('resources').$this->apptosync.'/';
	            break;
	            case 'upload':
	                $path = App::$config['uploads'].$this->apptosync.'/';
	            break;
	            case 'view':
	                $path = App::getConfig('views').$this->apptosync.'/';
	            break;
	            case 'plugin':
	                $path = App::getConfig('plugin').$this->apptosync.'/';
	            break;
	            case 'dep':
	                $this->dependenciesfiles();
	            break;
	        }
	        if($fv != 'dep'){
	            $this->isdependencyfile = false;
	            $this->fileinfolder($path,$fv,$path);
	        }
	    }
	    $this->setPagevar('response',$this->filearr);
	    return 'ajax';
	}
	public function dependenciesfiles(){
	    $sett = $this->model('setting')->getAppHeadFoot($this->apptosync);
	    $headf = array();
	    foreach($sett as $sk=>$sv){
	        $val = json_decode($sv['value'],true);
	        foreach($val as $k=>$v){
	         $headf[] = $v;   
	        }
	    }
	    $dep = array();
	    $installerfile = array($this->apptosync,'ace','bgrins-spectrum','filetool','jquery','jquery-ui-themes-1.11.4','jspacker','lang','Mobile-Detect-2.8.22','msgbox','regista','tinymce');
	    foreach($headf as $k=>$v){
	        $vbase = explode('/',$v);
	        if(in_array($vbase[0],$installerfile))
	            continue;
            
            $dep[] = array();
	        $depidx = count($dep)-1;
	        $dep[$depidx]['url'] = $v;   
	        $dep[$depidx]['urlx'] = App::getsourceurl($v);   
	    }
	    
	    $depaux = array();
	    $deped = array();
	    if(count($dep)){
	        foreach($dep as $dk=>$dv){
	            $dep[$dk]['ftype'] = strpos($dv['urlx'],App::$config['views']) !== false ? 'view' : 'res';
	            $dvx = explode('/',$dv['url']);
	            $dvx = $dep[$dk]['ftype'] == 'view' ? App::$config['views'].$dvx[0] : App::$config['resources'].$dvx[0];
	            $dep[$dk]['path'] = $dvx;
	            $dep[$dk]['basepath'] = $dep[$dk]['ftype'] == 'view' ? App::$config['views'] : App::$config['resources'];
	            
	            if(!in_array($dvx,$depaux)){
	                $depaux[] = $dvx;
	                $deped[] = $dep[$dk];
	            }
	        }
	        
	        $this->isdependencyfile = true;
	        foreach($deped as $dk=>$dv){
	            $this->fileinfolder($dv['path'],$dv['ftype'],$dv['basepath']);
	        }
	    }
	}
	public function createfolderstruct($base,$ext){
	    $extx = explode('/',$ext);
	    unset($extx[count($extx)-1]);

	    if(count($extx)){
	       for($i=0;$i<count($extx);$i++){
	           if($extx[$i]==''){
	               continue;
	           }
	           $foldertocre = str_replace('//','/',$base.'/'.$extx[$i]);
	           if(!file_exists($foldertocre)){
	               @mkdir($foldertocre);
	               $this->reportprogress('<br/>created new directory: '.$foldertocre.'<br/><br/>');
	           }
	           $base.='/'.$extx[$i];
	       }
	    }
	}
	public function reqsyncfiles(){
	    $url = App::getSessionVar('syncurl').'?app=regista&p=sync&a=handlesyncfilesreq&d[apptosync]='.$this->apptosync.'&d[newapp]='.App::getSessionVar('newapp').'&d[appsyncconfig]='.$this->appsyncconfig.'&d[progress]='.$this->progressfile;
	    $this->filearr = json_decode(file_get_contents($url),true);
	    $this->reportprogress('evaluating '.count($this->filearr).' files...<br/>');
	    $this->filesynceval['synced'] = 0;
	    $this->filesynceval['new'] = 0;
	    foreach($this->filearr as $respk=>$respv){
	        
	        switch($respv['ftype']){
	           case 'app':
	               $fdest = App::getConfig('approot').$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::getConfig('approot').$this->apptosync,$respv['floc']);
	           break;
	           case 'res':
	               if($respv['dpn']){
       	               $fdest = App::getConfig('resources').$respv['floc'];
       	               $this->createfolderstruct(App::getConfig('resources'),$respv['floc']);
	               }
	               else{
                        $fdest = App::getConfig('resources').$this->apptosync.$respv['floc'];
                        $this->createfolderstruct(App::getConfig('resources').$this->apptosync,$respv['floc']);   
	               }
	           break;
	           case 'upload':
	               $fdest = App::$config['uploads'].$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::$config['uploads'].$this->apptosync,$respv['floc']);
	           break;
	           case 'view':
	               if($respv['dpn']){
    	                $fdest = App::getConfig('views').$respv['floc'];
    	                $this->createfolderstruct(App::getConfig('views'),$respv['floc']);   
	               }
	               else{
    	               $fdest = App::getConfig('views').$this->apptosync.$respv['floc'];
    	               $this->createfolderstruct(App::getConfig('views').$this->apptosync,$respv['floc']);
	               }
	           break;
	           case 'plugin':
	               $fdest = App::getConfig('plugins').$respv['floc'];
	               $this->createfolderstruct(App::getConfig('plugins').$respv['floc'],$respv['floc']);
	           break;
	        }
	        $copied = $this->copyfile($respv['floc'],$respv['ftype'],$fdest,$respv['fsize'],$respv['dpn']);
	        if($copied === false){
	            $this->reportprogress('error copying file '.$fdest.'<br/>');
	        }
	        else{
	            if($copied==='identical'){
	                $this->reportprogress('made no changes to :"'.$fdest.'" --filesize is identical<br/>');
	            }
	            else{
	                if($this->filesyncmode==1){
	                    $this->reportprogress('synced.<br/>');
	                    $this->filesynceval['synced']++;
	                }
	                else{
	                    $this->reportprogress('done.<br/>');
	                    $this->filesynceval['new']++;
	                }
	            }
	        }
	    }
	    $this->reportprogress('<br/>file syncing complete. '.$this->filesynceval['synced'].' edited and '.$this->filesynceval['new'].' was added.<br/>');
	}
	public function copyfile($fileorigin,$ftype,$filedest,$fsize,$dpn){
	    if(file_exists($filedest)){
	        $existingsize = filesize($filedest);
	        if($existingsize == $fsize){
	            $this->filesyncmode = 2;
	            return 'identical';
	        }
	        else{
	            $this->filesyncmode = 1;
	            $this->reportprogress('--- syncing file :"'.$filedest .'"....');
	        }
	    }
	    else{ 
	        $this->filesyncmode = 0;
	        $this->reportprogress('--- adding file :"'.$filedest.'"....');
	    }
	    $dest = fopen($filedest,'wb');
	    if($dest !== false){
	        $copied = false;
	        $fileorigin = App::getSessionVar('syncurl').'?app=regista&p=sync&a=filecontent&d[dpn]='.$dpn.'&d[floc]='.urlencode($fileorigin).'&d[ftype]='.$ftype.'&d[apptosync]='.App::getSessionVar('apptosync');
	        $srcfilehandler = @fopen($fileorigin,'rb');
	        if($srcfilehandler){
    	        $srcfile = '';
    	        while(($read = fgets($srcfilehandler)) !== false){
    	            $srcfile .= $read;
    	        }
    	        $copied = fwrite($dest,$srcfile);
	        }
	        fclose($dest);
	        return $copied;
	    }
	    return false;
	}
	public function filecontent($data){
	    switch($data['ftype']){
           case 'app':
               $fdest = App::getConfig('approot').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'res':
                if($data['dpn']){
                   $fdest = App::getConfig('resources').$data['floc'];
                }
                else
                    $fdest = App::getConfig('resources').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'upload':
               $fdest = App::$config['uploads'].$data['apptosync'].'/'.$data['floc'];
           break;
           case 'view':
                if($data['dpn']){
                   $fdest = App::getConfig('views').$data['floc'];
                }
                else
                    $fdest = App::getConfig('views').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'plugin':
               $fdest = App::getConfig('plugins').$data['floc'];
           break;
        }
        if(file_exists($fdest)){
            $dest = @fopen($fdest,'rb');
    	    if($dest !== false && filesize($fdest)){
    	        echo @fread($dest,filesize($fdest));
    	    }
    	    fclose($dest);
        }
        return 'plain';
	}
	/*sync appdb*/
	public function reqsyncappdb(){
	    $this->reportprogress('<br/>syncing apps database...<br/>');

	    $url = $this->syncurl.'?app=regista&p=sync&a=handlesyncappdbreq&d[apptosync]='.$this->apptosync;
	    $urlfetch = file_get_contents($url);
	    $apptable = json_decode($urlfetch,true);
	    $tabletosync = App::getSessionVar('tabletosync');
	    if($tabletosync !=false){
	     	$this->reportprogress('<br/>table/tables to sync: '.print_r($tabletosync,true).'<br/>');
	        $tabletosyncx = explode('|',$tabletosync);   
	    }
	    else{
	        $printtables = '';
	        foreach($apptable as $tablek=>$tablev){
	            foreach($tablev as $tablevk=>$tablevv){
	                $printtables .= $tablevv.'|';
    	        }
    	    }
	        $this->reportprogress('<br/>table/tables to sync: '.$printtables.'<br/>');
	    }
	    foreach($apptable as $tablek=>$tablev){
	        if(App::getSessionVar('syncstagetable') !== false){
	            foreach($tablev as $tablevk=>$tablevv){
	                if($tablevv == App::getSessionVar('syncstagetable')){
    	                $this->reqsynctable($tablevv);
	                }
    	        }
	        }
	        else{
	            foreach($tablev as $tablevk=>$tablevv){
	                if($tabletosync !== false){
	                    if(in_array($tablevv,$tabletosyncx)){
	                        $this->reqsynctable($tablevv);
	                    }
	                }
	                else{
	                    $this->reqsynctable($tablevv);
	                }
    	        }
	        }
	    }
	    $this->reportprogress('<br/>syncing app database completed.<br/>');
	}
	public function reqtabledef($table){
	    $url        = $this->syncurl.'?app=regista&p=sync&a=handletabledefreq&d[apptosync]='.$this->apptosync.'&d[table]='.$table;
	    $urlfetch   = file_get_contents($url);

	    $newtable = App::createnewtable($this->apptosync,$urlfetch);
	    if($newtable === 0){
	        echo '1';exit();
	    }
	}
	public function handletabledefreq($data){
	    $this->setsyncsession($data,'server');

	    $tablemodel = new Model($data['table'],$this->apptosyncid);
	    $tabledef = $tablemodel->createtablesql();
	    echo $tabledef;
	    return 'plain';
	}
	public function reqsynctable($table,$offset=false){
	    App::setSessionVar('syncstagetable',$table);
	    $this->reportprogress('<br/>syncing table '.$table.'...<br/>');

	    $tablemodel = new Model($table,$this->apptosyncid);
	    if(count($tablemodel->db->errors) > 0){
	        $tablemodel->db->errors = array();
	        $this->reportprogress('creating table '.$table.'...<br/>');
	        $this->reqtabledef($table);
	    }
	    $this->tablerowsyncedcount = 0;

	    $this->_reqsynctable($table,$offset,$tablemodel);

	    $this->reportprogress('syncing table '. $table .' completed.<br/>');
	    App::setSessionVar('syncstagetable',false);
	}
	public function _reqsynctable($table,$offset,$tablemodel){
	    if($this->exitnow===true){
	        $this->exitnow=false;
	        $this->reportprogress('exiting...');
	        return true;
	    }
	    
	    $offset     = $offset === false ? $tablemodel->countrows() : $offset;
	    $url        = $this->syncurl.'?app=regista&p=sync&a=handlesynctablereq&d[apptosync]='.$this->apptosync.'&d[table]='.$table.'&d[offset]='.$offset;
	    $urlfetch   = file_get_contents($url);
	    $apptable   = json_decode($urlfetch,true);
	    $tablerows  = $apptable['rows'];
	    $rowlimit   = $apptable['limit'];

	    if(is_array($tablerows) && count($tablerows)>0){
	        $fieldname =array();
	        $fieldval = array();
	        foreach($tablerows as $rk=>$rv){
	            foreach($rv as $rvk=>$rvv){
	                if($rk==0){
	                    $fieldname[] = $rvk;
	                }
	                $fieldval[$rk][] = $rvv;
	            }
	        }
	        $added = $tablemodel->addrecords($fieldname,$fieldval);
	        if($added){
	            $this->tablerowsyncedcount += count($tablerows);
	        }
	        else{
	            if(count($tablemodel->db->errors)>0){
    	            $this->reportprogress('error importing data:<br/>'.$tablemodel->printerrors(false).'<br/>');
    	            $tablemodel->db->errors = array();
    	            $this->exitnow=true;
    	        }   
	        }

	        if(count($tablerows) == $rowlimit){
	            $this->reportprogress('--- new record added:'.$this->tablerowsyncedcount.'<br/>');
	            $this->_reqsynctable($table,($offset+$rowlimit),$tablemodel);
	        }
	        else{
	            $this->reportprogress('--- new record added:'.$this->tablerowsyncedcount.'<br/>');
	            return true;
	        }
	    }
	    else{
	        $this->reportprogress('made no changes.<br/>');
	        return true;
	    }
	}
	public function handlesynctablereq($data){
	    $this->setsyncsession($data,'server');

	    $tablemodel = new Model($data['table'],$this->apptosyncid);
	    $tablemodelprim = $tablemodel->primary();
	    $tablemodelordering = $tablemodelprim == false ? null: array($tablemodelprim,'asc');
	    $rows = $tablemodel->getrecords(null,null,$tablemodelordering,array($data['offset'],$this->tablesyncrowlimit));

	    $response = array();
	    $response['limit'] = $this->tablesyncrowlimit;
	    $response['rows']   = $rows;
	    $this->setPagevar('response',$response);

	    return 'ajax';
	}
	public function handlesyncappdbreq($data=false){
	    $this->setsyncsession($data);
	    $this->appdb = App::appdb($this->apptosync);

	    $tables = $this->appdb->query('show tables');
		$appdb 	= $this->appdb->fetchQueryResult($tables,true);

		$this->setPagevar('response',$appdb);
		return 'ajax';
	}
	/*sync extra functions*/
	public function extrasyncfn(){
	    if(file_exists(App::getConfig('approot').'controllers/'.$this->appsyncconfig.'.php')){
	        include App::getConfig('approot').'controllers/'.$this->appsyncconfig.'.php';

    	    $extrafn = new $this->appsyncconfig();
    	    $extrafn->app = $this->apptosyncid;
    	    $extrafn->db = App::appdb($this->apptosyncid);
    	    $extrafn->setPagevar('app',$this->apptosyncid);

    	    $extradata = array();
    	    $extradata['syncurl'] = $this->syncurl;
    	    $extradata['apptosync'] = $this->apptosync;
    	    $extrafn->pageInit($extradata);
	    }
	}
	/*sync appconfig*/
	public function reqsyncdb(){
	    $this->reportprogress('<br/>syncing app config...<br/>');

	    $url = $this->syncurl.'?app=regista&p=sync&a=handlesyncdbreq&d[apptosync]='.$this->apptosync;
	    $settings = json_decode(file_get_contents($url),true);

	    if(App::getSessionVar('newapp')){
	        $this->reportprogress('creating apps db setting...<br/>');
	        $appdbvars = App::getAppDbVars();
	        $appdbvars = json_encode($appdbvars);
	        $a = $this->model('setting')->addrecord(array('type','app','name','value'),array('globalpage',$this->apptosyncid,'dbsetting',$appdbvars));
	    }

	    foreach($settings as $sk=>$sv){
	        if($this->model('setting')->exists(array('app'=>$this->apptosyncid,'name'=>$sv['name']))){
                $a = $this->model('setting')->updaterecord(array('value'=>$sv['value']),array('app'=>$this->apptosyncid,'name'=>$sv['name']));
            }
            else{
                $a = $this->model('setting')->addrecord(array('type','app','name','value'),array($sv['type'],$this->apptosyncid,$sv['name'],$sv['value']));
            }
	    }
	    $this->reportprogress('app config sync completed.<br/>');
	}
	public function handlesyncdbreq($data){
	    $this->setsyncsession($data);
	    $settingsx = $this->model('setting')->getAppSettings($this->apptosync);
	    $settings = array();
	    foreach($settingsx as $xk=>$xv){
	        if($xv['name'] == 'dbsetting'){
	            continue;
	        }
	        $settings[] = $settingsx[$xk];
	    }
	    $this->setPagevar('response',$settings);

	    return 'ajax';
	}
}
