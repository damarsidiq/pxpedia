<?php

Class Pages extends Controller{
    function __construct() {
        parent::__construct();
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
		return true;
	}
    public function pageInit($data=null,$view='pages'){
		$pagesdir 	= Pxpedia::getConfig('approot').Pxpedia::appById(Pxpedia::getUser()['currentrole']['appid']).'/controllers/';
		$pagefiles 	= opendir($pagesdir);
		$pages		= array();
		if($pagefiles){
			while(($file = readdir($pagefiles)) !== false){
				if($file !== '.' && $file !== '..'){
					$pages[] = $file;
				}
			}
		}
		$this->setPagevar('pages',$pages);
		
		if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		
    }
}
?>