<?php

Class Users extends Controller{
    var $usersnumperpage;
    function __construct() {
        parent::__construct();
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
		$this->usersnumperpage = 3;
    }
	public function checkpage(){
		return true;
	}
    public function pageInit($data=null,$view='main'){
		if(!App::isLoggedin()){
			return 'login';
		}
		$users = $this->model('user')->getUsers();
		$roles = $this->model('role')->getRoles();
		$userspagenum = ($this->model('user')->numofusers() / $this->usersnumperpage);
		
		if(count($users)){
			$this->setPagevar('users',$users);
			$this->setPagevar('userspagenum',$userspagenum);
		}
		else{
		    $this->setPagevar('users',array());
			$this->setPagevar('userspagenum',0);
		}
		
		$this->setPagevar('distinctusermetakey',$this->model('usersdata')->distinctmetakey());
		$this->setPagevar('roles',$roles);
		
		if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		    
		return 'users';
    }
    public function metaquerystring($metacondi,$dbq,$oriq){
        if($oriq !=''){
            if(strpos($dbq,' where') === false){
                $oriqx = explode(' and',$oriq);
                $oriq = ' where';
                foreach($oriqx as $i=>$v){
                    if($i<2){
                        $oriq .= $v;
                    }
                    else $oriq .= ' and'.$v;
                }
            }
        }
        $str = $dbq.$oriq;
        if(!count($metacondi)){
            return $str;
        }
        if(strpos($str,' where') !== false){
            $str .= ' and id in(select userid from '.$this->model('usersdata')->table.' where '; 
        }
        else{
            $str .= ' where id in(select userid from '.$this->model('usersdata')->table.' where ';
        }
        
        foreach($metacondi as $k=>$v){
            if($k>0){
                $str.= ' or ';
            }
            
            $str.='(metakey ="'. $v[0] .'" and metavalue="'.$v[1].'")';
        }
        $str .= ')';
        return $str;
    }
    public function reqpage($data=null,$view='ajax'){
		if(!App::isLoggedin()){
			return 'login';
		}
		$condi = false;
		$metacondi = false;
		if($data['condi'] != ''){
		    $condi      = array();
		    $metacondi  = array();
		    $filters = explode('<f>',$data['condi']);
    		if(count($filters)){
    		    foreach($filters as $fk=>$fv){
    		        if($fv!=''){
    		            $umeta = explode('<fe>',$fv);
        		        switch($umeta[0]){
        		            case 'ID':
        		                $condi['id'] = $umeta[1];
        		            break;
        		            case 'username':
        		                $condi['username'] = $umeta[1];
        		            break;
        		            case 'email':
        		                $condi['email'] = $umeta[1];
        		            break;
        		            case 'registered date from':
        		                $condi['regfrom'] = $umeta[1];
        		            break;
        		            case 'registered date end':
        		                $condi['regend'] = $umeta[1];
        		            break;
        		            default:
        		                $metacondi[] = array($umeta[0],$umeta[1]);
        		            break;
        		        }   
    		        }
    		    }
    		    $sl = '';
    		    if(isset($condi['regfrom']) || isset($condi['regend']) ){
    		        if(isset($condi['regfrom'])){
    		            $regfrom = $condi['regfrom'];
    		            $sl .= ' and registered >="'. $regfrom .'"';
    		            unset($condi['regfrom']);
    		        }
    		        if(isset($condi['regend'])){
    		            $regend = $condi['regend'];
    		            $sl.= ' and registered <="'. $regend .'"';
    		            unset($condi['regend']);
    		        }
    		    }
    		    
    		        if(count($condi)){
    		            $sl = $this->metaquerystring($metacondi,$this->db->selectQuery($this->model('user')->table,null,$condi),$sl) .' order by id desc limit '.($data['page']*$this->model('user')->pagelimit).','.$this->model('user')->pagelimit;
    		        }
    		        else{
    		            $sl = $this->metaquerystring($metacondi,$this->db->selectQuery($this->model('user')->table,null,null),$sl) .' order by id desc limit '.($data['page']*$this->model('user')->pagelimit).','.$this->model('user')->pagelimit;
    		        }
    		  
    		  	$response['result'] = true;
        		$response['users'] = $this->db->fetchQueryResult($this->db->query($sl),true);
        		if($data['page'] == 0){
        		    $slnolimit = explode(' limit ',$sl);
        		    $slnolimit = 'select count(*) as rowcount from('.$slnolimit[0].') as a';
        		    $response['debug'] = $slnolimit;
        		    $response['pagenum'] = $this->db->fetchQueryResult($this->db->query($slnolimit),true)[0]['rowcount']/$this->usersnumperpage;
        		}
        		$this->setPagevar('response',$response);
        		return 'ajax';
    		}   
		}
		$response['result'] = true;
		$response['users'] = $this->model('user')->getUsers($condi,false,false,array('id','desc'),$data['page']);
		$this->setPagevar('response',$response);
		return 'ajax';
    }
    public function submitnewuser($data){
        if(!App::checkPermission()){
            $this->setPagevar('response','not enough permission');
            return 'ajax';
        }
        
        $appid = App::getUser()['currentrole']['appid'];
        
        $userdata = array();
        $usermeta = array();
        $userdatax = explode('<*edelemsep*>',$data['submitdata']);
        foreach($userdatax as $k=>$v){
            if($v == '')
                continue;
                
            $datax = explode('<*edelem*>',$v);
            if($datax[0] !='meta key' && $datax[0] != 'meta value'){
                $userdata[$datax[0]] = $datax[1];
            }
            else{
                $umetaidx = count($usermeta);
                if($datax[0] == 'meta key'){
                    $usermeta[$umetaidx]['metakey'] = $datax[1];
                }
                else{
                    $usermeta[$umetaidx-1]['metavalue'] = $datax[1];
                }   
            }
        }
        $userid = false;
        
        unset($userdata['repeat password']);
        $newuser = $this->model('user')->adduser($userdata,$appid);
        if($newuser != false){
            if(is_array($newuser)){
                $response['msg']    = $newuser[1];
                $response['result'] = $newuser[0];
            }
            else{
                foreach($usermeta as $mk=>$mv){
                    $this->model('usersdata')->addusermeta($newuser,$mv['metakey'],$mv['metavalue']);   
                }
                $response['msg'] = 'new user created';   
                $response['result'] = $newuser;
            }
        }
        else{
            $response['msg'] = 'db error';
            $response['result'] = $newuser;
        }
        
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function usereditform($data){
        if(!App::checkPermission()){
            $this->setPagevar('response','not enough permission');
            return 'ajax';
        }
        
        $response['role'] = $this->model('userrole')->getuserrolebyapp($data['userid'],$data['appid']);
        $response['meta'] = $this->model('usersdata')->getusersmeta($data['userid']);
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function submitedituser($data){
        if(!App::checkPermission()){
            $this->setPagevar('response','not enough permission');
            return 'ajax';
        }
        
        $appid = App::getUser()['currentrole']['appid'];
        
        $userdata = array();
        $usermetadata = array();
        $usermetadatadel = array();
        $userrole = array($appid);
        $newpassword = false;
        $edituserid = false;
        $data = explode('<*edelemsep*>',$data['submitdata']);
        foreach($data as $datak=>$dataval){
            $dataelems = explode('<*edelem*>',$dataval);
            switch($dataelems[0]){
                case 'metadatadel':
                    $metaidx = count($usermetadatadel);
                    $usermetadatadel[$metaidx] = array($dataelems[1],$dataelems[2]); 
                break;
                case 'metadataentry':
                case 'metadata':
                    if($dataelems[1] !='meta key' && $dataelems[2] != 'meta value'){
                        $metaidx = count($usermetadata);
                        $usermetadata[$metaidx] = array($dataelems[1],$dataelems[2]);   
                    }
                break;
                case 'username':
                case 'email':
                    $userdata[$dataelems[0]] = $dataelems[1];
                break;
                case 'password':
                    $newpassword = $dataelems[1];
                break;
                case 'userid':
                    $edituserid = $dataelems[1];
                break;
                case 'role':
                    $userrole[1] = $dataelems[1];
                break;
            }
        }
        
        $response['result'] = false;
        if(count($userdata)){
            $response['result'] = $this->model('user')->editusersprimary($edituserid,$userdata);
            if($response['result'] == false){
                $response['debug'] = $this->model('user')->printerrors(false).$this->model('user')->querystring();
                $response['msg'] = 'error updating primary data';
                $this->setPagevar('response',$response);
                return 'ajax';
            }
        }
        if(count($userrole)>1){
            $response['result'] = $this->model('userrole')->updaterole($edituserid,$userrole);
            if($response['result'] == false){
                $response['debug'] = $this->model('userrole')->printerrors(false).$this->model('userrole')->querystring();
                $response['msg'] = 'error updating role';
                $this->setPagevar('response',$response);
                return 'ajax';
            }
        }
        if(count($usermetadata)){
            $response['result'] = $this->model('usersdata')->editusermeta($edituserid,$usermetadata);
            if($response['result'] == false){
                $response['debug'] = $this->model('usersdata')->printerrors(false).$this->model('usersdata')->querystring();
                $response['msg'] = 'error updating meta';
                $this->setPagevar('response',$response);
                return 'ajax';
            } 
        }
        if(count($usermetadatadel)){
            $response['result'] = $this->model('usersdata')->deleteusermeta($edituserid,$usermetadatadel);
            if($response['result'] == false){
                $response['debug'] = $this->model('usersdata')->printerrors(false).$this->model('usersdata')->querystring();
                $response['msg'] = 'error updating meta';
                $this->setPagevar('response',$response);
                return 'ajax';
            } 
        }
        if($newpassword!==false){
            $response['result'] = $this->model('user')->updatepassword($edituserid,$newpassword);
            if($response['result'] == false){
                $response['msg'] = 'error updating password';
                $this->setPagevar('response',$response);
                return 'ajax';
            } 
        }
        $response['result'] = $edituserid;
        $response['msg'] = 'update was successful';
        $this->setPagevar('response',$response);
        return 'ajax';
    }
}
?>