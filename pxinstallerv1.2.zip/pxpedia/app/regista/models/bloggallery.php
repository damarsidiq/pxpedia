<?php

Class Bloggallery extends Model{
    function __construct(){
        parent::__construct('bloggallery',App::getUser()['currentrole']['appid']);
    }
    public function addimage($blogid,$imagename){
	    $added = $this->addrecord(array('blogid','image','sortorder'),array($blogid,$imagename,0));
	    if($added){
	        $this->setimgorder($blogid,$this->insertid);
	        return $this->insertid;
	    }
	    return $added;
    }
    public function setimgorder($blogid,$imageid){
        $imgorder = $this->countrows(array('blogid'=>$blogid));
        $imgorder-=1;
        $this->updaterecord(array('sortorder'=>$imgorder),array('id'=>$imageid));
    }
    public function removeimage($imageid){
        return $this->deleterecord(array('id'=>$imageid));
    }
    public function blogimages($blogid){
        return $this->getrecords(array('blogid'=>$blogid),array('id','image'),array('sortorder','desc'));
    }
    public function renameimage($imageid,$name){
        return $this->updaterecord(array('image'=>$name),array('id'=>$imageid));
    }
    public function imageupdate($imagearr){
        $count=count($imagearr)-1;
        $updated = false;
        foreach($imagearr as $k=>$v){
            if($v == ''){
                continue;
            }
            $imagedata= explode('<e>',$v);
            $updated = $this->updaterecord(array('image'=>$imagedata[2],'sortorder'=>$count),array('id'=>$imagedata[1]));
            
            if($updated === false){
                break;
            }
            $count--;
        }
        return $updated === false ? false : true;
    }
}


?>