<?php

Class Setting extends Model{
    function __construct(){
        parent::__construct('setting',App::getappid());
    }
    public function getAppHeadFoot($appname){
        $appid = App::getappid($appname);
        $setting = $this->fetchQueryResults($this->query('select name,value from '.$this->table.' where app='.$appid.' and (name="headsrc" or name="footsrc")'));
        return $setting;
    }
    public function getAppSettings($appname){
        $appid = App::getappid($appname);
        $setting = $this->getrecords(array('app'=>$appid),array('type','name','value'));
        return $setting;
    }
    public function savekeywords($keywords){  
        $appid = Pxpedia::currentRole()['appid'];
        if($this->exists(array('app'=>$appid,'name'=>'keywords'))){
             $this->updaterecord(array('value'=>$keywords),array('app'=>$appid,'name'=>'keywords'));
        }
        else{
             $this->addrecord(array('type','app','name','value'),array('globalpage',$appid,'keywords',$keywords));
        }
    }
    public function savefile($sourcefile,$name){
        $appid = Pxpedia::currentRole()['appid'];
        $sourcefilepath = [];
        foreach($sourcefile as $sf=>$sfv){
             if($sfv['error'] == 0){
                if(strpos($name,'.css') !== false || strpos($name,'.ico') !== false){
                    $sourcefilepath[$sf] = 'styles/'.$name;
                    $newfile = Pxpedia::getConfig('approot').Pxpedia::appById($appid).'/views/'.Pxpedia::currentTheme().'/styles/'.$name;
                }
                else{
                    $sourcefilepath[$sf] = Pxpedia::appById($appid).'/'.$name;
                    $newfile = Pxpedia::getConfig('resources').Pxpedia::appById($appid).'/'.$name;
                }
                $moved = move_uploaded_file($sfv['tmp_name'],$newfile);
             }
        }
        return $sourcefilepath;
    }
    public function savehead($head,$appid){
        list($sourcefilename,$sourcefilepath) = $head;
        $head = array();
       
        foreach($sourcefilename as $sf=>$sfv){
             $head[$sfv] = $sourcefilepath[$sf];
        }
       
        if($this->exists(array('app'=>$appid,'name'=>'headsrc'))){
             $this->updaterecord(array('value'=>json_encode($head)),array('app'=>$appid,'name'=>'headsrc'));
        }
        else{
             $this->addrecord(array('type','app','name','value'),array('globalpage',$appid,'headsrc',json_encode($head)));
        }
    }
    public function savefoot($foot,$appid){
        list($sourcefilename,$sourcefilepath) = $foot;
        $foot = array();
       
        foreach($sourcefilename as $sf=>$sfv){
             $foot[$sfv] = $sourcefilepath[$sf];
        }
        
        if($this->exists(array('app'=>$appid,'name'=>'footsrc'))){
             $a = $this->updaterecord(array('value'=>json_encode($foot)),array('app'=>$appid,'name'=>'footsrc'));
        }
        else{
             $a = $this->addrecord(array('type','app','name','value'),array('globalpage',$appid,'footsrc',json_encode($foot)));
        }
    }
    public function savedb($data,$appid){
        if($data['dbhost'] != ''){
            if($this->exists(array('name'=>'dbsetting','app'=>$appid))){
               $update = $this->updaterecord(array('value'=>json_encode(array('dbhost'=>$data['dbhost'],'dbuser'=>$data['dbuser'],'dbpasswd'=>$data['dbpassword'],'dbname'=>$data['dbname']))),array('name'=>'dbsetting','app'=>$appid,'type'=>'globalpage')); 
            }
            else{
                $update = $this->addrecord(array('type','app','name','value'),array('globalpage',$appid,'dbsetting',json_encode(array('dbhost'=>$data['dbhost'],'dbuser'=>$data['dbuser'],'dbpasswd'=>$data['dbpassword'],'dbname'=>$data['dbname']))));
            }   
        }
        return $update;
    }
}


?>