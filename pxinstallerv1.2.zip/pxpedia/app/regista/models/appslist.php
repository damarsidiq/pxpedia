<?php

Class Appslist extends Model{
    function __construct(){
        parent::__construct('app',App::getappid());
    }
    public function appsdesc($appid){
        return $this->getrecord(array('id'=>$appid));
    }
    public function changename($name){
        if(!App::checkPermission(Pxpedia::currentRole()['appid'])){
            return false;
        }
        $oldname = App::appById(Pxpedia::currentRole()['appid']);
        $this->updaterecord(array('name'=>$name),array('id'=>Pxpedia::currentRole()['appid']));
        $paths = array();
        $paths[] = App::$config['approot'];
        $paths[] = App::$config['resources'];
        $paths[] = App::$config['uploads'];
        $paths[] = App::$config['views'];
        
        foreach($paths as $pk=>$pv){
            $rename =rename($pv.$oldname,$pv.$name); 
            if(!$rename){
                return false;
            }
        }
        return true;
    }
    public function userApps(){
        $apps           = array();
        $superadmin     = false;
        foreach(Pxpedia::userRole() as $rk=>$rv){
            $apps[] = $rv['appid'];
            if($rv['role'] == 1){
                $superadmin = true;
                break;
            }
        }
        if(!$superadmin)
            return $this->getrecords(array('id'=>array('in',$apps)));
        else{
            return $this->getrecords(null);
        }
    }
    public function createApp($appname,$empty=false){
        $newapp = $this->addrecord(array('name','creator'),array($appname,App::getUser()['id']));
        if($newapp){
            Pxpedia::createApp($appname,$empty);
            return $this->insertid();
        }
        else
            return false;
    }
    public function deleteApp($appid){
        Pxpedia::deleteApp($appid);
        $deleted = $this->deleterecords(array('id'=>$appid));
        if($deleted !== false){
            $this->query('delete from setting where app ='.$appid);
            $this->query('delete from userrole where appid ='.$appid);
            return $deleted;
        }
    }
}


?>