var formdata = [];
var stageconfirmed = false;
var completedstage = [];
var numofstage = 1;
var stagecompletecallback =[];
var already;

function prepforminput(){
    var formdataidx = 0;
    $.each($('input[type="text"],input[type="password"]'),function(eli,elem){
        formdataidx = formdata.length;
        
        formdata[formdataidx]  = [];
        formdata[formdataidx].name  = $(elem).attr('name');
        formdata[formdataidx].id    = $(elem).attr('id');
        formdata[formdataidx].value = $(elem).val();
        formdata[formdataidx].stage = $(elem).parent().parent().parent().parent().attr('id').split('installerstage')[1];
        
        if(parseInt(formdata[formdataidx].stage) > numofstage){
            numofstage = parseInt(formdata[formdataidx].stage);
        }
    });
    
    var stageidx = stagecompletecallback.length;
    stagecompletecallback[stageidx] = [];
    stagecompletecallback[stageidx].stage = 1;
    stagecompletecallback[stageidx].callback = function(){
        var cbparam = [$('#dbname').val(),$('#dbhost').val(),$('#dbuser').val(),$('#dbpassword').val()];
        confirmdbconn(cbparam);
    };
}

function confirmdbconn(cbparam){
    $('#confirmstage1').val('verifying...');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'pxinstaller',a:'checkdb',d:{dbname:cbparam[0],dbhost:cbparam[1],dbuser:cbparam[2],dbpasswd:cbparam[3]}}
    }).done(function(msg){
        $('#confirmstage1').val('Confirm');
        if(msg == '0'){
            $('#installerstage1').find('.formmessage').html('unable to connect to database').addClass('active');
            stageconfirmed=false;
        }
        
        if(stageconfirmed){
            nextstage(stageconfirmed);
        }
        else{
            completedstage.splice(already,1);
        }
    });
}

function updateformdata(inputid){
    var inputidx = false;
    for(var i=0;i<formdata.length;i++){
        if(formdata[i].id == inputid){
            inputidx = i;
            break;
        }
    }
    formdata[i].value = $('#'+inputid).val();
    if((typeof($('#'+inputid).attr('class')) !== 'undefined' && $('#'+inputid).attr('class').indexOf('required') !== -1) && (formdata[i].value == formdata[i].name || formdata[i].value == '')){
        $('#'+inputid).addClass('error');
        stageconfirmed = false;
    }
    else{
        $('#'+inputid).removeClass('error');
        stageconfirmed = parseInt(formdata[i].stage);
    }
}

function updateinstaller(){
    if(completedstage.length){
        already = false;
        for(var i=0;i<completedstage.length;i++){
            if(completedstage[i] == stageconfirmed){
                already = i;
                break;
            }
        }
        if(already===false){
            completedstage[completedstage.length] = stageconfirmed;
        }
    }
    else{
        already=0;
        completedstage[0] = stageconfirmed;
    }
    
    if(numofstage >= stageconfirmed){
        var callbackfn = false;
        if(stagecompletecallback.length){
            for(var i=0;i<stagecompletecallback.length;i++){
                if(stagecompletecallback[i].stage == stageconfirmed){
                    callbackfn = true;
                    stagecompletecallback[i].callback();
                    break;
                }
            }
        }
        if(!callbackfn){
            nextstage(stageconfirmed);
        }
    }
}

function nextstage(curstage){
    curstage+=1;
    $('.installerstage.active').removeClass('active');
    
    if(curstage > numofstage || $.inArray(curstage,completedstage)!==-1){
        for(var i=1;i<=(numofstage+1);i++){
            if($.inArray(i,completedstage) === -1){
                curstage = i;
                break;
            }
        }
    }
    $('#installerstage'+curstage).addClass('active');
    if(curstage>numofstage){
        startinstalling();
    }
}

function startinstalling(){
    $('#installationprogress').html('Installing...');
    
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'pxinstaller',a:'install',d:{username:$('#username').val(),email:$('#email').val(),password:$('#password').val()}}
    }).done(function(msg){
        if(msg=='1'){
            $('#installationprogress').html('Redirecting...');
            setTimeout(function(){
                window.location.reload();
            },3000);
        }
    });
}

$(document).ready(
    function () {
        prepforminput();
        registaforminput('body','input[type="text"],input[type="password"]');
        
        $('h3').on('click',function(event){
            event.stopPropagation();
            
            $('.installerstage').removeClass('active');
            $(this).parent().addClass('active');
        })
        
        $('.confirmstage').on('click',function(event){
            event.stopPropagation();
            stageconfirmed = true;
            var stagecontainer = $(this).parent();
            $.each($(stagecontainer).find('input[type="text"],input[type="password"]'),function(idx,elem){
                updateformdata($(elem).attr('id'));
                if(!stageconfirmed){
                    return false;
                }
            });
            
            if(stageconfirmed){
                $(stagecontainer).parent().prev().html('').removeClass('active');
                updateinstaller();
                return;
            }
            else{
                $(stagecontainer).parent().prev().html('please complete the form').addClass('active');
            }
        });
    }
);

function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }

            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password');
            }

            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text');
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }
        }
    });
}