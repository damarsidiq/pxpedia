/*

    <div id="messagebox">
        <div id="messageboxtitle"></div>
        <div id="messageboxcontent">
            <div id="messageboxmsg"></div>
            <div class="table">
                <div class="tablecell">

                </div>
            </div>
        </div>
        <div id="messageboxaction">

        </div>
    </div>

*/
function messagebox(){
    this.title = '';
    this.content = '';
    this.action = '';
    this.msg = '';
}

messagebox.prototype.updatemessage = function(content){
    this.content = content;
    $('#messageboxcontent').find('.tablecell').html(this.content);
    $('#messageboxmsg').html(this.msg).removeClass('error active');
};

messagebox.prototype.displayfunc = function(title,content,action){
    this.title = title;
    this.content = content;
    this.action = action;

    this.action = '<span id="closemessagebox"><span id="thexsign">X</span>Close</span>'+this.action;

    $('#messageboxtitle').html(this.title);
    $('#messageboxcontent').find('.tablecell').html(this.content);
    $('#messageboxaction').html(this.action);
    $('#messageboxmsg').html(this.msg).removeClass('error active');

    $('#messagebox').addClass('active');
    $('.pagecontainer').css('opacity','0.3');

    $('#closemessagebox').on('click',function(){
        $('#messagebox').removeClass('active');
         $('.pagecontainer').css('opacity','1');
    });
};

messagebox.prototype.dispmsg = function(themsg,fadeout){
    this.msg = themsg;
    $('#messageboxmsg').html(themsg).addClass('active').removeClass('error').css('opacity',1);
    if(fadeout){
        setTimeout(function(){
            $('#messageboxmsg').animate({'opacity':0},'slow',function(){
                $('#messageboxmsg').removeClass('active');
            });
        },4000);
    }
};

messagebox.prototype.errormsg = function(themsg,fadeout){
    this.msg = themsg;
    $('#messageboxmsg').html(themsg).addClass('active error').css('opacity',1);
    if(fadeout){
        setTimeout(function(){
            $('#messageboxmsg').animate({'opacity':0},'slow',function(){
                $('#messageboxmsg').removeClass('active');
            });
        },4000);
    }
};

messagebox.prototype.display = function(){
    this.action = '<span id="closemessagebox"><span id="thexsign">X</span>Close</span>'+this.action;

    $('#messageboxtitle').html(this.title);
    $('#messageboxcontent').find('.tablecell').html(this.content);
    $('#messageboxaction').html(this.action);
    $('#messageboxmsg').html(this.msg).removeClass('error active');

    $('#messagebox').addClass('active');

    $('#closemessagebox').on('click',function(){
        $('#messagebox').removeClass('active');
        $('.pagecontainer').css('opacity','1');
    });

    $('.pagecontainer').css('opacity','0.3');
};

messagebox.prototype.close = function(){
    $('#messagebox').removeClass('active');
    $('.pagecontainer').css('opacity','1');
};