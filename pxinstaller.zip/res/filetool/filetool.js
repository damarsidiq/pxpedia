function filetool(){
    this.workerparams       = false;
    this.thefiles           = false;
    this.progress           = false;
    this.fileupload         = false;
    this.filereadersupport  = false;
    this.formdatasupport    = false;
    this.progresssupport    = false;
    this.holder             = false;
    this.support            = false;
    this.formData           = false;
    this.filetype           = false;
    this.filename           = false;
    this.filesize           = false;
    this.filesizebyte       = false;
    this.fileloadarraybuff  = false;
    this.fileuploadinchunk  = false;
    this.chunksize          = false;
    this.numofchunk         = false;
    this.enduploadcallback  = false;
    this.onprogresscallback = false;
    this.progressval        = false;
    this.initialized 	    = false;
    this.filecount          = false;
    this.fileloading        = 0;
    
    var filetoolinst = this;
    
    this.fileuploadertests = {
        filereader: typeof FileReader != 'undefined',
        dnd: 'draggable' in document.createElement('span'),
        formdata: !!window.FormData,
        progress: "upload" in new XMLHttpRequest()
    };
  
    this.acceptedTypes={
      'image/png': true,
      'image/jpeg': true,
      'image/gif': true
    };
    
    
    if(this.fileuploadertests.formdata)
        this.formData = new FormData();
    
    this.init = function(){       
        if(this.initialized) return;
 
        this.support= {
            filereader  : this.fileuploadertests.filereader   === false ? false     : (filetoolinst.filereadersupport ? $(filetoolinst.filereadersupport).addClass('hidden')    : false),
            formdata    : this.fileuploadertests.formdata     === false ? false     : (filetoolinst.formdatasupport ? $(filetoolinst.formdatasupport).addClass('hidden')        : false),
            progress    : this.fileuploadertests.progress     === false ? false     : (filetoolinst.progresssupport ? $(filetoolinst.progresssupport).addClass('hidden')        : false)
        };
        
        if(this.fileuploadertests.progress && this.progress !== false){
            this.onprogresscallback = function(progressval){
                filetoolinst.progressval = progressval;
                $(filetoolinst.progress).val(filetoolinst.progressval).html(filetoolinst.progressval);
            };
        }
        
        var filetoolobj = this;
        if (this.fileuploadertests.dnd && this.holder !== false) {
            $(this.holder).on('dragover',function(){
                $(this).addClass('hover'); return false; 
            });
            $(this.holder).on('dragend',function(){
                $(this).removeClass('hover'); return false;
            });
            $(this.holder).on('drop',function(e){
                e.originalEvent.preventDefault();
                var files = e.originalEvent.dataTransfer.files;
                var theholder = this;
                filetoolobj.fileuploaderhandle(files,theholder,filetoolobj);
            });
        }
        else {
            if(this.fileupload !== false){
               $(this.fileupload).removeClass('hidden');
               $(this.fileupload).on('change',function () {
                   var files =  this.files;
                   var theholder = filetoolobj.holder;
                   filetoolobj.fileuploaderhandle(files,theholder,filetoolobj);
               });   
            }
        }
    };
    this.addhandler = function(type,elem,theholder){
        if(type == 'fileinput'){
            $(elem).removeClass('hidden');
            $(elem).on('change',function () {
                var files =  this.files;
                filetoolobj.fileuploaderhandle(files,theholder,filetoolobj);
            });  
            return;
        }
        else{
            $(elem).on('dragover',function(){
                $(this).addClass('hover'); return false; 
            });
            $(elem).on('dragend',function(){
                $(this).removeClass('hover'); return false;
            });
            $(elem).on('drop',function(e){
                e.originalEvent.preventDefault();
                var files = e.originalEvent.dataTransfer.files;
                var theholder = this;
                filetoolobj.fileuploaderhandle(files,theholder,filetoolobj);
            });
        }
    };
    this.resetfile=function(){
        $(this.holder).html('');
        this.thefiles           = false;
        this.filename           = false;
        this.filetype           = false;
        this.filesizebyte       = false;
        this.filesize           = false;
        this.fileuploadinchunk  = false;
        this.chunksize          = false;
        this.numofchunk         = false;
        this.fileloadarraybuff  = false;
        this.fileloading        = 0;
    };
    this.initFile=function(file){
        if(this.thefiles === false){
            this.thefiles           = [];
            this.filename           = [];
            this.filetype           = [];
            this.filesizebyte       = [];
            this.filesize           = [];
            this.fileuploadinchunk  = [];
            this.chunksize          = [];
            this.numofchunk         = [];
            this.fileloadarraybuff  = [];
            this.fileloading++;
        }
        this.thefiles[this.thefiles.length]                     = file;
        this.filename[this.filename.length]                     = file.name;
        this.filetype[this.filetype.length]                     = file.type;
        this.filesizebyte[this.filesizebyte.length]             = file.size;
        this.fileloadarraybuff[this.fileloadarraybuff.length]   = false;
        this.filesize[this.filesize.length]                     = Math.ceil(this.filesizebyte/1048576);
        
        
        if(this.filesize[this.filesize.length-1] > 12){
            this.fileuploadinchunk[this.fileuploadinchunk.length]       = true;
            this.chunksize[this.chunksize.length]                       = 12;
            this.numofchunk[this.numofchunk.length]                     = Math.ceil(this.filesize[this.filesize.length-1]/this.chunksize[this.chunksize.length-1]);
        }
        this.filecount+=1;
    };
    
    this.startupload=function(){
        if(this.fileloading){
            setTimeout(this.startupload,200);
        }
        else
            fileuploaderworker(filetoolinst);
    };
    
    var createObjectURL = function(blob){
        if (window.URL){
            return window.URL.createObjectURL(blob);
        } else if (window.webkitURL){
            return window.webkitURL.createObjectURL(blob);
        } else {
            return null;
        }
    };
    
    this.fileuploaderhandle = function(files,theholder,filetoolobj){
        filetoolobj.initFile(files[0]);
        if (filetoolobj.fileuploadertests.filereader === true) {
            var reader = new FileReader();
            if(filetoolobj.filetype[filetoolobj.filetype.length-1].indexOf('image') !== -1){
                var image = createObjectURL(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                if(image === null){
                    reader.readAsDataURL(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                    reader.onload = function () {
                        image = reader.result;
                        if(theholder !== false){
                            $(theholder).parent().addClass('imagecontainer');
                            if($(theholder).children().length == 1){
                                $(theholder).children().remove();
                            }
                            $(theholder).append('<img src='+ image + '>');   
                        }
                    };
                }
                else{
                    if(theholder !== false){
                        if($(theholder).children().length == 1){
                            $(theholder).children().remove();
                        }
                        $(theholder).parent().addClass('imagecontainer');
                        $(theholder).append('<img src='+ image + '>');   
                    }
                }
                var reader2 = new FileReader();
                reader2.readAsArrayBuffer(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                reader2.onload = function () {
                    filetoolobj.fileloading--;
                    filetoolobj.thefiles[filetoolobj.thefiles.length-1] = reader2.result;
                };   
            }
            else{
                var image = createObjectURL(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                if(image === null){
                    reader.readAsDataURL(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                    reader.onload = function () {
                        image = reader.result;
                    };
                }
                var reader2 = new FileReader();
                reader2.readAsArrayBuffer(filetoolobj.thefiles[filetoolobj.thefiles.length-1]);
                reader2.onload = function () {
                    filetoolobj.fileloading--;
                    filetoolobj.thefiles[filetoolobj.thefiles.length-1] = reader2.result;
                    if(theholder)
                        theholder.innerHTML += filetoolobj.filename[filetoolobj.filename.length-1] + ' ' + (filetoolobj.filesize[filetoolobj.filesize.length-1]) + 'MB';
                };
            }
        }else {
            if(theholder !== false)
                theholder.innerHTML += filetoolobj.filename[filetoolobj.filename.length-1] + ' ' + (filetoolobj.filesize[filetoolobj.filesize.length-1]) + 'MB';
        }
    };
    
    var fileuploaderworker = function(filetoolobj){
        if(filetoolobj.thefiles === false)
            return;
        
        var worker      = new Worker('res/filetool/pxworker.js');
        var postdata    = {workeraction:filetoolobj.workerparams.workeraction,app:filetoolobj.workerparams.app,p:filetoolobj.workerparams.p,a:filetoolobj.workerparams.a,d:filetoolobj.workerparams.d};
        
        worker.onmessage = function(event){
            var data = event.data;
            if(data !== 'testresponse'){
                if(typeof data === 'number'){
                    if(filetoolobj.onprogresscallback !== false){
                        if($.isArray(filetoolobj.onprogresscallback)){
                            filetoolobj.onprogresscallback[filetoolobj.filecount-1](data);
                            return;
                        }
                        filetoolobj.onprogresscallback(data);
                        
                    }
                }
                else{
                    if(data.indexOf('anotherchunk') !== -1){                   
                        chunkupload.start();
                    }
                    else{                        
                        if(filetoolobj.enduploadcallback !== false){
                            if($.isArray(filetoolobj.enduploadcallback)){
                                filetoolobj.enduploadcallback[filetoolobj.filecount-1](data);
                                filetoolobj.filecount-=1;
                                if(filetoolobj.filecount===0){
                                    filetoolobj.thefiles = false;
                                }
                                return;
                            }
                            filetoolobj.enduploadcallback(data);
                            filetoolobj.thefiles = false;
                        }
                    }
                }
            }
        };
        worker.onerror = function(event){
            console.log("ERROR: " + event.filename + " (" + event.lineno + "): " + event.message);
        };
        
        var chunkuploadproto = function(filetoolobj){
            this.chunks     = [];
            this.file       = false;
            this.startByte  = 0;
            this.filesize   = false;
            this.chunksize  = false;
            this.numofchunk = false;
            this.currentchunk = 0;
            
            this.init = function(thefile,numofchunk,chunksize,filesizebyte){
                this.file       = thefile;
                this.chunksize  = chunksize;
                this.numofchunk = numofchunk;
                this.filesize   = filesizebyte;
                
                for(var i=0;i<this.numofchunk;i++){
                    var endbyte = this.startByte+this.chunksize;
                    if(endbyte >= this.filesize){
                        endbyte = this.filesize-1; 
                    }
                    this.chunks[i] = this.file.slice(this.startByte,endbyte);
                    this.startByte += this.chunksize;
                }
            };
            
            this.start = function(){
                if(this.currentchunk < this.numofchunk){                    
                    if(filetoolobj.onprogresscallback !== false){
                        var progressval = ((this.currentchunk/this.numofchunk) * 100);
                        filetoolobj.onprogresscallback(progressval);
                    }
                    
                    worker.postMessage(this.chunks[this.currentchunk],[this.chunks[this.currentchunk]]);
                    this.currentchunk+=1;
                }
            };
        };
        
        var transferableobj = new ArrayBuffer(1);
        worker.postMessage(transferableobj,[transferableobj]);
        if (transferableobj.byteLength) {
            // Transferables arent supported.
        } else {
            var chunkupload = new chunkuploadproto(filetoolobj);
            for(var iu=0;iu<filetoolobj.thefiles.length;iu++){
                if(filetoolobj.fileuploadinchunk[iu]){
                    postdata.fileinchunk = true;
                    postdata.numofchunk = filetoolobj.numofchunk[iu];
                }
                postdata.filetype=filetoolobj.filetype[iu];
                postdata.filename=filetoolobj.filename[iu];
                postdata.filesize=filetoolobj.filesize[iu];
                
                worker.postMessage(postdata);
                if(postdata.fileinchunk){
                    chunkupload.init(filetoolobj.thefiles[iu],filetoolobj.numofchunk[iu],(filetoolobj.chunksize[iu]*1048576),filetoolobj.filesizebyte[iu]);
                    chunkupload.start();
                }
                else{
                    worker.postMessage(filetoolobj.thefiles[iu],[filetoolobj.thefiles[iu]]);
                }       
            }
        }
    };
}