<?php
/**
 * db Class.
 */


/**
 *	Class db. The class that holds the database connection
 *
 *	Generally this class intermediates all the app's querying needs and store information related to it such as
 *	any errors produce and its description,the last query string executed, the results associative array.<br/>
 *	One of the main advantage of using this class is its ability to further process the conditional statement of a query input to suit
 *	its field type eg: string type value will be concatenated with a quote sign
 *
 *	@name db
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class db{
	/**
	 * @var int stores insertid of the last insert query,holds valid until the output is produce, any subsequent non-insert operation wont affect its value
	*/
    var $insertid;
	/**
	 * @var int stores the number of records deleted of the last delete operation,holds valid until the output is produce, any subsequent non-delete operation wont affect its value
	*/
    var $deleted;
	/**
	 * @var string currently accepts 'mysql' or 'mysqli'
	*/
    var $dbtype;
	/**
	 * @var object the database object after it is connected or false if failed
	*/
    var $db;
	/**
	 * @var array array of string of field type that needs a quote sign around its soon to be inserted value
	*/
    var $stringtype;
	/**
	 * @var array the results from the last select operation or false if it failed
	*/
    var $rows;
	/**
	 * @var int current index of the iteration operation of $rows starting from 0, incremented automatically in getRow function
	*/
    var $rowsix;
	/**
	 * @var array stores every error produce from queries executed
	*/
    var $errors;
	/**
	 * @var string the query string executed from the last operation
	*/
    var $querystring;


	/**
	 * @var string database host each instance of this class is connected to
	*/
    var $dbhost;
	/**
	 * @var string database authorized user each instance of this class is using
	*/
    var $dbuser;
	/**
	 * @var string database authorized password this instance of class is using
	*/
    var $dbpasswd;
	/**
	 * @var string database name this instance of class is connected to
	*/
    var $dbname;


    /**
	 * Constructor.
	 *
	 *
	 * @param string $dbname database name to connect
	 * @param string $dbhost hostname defaults to localhost
	 * @param string $dbuser user defaults to root
	 * @param string $dbpasswd defaults to empty
	 * @param string $dbtype defaults to 'mysqli'
	 */
    function __construct($dbname='',$dbhost='localhost',$dbuser='root',$dbpasswd='',$dbtype='mysqli'){
        $this->dbhost 		= $dbhost;
        $this->dbuser 		= $dbuser;
        $this->dbpasswd 	= $dbpasswd;
        $this->dbname 		= $dbname;
        $this->dbtype 		= $dbtype;
				$this->stringtype  	= array('char','varchar','tinytext','text','mediumtext','longtext','binary','varbinary','tinyblob','mediumblob','blob','longblob','enum','set','datetime','date','timestamp','time','year');

        switch($this->dbtype){
            case 'mysqli':
                $this->db = new mysqli($this->dbhost,$this->dbuser,$this->dbpasswd,$this->dbname);
                if($this->db->connect_error){
										echo 'error connecting to '.$this->dbname.' with account:'.$this->dbuser.' password: '.$this->dbpasswd.' on: '.$this->dbhost;
										return false;
                }
								else{ $this->db->set_charset("utf8");}
            break;
            case 'mysql':
                $this->db = mysql_connect($this->dbhost,$this->dbuser,$this->dbpasswd);
                if($this->db){
                    mysql_select_db($dbname,$this->db);
                    mysql_set_charset('utf8',$this->db);
                }
                else{
                    echo 'error connecting to '.$this->dbname.' with account:'.$this->dbuser.' password: '.$this->dbpasswd.' on: '.$this->dbhost;
										return false;
                }
            break;
        }
        $this->rows 	= array();
        $this->rowsix 	= 0;
        $this->errors 	= array();
    }
	/**
	 * Establishes new connection
	 *
	 * @param string $dbname database name to connect
	 * @param string $dbhost hostname defaults to localhost
	 * @param string $dbuser user defaults to root
	 * @param string $dbpasswd defaults to empty
	 * @param string $dbtype defaults to 'mysqli'
	 */
		public function connect($dbname='',$dbhost='localhost',$dbuser='root',$dbpasswd='',$dbtype='mysqli'){
				$this->dbhost 		= $dbhost;
        $this->dbuser 		= $dbuser;
        $this->dbpasswd 	= $dbpasswd;
        $this->dbname 		= $dbname;
        $this->dbtype 		= $dbtype;

				switch($this->dbtype){
            case 'mysqli':
                $this->db = new mysqli($this->dbhost,$this->dbuser,$this->dbpasswd,$this->dbname);
                if($this->db->connect_error){
										return false;
                }
								else{ $this->db->set_charset("utf8");return true;}
            break;
            case 'mysql':
                $this->db = mysql_connect($this->dbhost,$this->dbuser,$this->dbpasswd);
                if($this->db){
                    mysql_select_db($dbname,$this->db);
                    mysql_set_charset('utf8',$this->db);
										return true;
                }
                else{
										return false;
                }
            break;
        }
        $this->rows 		= array();
        $this->rowsix 	= 0;
        $this->errors 	= array();
		}
	/**
	 * Get columns from table
	 *
	 * @param string $tablename the table name
	 */
    public function getColumns($tablename){
        $column = array();
        $columnval = $this->query('SHOW COLUMNS FROM '.$tablename);
        if($columnval === false){
            return false;
        }

        if($this->dbtype == 'mysql'){
            while($col = mysql_fetch_assoc($columnval)){
               $column[] = $col;
            }
        }
        else{
            while($col = $columnval->fetch_assoc()){
               $column[] = $col;
            }
        }
        return $column;
    }
	/**
	 * Get fields descriptions from a table
	 *
	 * @param array $column the fields name
	 * @param string $tablename the tablename
	 *
	 * @return array -- $columndata(type,name,field) eg: Array([0] => Array   ( [type] => int  [name] => id [Field] => id )
	 * $columnval(field names) eg:id,app,name,status,settings,lastupdated,location ,
	 * $tablecol(Field,type,null,key,default,extra,type,name) eg: [Field] => id, [Type] => int(11), [Null] => NO, [Key] => PRI, [Default] => , [Extra] => auto_increment, [type] => int, [name] => id
	 */
    public function columnset($column,$tablename){
        if(is_array($column))
        foreach($column as $ck=>$cv){
            if(strpos($cv,' as ') !== false){
                $column[$ck] = explode(' as ',$cv);
                $column[$ck] = $column[$ck][0];
            }
        }
        else{
            if(strpos($column,' as ') !== false){
                $column = explode(' as ',$column);
                $column = $column[0];
            }
        }
        if(is_array($tablename)){
            $columndata = array();
            $tablecol = array();
            foreach($tablename as $tk=>$tv){
                $tablecolk = $this->getColumns($tv);
                if($tablecolk === false)
                    return $tablecolk;

                $tablecol = array_merge($tablecol,$tablecolk);
            }
        }
        else{
            $tablecol = $this->getColumns($tablename);
            if($tablecol === false){
                return false;
            }

            $columndata = array();
        }
            if(is_array($column) && count($column)>0){
                  foreach($tablecol as $ck=>$cv){
                      if(FALSE !== ($columnindex=array_search($cv['Field'], $column)) ){
                          $columndata[$columnindex]['type']   = substr($cv['Type'],0,  (strpos($cv['Type'], '('))===false? strlen($cv['Type']) : (strpos($cv['Type'], '(')) );
                          $tablecol[$ck]['type']              = $columndata[$columnindex]['type'];
                          $columndata[$columnindex]['name']   = $cv['Field'];
                          $columndata[$columnindex]['Field']  = $cv['Field'];
                          $tablecol[$ck]['name']              = $columndata[$columnindex]['name'];
                          $tablecol[$ck]['Field']             = $columndata[$columnindex]['name'];
                      }
                      else{
                          $tablecol[$ck]['type']              = substr($cv['Type'],0,  (strpos($cv['Type'], '('))===false? strlen($cv['Type']) : (strpos($cv['Type'], '(')) );
                          $tablecol[$ck]['name']              = $cv['Field'];
                          $tablecol[$ck]['Field']             = $cv['Field'];
                      }
                  }
                  $columnval = '('.implode(',',$column).')';
            }
            else{
                $columnval = '(';
                foreach($tablecol as $ck=>$cv){

                        $columnindex                        = count($columndata);
                        $columndata[$columnindex]['type']   = substr($cv['Type'],0,  (strpos($cv['Type'], '('))===false? strlen($cv['Type']) : (strpos($cv['Type'], '(')) );
                        $tablecol[$ck]['type']              = $columndata[$columnindex]['type'];
                        $columndata[$columnindex]['name']   = $cv['Field'];
                        $columndata[$columnindex]['Field']   = $cv['Field'];
                        $tablecol[$ck]['name']              = $columndata[$columnindex]['name'];
                        $tablecol[$ck]['Field']              =$cv['Field'];
                        $columnval.=$cv['Field'];
                        if($ck!=(count($tablecol)-1)){
                            $columnval .= ',';
                        }
                }
                $columnval.=')';
            }
			return array($columndata,$columnval,$tablecol);
    }
	/**
	 * Generate query for inserting multiple dataset into a single table
	 *
	 * @param string $tablename the table name
	 * @param array $column the field/fields name
	 * @param array $data the data values
	 *
	 * @return string the query string
	 */
    public function insertQuery($tablename,$column,$data){
        $q = 'insert into '.$tablename;
        $columnarr = $this->columnset($column,$tablename);
        $q.=$columnarr[1];
        $columndata = $columnarr[0];
        $q.=' values';
        if(count($data)){
            $dataval = '';
            $dataind = -1;
            foreach($data as $datak=>$datav){
                $dataind++;
                if(is_array($datav)){
                    $dataval.= '(';
                    foreach($datav as $k=>$v){
                        if(in_array($columndata[$k]['type'],$this->stringtype)){
                            if($v === NULL || $v === ''){
                                $v = '""';
                            }
                            else{
                                if($v[0]!='"'){
                                    $v= '"'.$v;
                                }
                                if($v[strlen($v)-1]!='"'){
                                    $v= $v.'"';
                                }
                            }
                        }
                        $dataval.=$v.',';
                    }
                    $dataval= substr($dataval, 0,-1). '),';
                }
                else{
                    if(in_array($columndata[$dataind]['type'],$this->stringtype)){
                        if($datav === NULL || $datav === ''){
                            $datav = '""';
                        }
                        else{
                            if($datav[0]!='"'){
                                $datav= '"'.$datav;
                            }
                            if($datav[strlen($datav)-1]!='"'){
                                $datav= $datav.'"';
                            }
                        }
                    }
                    $dataval .= $dataind == 0 ? ((count($data) == 1) ? '('.$datav.'),' : '('.$datav.',') : ($dataind == (count($data)-1) ? $datav.'),' : $datav.',');
                }
            }
            $q.= substr($dataval,0,-1);
        }
        return $q;
    }
	/**
	 * Generate query for selecting records from a table
	 *
	 * @param string $tablename the table name
	 * @param mixed $column array of field/fields names, string of field name or null for all the field
	 * @param mixed $condition array of conditional requirement to meet or null for all
	 *
	 * @return string the query string
	 */
    public function selectQuery($tablename,$column=null,$condition=null){
        $q  = 'select ';
        $cval = is_array($column) ? (count($column) >0 ? implode(',',$column) : '*') : (($column===null) ? '*' : $column);

            $columnarr = $this->columnset($column,$tablename);
            $columndata = $columnarr[0];
            $tablecol = $columnarr[2];

        $q .= $cval;
        $q  .=' from '. (is_array($tablename) ? implode(',', $tablename) :$tablename);

		$q	 = $this->conditionalPart($condition,$q,$columndata,$tablecol);

        return  $q;
    }
	/**
	 * Generate the conditional part of a query
	 *
	 * @param mixed $condition conditional statement
	 * @param mixed $q query string
	 * @param array $columndata table column metadata
	 *
	 * @return string the appended query string
	 */
	public function conditionalPart($condition,$q,$columndata,$tablecol){
		if(is_array($condition) && count($condition)>0){
            $q.= ' where ';
            $conditioncount=0;
            foreach($condition as $index=>$value){
                if( strtolower($index)==='and' || strtolower($index)==='or'){
                    $q .= '(';
                    $countsubcondition = 0;
                    foreach ($value as $vk=>$vv){
                        if(is_string($vk)){
                            $q .= $vk.' ';
                            if(!is_array($vv)){
                                if(count($columndata)){
									$vv = $this->prepvalue($tablecol,$vk,$vv);
                                }
                            }
                            else{
								if(in_array(strtolower($vv[0]), array('=','!=','>', '<','<=','>=','=<','=>','like','not like') )){
									if((strtolower($vv[0]) == 'like' || strtolower($vv[0]) == 'not like') && strpos($vv[1],'%') === false){
										$vv[1] = '%'. $vv[1] .'%';
									}
									if(count($columndata)){
										$vv[1] = $this->prepvalue($tablecol,$vv[0],$vv[1]);
									}
								}
								else{
								    if(count($columndata)){
										if(!is_array($vv[1])){
											$vv[1] = $this->prepvalue($tablecol,$vv[0],$vv[1]);
										}
									}
								}
                            }

                            $q.= is_array($vv) ? (strtoupper($vv[0]) == 'IN' || strtoupper($vv[0]) == 'NOT IN' ? !is_string(array_keys($vv)[1]) ? ' '. $vv[0].' ('. implode(',',$vv[1]) .') ' : ' '.$vv[0].' ('.$this->selectQuery(array_keys($vv)[1],$vv[array_keys($vv)[1]][0],$vv[array_keys($vv)[1]][1]).') ' : $vv[0].$vv[1]) : '='.$vv.' ' ;
                            if($countsubcondition < (count($value)-1) ){
                                $q.=$index.' ';
                            }
                            $countsubcondition++;
                        }
                        else{
                            foreach($vv as $valkey=>$valval){
                                if(!is_array($valval)){
                                    if(count($columndata)){
										$valval = $this->prepvalue($tablecol,$valkey,$valval);
                                    }
                                }
                                else{
                                    /*operator operand array val*/
                                    if(in_array(strtolower($valval[0]), array('=','!=','>', '<','<=','>=','=<','=>','like','not like') )){
                                        if((strtolower($valval[0]) == 'like' || strtolower($valval[0]) == 'not like') && strpos($valval[1],'%') === false){
                                            $valval[1] = '%'. $valval[1] .'%';
                                        }
                                        if(count($columndata)){
											$valval[1] = $this->prepvalue($tablecol,$valval[0],$valval[1]);
                                        }
                                    }
									else{
										if(count($columndata)){
											if(!is_array($valval[1])){
												$valval[1] = $this->prepvalue($tablecol,$valval[0],$valval[1]);
											}
										}
									}
                                }

                                $q .= $valkey.' ';
                                $q.= is_array($valval) ? (strtoupper($valval[0]) == 'IN' || strtoupper($valval[0]) == 'NOT IN'? !is_string(array_keys($valval)[1]) ? ' '.$valval[0].' ('.implode(',',$valval[1]).') ' : ' '.$valval[0].' ('.$this->selectQuery(array_keys($valval)[1],$valval[array_keys($valval)[1]][0],$valval[array_keys($valval)[1]][1]).')  ' : $valval[0].' '.$valval[1].' ') : '='.$valval.' ' ;
                                if($countsubcondition < (count($value)-1) ){
                                    $q.=$index.' ';
                                }
                                $countsubcondition++;
                            }
                        }
                    }
                    $q .= ')';
                    if($conditioncount < (count($condition)-1) ){
                        $q.=$index.' ';
                    }
                    $conditioncount++;
                }
                else{
                    if(!is_array($value)){
                        if(count($columndata)){
							$value = $this->prepvalue($tablecol,$index,$value);
                        }
                    }
                    else{
                        if(isset($value[0]) && in_array(strtolower($value[0]), array('=','!=','>', '<','<=','>=','=<','=>','like','not like') )){
                            if((strtolower($value[0]) == 'like' || strtolower($value[0]) == 'not like') && strpos($value[1],'%') === false){
                                $value[1] = '%'. $value[1] .'%';
                            }
                            if(count($columndata)){
								$value[1] = $this->prepvalue($tablecol,$index,$value[1]);
                            }
                        }
						else{
							if(count($columndata)){
								if(isset($value[1]) && !is_array($value[1])){
									$value[1] = $this->prepvalue($tablecol,$value[0],$value[1]);
								}
							}
						}
                    }
                    $q .= $index.' ';
                    $q.= is_array($value) ? (strtoupper($value[0]) == 'IN' || strtoupper($value[0]) == 'NOT IN'? !is_string(array_keys($value)[1]) ? ' '.$value[0].' ('.implode(',',$value[1]).') ' : ' '.$value[0].' ('.$this->selectQuery(array_keys($value)[1],$value[array_keys($value)[1]][0],$value[array_keys($value)[1]][1]).')  ' : ' '.$value[0].' '.$value[1].' ') : '='.$value.' ' ;
                    if($conditioncount < (count($condition)-1) ){
                        $q.='and ';
                    }
                    $conditioncount++;
                }
            }
        }
		return  $q;
	}
	public function prepvalue($tablecol,$colname,$value){
		$coltype = $this->getColumnType($tablecol, $colname);
		if($coltype[1] !== FALSE){
			if($value == '' || ($value[0] !== '"' && $value[strlen($value)-1] !== '"')){
				$value = '"'. $this->escapestr($value) .'"';
			}
		}
		else{
			$value = (float) floatval(str_replace(' ','',$value));
		}
		return $value;
	}
	/**
	 * Retrieves column type
	 *
	 * @param array $tablecoldata the table fields data retrieved from getColumns function
	 * @param string $colname the field name to retrieve
	 *
	 * @return array the type of field, boolean of does it need the quote sign for insert statements
	 */
    public function getColumnType($tablecoldata,$colname){
        foreach($tablecoldata as $tk=>$tv){
            if($tv['Field'] === $colname){
                $thetype = $tv['type'];
                return array($thetype,  in_array($thetype, $this->stringtype));
            }
        }
    }
	/**
	 * Generate update query
	 *
	 * @param string $tablename the table name
	 * @param array $updated key value pair fieldname=>datavalue
	 * @param array $condition the conditional statement to meet
	 *
	 * @return string the query string
	 */
    public function updateQuery($tablename,$updated,$condition){
        $q = 'update '.$tablename.' set ';
        $fieldcount=0;

        $colarr = $this->columnset(array_keys($updated),$tablename);
        $columndata = $colarr[0];
        $tablecol = $colarr[2];

        foreach($updated as $uk=>$uv){
            $fieldcount++;

			$newval = $this->prepvalue($colarr[0],$uk,$uv);
            $q		.= $uk.'='. $newval;

            if($fieldcount<count($updated)){
                $q.=',';
            }
        }
        $q	 = $this->conditionalPart($condition,$q,$columndata,$tablecol);
        return $q;
    }
	/**
	 * Generate delete query
	 *
	 * @param string $tablename the table name
	 * @param array $condition the conditional statement to meet
	 *
	 * @return string the query string
	 */
    public function deleteQuery($tablename,$condition){
        $q = 'delete from '.$tablename;

		$columnarr = $this->columnset('*',$tablename);
		$columndata = $columnarr[0];
		$tablecol = $columnarr[2];

        $q	 = $this->conditionalPart($condition,$q,$columndata,$tablecol);
        return $q;
    }
	/**
	 * cleans the string for legal query operation
	 *
	 * @param string $str the string to clean
	 *
	 * @return string
	 */
    public function escapestr($str){
        if(is_array($str)){
            return $str;
        }
        if($this->dbtype == 'mysqli')
            return $this->db->real_escape_string($str);
        elseif($this->dbtype == 'mysql')
            return mysql_real_escape_string($str);
    }
	/**
	 * Execute a query string
	 *
	 * @param string $q the query string
	 *
	 * @return mixed the query object resulted from the operation or false if failed
	 */
    public function query($q){
        $this->rows     = array();
        $this->rowsix   = 0;
        $this->querystring = $q;

        if($this->dbtype == 'mysqli'){
            $query = $this->db->query($q);
        }
        elseif($this->dbtype == 'mysql'){
            mysql_select_db($this->dbname,$this->db);
            $query = mysql_query($q,$this->db);
        }
				else{
					return false;
				}

        if(!$query){
            $this->mysqlerror($q);
            return false;
        }

        if(strpos(strtolower($this->querystring),'insert into') !== false){
            if($this->dbtype == 'mysqli')
                $this->insertid = $this->db->insert_id;
            elseif($this->dbtype == 'mysql')
                $this->insertid = mysql_insert_id();
        }

        return $query;
    }
	/**
	 * Intermediary function for the fetchQueryResult function to work, basically it checks whether php is configured to use mysql native driver,
	 * if it isnt use fetch_array in a loop to populate $rows
	 *
	 * @param object $query the query object
	 * @param constant $resulttype result type could be MYSQLI_ASSOC,MYSQLI_NUM, or MYSQLI_BOTH.
	 *
	 * @return void
	 */
	public function mysqlindb_fetch_all($query,$resulttype = MYSQLI_ASSOC)
	{
	    if (method_exists('mysqli_result', 'fetch_all')){
			/*Compatibility layer with PHP < 5.3*/
			$this->rows = $query->fetch_all($resulttype);
		}
	    else{
			while ($arow = $query->fetch_array($resulttype)){
				$this->rows[] = $arow;
			}
		}
	}
	/**
	 * Fetch results in associative array
	 *
	 * @param object $query the query object
	 * @param bool $returnresult return $rows
	 *
	 * @return array associative array of the result set
	 */
    public function fetchQueryResult($query,$returnresult=false){
        if($this->dbtype == 'mysqli'){
			$this->mysqlindb_fetch_all($query,MYSQLI_ASSOC);
		}
        elseif($this->dbtype == 'mysql'){
            while ($row = mysql_fetch_array($query, MYSQL_ASSOC)) {
                $this->rows[] = $row;
            }
        }
        if($returnresult)
            return $this->rows;
    }
			/**
	 * Fetch results in associative array
	 *
	 * @param object $query the query object
	 * @param bool $returnresult return $rows
	 *
	 * @return array associative array of the result set
	 */
    public function fetchQueryResults($query,$returnresult=false){
        if($this->dbtype == 'mysqli'){
			$this->mysqlindb_fetch_all($query,MYSQLI_ASSOC);
		}
        elseif($this->dbtype == 'mysql'){
            while ($row = mysql_fetch_array($query, MYSQL_ASSOC)) {
                $this->rows[] = $row;
            }
        }
        if($returnresult)
            return $this->rows;
    }
	/**
	 * Insert data to table
	 *
	 * @param string $tablename the table name
	 * @param mixed $column string or array of the column name/names
	 * @param mixed $data string or array of the data
	 *
	 * @return mixed the insert ID if success,false otherwise
	 */
    public function insertRows($tablename,$column,$data){
        $q      = $this->insertQuery($tablename, $column, $data);
        $insert = $this->query($q);

        if(!$insert){
            return false;
        }
        else{
            return $this->insertid;
        }
    }
	/**
	 * Checks if a record exists in a table
	 *
	 * @param string $tablename the table name
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return bool false if exists or an error occured, true otherwise
	 */
    public function exists($tablename,$condition=null){
	$querystr = $this->selectQuery($tablename,null,$condition);
        $query = $this->query($querystr);
        if(!is_bool($query)){
            $rows = array();
            if($this->dbtype == 'mysql'){
                while ($row = mysql_fetch_assoc($query)){
                    $rows[] = $row;
                }
            }
            else{
                while ($row = $query->fetch_assoc()){
                    $rows[] = $row;
                }
            }
            return count($rows) === 0 ? FALSE : TRUE;
        }
        else{
            $this->mysqlerror($querystr);
            return true;
        }
    }
	/**
	 * Retrieves record/records from a table
	 *
	 * @param string $tablename the table name
	 * @param mixed $column the column to include in the result
	 * @param mixed $condition conditional statement to meet
	 * @param mixed $order array in the form of (field,sortdirection) or string in the form 'field,sortdirection'
	 * @param mixed $limit array in the form of (offset,amount) or string in the form 'offset,amount'
	 *
	 *
	 * @return array the result or false if an error occured
	 */
    public function getRows($tablename,$column=null,$condition=null,$order=null,$limit=null){
        $limitq = $limit === null ? '' : (is_array($limit) ? ' limit '.$limit[0].','.$limit[1] : ' limit '.$limit);
        $orderq = is_array($order) ? (' order by '.$order[0].' '.$order[1]) : (($order===null) ? '' : ' order by '.$order) ;
        $querystr = $this->selectQuery($tablename,$column,$condition).$orderq.$limitq;

        $query  = $this->query($querystr);

        if(is_bool($query)){
            $this->mysqlerror($querystr);
            return false;
        }
        else{
            $this->fetchQueryResult($query);
        }
        return $this->rows;
    }
	/**
	 * Count the result from the last select operation
	 *
	 * @return int
	 */
    public function count(){
        return count($this->rows);
    }
	/**
	 * Retrieves one row from the result set
	 *
	 * @return array
	 */
    public function getRow(){
        $row = false;
        if($this->rowsix < count($this->rows)){
            $row = $this->rows[$this->rowsix];
            $this->rowsix++;
        }
        else{
            $this->rowsix = 0;
        }
        return $row;
    }
	/**
	 * Edit row/rows
	 *
	 * @param string $tablename the table name
	 * @param array $updated key value pair
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return mixed the number of rows affected or false if an error occured
	 */
    public function editRows($tablename,$updated,$condition){
        $edited = $this->query($this->updateQuery($tablename,$updated,$condition));
        if($this->dbtype == 'mysqli'){
            if($edited)
                return $this->db->affected_rows;
            else
                return false;
        }
        elseif($this->dbtype == 'mysql'){
            if($edited)
                return mysql_affected_rows();
            else
                return false;
        }
    }
	/**
	 * Get the number of items delete from last delete operation
	 *
	 * @return int
	 */
    public function deletednum(){
        return $this->deleted;
    }
	/**
	 * Perform a delete operation on a table
	 *
	 * @param string $tablename the table name
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return bool
	 */
    public function deleteRows($tablename,$condition=0){
        $this->deleted = 0;
        $delete =  $this->query($this->deleteQuery($tablename,$condition));
        if($delete){
            if($this->dbtype == 'mysqli'){
                $this->deleted = $this->db->affected_rows;
            }
            elseif($this->dbtype == 'mysql'){
                $this->deleted = mysql_affected_rows();
            }
        }
        return $delete;
    }
	/**
	 * Count how many record exists in a table, optionally as specified by the conditional statement
	 *
	 * @param string $tablename the table name
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return int
	 */
    public function countRows($tablename,$condition=null){
        $q = $this->selectQuery($tablename,'count(*) as numofrow',$condition);
        $numofrows = $this->query($q);

        if($numofrows){
            if($this->dbtype == 'mysqli')
                    $result = $numofrows->fetch_assoc();
            elseif($this->dbtype == 'mysql')
                    $result = mysql_fetch_assoc($numofrows);


            return $result['numofrow'];
        }
        return false;
    }
	/**
	 * Registers an error from a query operation, takes the query string that resulted in the error and calls mysql for the error log
	 *
	 * @param string $q the query string
	 *
	 * @return void
	 */
    public function mysqlerror($q=''){
        $erridx = count($this->errors);
        if($this->dbtype == 'mysqli')
            $this->errors[$erridx]['mysqli'] = $this->db->error;
        elseif($this->dbtype == 'mysql')
            $this->errors[$erridx]['mysql'] = mysql_error();

        $this->errors[$erridx]['query'] = $q;
    }
	/**
	 * Retrieves the error log
	 *
	 * @param bool $print whether to print directly or return the error string
	 *
	 * @return string
	 */
    public function printerrors($print=true){
        $output = '';
        if(count($this->errors)>0){
            foreach($this->errors as $erk=>$erv){
                if($this->dbtype == 'mysqli')
					if(isset($erv['mysqli']))
						$output .= $erk.'. '.$erv['mysqli'].'<br/><br/>';
					else
						$output .= print_r($erv,true);
                else
                    $output .= $erk.'. '.$erv['mysql'].'<br/><br/>';

                $output .= $erv['query'].'<br/><br/>';
				$output .= '=========================================';
            }
        }
        else{
            $output .= '0 errors found';
        }
        if($print)
            echo  $output;
        else
            return $output;
    }
	/**
	 * Retrieves the resulting insert ID from last insert operation
	 *
	 * @return int
	 */
    public function getinsertid(){
        return $this->insertid;
    }
}

