<?php
/**
 * Pxpedia Class.
 */


/**
 *	Class Pxpedia. Extension of the Application class
 *
 *	This class is responsible for regulating request to specific apps, creating database object for that app aside from the main database connection,
 *	CRUD operation of apps, users, sessions and basic app requirement like upload image,delete files etc
 *
 *
 *	@name Pxpedia
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class Pxpedia extends Application{
	/**
	 * @var array stores the current user descriptions
	*/
	public static $user;
	/**
	 * @var array stores the client browser descriptions
	*/
	public static $browser;
	/**
	 * @var string stores the client ip
	*/
	public static $visitorip;
	/**
	 * @var mixed stores the app's database object
	*/
	public static $appdb;
	/**
	 * @var bool an auxiliary variable for recursive functions
	*/
	public static $recursivebreak;

	/**
	 * @var string stores the page file name for the current request
	*/
	public static $page;
	/**
	 * @var string stores the view file name for the current request
	*/
	public static $view;
	/**
	 * @var string stores the plugin view file name
	*/
	public static $pluginview;
	/**
	 * @var string stores the function to execute on the page class instance
	*/
	public static $activity;
	/**
	 * @var array stores the data sent by the client
	*/
	public static $data;
	/**
	 * @var array stores valid html tags name
	*/
	public static $htmltags;
	/**
	 * @var bool stores the mobile client flag
	*/
	public static $isMobile;

	/**
	 * Constructor.
	 */
    function __construct(){
		parent::__construct();
		self::$user =  false;
		self::$appdb = false;
		self::$isMobile = null;

		self::htmltagsinit();
    }
	/**
	 * Create new app
	 *
	 * copies all the files in base/src to the newly created app folder
	 *
	 * @param string $appname the app name
	 *
	 * @return void
	 */
	public static function createApp($appname,$empty=false){
		@mkdir(self::$config['approot'].$appname);
		@mkdir(Pxpedia::getConfig('resources').$appname);
		@mkdir(self::$config['uploads'].$appname);
		@mkdir(self::$config['views'].$appname);

		if(!$empty){
			self::copyfileindir(self::$config['baseroot'].'/src/app',self::$config['approot'].$appname);
			self::copyfileindir(self::$config['baseroot'].'/src/views',self::$config['views'].$appname);
			self::copyfileindir(self::$config['baseroot'].'/src/res',Pxpedia::getConfig('resources').$appname);
		}
	}
	/**
	 * Delete an app
	 *
	 * @param int $appid the app ID to delete
	 *
	 * @return void
	 */
	public static function deleteApp($appid){
		$appname = Application::appById($appid);

		self::removedir(self::$config['approot'].$appname);
		self::removedir(Pxpedia::getConfig('resources').$appname);
		self::removedir(self::$config['uploads'].$appname);
		self::removedir(self::$config['views'].$appname);
	}
	/**
	 * Remove a directory
	 *
	 * @param string $dirpath the directory path
	 *
	 * @return bool
	 */
	public static function removedir($dirpath){
		ini_set('track_errors', 1);
		if(!file_exists($dirpath)){
			return false;
		}

		if(is_file($dirpath)){
			unlink($dirpath);
			return true;
		}
		else{
			$handle = opendir($dirpath);
			while(false !== ($thefile = readdir($handle))){
				if($thefile != '.' && $thefile != '..' ){
					Pxpedia::removedir($dirpath.'/'.$thefile);
				}
			}
			rmdir($dirpath);
		}
	}
	/**
	 * copy all files in a directory
	 *
	 * @param string $dirpathsrc the path to directory to copy
	 * @param string $dirpathdest the path to the directory of destination
	 *
	 * @return bool
	 */
	public static function copyfileindir($dirpathsrc,$dirpathdest){
        ini_set('track_errors', 1);
        if(is_file($dirpathsrc)){
            $copied = copy($dirpathsrc,$dirpathdest);
            if(!$copied){
                echo $dirpathsrc.'/'.$thefile.'--'.$dirpathdest.'/'.$thefile;
                exit();
                return false;
            }
        }
        else{
            $handle = opendir($dirpathsrc);
            while(false !== ($thefile = readdir($handle))){
                if($thefile != '.' && $thefile != '..' ){
                    if(is_dir($dirpathsrc.'/'.$thefile)){
                        @mkdir(($dirpathdest.'/'.$thefile), 0755, true);
                        $copied = Pxpedia::copyfileindir($dirpathsrc.'/'.$thefile,$dirpathdest.'/'.$thefile);
                        if(!$copied){
                            exit();
                            return false;
                        }
                    }
                    else{
                        if(!file_exists($dirpathdest)){
                            mkdir($dirpathdest, 0755, true);
                        }
                        $copied = copy($dirpathsrc.'/'.$thefile,$dirpathdest.'/'.$thefile);
                        if(!$copied){
                            echo $dirpathsrc.'/'.$thefile.'--'.$dirpathdest.'/'.$thefile;
                            exit();
                            return false;
                        }
                    }
                }
            }
            closedir($handle);
        }
        return true;
    }
	/**
	 * Gets the current theme
	 *
	 * @return string
	 */
	public static function currentTheme(){
		$theme = self::$config['theme'];

		if(($ctheme = self::getSessionVar('theme')) !== false){
			$theme = $ctheme;
		}
		return $theme;
	}
	/**
	 * Sets the current theme to use
	 *
	 * @param string $theme the theme name
	 *
	 * @return void
	 */
	public static function setCurrentTheme($theme){
		self::setConfig('theme',$theme);
	}
	/**
	 * Get config value
	 *
	 * @param string $key the config variable name
	 *
	 * @return mixed
	 */
	public static function getConfig($key){
		if($key == 'uploads')
			return self::$config[$key].Pxpedia::getAppname().'/';
		elseif($key =='appviews'){
			return self::getConfig('views').self::getAppname().'/'.self::$config['theme'];
		}

		return self::$config[$key];
	}
	/**
	 * Set config value
	 *
	 * @param string $tablename the table name
	 *
	 * @return string the query string
	 */
	public static function setConfig($key,$value){
		self::$config[$key] = $value;
	}
	/**
	 * getsourceurl. get sourced dom element url to use with getdomelem
	 *
	 * @param string $v the source name
	 *
	 * @return string the url string or false if file not found
	 */
	public static function getsourceurl($v){
		$url 		= file_exists(self::$config['views'].'/'. $v) ? self::$config['views']. $v : false;
		$url		= $url === false ? (file_exists(self::$config['resources'].$v) ? self::$config['resources'].$v : false) : $url;
		$url		= $url === false ? (file_exists($v) ? $v : false) : $url;

		return $url;
	}
	/**
	 * getdomelem. get dom element string to be appended
	 *
	 * @param string $v the source name
	 *
	 * @return string the dom element innerHTML
	 */
	public static function getdomelem($v){
		if(strpos($v,'.css') !== false){
			$url 		= self::getsourceurl($v);
			$domelem 	= $url === false ? '' : '<link rel="stylesheet" href="'. $url . '" type="text/css" media="all" />';
		}
		elseif(strpos($v,'.ico') !== false){
			$url 		= self::getsourceurl($v);

			$domelem 	= $url === false ? '' : '<link rel="icon" href="'. $url . '" type="image/x-icon" /><link rel="shortcut icon" href="'.$url . '" type="image/x-icon" />';
		}
		else{
			if(strpos($v,'|') !== false){
				$v 			= explode('|',$v);
				$url 		= self::getsourceurl($v[0]);
				$domelem 	= $url === false ? '' : '<script type="text/javascript" src="'. $url .'"';
				unset($v[0]);
				foreach($v as $vk=>$vv){
					$domelem .= ' '.$vv;
				}
				$domelem.='></script>';
			}
			else{
				$url 		= self::getsourceurl($v);
				$domelem 	= $url === false ? '' :'<script type="text/javascript" src="'. $url .'"></script>';
			}
		}
		return $domelem;
	}
	/**
	 * Gets the setting for head and foot document element
	 *
	 * @return array
	 */
	public static function getPageheadfootsrc(){
		$pv 			= array();
		$headsrcsetting = Pxpedia::getSetting(self::$config['currentapp'],'headsrc','globalpage');
		$footsrcsetting = Pxpedia::getSetting(self::$config['currentapp'],'footsrc','globalpage');

		if($headsrcsetting){
			$headsrc = array();
			foreach($headsrcsetting as $k=>$v){
				$headsrc[$k] = self::getdomelem($v);
			}
			if(count($headsrc))
				$pv['head'] = $headsrc;
		}
		else{
			$pv['head'] = array();
		}

		if($footsrcsetting){
			$footsrc = array();
			foreach($footsrcsetting as $k=>$v){
				$footsrc[$k] = self::getdomelem($v);
			}
			if(count($footsrc))
				$pv['foot'] = $footsrc;
		}
		else{
			$pv['foot'] = array();
		}
		return $pv;
	}
	/**
	 * Adds document element to the head or foot of the document
	 *
	 * @param array $pagesrc the document elements settings
	 * @param string $head elements to add to head
	 * @param string $foot elements to add to foot
	 *
	 * @return array
	 */
	public static function addheadfootsrc($pagesrc = false,$head=0,$foot=0){
		$head = $head === false ? 0 : $head;
		$foot = $foot === false ? 0 :$foot;

		if($pagesrc === false){
			$pv = self::getPageheadfootsrc();
		}
		else{
			$pv = $pagesrc;
		}

		if($head !== 0){
			if(!is_array($head)){
				$head = array($head);
			}
			$headsrc = array();
			foreach($head as $hkey=>$hval){
				$headsrc[$hkey] = self::getdomelem($hval);
			}
			$pv['head'] = isset($pv['head']) ? array_merge($pv['head'],$headsrc) : $headsrc;
		}

		if($foot !== 0){
			if(!is_array($foot)){
				$foot = array($foot);
			}

			$footsrc = array();
			foreach($foot as $fkey=>$fval){
				$footsrc[$fkey] = self::getdomelem($fval);
			}
			$pv['foot'] = isset($pv['foot']) ? array_merge($pv['foot'],$footsrc) : $footsrc;
		}
		return $pv;
	}
	/**
	 * excludes one element or more from document's head/foot
	 *
	 * @param array $pagesrc the document elements settings
	 * @param array $head elements to exclude from head
	 * @param array $foot elements to exclude from foot
	 *
	 * @return array
	 */
	public static function exclheadfootsrc($pagesrc = false,$head=0,$foot=0){
		$head = $head === false ? 0 : $head;
		$foot = $foot === false ? 0 :$foot;

		if($pagesrc === false){
			$pv = self::getPageheadfootsrc();
		}
		else{
			$pv = $pagesrc;
		}
		$headsrcsetting = $pv['head'];
		$footsrcsetting = $pv['foot'];

		if(is_array($head)){
			$headsrc = array();
			foreach($headsrcsetting as $k=>$v){
				if(in_array($k,$head) === false){
					$headsrc[$k] = $v;
				}
			}
			$pv['head'] = $headsrc;
		}
		if(is_array($foot)){
			$footsrc = array();
			foreach($footsrcsetting as $k=>$v){
				if(in_array($k,$foot) === false){
					$footsrc[$k] = $v;
				}
			}
			$pv['foot'] = $footsrc;
		}
		return $pv;
	}
	/**
	 * selects the element to include from the document's head/foot
	 *
	 * @param array $pagesrc the document elements settings
	 * @param array $head elements to exclude from head
	 * @param array $foot elements to exclude from foot
	 *
	 * @return array
	 */
	public static function incheadfootsrc($pagesrc = false,$head=0,$foot=0){
		$head = $head === false ? 0 : $head;
		$foot = $foot === false ? 0 :$foot;

		if($pagesrc === false){
			$pv = self::getPageheadfootsrc();
		}
		else{
			$pv = $pagesrc;
		}
		$headsrcsetting = $pv['head'];
		$footsrcsetting = $pv['foot'];

		if(is_array($head)){
			$headsrc = array();
			foreach($headsrcsetting as $k=>$v){
				if(in_array($k,$head)){
					$headsrc[$k] = $v;
				}
			}
			$pv['head'] = $headsrc;
		}
		if(is_array($foot)){
			$footsrc = array();
			foreach($footsrcsetting as $k=>$v){
				if(in_array($k,$foot)){
					$footsrc[$k] = $v;
				}
			}
			$pv['foot'] = $footsrc;
		}
		return $pv;
	}
	/**
	 * Generate the visitors profile
	 *
	 * @return void
	 */
	public function visitorProfile(){
		self::$browser 		= isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'unknown';
		self::$visitorip 	= $_SERVER['REMOTE_ADDR'];
	}
	/**
	 * Checks whether the clients is in mobile mode/using mobile device, thanks to of Heinrich Goebl's Mobile-Detect-2.8.22
	 *
	 * @return bool
	 */
	public static function isMobile(){
		if(is_null(self::$isMobile)){
			include_once(self::getConfig('resources').'Mobile-Detect-2.8.22/Mobile_Detect.php');

			$detect = new Mobile_Detect;
			self::$isMobile = $detect->isMobile();
		}
		return self::$isMobile;
    }
	/**
	 * Checks if current user's role is root
	 *
	 * @return bool
	 */
	public static function isRoot(){
		foreach(Pxpedia::userRole() as $rk=>$rv){
			if($rv['role'] == 1)
				return true;
		}
		return false;
	}
	/**
	 * Checks whether the current user's role is app admin
	 *
	 * @param int $app the app's ID
	 *
	 * @return bool
	 */
	public static function isAppadmin($app=false){
		foreach(Pxpedia::userRole() as $rk=>$rv){
			if($app !== false && $rv['appid'] == $app){
				if($rv['role'] == 2)
					return true;
			}
			else{
				if($rv['role'] == 2){
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * Gets the current user's role ID
	 *
	 * @return int
	 */
	public static function userRole(){
		return Pxpedia::getUser()['role'];
	}
	/**
	 * Get current user current role
	 *
	 * @return int
	 */
	public static function currentRole(){
		return Pxpedia::getUser()['currentrole'];
	}
	/**
	 * Switch role
	 *
	 * @param int $app the app ID
	 * @param int $role role ID
	 *
	 * @return void
	 */
	public static function switchRole($app,$role=false){
		$superadmin = false;
		foreach(Pxpedia::userRole() as $rk=>$rv){
			if($app == $rv['appid']){
				if($role !== false){
					if($rv['role'] == $role){
						$_SESSION[$_SESSION['currentapp']]['user']['currentrole'] = self::$user['currentrole'] =  $rv;
					}
				}
				else{
					$_SESSION[$_SESSION['currentapp']]['user']['currentrole'] = self::$user['currentrole'] = $rv;
				}
			}
			else{
				if($rv['role'] == 1){
					$superadmin = true;
				}
			}
		}
		if($superadmin && self::$user['currentrole']['role'] !== $role && self::$user['currentrole']['appid'] !== $app){
			$_SESSION[$_SESSION['currentapp']]['user']['currentrole'] = self::$user['currentrole'] = array('role'=>1,'appid'=>$app);
		}
	}
	/**
	 * Get user meta
	 *
	 * @param string $key meta key
	 *
	 * @return mixed
	 */
	public static function getUserMeta($key=false,$userid=false){
		if($userid===false){
			self::$user = self::getUser();
			if(self::$user)
				$userid = self::$user['id'];
		}
		$condition = array('userid'=>$userid);
		if($key)
			$condition['metakey'] =  $key;

		$metas = self::$db->getRows('usersdata',null,$condition);

		return $metas;

		return false;
	}
	/**
	 * getUserbyId. get user's description
	 *
	 * @param int $userid the user ID
	 *
	 * @return array
	 */
	public static function getUserbyId($userid){
		$userrow = self::$db->getRows('users',null,array('id'=>$userid));
		return $userrow;
	}
	/**
	 * loginuser. log user in
	 *
	 * @param int $userid the user ID
	 * @param int $appid the app ID
	 *
	 * @return void
	 */
	public static function loginuser($userid,$appid=false){
		$usersrow = self::getUserbyId($userid);
		if(count($usersrow) == 1){
			$user = $usersrow[0];
			$role = self::$db->getRows('userrole',array('role','appid'),array('userid'=>$user['id']));
			$user['role'] = $role;

			$user['currentrole'] = $role[0];
			if($appid)
				foreach($user['role'] as $rolek=>$rolev){
					if($rolev['appid'] == $appid){
						$user['currentrole'] = $role[$rolek];
					}
				}


			self::$user = $_SESSION[$_SESSION['currentapp']]['user'] = $user;
		}
	}
	/**
	 * getUser. get user's description in an associative array
	 *
	 * @return array
	 */
    public static function getUser(){
        if(!self::$user){
			if(isset($_SESSION[$_SESSION['currentapp']]['user'])){
				self::$user = $_SESSION[$_SESSION['currentapp']]['user'];
				return self::$user;
			}
            if(self::isLoggedin()){
				$user = $_SESSION[$_SESSION['currentapp']]['user'];
				if(!isset($_SESSION[$_SESSION['currentapp']]['user']['role'])){
					$role 					= self::$db->getRows('userrole',array('role','appid'),array('userid'=>$user['id']));
					$user['role'] 			= $role;
					$user['currentrole'] 	= $role[0];
				}
				else{
					$user['role'] 			= $_SESSION[$_SESSION['currentapp']]['user']['role'];
					$user['currentrole'] 	= $_SESSION[$_SESSION['currentapp']]['user']['currentrole'];

					self::$user = $_SESSION[$_SESSION['currentapp']]['user'] = $user;
				}
            }
        }
        return self::$user;
    }
	/**
	 * isLoggedin. checks whether the current client is logged in
	 *
	 * @return bool
	 */
    public static function isLoggedin(){
        if(isset($_SESSION[$_SESSION['currentapp']]['user'])){
           return true;
        }
		$apps 		= self::$db->getRows('app',array('name'));
		$loggedin 	= false;
		$appid 		= self::getappid($_SESSION['currentapp']);

		foreach($apps as $appk=>$appv){
			if($appv == $_SESSION['currentapp']){
				continue;
			}
			if(isset($_SESSION[self::getConfig('approot').$appv['name']]['user'])){
				$_SESSION[$_SESSION['currentapp']]['user'] = $_SESSION[self::getConfig('approot').$appv['name']]['user'];

				foreach($_SESSION[$_SESSION['currentapp']]['user']['role'] as $rk=>$rv){
					if($rv['appid'] == $appid){
						$_SESSION[$_SESSION['currentapp']]['user']['currentrole'] = $rv;
						break;
					}
				}
				self::$user = $_SESSION[$_SESSION['currentapp']]['user'];
				$loggedin = true;
				break;
			}
		}
        return $loggedin;
    }
	/**
	 * passwordcheck. checks user given plain text to the hash stored in the database
	 *
	 * @param string $plain the password's plain text
	 * @param array $user user's data
	 *
	 * @return bool
	 */
	public static function passwordcheck($plain,$user){
		date_default_timezone_set("Europe/Berlin");
		$user['registered'] = strtotime($user['registered']);
		$timemd = md5($user['registered']);
		$salt 	= substr($timemd,substr($user['registered'],7,1),substr($user['registered'],8,1));

		if(md5($plain.'~'.$salt) === $user['password']){
			return true;
		}
		return false;
	}
	/**
	 * createpasswordhash. hash user's plain text password and update the database
	 *
	 * @param array $user
	 *
	 * @return mixed the number of rows affected or false if an error occured
	 */
	public static function createpasswordhash($user){
		date_default_timezone_set("Europe/Berlin");
		$timestr 	= strtotime($user['registered']);
		$timemd 	= md5($timestr);
		$salt 		= substr($timemd,substr($timestr,7,1),substr($timestr,8,1));
		$hashedpass = md5($user['password'].'~'.$salt);

		return self::$db->editRows('users',array('password'=>$hashedpass),array('id'=>$user['id']));
	}
	/**
	 * login
	 *
	 * @param string $passwd the password plain text
	 * @param string $user the user's login email
	 * @param int $appid the table name
	 *
	 * @return int 0 means the user dont have an account to the specified app, 1 means wrong password, 2 means login was successful
	 */
  	public static function login($passwd,$user,$appid=false){
		$user = self::$db->getRows('users',null,array('email'=>$user));
		if($user !== false && count($user) == 1){
			$user = $user[0];
			if(self::passwordcheck($passwd,$user)){
				if($appid === false)
					$role = self::$db->getRows('userrole',array('role','appid'),array('userid'=>$user['id']));
				else{
					$role = self::$db->getRows('userrole',array('role','appid'),array('userid'=>$user['id'],'appid'=>$appid));

					if(!count($role)){
						return 0;
					}
				}
				$user['role'] = $role;
				$user['currentrole'] = $role[0];

				self::$user = $_SESSION[$_SESSION['currentapp']]['user'] = $user;
				return 2;
			}
			return 1;/*wrong password*/
		}
		else{
			return 0;/*0 account*/
		}
	}
	/**
	 * logout. unset current user login session
	 *
	 * @return void
	 */
	public static function logout(){
		$apps 		= self::$db->getRows('app',array('name'));
		$appid 		= self::getappid($_SESSION['currentapp']);

		foreach($apps as $appk=>$appv){
			if(isset($_SESSION[self::getConfig('approot').$appv['name']]['user'])){
				unset($_SESSION[self::getConfig('approot').$appv['name']]['user']);
			}
		}
	}
	public static function adduserrole($data,$appid=false){
			$appid = $appid === false ? self::getappid(self::getAppname()) : $appid;
			$role = 3;
			if(isset($data['role'])){
				if(is_array($data['role'])){
					foreach($data['role'] as $rolek=>$rolev)
					{
						$roleinsert = self::$db->insertRows('userrole',array('userid','role','appid'),array($data['id'],$rolev,$appid));
						if(!$roleinsert){
							return false;
						}
					}
				}
				else{
					$roleinsert = self::$db->insertRows('userrole',array('userid','role','appid'),array($data['id'],$data['role'],$appid));
					if(!$roleinsert){
						return false;
					}
				}
				return $data['id'];
			}
			return $data['id'];
	}
	/**
	 * register
	 *
	 * @param array $data the user's data, email, role (defaults to 3)
	 *
	 * @return bool
	 */
	public static function register($data,$appid=false){
		$user = self::$db->getRows('users',null,array('email'=>$data['email']));
		if(count($user)){
			return array(false,'email exist',$user[0]['id']);
		}

		$added = self::$db->insertRows('users',array('username','email','password','registered'),array($data['username'],$data['email'],$data['password'],date('Y-m-d H:i:s',time())));
		if(!$added)
			return $added;

		$user = self::$db->getRows('users',null,array('email'=>$data['email']))[0];
		self::createpasswordhash($user);

		$appid = $appid === false ? self::getappid(self::getAppname()) : $appid;
		$role = 3;
		if(isset($data['role'])){
			if(is_array($data['role'])){
				foreach($data['role'] as $rolek=>$rolev)
				{
					$roleinsert = self::$db->insertRows('userrole',array('userid','role','appid'),array($user['id'],$rolev,$appid));
					if(!$roleinsert){
						return false;
					}
				}
			}
			else{
				$roleinsert = self::$db->insertRows('userrole',array('userid','role','appid'),array($user['id'],$data['role'],$appid));
				if(!$roleinsert){
					return false;
				}
			}
		}
		else{
			$roleinsert = self::$db->insertRows('userrole',array('userid','role','appid'),array($user['id'],$role,$appid));
			if(!$roleinsert){
				return false;
			}
		}
		return $user['id'];
	}
	/**
	 * createdb
	 *
	 * @param array $dbsetting hostname,dbname,user and password
	 *
	 * @return mixed
	 */
	public function createdb($dbsetting = false){
		if($dbsetting == false){
			if(self::$appdb !== false){
				return;
			}
			$dbsetting = self::getSetting(self::$config['currentapp'],'dbsetting','globalpage');
			if($dbsetting){
				self::$appdb 	= new db($dbsetting['dbname'],$dbsetting['dbhost'],$dbsetting['dbuser'],$dbsetting['dbpasswd']);
			}
			else{
				self::$appdb = Application::getdb();
			}
		}
		else{
			$appdb 	= self::$appdb = new db($dbsetting['dbname'],$dbsetting['dbhost'],$dbsetting['dbuser'],$dbsetting['dbpasswd']);
			return $appdb;
		}
	}
	/**
	 * appdb. get and instantiate the app's database connection if not already
	 *
	 * @param mixed $app either app name or ID
	 *
	 * @return object
	 */
	public static function appdb($app=false){
		if($app == false)
			return self::$appdb;
		else{
			if(is_numeric($app)){
				$dbsetting = self::appSetting($app,'dbsetting','globalpage');
			}
			else
				$dbsetting = self::getSetting($app,'dbsetting','globalpage');

			if($dbsetting){
				$appdb 	= new db($dbsetting['dbname'],$dbsetting['dbhost'],$dbsetting['dbuser'],$dbsetting['dbpasswd']);
				return $appdb;
			}
			else{
				return self::$appdb;
			}
		}
	}
	/**
	 * oldsql. sql statement compatibility
	 *
	 * @param string $sql the sql statement
	 *
	 * @return string
	 */
	    public static function oldsql($sql){
		$sql = str_replace(array('current_timestamp()','current_timestamp'),array('null','null'),$sql);
		$sql = str_replace('not null default null','null',$sql);

		return $sql;
	    }
	/**
	 * parsexml. parse any hypertext string to an associative array
	 *
	 * @param string $file url of the file
	 * @param string $content file content
	 * @param bool $html is the content in html form
	 * @param bool $debug debug mode
	 *
	 * @return array
	 */
	public static function parsexml($file=false,$content=false,$html=false,$debug=false){
		$xmldata = array();
		$xddata = 0;
		$xddataix = 0;
		$parent = array(array(0,0,0));

		if($file !== false){
			$context=array(
				"ssl"=>array(
					"verify_peer"=>false,
					"verify_peer_name"=>false,
				),
			);
			$xmlfile = @fopen($file, 'rb', false, stream_context_create($context));
			$path = self::getConfig('uploads').'debuglog111_'.time().'.txt';
			if($xmlfile ===false){
				$handler = @fopen($path,'w');
				$response = fputs($handler,$file);
				return false;
			}
			if($debug){
				$handler = @fopen($path,'w');
				$debugcontents = '';
			}

			$openinghtmltag = false;
			$count = 0;
			while(($xmlline = fgets($xmlfile)) !== false){
				if($debug){
					$debugcontents .= $xmlline;
				}
				$xmlline 	= (trim($xmlline));

				if($html && !$openinghtmltag && strpos(strtolower($xmlline),'<html') !== false){
					$openinghtmltag = true;
					$xmlline 				= substr($xmlline,strpos(strtolower($xmlline),'<html'));
				}

				$xmlline 	= str_replace(array('<![CDATA[ ','<![CDATA[', ']]>','<!DOCTYPE html>','<!doctype html>'),'',$xmlline);
				$xmlline 	= str_replace('-->','</!-->',$xmlline);
				$xmlline 	= str_replace('<!--','<!-->',$xmlline);
				$xmlline 	= str_replace('<base','<!-->',$xmlline);
				$xmlline 	= str_replace('</base>','</!-->',$xmlline);
				$result 	= Pxpedia::parsetags($xmlline,false,$xmldata,$xddata,$xddataix,$parent,$html);

				$xmldata 	= $result[0];
				$xddata	 	= $result[1];
				$xddataix 	= $result[2];
				$parent 	= $result[3];
			}
			if($debug){
				$response = fputs($handler,$debugcontents);
			}
			fclose($xmlfile);
		}
		else{
			$xmlline 	= (trim($content));

			if($html && strpos(strtolower($xmlline),'<html') !== false){
				$xmlline 				= substr($xmlline,strpos(strtolower($xmlline),'<html'));
			}

			$xmlline 	= str_replace(array('<![CDATA[ ','<![CDATA[', ']]>','<!DOCTYPE html>','<!doctype html>' ),'',$xmlline);
			$xmlline 	= str_replace('-->','</!-->',$xmlline);
			$xmlline 	= str_replace('<!--','<!-->',$xmlline);
			$xmlline 	= str_replace('<base','<!-->',$xmlline);
			$xmlline 	= str_replace('</base>','</!-->',$xmlline);
			$result 	= Pxpedia::parsetags($xmlline,false,$xmldata,$xddata,$xddataix,$parent,$html);

			$xmldata 	= $result[0];
			$xddata	 	= $result[1];
			$xddataix 	= $result[2];
			$parent 	= $result[3];
		}
		return Pxpedia::xmltree($result[0]);
	}
	/**
	 * xmltree.
	 *
	 * @param array $parsed the parsed resulted from parsexml
	 * @param string $parent the parent tag of which the descendent would be extracted
	 * @param string $xmltree container for recursive operation
	 *
	 * @return array the tree
	 */
	public static function xmltree($parsed,$parent='',$xmltree=''){
		if($xmltree === '')
			$xmltree = array();
		if($parent === '')
			$parent = array(0,0);

		if(is_array($parsed)){
			foreach($parsed as $parsedkey=>$parsedval){
				foreach($parsedval as $nodekey=>$nodeval){
					if(!isset($nodeval['parent'])){
						continue;
					}
					if($nodeval['parent'][0] === $parent[0] && $nodeval['parent'][1] === $parent[1]){
						$nodeval['elements'] = Pxpedia::xmltree($parsed,array($parsedkey,$nodekey));
						$xmltree[] = $nodeval;
					}
				}
			}
		}
		return $xmltree;
	}
	/**
	 * updateparent
	 *
	 * @param string $parent the parent array
	 * @param string $recentclose the most recently closed tag
	 *
	 * @return array
	 */
	public static function updateparent($parent,$recentclose){
		if(count($parent) > 1){
			$removeix = -1;
			foreach($parent as $pk=>$pv){
				if($pv[0] === $recentclose[0] && $pv[1] === $recentclose[1]){
					$removeix = $pk;
				}
			}
			if($removeix !== -1){
				for($i=(count($parent)-1);$i>=$removeix;$i--){
					array_pop($parent);
				}
			}
			return $parent;
		}
	}
	/**
	 * parsetags
	 *
	 * @param string $string the string to parse
	 * @param bool $tagstripped operating on the attribute
	 * @param array $xmldata the tree data
	 * @param string $xddata the node's elements : closed,content,attributeclosed,attribute,parent,elements
	 * @param int $xddataix xddata index
	 * @param array $parent parent array of the current element
	 * @param bool $html
	 *
	 * @return array ($xmldata,$xddata,$xddataix,$parent)
	 */
	public static function parsetags($string,$tagstripped,$xmldata,$xddata,$xddataix,$parent,$html){
		if($tagstripped){
			$line = explode(' ',$string);
			if(count($line)){
				$xddata = $line[0];

				if(isset($xmldata[$xddata])){
					$xddataix = count($xmldata[$xddata]);
				}
				else{
					$xmldata[$xddata] = array();
					$xddataix = 0;
				}
				$xmldata[$xddata][$xddataix]['closed'] =false;/*
				$xmldata[$xddata][$xddataix]['debug'] ='1';
				$xmldata[$xddata][$xddataix]['debugco'] = print_r($line,true);*/
				$xmldata[$xddata][$xddataix]['content'] ='';
				$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
				$xmldata[$xddata][$xddataix]['attribute'] = array();
				$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
				$parent[count($parent)-1][2]++;
				$parent[] = array($xddata,$xddataix,0);

				$opparenthesis = false;
				foreach($line as $lineix =>$linev){
					$attridx = $fillindx = count($xmldata[$xddata][$xddataix]['attribute']);

					if(strpos($linev,'"') !== false){
						if(substr_count($linev,'"') == 1){
							if($opparenthesis){
								$opparenthesis = false;
								$attridx = $attridx == 0 ? 0 : $attridx-1;
							}
							else{
								$opparenthesis = true;
							}
						}
					}
					elseif(strpos($linev,"'") !== false){
						if(substr_count($linev,"'") == 1){
							if($opparenthesis){
								$opparenthesis = false;
								$attridx = $attridx == 0 ? 0 : $attridx-1;
							}
							else{
								$opparenthesis = true;
							}
						}
					}
					elseif($opparenthesis){
						$attridx = $attridx == 0 ? 0 : $attridx-1;
					}

					if($attridx == $fillindx && !$opparenthesis)
						$xmldata[$xddata][$xddataix]['attribute'][] = $linev;
					else{
						if(!isset($xmldata[$xddata][$xddataix]['attribute'][$attridx]))
							$xmldata[$xddata][$xddataix]['attribute'][$attridx] = '';
						$xmldata[$xddata][$xddataix]['attribute'][$attridx] .= ' '. $linev;
					}
				}
			}
			else{
				$xddata = $string;

				if(isset($xmldata[$xddata])){
					$xddataix = count($xmldata[$xddata]);
				}
				else{
					$xmldata[$xddata] = array();
					$xddataix = 0;
				}
				$xmldata[$xddata][$xddataix]['closed'] =false;/*
				$xmldata[$xddata][$xddataix]['debug'] ='2';*/
				$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
				$xmldata[$xddata][$xddataix]['content'] ='';
				$xmldata[$xddata][$xddataix]['attribute'] = array();
				$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
				$parent[count($parent)-1][2]++;
				$parent[] = array($xddata,$xddataix,0);
			}
		}
		else{
			$line = explode('<',$string);
			if(count($line)>1){
				foreach($line as $lineix=>$linev){
					if($linev === ''){
						continue;
					}
					if(substr($linev,0,1) === '/'){
						$closetag = explode('>',$linev);

						if(isset($xmldata[$xddata]) && $xmldata[$xddata][$xddataix]['attributeclosed'] == false){
							$xmldata[$xddata][$xddataix]['attributeclosed'] = true;/*
							$xmldata[$xddata][$xddataix]['debug'] ='4';*/
							$xmldata[$xddata][$xddataix]['attribute'][] = $closetag[0];

							if(isset($closetag[1]) && $closetag[1] != ''){/*
								$xmldata[$xddata][$xddataix]['debug'] ='3';*/
								$xmldata[$xddata][$xddataix]['content'] = $closetag[1];
							}

							$xddata = substr($closetag[0],1);

							if(isset($xmldata[$xddata])){
								for($i=(count($xmldata[$xddata])-1);$i>=0;$i--){
									$xddataix = $i;

									if(!$xmldata[$xddata][$xddataix]['closed']){
										$xmldata[$xddata][$xddataix]['closed'] = true;
										$parent = Pxpedia::updateparent($parent,array($xddata,$xddataix));
										break;
									}
								}
							}
						}
						else{
							if(count($closetag)>1){
								if(trim($closetag[1]) !== ''){
									$xddata = 'xmlcontent';

									if(isset($xmldata[$xddata])){
										$xddataix = count($xmldata[$xddata]);
									}
									else{
										$xmldata[$xddata] = array();
										$xddataix = 0;
									}
									$xmldata[$xddata][$xddataix]['closed'] =true;/*
									$xmldata[$xddata][$xddataix]['debug'] ='6';
									$xmldata[$xddata][$xddataix]['debugco'] =print_r($closetag,true);*/
									$xmldata[$xddata][$xddataix]['content'] =' '.$closetag[1];
									$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
									$xmldata[$xddata][$xddataix]['attribute'] = array('span');
									$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-2]);
									$parent[count($parent)-2][2]++;



									$xddata = substr($closetag[0],1);

									if(isset($xmldata[$xddata])){
										for($i=(count($xmldata[$xddata])-1);$i>=0;$i--){
											$xddataix = $i;

											if(!$xmldata[$xddata][$xddataix]['closed']){
												$xmldata[$xddata][$xddataix]['closed'] = true;
												$parent = Pxpedia::updateparent($parent,array($xddata,$xddataix));
												break;
											}
										}
									}
								}
								else{
									$xddata = substr($closetag[0],1);

									if(isset($xmldata[$xddata])){
										for($i=(count($xmldata[$xddata])-1);$i>=0;$i--){
											$xddataix = $i;

											if(!$xmldata[$xddata][$xddataix]['closed']){
												$xmldata[$xddata][$xddataix]['closed'] = true;
												$parent = Pxpedia::updateparent($parent,array($xddata,$xddataix));
												break;
											}
										}
									}
								}
							}
						}
					}
					else{
						$opentag = explode('>',$linev);
						if(count($opentag)>1){
							if($opentag[0] !== ''){
								if(substr($opentag[0],-1) === '/'){
									$completetag = explode(' ',$opentag[0]);
									if(count($completetag)){
										$xddata = $completetag[0];

										if(isset($xmldata[$xddata])){
											$xddataix = count($xmldata[$xddata]);
										}
										else{
											$xmldata[$xddata] = array();
											$xddataix = 0;
										}
										$xmldata[$xddata][$xddataix]['closed'] =true;/*
										$xmldata[$xddata][$xddataix]['debug'] ='7';*/
										$xmldata[$xddata][$xddataix]['content'] ='';
										$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
										$xmldata[$xddata][$xddataix]['attribute'] = array();
										$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
										$parent[count($parent)-1][2]++;


										$opparenthesis = false;
										foreach($completetag as $completetagix =>$completetagv){
											$attridx = $fillindx = count($xmldata[$xddata][$xddataix]['attribute']);

											if(strpos($completetagv,'"') !== false){
												if(substr_count($completetagv,'"') == 1){
													if($opparenthesis){
														$opparenthesis = false;
														$attridx = $attridx == 0 ? 0 : $attridx-1;
													}
													else{
														$opparenthesis = true;
													}
												}
											}
											elseif($opparenthesis){
												$attridx = $attridx == 0 ? 0 : $attridx-1;
											}

											if($attridx == $fillindx && !$opparenthesis)
												$xmldata[$xddata][$xddataix]['attribute'][] = $completetagv;
											else{
												if(!isset($xmldata[$xddata][$xddataix]['attribute'][$attridx]))
													$xmldata[$xddata][$xddataix]['attribute'][$attridx] = '';
												$xmldata[$xddata][$xddataix]['attribute'][$attridx] .= ' '. $completetagv;
											}
										}
									}
								}
								else{
									if(isset($xmldata[$xddata])){
										if($xmldata[$xddata][$xddataix]['attributeclosed'] === false){
											$xmldata[$xddata][$xddataix]['attribute'][] = $opentag[0];
										}
										else{
											$parsed = Pxpedia::parsetags($opentag[0],true,$xmldata,$xddata,$xddataix,$parent,$html);

											$xmldata = $parsed[0];
											$xddata = $parsed[1];
											$xddataix = $parsed[2];
											$parent = $parsed[3];
										}
									}
									else{
										$parsed = Pxpedia::parsetags($opentag[0],true,$xmldata,$xddata,$xddataix,$parent,$html);

										$xmldata = $parsed[0];
										$xddata = $parsed[1];
										$xddataix = $parsed[2];
										$parent = $parsed[3];
									}
								}
							}
							if(isset($opentag[1]) && $opentag[1] !== ''){
								$parsed = Pxpedia::xmltagcontent($opentag[1],$xmldata,$xddata,$xddataix);

								$xmldata 	= $parsed[0];
								$xddata 	= $parsed[1];
								$xddataix 	= $parsed[2];
							}
						}
						else{
							$opentag = explode(' ',$linev);
							if(count($opentag)){
								$xddata = $opentag[0];

								if($html && !in_array(strtolower($xddata),self::$htmltags)){
									$tempxddata = $parent[count($parent)-1][0];
									$tempxddataix = isset($xmldata[$tempxddata]) ? count($xmldata[$tempxddata])-1 : 0;
									if(!isset($xmldata[$tempxddata][$tempxddataix]) || !$xmldata[$tempxddata][$tempxddataix]['closed']){
										$xddata = 'xmlcontent';
										if(isset($xmldata[$xddata])){
											$xddataix = count($xmldata[$xddata]);
										}
										else{
											$xmldata[$xddata] = array();
											$xddataix = 0;
										}
										$xmldata[$xddata][$xddataix]['closed'] =true;/*
										$xmldata[$xddata][$xddataix]['debug'] ='44';*/
										$xmldata[$xddata][$xddataix]['content'] = ' '.implode(' ',$opentag);
										$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
										$xmldata[$xddata][$xddataix]['attribute'] = array('span');
										$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
										$parent[count($parent)-1][2]++;
									}
									else{
										$xddata = 'xmlcontent';

										if(isset($xmldata[$xddata])){
											$xddataix = count($xmldata[$xddata]);
										}
										else{
											$xmldata[$xddata] = array();
											$xddataix = 0;
										}
										$xmldata[$xddata][$xddataix]['closed'] =true;/*
										$xmldata[$xddata][$xddataix]['debug'] ='8';*/
										$xmldata[$xddata][$xddataix]['content'] =' '.implode(' ',$opentag);
										$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
										$xmldata[$xddata][$xddataix]['attribute'] = array('span');
										$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
										$parent[count($parent)-1][2]++;
									}
								}
								else{
									if(isset($xmldata[$xddata])){
										$xddataix = count($xmldata[$xddata]);
									}
									else{
										$xmldata[$xddata] = array();
										$xddataix = 0;
									}

									$xmldata[$xddata][$xddataix]['closed'] =false;/*
									$xmldata[$xddata][$xddataix]['debug'] ='9';*/
									$xmldata[$xddata][$xddataix]['content'] ='';
									$xmldata[$xddata][$xddataix]['attributeclosed'] =false;
									$xmldata[$xddata][$xddataix]['attribute'] = array();
									$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
									$parent[count($parent)-1][2]++;
									$parent[] = array($xddata,$xddataix,0);

									foreach($opentag as $opentagix =>$opentagv){
										$xmldata[$xddata][$xddataix]['attribute'][] = $opentagv;
									}
								}
							}
						}
					}
				}
			}
			else{
				$line = explode('>',$string);
				if(count($line)>1){
					if(isset($xmldata[$xddata])){
						if($xmldata[$xddata][$xddataix]['closed'] === false){
							$xmldata[$xddata][$xddataix]['closed'] =true;
						}
						if($xmldata[$xddata][$xddataix]['attributeclosed'] === false){
							$xmldata[$xddata][$xddataix]['attribute'][] = $line[0];
							$xmldata[$xddata][$xddataix]['attributeclosed'] = true;
						}
						else{

						}
					}
				}
				else{
					if(isset($xmldata[$xddata][$xddataix])){
						if($xmldata[$xddata][$xddataix]['attributeclosed'] === false){
							$xmldata[$xddata][$xddataix]['attribute'][] = $string;
						}
						else{
							if($xmldata[$xddata][$xddataix]['closed'] === false){/*
								$xmldata[$xddata][$xddataix]['debug'] ='10';*/
								$xmldata[$xddata][$xddataix]['content'] .= $string;
							}
							else{
								$parentofcurrrent = $xmldata[$xddata][$xddataix]['parent'];
								while(isset($xmldata[$parentofcurrrent[0]][$parentofcurrrent[1]])){
									if($xmldata[$parentofcurrrent[0]][$parentofcurrrent[1]]['closed'] == false){
										$xddata = 'xmlcontent';

										if(isset($xmldata[$xddata])){
											$xddataix = count($xmldata[$xddata]);
										}
										else{
											$xmldata[$xddata] = array();
											$xddataix = 0;
										}

										/*bugfix 24 may 17 : wrong parent assignment*/
										$xmldata[$xddata][$xddataix]['closed'] =true;/*
										$xmldata[$xddata][$xddataix]['debug'] ='11';*/
										$xmldata[$xddata][$xddataix]['content'] = ' '.$string;
										$xmldata[$xddata][$xddataix]['attributeclosed'] =true;
										$xmldata[$xddata][$xddataix]['attribute'] = array('span');
										$xmldata[$xddata][$xddataix]['parent'] = ($parent[count($parent)-1]);
										$parent[count($parent)-1][2]++;


										if(isset($xmldata[$xddata])){
											$xddataix = count($xmldata[$xddata])-1;

											if(!$xmldata[$xddata][$xddataix]['closed']){
												$xmldata[$xddata][$xddataix]['closed'] = true;
												$parent = Pxpedia::updateparent($parent,array($xddata,$xddataix));
											}
										}
										break;
									}
									else{
										$parentofcurrrent = $xmldata[$parentofcurrrent[0]][$parentofcurrrent[1]]['parent'];
									}
								}
							}
						}
					}
					else{

					}
				}
			}
		}
		return array($xmldata,$xddata,$xddataix,$parent);
	}
	/**
	 * xmltagcontent
	 *
	 * @param string $string content
	 * @param array $xmldata the tree array
	 * @param string $xddata the node's element index
	 * @param string $xddataix xddata index
	 *
	 * @return string the query string
	 */
	public static function xmltagcontent($string,$xmldata,$xddata,$xddataix){
		if(isset($xmldata[$xddata][$xddataix])){/*
			$xmldata[$xddata][$xddataix]['debug'] ='13';*/
			$xmldata[$xddata][$xddataix]['content'] .= $string;
		}
		return array($xmldata,$xddata,$xddataix);
	}
	/**
	 * _xmldata
	 *
	 * @param string $node the tag to extract description
	 * @param string $parentnode the parent tag name
	 * @param array $xmltree the tree array
	 * @param array $xmldata the extracted tree element
	 * @param int $count forever loop precaution variable
	 *
	 * @return array
	 */
	public static function _xmldata($node,$parentnode='',$xmltree,$xmldata='',$count=0){
		$count++;
		$xmldata =  $xmldata === '' ? array() : $xmldata;
		if(Pxpedia::$recursivebreak)
			return $xmldata;
		if(!empty($xmltree)){
			foreach($xmltree as $xmlkey =>$xmlval){
				if(!is_numeric($xmlkey)){
					if(isset($xmltree['elements']) && count($xmltree['elements'])){
						$xmldata = Pxpedia::_xmldata($node,$parentnode,$xmltree['elements'],$xmldata,$count);
					}
					else{
						return;
					}
				}

				if(is_array($node)){
					if($xmlval['attribute'][0] === $node['contenttag']){
						$foundnode = false;
						for($i=1;$i<count($xmlval['attribute']);$i++){
							if($node['contenttagattr'] == ''){
								$foundnode = true;
								if($parentnode !== ''){
									if($xmlval['parent'][0] === $parentnode){
										Pxpedia::$recursivebreak++;
										$xmldata[] = $xmlval;
									}
									else{
										$foundnode = false;
									}
								}
								else{
									Pxpedia::$recursivebreak++;
									$xmldata[] = $xmlval;
								}
							}
							else{
								if(strpos(trim($xmlval['attribute'][$i]),trim($node['contenttagattr'])) !== false ){
									if(strpos(trim($xmlval['attribute'][$i]),trim($node['contenttagattrvalue'])) !== false ){
										$foundnode = true;
										if($parentnode !== ''){
											if($xmlval['parent'][0] === $parentnode){
												Pxpedia::$recursivebreak++;
												$xmldata[] = $xmlval;
											}
											else{
												$foundnode = false;
											}
										}
										else{
											Pxpedia::$recursivebreak++;
											$xmldata[] = $xmlval;
										}
									}
								}
							}
						}
						if(!$foundnode){
							if(count($xmlval['elements'])){
								$xmldata = Pxpedia::_xmldata($node,$parentnode,$xmlval['elements'],$xmldata,$count);
							}
						}
					}
					else{
						if(count($xmlval['elements'])){
							$xmldata = Pxpedia::_xmldata($node,$parentnode,$xmlval['elements'],$xmldata,$count);
						}
					}
				}
				else{
					if(isset($xmlval['attribute']) && isset($xmlval['attribute'][0]) && $xmlval['attribute'][0] == $node){
						if($parentnode != ''){
							if($xmlval['parent'][0] == $parentnode){
								$xmldata[] = $xmlval;
							}
						}
						else{
							$xmldata[] = $xmlval;
						}
						Pxpedia::$recursivebreak++;
					}
					else{
						if(isset($xmlval['elements'])){
							if(count($xmlval['elements'])){
								$xmldata = Pxpedia::_xmldata($node,$parentnode,$xmlval['elements'],$xmldata,$count);
							}
						}
					}
				}
			}
			return $xmldata;
		}
	}
	/**
	 * xmldata. the 'interface' function for _xmldata
	 *
	 * @param string $node the table name
	 * @param string $parentnode the table name
	 * @param string $xmltree the table name
	 * @param string $xmldata the table name
	 *
	 * @return string the query string
	 */
	public static function xmldata($node,$parentnode='',$xmltree,$xmldata=''){
		Pxpedia::$recursivebreak = 0;
		$results    = Pxpedia::_xmldata($node,$parentnode,$xmltree,$xmldata);
		return $results;
	}
	/**
	 * appendTag. restructure to html form from an extracted tree form
	 *
	 * @param string $content tag's content string
	 * @param string $tag the tag's name
	 * @param bool $html means it should be verified against existing html tags
	 * @param int $openclose determines the tag element's close status.
	 *
	 * @return string the query string
	 */
	public static function appendTag($content,$tag,$html,$openclose=2){
		if($html){
			if(in_array(strtolower(trim($tag[0])),self::$htmltags)){
				if(in_array(strtolower(trim($tag[0])),array('br','img','::before','::after'))){
					if($openclose == 0)
						$content = $content.'<'.implode(' ', $tag).'>';
				}
				else{
					/*pdf quirk with div*/
					$tag[0] = str_replace('div','span',strtolower(trim($tag[0])));
					if($openclose === 0)
						$content = '<'. implode(' ',$tag) .'>'.$content;
					elseif($openclose === 1)
						$content = $content.'</'. $tag[0] .'>';
					else
						$content = '<'. implode(' ',$tag) .'>'.$content.'</'. $tag[0] .'>';
				}
			}
			else{
				$content = implode(' ',$tag);
				$tag = array('span');
				if($openclose === 0)
					$content = '<'. implode(' ',$tag) .'>'.$content;
				elseif($openclose === 1)
					$content = $content.'</'. strtolower(trim($tag[0])) .'>';
				else
					$content = '<'. implode(' ',$tag) .'>'.$content.'</'. strtolower(trim($tag[0])) .'>';
			}
		}
		return $content;
	}
	/**
	 * xmlelemsort
	 *
	 * @param array $xmltree
	 *
	 * @return array
	 */
	public static function xmlelemsort($xmltree){
		$sorted = array();
		for($i=0;$i<count($xmltree);$i++){
			$sorted[] = '';
		}

		foreach($sorted as $sk=>$sv){
			foreach($xmltree as $xk=>$xv){
				if($xv['parent'][2] == $sk){
					$sorted[$sk] = $xmltree[$xk];
					break;
				}
			}
		}
		return $sorted;
	}
	/**
	 * xmlcontent
	 *
	 * @param array $node
	 * @param array $xmltree
	 * @param string $content
	 * @param bool $html
	 * @param array $excludenode
	 * @param int $contentmaxlen
	 * @param array $defaultexclude
	 *
	 * @return string
	 */
	public static function xmlcontent($node='',$xmltree,$content='',$html=true,$excludenode=null,$contentmaxlen=false,$defaultexclude=array('iframe','!--','script','noscript')){
		if(count($xmltree)){
			if(isset($xmltree['content'])){
				$thetag = strtolower(trim($xmltree['attribute'][0]));
				$exclude = in_array($thetag,$defaultexclude) ? true : false;
				if(!is_null($excludenode) && !$exclude){
					foreach($excludenode as $exclk=>$exclv){
						if($thetag == $exclv['contenttag'] ){
							if($exclv['contenttagattr'] == '' && $exclv['contenttagattrvalue']=='' ){
								$exclude = true;
								break;
							}
							else{
								$attrcount = count($xmltree['attribute']);
								if($attrcount > 1){
									for($i=1;$i<$attrcount;$i++){
										$xattrv = $xmltree['attribute'][$i];
										$attrcheck = trim($xattrv);
										if(strpos($attrcheck,$exclv['contenttagattr'])!==false && strpos($attrcheck,$exclv['contenttagattrvalue'])!==false){
											$exclude = true;
											break;
										}
									}
								}
							}
						}
						if($exclude)
							break;
					}
				}
				if(!$exclude){
					if($node !== ''){
						if($xmltree['attribute'][0] === $node){
							$content .= Pxpedia::appendTag($xmltree['content'],$xmltree['attribute'],$html,0);
							if(count($xmltree['elements'])){
								$content = Pxpedia::xmlcontent('',Pxpedia::xmlelemsort($xmltree['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
							}
							$content .= Pxpedia::appendTag('',$xmltree['attribute'],$html,1);
						}
						else{
							if(count($xmltree['elements'])){
								$content = Pxpedia::xmlcontent($node,Pxpedia::xmlelemsort($xmltree['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
							}
						}
					}
					else{
						$content .= Pxpedia::appendTag($xmltree['content'],$xmltree['attribute'],$html,0);
						if(count($xmltree['elements'])){
							$content = Pxpedia::xmlcontent($node,Pxpedia::xmlelemsort($xmltree['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
						}
						$content .= Pxpedia::appendTag('',$xmltree['attribute'],$html,1);
					}
					if($contentmaxlen && strlen($content)>=$contentmaxlen){
						return $content;
					}
				}
			}
			else{
				foreach($xmltree as $xmlkey =>$xmlval){
					$thetag = strtolower(trim($xmlval['attribute'][0]));
					$exclude = in_array($thetag,$defaultexclude) ? true : false;
					if(!is_null($excludenode) && !$exclude){
						foreach($excludenode as $exclk=>$exclv){
							if($thetag == $exclv['contenttag']){
								if( $exclv['contenttagattr'] == '' && $exclv['contenttagattrvalue']=='' ){
									$exclude = true;
									break;
								}
								else{
									$attrcount = count($xmlval['attribute']);
									if($attrcount > 1){
										for($i=1;$i<$attrcount;$i++){
											$xattrv = $xmlval['attribute'][$i];
											$attrcheck = trim($xattrv);
											if(strpos($attrcheck,$exclv['contenttagattr'])!==false && strpos($attrcheck,$exclv['contenttagattrvalue'])!==false){
												$exclude = true;
												break;
											}
										}
									}
								}
							}
							if($exclude)
								break;
						}
					}
					if(!$exclude){
						if($node !== ''){
							if($xmlval['attribute'][0] === $node){
								$content .= Pxpedia::appendTag($xmlval['content'],$xmlval['attribute'],$html,0);
								if(count($xmlval['elements'])){
									$content = Pxpedia::xmlcontent('',Pxpedia::xmlelemsort($xmlval['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
								}
								$content .= Pxpedia::appendTag('',$xmlval['attribute'],$html,1);
							}
							else{
								if(count($xmlval['elements'])){
									$content = Pxpedia::xmlcontent($node,Pxpedia::xmlelemsort($xmlval['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
								}
							}
						}
						else{
							$content .= Pxpedia::appendTag($xmlval['content'],$xmlval['attribute'],$html,0);
							if(count($xmlval['elements'])){
								$content = Pxpedia::xmlcontent($node,Pxpedia::xmlelemsort($xmlval['elements']),$content,$html,$excludenode,$contentmaxlen,$defaultexclude);
							}
							$content .= Pxpedia::appendTag('',$xmlval['attribute'],$html,1);
						}
						if($contentmaxlen && strlen($content)>=$contentmaxlen){
							return $content;
						}
					}
				}
			}
			return $content;
		}
	}
	/**
	 * htmltagsinit
	 *
	 * @return void
	 */
	public static function htmltagsinit(){
		self::$htmltags = array();

		self::$htmltags[] = 'html';
		self::$htmltags[] = 'title';
		self::$htmltags[] = 'style';
		self::$htmltags[] = 'link';
		self::$htmltags[] = 'area';
		self::$htmltags[] = 'meta';
		self::$htmltags[] = 'head';
		self::$htmltags[] = 'body';
		self::$htmltags[] = 'source';
		self::$htmltags[] = 'svg';
		self::$htmltags[] = 'path';
		self::$htmltags[] = 'draw';
		self::$htmltags[] = 'select';
		self::$htmltags[] = 'textarea';
		self::$htmltags[] = 'map';
		self::$htmltags[] = 'abbr';
		self::$htmltags[] = 'audio';
		self::$htmltags[] = 'video';
		self::$htmltags[] = 'bdi';
		self::$htmltags[] = 'bdo';
		self::$htmltags[] = 'canvas';
		self::$htmltags[] = 'symbol';
		self::$htmltags[] = 'polygon';
		self::$htmltags[] = 'circle';
		self::$htmltags[] = 'path';
		self::$htmltags[] = 'ellipse';
		self::$htmltags[] = 'rect';
		self::$htmltags[] = 'g';
		self::$htmltags[] = 'u';
		self::$htmltags[] = 'section';
		self::$htmltags[] = 'footer';
		self::$htmltags[] = 'aside';
		self::$htmltags[] = 'picture';
		self::$htmltags[] = 'figure';
		self::$htmltags[] = 'h6';
		self::$htmltags[] = 'h5';
		self::$htmltags[] = 'h4';
		self::$htmltags[] = 'h3';
		self::$htmltags[] = 'h2';
		self::$htmltags[] = 'h1';
		self::$htmltags[] = 'iframe';
		self::$htmltags[] = 'embed';
		self::$htmltags[] = 'img';
		self::$htmltags[] = 'div';
		self::$htmltags[] = 'span';
		self::$htmltags[] = 'b';
		self::$htmltags[] = 'strong';
		self::$htmltags[] = 'br';
		self::$htmltags[] = '::before';
		self::$htmltags[] = '::after';
		self::$htmltags[] = 'a';
		self::$htmltags[] = 'p';
		self::$htmltags[] = 'ul';
		self::$htmltags[] = 'li';
		self::$htmltags[] = 'script';
		self::$htmltags[] = 'em';
		self::$htmltags[] = 'i';
		self::$htmltags[] = 'input';
		self::$htmltags[] = 'hgroup';
		self::$htmltags[] = 'time';
		self::$htmltags[] = 'wbr';
		self::$htmltags[] = 'code';
		self::$htmltags[] = 'cite';
		self::$htmltags[] = 'label';
		self::$htmltags[] = 'object';
		self::$htmltags[] = 'form';
		self::$htmltags[] = 'fieldset';
		self::$htmltags[] = 'header';
		self::$htmltags[] = 'blockquote';
		self::$htmltags[] = 'nav';
		self::$htmltags[] = 'noscript';
		self::$htmltags[] = 'ol';
		self::$htmltags[] = 'pre';
		self::$htmltags[] = 'small';
		self::$htmltags[] = 'sub';
		self::$htmltags[] = 'sup';
		self::$htmltags[] = 'hr';
		self::$htmltags[] = 'table';
		self::$htmltags[] = 'colgroup';
		self::$htmltags[] = 'col';
		self::$htmltags[] = 'tbody';
		self::$htmltags[] = 'tr';
		self::$htmltags[] = 'td';
		self::$htmltags[] = 'th';
		self::$htmltags[] = 'address';
		self::$htmltags[] = 'figcaption';
		self::$htmltags[] = 'caption';
		self::$htmltags[] = 'ins';
		self::$htmltags[] = 'article';
		self::$htmltags[] = 'button';
		self::$htmltags[] = 'progress';
		self::$htmltags[] = 'center';
		self::$htmltags[] = 'main';
		self::$htmltags[] = 'gcse:search';
		self::$htmltags[] = 'gcse:searchbox';
		self::$htmltags[] = 'gcse:searchbox-only';
		self::$htmltags[] = 'gcse:searchresults';
		self::$htmltags[] = 'gcse:searchresults-only';
		self::$htmltags[] = 'ytd-app';
		self::$htmltags[] = 'ytd-masthead';
		self::$htmltags[] = 'use';
		self::$htmltags[] = 'dt';
		self::$htmltags[] = 'dd';
		self::$htmltags[] = 'dl';
	}
	/**
	 * deleteFile
	 *
	 * @param string $file
	 * @param string $folder
	 *
	 * @return bool
	 */
	public static function deleteFile($file,$folder){
		$filetodelete = self::getConfig('uploads'). $folder .'/' . $file;
		return unlink($filetodelete);
	}
	/**
	 * uploadChunks
	 *
	 * @param array $chunk
	 * @param string $folder
	 * @param string $newfilename
	 *
	 * @return int
	 */
	public static function uploadChunks($chunk,$folder='',$newfilename=false){
		if($newfilename !== false){
			self::setSessionVar('chunkfilename',$newfilename);
		}
		else{
			$newfilename = self::getSessionVar('chunkfilename');
			if($newfilename === false){
				self::setSessionVar('chunkfilename',$chunk['name']);
				$newfilename = $chunk['name'];
			}
		}
		$location = $folder == '' ? App::getConfig('uploads').$newfilename : App::getConfig('uploads').$folder.'/'.$newfilename ;
        $towrite = file_get_contents($chunk['tmp_name']);
        $file = fopen($location,'a');
        $wrote = fwrite($file,$towrite,$chunk['size']);

		return $wrote;
	}
	/**
	 * uploadimage. return false upon error
	 *
	 * @param string $uploaded
	 * @param string $newfilename
	 * @param string $folder
	 * @param string $folderurl
	 *
	 * @return string
	 */
	public static function uploadimage($uploaded,$newfilename='',$folder='',$folderurl=false){
		$tempFile 	            = $uploaded['tmp_name'];
		$tempname 	            = $uploaded['name'];
		$newfilename			= $newfilename == '' ? time() : $newfilename;

		list($width,$height)    = getimagesize($tempFile);

		$nimg = imagecreatetruecolor($width,$height);

		$simgtype 	= explode('/',$uploaded['type']);
		$simgtypex 	= $simgtype[count($simgtype)-1];
		$imgtype 	= strtolower($simgtypex);

		if($imgtype === 'jpg' || $imgtype === 'jpeg')
			$oimg = imagecreatefromjpeg($tempFile);
		elseif($imgtype === 'gif')
			$oimg = imagecreatefromgif($tempFile);
		else
			$oimg = imagecreatefrompng($tempFile);

		imagecopyresampled($nimg, $oimg, 0, 0, 0, 0, $width, $height, $width, $height);

		$newfilename 	.=  '.png';
		$imglocation    = $folderurl ? $folder .'/'. $newfilename : self::getConfig('uploads'). $folder .'/' . $newfilename;
		$moved          = imagepng($nimg, $imglocation,0);

		if($moved){
			return $imglocation;
		}
		return false;
	}
	public static function imagewithsize($id,$size=0,$pathurl=false){
		$pathurl = $pathurl === false ? App::getConfig('uploads').'images' : $pathurl;
		$pathurl .= substr($pathurl,-1) == '/' ? '' : '/';
        switch($size){
            case 1:
                $nimgfile = $pathurl . $id.'_medium.png';
                if(!file_exists($nimgfile)){
                    $oimgfile = $pathurl . $id.'.png';
                    list($width,$height)    = getimagesize($oimgfile);

                    $thumbheight    = 300;
                    $thumbwidth     = (($thumbheight/$height) * $width);

            		$nimg       = @imagecreatetruecolor($thumbwidth,$thumbheight);
            		$oimg       = @imagecreatefrompng($oimgfile);
								if($oimg === false){
									return false;
								}


            		imagecopyresampled($nimg, $oimg, 0, 0, 0, 0, $thumbwidth, $thumbheight, $width, $height);
            		$imglocation    = $nimgfile;
            		$moved          = imagepng($nimg, $imglocation,0);
            		if($moved){
            		    return $imglocation;
            		}
            		return false;
                }
            break;
            case 0:
                $nimgfile = $pathurl. $id.'_thumb.png';
                if(!file_exists($nimgfile)){
                    $oimgfile = $pathurl. $id.'.png';
                    list($width,$height)    = getimagesize($oimgfile);

                    $thumbheight    = 100;
                    $thumbwidth     = (($thumbheight/$height) * $width);

            		$nimg       = @imagecreatetruecolor($thumbwidth,$thumbheight);
            		$oimg       = @imagecreatefrompng($oimgfile);
								if($oimg === false){
									return false;
								}

            		imagecopyresampled($nimg, $oimg, 0, 0, 0, 0, $thumbwidth, $thumbheight, $width, $height);
            		$imglocation    = $nimgfile;
            		$moved          = imagepng($nimg, $imglocation,0);
            		if($moved){
            		    return $imglocation;
            		}
            		return false;
                }
            break;
        }
        return $nimgfile;
    }
	/**
	 * appurl
	 *
	 * @param string $app the app's name
	 * @param array $param
	 * @param bool $retaincurrentparam
	 *
	 * @return string
	 */
	public static function appurl($app='',$param='',$retaincurrentparam = false){
		$domain = str_replace(array('127.0.0.1','::1'),'localhost',self::$config['domain']);
		$siteurl = substr($domain,-1) === '/' ? $domain : $domain.'/';
		if($app===''){
			$siteurl = isset($_SESSION['currentapp']) ? $siteurl.'?app='.Pxpedia::getAppname() : $siteurl;
		}
		else{
			$siteurl = $siteurl.'?app='.$app;
		}

		$theparam = $retaincurrentparam ? array('p'=>self::$page,'v'=>self::$view,'a'=>self::$activity,'d'=>self::$data) : array();

		if($param !== ''){
			$theparam = array_merge($theparam,$param);
		}
		foreach($theparam as $theparamk=>$theparamv){
			if(is_array($theparamv)){
				foreach($theparamv as $theparamvk=>$theparamvv){
					if(is_array($theparamvv)){
						foreach($theparamvv as $theparamvvk=>$theparamvvv){
							$siteurl .= '&'.$theparamk.'['. $theparamvk .']['. $theparamvvk .']='.$theparamvvv;
						}
					}
					else
						$siteurl .= '&'.$theparamk.'['. $theparamvk .']='.$theparamvv;
				}
			}
			else
				$siteurl .= '&'.$theparamk.'='.$theparamv;
		}
		return $siteurl;
	}
	/**
	 * pluginUrl
	 *
	 * @param string $plugin the plugin's location
	 * @param array $param
	 *
	 * @return void
	 */
	public static function pluginUrl($plugin,$param=''){
		$plugindesc 	= Application::getPluginByLoc($plugin,Pxpedia::getUser()['currentrole']['appid']);
		$pluginfolder   = $plugindesc['location'];
		$pluginid       = $plugindesc['id'];
		$pluginloc      = $plugindesc['location'].'/'.$pluginid;
		$pluginclass    = $param['p'].'_'.$plugindesc['location'];

		if(is_array($param)){
			$param['plugin'] = $pluginloc;
		}
		$param = array('d'=>array('plugindata'=>$param));
		echo Pxpedia::appurl('',$param,false);
	}
	/**
	 * resetSession.  unset a session variable previously assigned by setSessionVar
	 *
	 * @param string $varname
	 *
	 * @return void
	 */
	public static function resetSession($varname=false){
		if($varname === false){
			foreach($_SESSION as $sessionvark=>$sessionvarval){
				if(strpos($sessionvark,$_SESSION['currentapp']) !== false){
					unset($_SESSION[$sessionvark]);
				}
			}
		}
		else
			unset($_SESSION[$_SESSION['currentapp'].'_'.$varname]);
	}
	/**
	 * setSessionVar. sets app's specific session variable
	 *
	 * @param string $varname
	 * @param mixed $varval
	 * @param int $time
	 *
	 * @return void
	 */
	public static function setSessionVar($varname,$varval,$time=3600){
		$_SESSION[$_SESSION['currentapp'].'_'.$varname] = $varval;
		$_SESSION[$_SESSION['currentapp'].'_'.$varname.'_time'] = $time;
	}
	/**
	 * getSessionVar
	 *
	 * @param string $varname
	 *
	 * @return mixed
	 */
	public static function getSessionVar($varname){
		if(isset($_SESSION[$_SESSION['currentapp'].'_'.$varname]))
			return $_SESSION[$_SESSION['currentapp'].'_'.$varname];

		return false;
	}
	/**
	 * pagedata. gets client sents data
	 *
	 * @param string $varname
	 *
	 * @return mixed
	 */
	public static function pagedata($varname){
		if(isset(self::$data[$varname])){ return self::$data[$varname];}
		return false;
	}
	/**
	 * finalizeRequest. stores any data sent by the page asides from app,p,v,a,d
	 *
	 * @param array $postdata
	 * @param array $getdata
	 *
	 * @return void
	 */
	public static function finalizeRequest($postdata,$getdata){
		if(self::$page == 'undefined'){
			self::$page = 'home';
		}
		if(self::$activity == 'undefined'){
			self::$activity = 'pageInit';
		}
		if(is_string(self::$data)){
			self::$data = json_decode(self::$data,true);
		}
		unset($postdata['app']);
		unset($postdata['p']);
		unset($postdata['v']);
		unset($postdata['a']);
		unset($postdata['d']);

		unset($getdata['app']);
		unset($getdata['p']);
		unset($getdata['v']);
		unset($getdata['a']);
		unset($getdata['d']);

		if(is_array(self::$data)){
			self::$data = array_merge(self::$data,$postdata);
			self::$data = array_merge(self::$data,$getdata);
		}
	}
	/**
	 * run. load every active plugins and related controller to eventually calls the view file for html output
	 *
	 * @return void
	 */
	public function run(){
		if(!self::$config['debug']){
			error_reporting(0);
		}
		else{
			error_reporting(-1);
		}
		ini_set('user_agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 YaBrowser/17.9.1.982 (beta) Yowser/2.5 Safari/537.36');
		$this->visitorProfile();

		if($this->isMobile()){
				$this->setConfig('theme',$this->getConfig('mobiletheme'));
		}

		self::$page       = isset($_POST['p'])  ?  $_POST['p']  : (isset($_GET['p'])  ? $_GET['p'] : 'home');
		self::$view       = isset($_POST['v'])  ?  $_POST['v']  : (isset($_GET['v'])  ? $_GET['v'] : self::$page);
		self::$activity   = isset($_POST['a'])  ?  $_POST['a']  : (isset($_GET['a'])  ? $_GET['a'] : 'pageInit');
		self::$data       = isset($_POST['d'])  ?  (isset($_GET['d']) ? array_merge($_GET['d'],$_POST['d']) : $_POST['d'])  : (isset($_GET['d'])  ? $_GET['d'] : array());

		$finalpost 	= isset($_POST) ? $_POST : array();
		$finalget 	= isset($_GET) ? $_GET : array();

		self::finalizeRequest($finalpost,$finalget);

		$this->createdb();

		$controller 	= self::loadController(self::$page);
		$activity 	= self::$activity;
		if($controller === false){
			require_once(self::$config['baseroot'].'404.php');
			return;
		}
		if(!method_exists($controller,$activity)){
			require_once(self::$config['baseroot'].'404.php');
			return;
		}


		$cview 			= $controller->$activity(self::$data);
		self::$view		= is_null($cview) ? self::$view : $cview;
		self::$pluginview 	= false;
		if(isset(self::$data['plugindata'])){
			list(self::$pluginview,$pluginloc,$pluginfolder) = $controller->loadPlugin(self::$data['plugindata']);
			if(!is_null(self::$pluginview)){
				if(self::$pluginview == 'ajax' || self::pagedata('ajax')){
					self::$pluginview = 'plugins/'.$pluginloc.'/views/'.self::$pluginview.'.php';
					$controller->setPagevar('ajax',true);
					self::loadView(self::$pluginview,$controller);
					return;
				}
				self::$pluginview = 'plugins/'.$pluginloc.'/views/'.self::$pluginview.'.php';
			}
		}

		$activeplugins = Application::getActivePlugins();
		if(is_array($activeplugins)){
			if(isset(self::$data['plugindata'])){
				$excludeplug = explode('/',self::$data['plugindata']['plugin']);
				$excludeplug = $excludeplug[0];
				foreach($activeplugins as $apk=>$ape){
					if($ape['name'] == $excludeplug)
						continue;

					$ape['settings'] = json_decode($ape['settings']);
					$controller->applyPlugin($ape);
				}
			}
			else
				foreach($activeplugins as $apk=>$ape){
					$ape['settings'] = json_decode($ape['settings']);
					$controller->applyPlugin($ape);
				}
		}
		if(self::$pluginview !== false){
			self::$view = array(self::$view,self::$pluginview);
		}
		self::loadView(self::$view,$controller);
    }
}
?>
