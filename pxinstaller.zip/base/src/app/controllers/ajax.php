<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
}
?>