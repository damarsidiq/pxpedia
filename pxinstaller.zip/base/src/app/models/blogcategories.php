<?php
/**
 * BlogCategories model class.
 */

/**
 *	Class BlogCategories. class for BlogCategories table manipulation
 *	@name BlogCategories
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class BlogCategories extends Model{
    /**
	 * Constructor. 
	 */
    function __construct(){
        parent::__construct('blogcat');
    }
    /**
	 * getCategories. get blog categories
	 * 
	 * @return array
	 */
    public function getCategories(){
        $categories =  $this->getrecords();
        $assoc = array();
        if(count($categories) > 0){
            foreach($categories as $ck=>$cv){
                $assoc[$cv['id']] = $cv;
            }
        }
        return $assoc;
    }
    /**
	 * categories. get blog categories for hierarchical display
	 * 
	 * @return array
	 */
    public function categories($condition=null){
        $categories     =  $this->getrecords($condition,null,array('id','asc'));
        $assoc          = array();
        $assocparent    = array();
        
        if(count($categories) > 0){
            foreach($categories as $ck=>$cv){
                $assoc[$cv['id']] = $cv;
                $index = (int) $cv['parent'];
                $assocparent[$index][] =  $cv;
            }
        }
        return array($assoc,$assocparent);
    }
}


?>