<?php
/**
 * Blog model class.
 */

/**
 *	Class Blog. class for blog table manipulation
 *	@name Blog
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class Blog extends Model{
    /**
	 * Constructor. 
	 */
    function __construct(){
        parent::__construct('blog');
    }
    /**
	 * entries
	 *
	 * @param int $limit the model name
	 * @param int $offset the model name
	 * @param array $conditions the model name
	 * @param array $order the model name
	 * @param array $fields the model name
	 * 
	 * @return array
	 */
    public function entries($limit=30,$offset=0,$conditions=false,$order=array('id','desc'),$fields=null){
        $condi = array('status'=>1);
        if($conditions !== false){
            $condi = array_merge($condi,$conditions);
        }
        $blogs = $this->getrecords($condi,$fields,$order,$offset.','.$limit);
        return $blogs;
    }
     /**
	 * content. get blog content
	 *
	 * @param int $blogid the blog ID
	 * 
	 * @return array
	 */
    public function content($blogid){
        return $this->getrecord(array('id'=>$blogid),'content');
    }
}


?>