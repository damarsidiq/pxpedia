<?php
/**
 * configurations
 */

$domain         = 'http://'. $_SERVER['SERVER_ADDR'].':'.$_SERVER['SERVER_PORT'] .'/pxtest/';
$approot        = './app/';
$baseroot       = './base/';
$views      	  = './views/';
$resources      = './res/';
$uploads        = './uploads/';
$plugins        = './plugins/';

$defaultapp     = $approot.'regista';
$adminapp       = $approot.'regista';
$theme          = 'default';
$mobiletheme    = 'default';

$autoloadmodels = false;

$lang = 'en';
$debug = true;


if($_SERVER['REMOTE_ADDR'] =='127.0.0.1'){
 $domain  = 'http://localhost:'.$_SERVER['SERVER_PORT'] .'/pxtest/';
}