<?php
Class Pxinstaller extends Controller{
    var $stage;
    var $stagevar;
	function __construct(){
		parent::__construct();
		$this->stage = 0;
		$this->stagevar = array();
	}
	public function checkpage(){
		return false;
	}

	public function pageInit($data=false,$view='pxinstaller'){
			if(isset(App::$config['dbhost'])){
				header('Location:'.App::$config['domain'].'?app=regista');
			}
	    $this->setPagevar('pagesrc',array());
	    $this->addheadfootsrc(array('registastyle'=>App::getConfig('appviews').'/styles/style.css'),array());
	    $this->addheadfootsrc(array('pxinstallerstyle'=>App::getConfig('appviews').'/styles/pxinstaller.css'),array());
	    $this->addheadfootsrc(false,array('jquery'=>Pxpedia::getConfig('resources').'jquery/jquery-1.9.1.min.js'));
	    $this->addheadfootsrc(false,array('pxinstaller'=>Pxpedia::getConfig('resources').'regista/pxinstaller.js'));

	    $this->setPagevar('installer',true);

	    return $view;
	}
	public function install($data=false,$view='plain'){
	    $conn = $this->db->connect(App::getSessionVar('dbname'),App::getSessionVar('dbhost'),App::getSessionVar('dbuser'),App::getSessionVar('dbpasswd'));
	    if($conn){
	        $this->db->query('use '.App::getSessionVar('dbname'));
	        $query = file_get_contents(App::getConfig('resources').'regista/install.sql');

	        $q = $this->db->query('SHOW VARIABLES WHERE Variable_name = "version"');
            $r = $this->db->fetchQueryResults($q,true);
            if(floatval($r[0]['Value']) <= 5.5){
                $query = App::oldsql($query);
            }

	        $complete=true;
	        $queryx = explode(';',$query);
	        foreach($queryx as $xk=>$xv){
	            if(trim($xv)=='')
	                continue;

	            $exec = $this->db->query($xv.';');
	            if(!$exec){
	                $complete = false;
	                echo $this->db->printerrors(false);
	                break;
	            }
	        }

	        if($complete){
	            if($data!==false){
	                $this->db->query('insert into app(id,name,createdon,modified,creator) values(1,"regista","'.date('Y-m-d H:i:s',time()).'","'.date('Y-m-d H:i:s',time()).'",1)');
	                $appsetting['footsrc'] = array();
	                $appsetting['footsrc']['jquery_jquery-1'] = 'jquery/jquery-1.9.1.min.js';
	                $appsetting['footsrc']['jqueryui'] = 'jquery/jquery-ui-1.10.3.custom.min.js';
	                $appsetting['footsrc']['regista_registaminjs'] = 'regista/regista.min.js';
	                $appsetting['footsrc']['filetool_filetool'] = 'filetool/filetool.js';
	                $appsetting['footsrc']['filetool_pxworker'] = 'filetool/pxworker.js';

	                $appsetting['headsrc']  =   array();
	                $appsetting['headsrc']['regista_favicon'] = 'regista/default/styles/images/favicon.ico';
	                $appsetting['headsrc']['regista_style'] = 'regista/default/styles/style.css';

	                $appsetting['dbsetting'] =  array();
	                $appsetting['dbsetting']['dbhost'] = App::getSessionVar('dbhost');
	                $appsetting['dbsetting']['dbname'] = App::getSessionVar('dbname');
	                $appsetting['dbsetting']['dbpasswd'] = App::getSessionVar('dbpasswd');
	                $appsetting['dbsetting']['dbuser'] = App::getSessionVar('dbuser');

	                foreach($appsetting as $pk=>$pv){
	                    $set = $this->db->query('insert into setting(type,app,name,value) values("globalpage",1,"'.$pk.'",\''. json_encode($pv) .'\')');
	                    if(!$set){
        	                echo $this->db->printerrors(false);
        	                break;
	                    }
	                }

	                App::$db = $this->db;
	                $data['role'] = 1;
	                $register = App::register($data,1);
	                if(is_array($register)){
	                    echo '0';
	                }
	                elseif($register===false){
	                    echo '0';
	                }
	                else{
	                    $config = @fopen(App::getConfig('baseroot').'config.php','ab');
	                    if($config){
	                        $dbconfig = "\r\n\r\n";
				$dbconfig .='$dbhost="'.App::getSessionVar('dbhost').'";';
				$dbconfig .= "\r\n";
	                        $dbconfig .='$dbname="'. App::getSessionVar('dbname') .'";';
				$dbconfig .= "\r\n";
	                        $dbconfig .='$dbuser="'.App::getSessionVar('dbuser').'";';
				$dbconfig .= "\r\n";
	                        $dbconfig .='$dbpasswd="'.App::getSessionVar('dbpasswd').'";';
				$dbconfig .= "\r\n";
	                        $dbconfig .='$dbtype="mysqli";';

	                        $dbconfig = fputs($config,$dbconfig);
	                        if(!$dbconfig){
	                            echo '0';
	                        }
	                        else{
	                            echo '1';
	                        }
	                    }
	                    else{
	                        echo '0';
	                    }
	                }
	            }
	        }
	    }
	    return $view;
	}
	public function checkdb($data=false,$view='plain'){
	    if($data!==false){
	        $dbpasswd = $data['dbpasswd'] == 'db password' ? '' : $data['dbpasswd'];
	        $connect = $this->db->connect($data['dbname'],$data['dbhost'],$data['dbuser'],$dbpasswd);
	        if($connect){
	            App::setSessionVar('dbname',$this->db->dbname);
	            App::setSessionVar('dbhost',$this->db->dbhost);
	            App::setSessionVar('dbuser',$this->db->dbuser);
	            App::setSessionVar('dbpasswd',$this->db->dbpasswd);
	            echo '1';
	        }
	        else{
	            echo '0';
	        }
	        return 'plain';
	    }
	    echo '0';
	    return 'plain';
	}
}
