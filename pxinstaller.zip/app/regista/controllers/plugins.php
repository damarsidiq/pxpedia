<?php

Class Plugins extends Controller{
    function __construct() {
        parent::__construct();
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
		return true;
	}
    public function pageInit($data=null,$view='plugins'){
		if(isset($data['activatePlugin'])){
			$activated = $this->model('plugin')->activatePlugin($data['activatePlugin']);
			if($activated[1] != false){
				$response['msg'] 		= true;
				$response['pluginurl'] 	= $activated[0];
				$response['url'] 		= App::appurl('',array('p'=>'plugins','d'=>array('removePlugin'=>$activated[1])));
			}
			else{
				$response['msg'] = false;
			}
			$this->setPagevar('response',$response);
			return 'ajax';
		}
		elseif(isset($data['removePlugin'])){
			$this->setPagevar('ajax',true);
			$removed = $this->model('plugin')->removePlugin($data['removePlugin']);
			if($removed[1] != false){
				$response['msg'] 		= true;
				$response['pluginurl'] 	= $removed[0];
				$response['url'] 		= App::appurl('',array('p'=>'plugins','d'=>array('activatePlugin'=>$removed[1])));
			}
			else{
				$response['msg'] = false;
			}
			$this->setPagevar('response',$response);
			return 'ajax';
		}
		$plugins = App::pluginlist();
		$this->setPagevar('plugins',$plugins);
		
		$this->setPagevar('pluginpagenum',1);
		
		if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		
    }
    public function submitPlugin($data){
   	    if(isset($_FILES) && count($_FILES)){
			$thefile = $_FILES['file'];
		}
		else{
			if(isset($_POST['file'])){
				$thefile = [];
				$thefile['file'] = $_POST['file'];
			}
		}
		
		$thefile['name'] = str_replace(' ','_',$data);
		
		if(!isset($thefile['tmp_name'])){
			$thefile['tmp_name'] = $thefile['file'];
		}
		
		$response['result'] = false;
		$filedescription = explode('|',$_POST['filedescriptor']);
	    if($filedescription[3]!= 'false'){
	        App::uploadChunks($thefile,'',false);
            if($filedescription[4] == ((int)$filedescription[5]+1)){
                $thefile['tmp_name'] = App::getConfig('uploads').$thefile['tmp_name'];
                $response = $this->extractplugin($thefile);
                unlink(App::getConfig('uploads').$thefile['tmp_name']);
            }
            else{
                $response['msg'] = 'anotherchunk';
            }
        }
        else{
            $response = $this->extractplugin($thefile);
        }
    
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function extractplugin($thefile){
        $response['result'] = false;
        $zip = new ZipArchive;
        if (($opened = $zip->open($thefile['tmp_name'])) === TRUE) {
            $newpluginfolder = App::getConfig('plugins').$thefile['name'];
            if(file_exists($newpluginfolder)){
                $newpluginfolder .= time();
            }
            $extracted = $zip->extractTo($newpluginfolder.'/0');
            $zip->close();
            
            if($extracted){
                $response['result'] = true;
            }
            else{
                $response['msg'] = 'failed extracting folder';
            }
        } else {
            $response['msg'] = 'failed opening zip file:'.$opened;
        }
        return $response;
    }
}
?>