<?php

Class Contacts extends Controller{
    function __construct() {
        parent::__construct();
        if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
	    $this->delmodel('contactslist');
		return !(count($this->model('contactslist')->db->errors));
	}
    public function pageInit($data=null,$view='contacts'){
        if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		    
        if(count($this->model('contactslist')->db->errors)){
            $response['view'] = '404';
		    $this->setPagevar('response',$response);
		    
            $messages = false;
			return '404';
        }
		
		$this->setPagevar('contactpagenum',1);
		$messages = $this->model('contactslist')->messagelist(0);
		if($messages === false){
			$messages = array();
		}
		
		    
		$this->setPagevar('messages',$messages);
    }
	
	public function deletemessage($msgid){
		$response['deleted'] = true;
		$this->setPagevar('response',$response);
		
		return 'ajax';
	}
}
?>