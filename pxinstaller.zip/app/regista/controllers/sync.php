<?php
Class Sync extends Controller{
    var $progressfile;
    var $filearr;
    var $syncurl;
    var $appsyncconfig;

    var $apptosync;
    var $apptosyncid;

    var $appsyncconfigarr;
    var $apptosyncarr;


    var $appdb;
    var $tablesyncrowlimit;
    var $tablerowsyncedcount;
	function __construct(){
		parent::__construct();
		$this->filearr = array();
		$this->tablesyncrowlimit = 120;
	}
	public function checkpage(){
		return false;
	}
	public function readprogress($data){
	    header('Access-Control-Allow-Origin: *');
	    $progressedfile = App::getConfig('uploads').$data['progressfile'].'.progress';
	    $response['progress'] = 'false';
	    if(file_exists($progressedfile) && filesize($progressedfile) > 0){
    	    $progressed = @fopen($progressedfile,'rb');
    	    $progressedcontent = fread($progressed,filesize($progressedfile));

    	    /*truncate the file*/
    	    $progressed = @fopen($progressedfile,'w+');
    	    fclose($progressed);
    	    $response['progress'] = $progressedcontent;
	    }

	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function writeprogress($data){
	    $this->setsyncsession($data,'server');

	    $progressed = @fopen($this->progressfile,'ab');
	    $wrote      = @fwrite($progressed,$data['result']);

	    fclose($progressed);
	    echo $wrote;
	    return 'plain';
	}
	public function reportprogress($results){
	    return file_get_contents($this->syncurl.'?app=regista&p=sync&a=writeprogress&d[result]='.urlencode($results).'&d[progress]='.$this->progressfile);
	}
    public function fixurl($data){
        if(substr($data['url'],0,4) !== 'http'){
            $data['url'] = 'http://'.$data['url'];
        }
        if(substr($data['url'],-1) !== '/'){
            $data['url'] .= '/';
        }
        $this->setsyncsession($data);
        return $data;
	}
	public function testdb($data=false){
	    App::createnewdb('testes');
	}
	public function testoutput($data){
	    echo '===';
	    return 'plain';
	}
	public function dbcred($data){
	    $username = $data['username'];
	    $passwd = $data['passwd'];

	    if(App::createdbcreator($username,$passwd)){
	        echo App::createnewdb(App::getSessionVar('apptosync'));
	        return 'plain';
	    }

	    echo '5';
	    return 'plain';
	}
	public function setsyncsession($data,$mode='client'){
	    if($data === false){
            $this->apptosync = App::getSessionVar('apptosync');
            $this->apptosyncid = App::getSessionVar('apptosyncid');
    	    $this->appsyncconfig = App::getSessionVar('appsyncconfig');

            $this->syncurl = App::getSessionVar('syncurl');

            $this->apptosyncarr = App::getSessionVar('apptosyncarr');
            $this->appsyncconfigarr = App::getSessionVar('appsyncconfigarr');
            $this->progressfile = App::getSessionVar('progressfile');

            if($mode !=='client' && $this->progressfile === false){
                $this->progressfile = App::getConfig('uploads').'syncapp'.time().'.progress';
                App::setSessionVar('progressfile',$this->progressfile);

                $h = @fopen($this->progressfile,'wb');
                fclose($h);
            }

	        return;
	    }
	    foreach($data as $k=>$v){
	        switch($k){
	            case 'apptosync':
	                $this->apptosync = $data['apptosync'];
	                App::setSessionVar('apptosync',$this->apptosync);

	                $this->apptosyncid = App::getappid($this->apptosync);
	                if(!$this->apptosyncid){
	                    App::setSessionVar('newapp',true);
	                    $this->apptosyncid = $this->model('appslist')->createApp($this->apptosync,true);
	                }
	                if($this->apptosyncid == false){
	                    echo '0';exit();
	                }
	                App::setSessionVar('apptosyncid',$this->apptosyncid);
	            break;
	            case 'appsyncconfig':
            	    $this->appsyncconfig = $data['appsyncconfig'];
            	    App::setSessionVar('appsyncconfig',$this->appsyncconfig);
	            break;
	            case 'url':
	                $this->syncurl = $data['url'];
                    App::setSessionVar('syncurl',$this->syncurl);
	            break;
	            case 'apptosyncarr':
	                App::setSessionVar('apptosyncarr',$v);
	            break;
	            case 'progress':
	                if($mode == 'client'){
	                    $this->progressfile = $data['progress'];
	                    App::setSessionVar('progressfile',$this->progressfile);
	                }
	                else{
	                 	$this->progressfile = App::getConfig('uploads').$data['progress'].'.progress';
	                    App::setSessionVar('progressfile',$this->progressfile);
	                }
	            break;
	            case 'appsyncconfigarr':
	                App::setSessionVar('appsyncconfigarr',$v);
	            break;
	        }
	    }
	}
	public function appsyncsession(){
	    $atsa = App::getSessionVar('apptosyncarr');
	    if($atsa === false)
	        return false;


	    $appsessx = explode('<edsep>',$atsa);
	    if($appsessx[0] === ''){
	        App::setSessionVar('apptosyncarr',false);
	        return false;
	    }

	    $ascax = explode('<edsep>',App::getSessionVar('appsyncconfigarr'));
	    $data = array('apptosync'=>$appsessx[0],'appsyncconfig'=>$ascax[0]);

	    $this->setsyncsession($data);
	}
	public function beginsyncsession($data){
	    if(count($data) != 0){
	        App::setSessionVar('syncstagetable',false);
	        App::setSessionVar('tabletosync',false);
	        App::setSessionVar('syncstageextra',false);
	        App::setSessionVar('newapp',false);

	        $this->setsyncsession($data);
	        $this->reqsyncsession();

	        $response['syncurl'] = App::getSessionVar('syncurl');
	        $response['progressfile'] = $this->progressfile;

	        $this->setPagevar('response',$response);
	        return 'ajax';
	    }

	    while($this->appsyncsession() !==false){
	        $this->setsyncsession(false);
	        $this->reqtosync();
	    }
	    echo '9';
	    return 'plain';
	}
	public function reqsyncsession(){
	    $url = App::getSessionVar('syncurl').'?app=regista&p=sync&a=handlesyncsessionreq';
	    $data['progress'] = file_get_contents($url);

	    $this->setsyncsession($data);
	}
	public function handlesyncsessionreq($data){
	    $this->setsyncsession(false,'server');
	    echo str_replace(array('.progress',App::getConfig('uploads')),array('',''),$this->progressfile);

	    return 'plain';
	}
	public function reqtosync(){
        switch(App::getSessionVar('syncstage')){
            case false:
            case 'filesync':
                $this->reportprogress('starting app sync:'.$this->apptosync.'...<br/><br/>');
                if(in_array('app',explode(',',$this->appsyncconfig)) || in_array('apps',explode(',',$this->appsyncconfig)) || in_array('res',explode(',',$this->appsyncconfig)) || in_array('upload',explode(',',$this->appsyncconfig)) || in_array('uploads',explode(',',$this->appsyncconfig)) || in_array('view',explode(',',$this->appsyncconfig)) || in_array('views',explode(',',$this->appsyncconfig)) ){
                    $this->reqsyncfiles();
        	   	}
               App::setSessionVar('syncstage','appconfig');
               $this->reqtosync();
            break;
            case 'appconfig':
                if(in_array('appconfig',explode(',',$this->appsyncconfig))){
        	   	    $this->reqsyncdb();
        	   	}

        	   App::setSessionVar('syncstage','appdb');
               $this->reqtosync();
            break;
            case 'appdb':
                if(in_array('appdb',explode(',',$this->appsyncconfig))){
                    foreach(explode(',',$this->appsyncconfig) as $ascxk=>$ascxv){
                        if(strpos($ascxv,'dbtable:') !==false){
                            App::setSessionVar('tabletosync',str_replace('dbtable:','',$ascxv));
                            break;
                        }
                    }
                    if(App::getSessionVar('newapp')){
                        App::setSessionVar('newapp',false);
                        $newdb = App::createnewdb($this->apptosync);
	                    if($newdb === 0){
	                        echo '1';exit();
	                    }
            	        $appdbvars = App::getAppDbVars();
            	        $appdbvars['dbname'] = $this->apptosync;
	                    $this->model('setting')->savedb($appdbvars,$this->apptosyncid);
                    }
        	   	    $this->reqsyncappdb();
        	   	}
        	   App::setSessionVar('syncstage','extra');
               $this->reqtosync();
            break;
            case 'extra':
               	foreach(explode(',',$this->appsyncconfig) as $ascxk=>$ascxv){
        	   	    if(strpos($ascxv,'extra:') !== false){
        	   	        $this->appsyncconfig = str_replace('extra:','',$ascxv);
        	   	        if(App::getSessionVar('syncstageextra') !== false){
        	   	            if($this->appsyncconfig == App::getSessionVar('syncstageextra')){
        	   	                $this->extrasyncfn();
        	   	            }
        	   	        }
        	   	        else{
        	   	            App::setSessionVar('syncstageextra',$this->appsyncconfig);
        	   	            $this->extrasyncfn();
        	   	        }
        	   	    }
        	   	}
        	   	App::setSessionVar('syncstage','cleaninganappsession');
        	   	$this->reqtosync();
            break;
            case 'cleaninganappsession':
                $atsa =  explode('<edsep>',App::getSessionVar('apptosyncarr'));
        	   	$ascax = explode('<edsep>',App::getSessionVar('appsyncconfigarr'));

        	   	unset($atsa[0]);
        	   	unset($ascax[0]);

        	   	App::setSessionVar('apptosyncarr',implode('<edsep>',$atsa));
        	   	App::setSessionVar('appsyncconfigarr',implode('<edsep>',$ascax));

        	   	App::setSessionVar('syncstage',false);

        	   	$this->reportprogress('<br/>end of syncing app:'.$this->apptosync.'.<br/>');
            break;
            default:
            break;
        }
	}
	public function reqsyncprep($data){
	    $data   = $this->fixurl($data);
	    $url    = $data['url'].'?app=regista&p=sync&a=handlesyncprepreq';

	    $response = file_get_contents($url);
	    echo $response;
	    return 'plain';
	}
	public function handlesyncprepreq($data){
	    $applist = $this->model('appslist')->getrecords(null,array('name','modified'),array('modified','desc'));
	    foreach($applist as $ak=>$av){
	        $syncappfile = App::getConfig('resources').$av['name'].'/config.pxsync';
	        if(file_exists($syncappfile)){
	            $applist[$ak]['syncconfig'] = file_get_contents($syncappfile);
	        }
	        else{
	            unset($applist[$ak]);
	        }
	    }
	    $this->setPagevar('response',$applist);
	    return 'ajax';
	}
	public function fileinfolder($path,$ftype,$basepath){
	    $opendir = opendir($path);
        if($opendir){
            while(($file = readdir($opendir)) !== false){
                if($file == '.' || $file == '..'){
                    continue;
                }
                if(is_dir($path.'/'.$file)){
                    if($file != 'pxarchive'){
                        $this->fileinfolder($path.'/'.$file,$ftype,$basepath);
                    }
                }
                else{
                    $filearridx = count($this->filearr);
                    $this->filearr[$filearridx] = array();
                    $this->filearr[$filearridx]['floc'] = str_replace($basepath,'',$path).'/'.$file;
                    $this->filearr[$filearridx]['ftype'] = $ftype;
                }
            }
            closedir($opendir);
        }
	}
	public function handlesyncfilesreq($data){
	    $this->setsyncsession($data);
	    $ftypedefault       = array('app','res','upload','view');
	    $ftypeconfig        = explode(',',$this->appsyncconfig);
	    $ftype              = array();
	    foreach($ftypedefault as $k=>$v){
	        if(in_array($v,$ftypeconfig) || in_array($v.'s',$ftypeconfig)){
	           $ftype[] = $v;
	        }
	    }

	    $this->filearr      = array();
	    foreach($ftype as $fk=>$fv){
	        switch($fv){
	            case 'app':
	                $path = App::getConfig('approot').$this->apptosync.'/';
	            break;
	            case 'res':
	                $path = App::getConfig('resources').$this->apptosync.'/';
	            break;
	            case 'upload':
	                $path = App::$config['uploads'].$this->apptosync.'/';
	            break;
	            case 'view':
	                $path = App::getConfig('views').$this->apptosync.'/';
	            break;
	            case 'plugin':
	                $path = App::getConfig('plugin').$this->apptosync.'/';
	            break;
	        }
	        $this->fileinfolder($path,$fv,$path);
	    }
	    $this->setPagevar('response',$this->filearr);
	    return 'ajax';
	}
	public function createfolderstruct($base,$ext){
	    $extx = explode('/',$ext);
	    unset($extx[count($extx)-1]);

	    if(count($extx)){
	       for($i=0;$i<count($extx);$i++){
	           if($extx[$i]==''){
	               continue;
	           }
	           if(!file_exists($base.'/'.$extx[$i])){
	               @mkdir($base.'/'.$extx[$i]);
	               $this->reportprogress('<br/>created new directory: '.$base.'/'.$extx[$i].'<br/><br/>');
	           }
	           $base.='/'.$extx[$i];
	       }
	    }
	}
	public function reqsyncfiles(){
	    $url = App::getSessionVar('syncurl').'?app=regista&p=sync&a=handlesyncfilesreq&d[apptosync]='.$this->apptosync.'&d[appsyncconfig]='.$this->appsyncconfig.'&d[progress]='.$this->progressfile;
	    $this->filearr = json_decode(file_get_contents($url),true);

	    $this->reportprogress('copying '.count($this->filearr).' files...<br/>');


	    foreach($this->filearr as $respk=>$respv){
	        switch($respv['ftype']){
	           case 'app':
	               $fdest = App::getConfig('approot').$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::getConfig('approot').$this->apptosync,$respv['floc']);
	           break;
	           case 'res':
	               $fdest = App::getConfig('resources').$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::getConfig('resources').$this->apptosync,$respv['floc']);
	           break;
	           case 'upload':
	               $fdest = App::$config['uploads'].$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::$config['uploads'].$this->apptosync,$respv['floc']);
	           break;
	           case 'view':
	               $fdest = App::getConfig('views').$this->apptosync.$respv['floc'];
	               $this->createfolderstruct(App::getConfig('views').$this->apptosync,$respv['floc']);
	           break;
	           case 'plugin':
	               $fdest = App::getConfig('plugins').$respv['floc'];
	               $this->createfolderstruct(App::getConfig('plugins').$respv['floc'],$respv['floc']);
	           break;
	        }
	        $copied = $this->copyfile($respv['floc'],$respv['ftype'],$fdest);
	        if($copied === false){
	            $this->reportprogress('error copying file '.$fdest.'<br/>');
	        }
	        else{
	            $this->reportprogress('successfully overwrite file '.$fdest.'<br/>');
	        }
	    }
	    $this->reportprogress('<br/>file syncing completed.<br/>');

	}
	public function copyfile($fileorigin,$ftype,$filedest){
	    $dest = @fopen($filedest,'wb');
	    if($dest !== false){
	        $copied = false;
	        $fileorigin = App::getSessionVar('syncurl').'?app=regista&p=sync&a=filecontent&d[floc]='.urlencode($fileorigin).'&d[ftype]='.$ftype.'&d[apptosync]='.App::getSessionVar('apptosync');
	        $srcfilehandler = @fopen($fileorigin,'rb');
	        if($srcfilehandler){
    	        $srcfile = '';
    	        while(($read = fgets($srcfilehandler)) !== false){
    	            $srcfile .= $read;
    	        }
    	        $copied = fwrite($dest,$srcfile);
	        }
	        fclose($dest);
	        return $copied;
	    }
	    return false;
	}
	public function filecontent($data){
	    switch($data['ftype']){
           case 'app':
               $fdest = App::getConfig('approot').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'res':
               $fdest = App::getConfig('resources').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'upload':
               $fdest = App::$config['uploads'].$data['apptosync'].'/'.$data['floc'];
           break;
           case 'view':
               $fdest = App::getConfig('views').$data['apptosync'].'/'.$data['floc'];
           break;
           case 'plugin':
               $fdest = App::getConfig('plugins').$data['floc'];
           break;
        }
        if(file_exists($fdest)){
            $dest = @fopen($fdest,'rb');
    	    if($dest !== false && filesize($fdest)){
    	        echo @fread($dest,filesize($fdest));
    	    }
    	    fclose($dest);
        }
        return 'plain';
	}
	/*sync appdb*/
	public function reqsyncappdb(){
	    $this->reportprogress('<br/>syncing apps database...<br/>');

	    $url = $this->syncurl.'?app=regista&p=sync&a=handlesyncappdbreq&d[apptosync]='.$this->apptosync;
	    $urlfetch = file_get_contents($url);
	    $apptable = json_decode($urlfetch,true);
	    $tabletosync = App::getSessionVar('tabletosync');

	    foreach($apptable as $tablek=>$tablev){
	        if(App::getSessionVar('syncstagetable') !== false){
	            foreach($tablev as $tablevk=>$tablevv){
	                if($tablevv == App::getSessionVar('syncstagetable')){
    	                $this->reqsynctable($tablevv);
	                }
    	        }
	        }
	        else{
	            foreach($tablev as $tablevk=>$tablevv){
	                if($tabletosync !== false){
	                    if(in_array($tablevv,explode('|',$tabletosync))){
	                        $this->reqsynctable($tablevv);
	                    }
	                }
	                else{
	                    $this->reqsynctable($tablevv);
	                }
    	        }
	        }
	    }
	    $this->reportprogress('<br/>syncing app database completed.<br/>');
	}
	public function reqtabledef($table){
	    $url        = $this->syncurl.'?app=regista&p=sync&a=handletabledefreq&d[apptosync]='.$this->apptosync.'&d[table]='.$table;
	    $urlfetch   = file_get_contents($url);

	    $newtable = App::createnewtable($this->apptosync,$urlfetch);
	    if($newtable === 0){
	        echo '1';exit();
	    }
	}
	public function handletabledefreq($data){
	    $this->setsyncsession($data,'server');

	    $tablemodel = new Model($data['table'],$this->apptosyncid);
	    $tabledef = $tablemodel->createtablesql();
	    echo $tabledef;
	    return 'plain';
	}
	public function reqsynctable($table,$offset=false){
	    App::setSessionVar('syncstagetable',$table);
	    $this->reportprogress('<br/>syncing table '.$table.'...<br/>');

	    $tablemodel = new Model($table,$this->apptosyncid);
	    if(count($tablemodel->db->errors) > 0){
	        $tablemodel->db->errors = array();
	        $this->reportprogress('creating table '.$table.'...<br/>');
	        $this->reqtabledef($table);
	    }
	    $this->tablerowsyncedcount = 0;

	    $this->_reqsynctable($table,$offset,$tablemodel);

	    $this->reportprogress('syncing table '. $table .' completed.<br/>');
	    App::setSessionVar('syncstagetable',false);

	}
	public function _reqsynctable($table,$offset,$tablemodel){
	    $offset     = $offset === false ? $tablemodel->countrows() : $offset;
	    $url        = $this->syncurl.'?app=regista&p=sync&a=handlesynctablereq&d[apptosync]='.$this->apptosync.'&d[table]='.$table.'&d[offset]='.$offset;
	    $urlfetch   = file_get_contents($url);
	    $apptable   = json_decode($urlfetch,true);
	    $tablerows  = $apptable['rows'];
	    $rowlimit   = $apptable['limit'];

	    if(is_array($tablerows) && count($tablerows)>0){
	        foreach($tablerows as $rk=>$rv){
	            $fieldname =array();
	            $fieldval = array();
	            foreach($rv as $rvk=>$rvv){
	                $fieldname[] = $rvk;
	                $fieldval[] = $rvv;
	            }
	            $added = $tablemodel->addrecord($fieldname,$fieldval);
	            if($added){
	                $this->tablerowsyncedcount += 1;
	            }
	        }

	        if(count($tablemodel->db->errors)>0){
	            $this->reportprogress('error importing data:<br/>'.$tablemodel->printerrors(false).'<br/>');
	            $tablemodel->db->errors = array();
	        }

	        if(count($tablerows) == $rowlimit){
	            $this->reportprogress('new record added:'.$this->tablerowsyncedcount.'<br/>');
	            $this->_reqsynctable($table,($offset+$rowlimit),$tablemodel);
	        }
	        else{
	            $this->reportprogress('new record added:'.$this->tablerowsyncedcount.'<br/>');
	            return true;
	        }
	    }
	    else{
	        return true;
	    }
	}
	public function handlesynctablereq($data){
	    $this->setsyncsession($data,'server');

	    $tablemodel = new Model($data['table'],$this->apptosyncid);
	    $rows = $tablemodel->getrecords(null,null,null,array($data['offset'],$this->tablesyncrowlimit));

	    $response = array();
	    $response['limit'] = $this->tablesyncrowlimit;
	    $response['rows']   = $rows;
	    $this->setPagevar('response',$response);

	    return 'ajax';
	}
	public function handlesyncappdbreq($data=false){
	    $this->setsyncsession($data);
	    $this->appdb = App::appdb($this->apptosync);

	    $tables = $this->appdb->query('show tables');
		$appdb 	= $this->appdb->fetchQueryResult($tables,true);

		$this->setPagevar('response',$appdb);
		return 'ajax';
	}
	/*sync extra functions*/
	public function extrasyncfn(){
	    if(file_exists(App::getConfig('approot').'controllers/'.$this->appsyncconfig.'.php')){
	        include App::getConfig('approot').'controllers/'.$this->appsyncconfig.'.php';

    	    $extrafn = new $this->appsyncconfig();
    	    $extrafn->app = $this->apptosyncid;
    	    $extrafn->db = App::appdb($this->apptosyncid);
    	    $extrafn->setPagevar('app',$this->apptosyncid);

    	    $extradata = array();
    	    $extradata['syncurl'] = $this->syncurl;
    	    $extradata['apptosync'] = $this->apptosync;
    	    $extrafn->pageInit($extradata);
	    }
	}
	/*sync appconfig*/
	public function reqsyncdb(){
	    $this->reportprogress('<br/>syncing app config...<br/>');

	    $url = $this->syncurl.'?app=regista&p=sync&a=handlesyncdbreq&d[apptosync]='.$this->apptosync;
	    $settings = json_decode(file_get_contents($url),true);

	    if(App::getSessionVar('newapp')){
	        $this->reportprogress('creating apps db setting...<br/>');
	        $appdbvars = App::getAppDbVars();
	        $appdbvars = json_encode($appdbvars);
	        $a = $this->model('setting')->addrecord(array('type','app','name','value'),array('globalpage',$this->apptosyncid,'dbsetting',$appdbvars));
	    }

	    foreach($settings as $sk=>$sv){
	        if($this->model('setting')->exists(array('app'=>$this->apptosyncid,'name'=>$sv['name']))){
                $a = $this->model('setting')->updaterecord(array('value'=>$sv['value']),array('app'=>$this->apptosyncid,'name'=>$sv['name']));
            }
            else{
                $a = $this->model('setting')->addrecord(array('type','app','name','value'),array($sv['type'],$this->apptosyncid,$sv['name'],$sv['value']));
            }
	    }
	    $this->reportprogress('app config sync completed.<br/>');
	}
	public function handlesyncdbreq($data){
	    $this->setsyncsession($data);
	    $settingsx = $this->model('setting')->getAppSettings($this->apptosync);
	    $settings = array();
	    foreach($settingsx as $xk=>$xv){
	        if($xv['name'] == 'dbsetting'){
	            continue;
	        }
	        $settings[] = $settingsx[$xk];
	    }
	    $this->setPagevar('response',$settings);

	    return 'ajax';
	}
}
