<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
		    $this->addheadfootsrc(false,array('mobileregista'=>App::getConfig('appviews').'/styles/mobileregista.css'));
		}
		else{
		    $this->setPagevar('mobile','false');
		}
    }
	public function checkpage(){
		return true;		
	}
    public function pageInit($data=null,$view=''){
        if(!isset(App::$config['dbhost'])){
			header('Location:'.App::$config['domain'].'?app=regista&p=pxinstaller');
		}
		
        if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		else
		    $this->setPagevar('ajax',false);
		    
		if(App::isLoggedin()){
		    if(!isset($data['plugindata'])){
		        $this->controller('recentactivities')->load($this->getPagevar('ajax'));   
		    }
			$view = 'plain';
        }
        else{
			$view = 'login';
        }
		return $view;
    }
	public function logout($data){
		$view = 'login';
		if(isset($data['ajax'])){
			$this->setPagevar('ajax',true);
		}
		if(App::isLoggedin()){
			App::logout();
		}
		return $view;
	}
}
?>