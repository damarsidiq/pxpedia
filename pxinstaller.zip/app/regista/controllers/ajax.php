<?php

Class Ajax extends Controller{
    function __construct() {
        parent::__construct();
		$this->setPagevar('ajax',true);
    }
    public function electrified($data=null,$view=''){
       	$view = $this->controller('apps')->pageInit(null,'apps');
    	$this->pagevar = array_merge($this->pagevar,$this->controller('apps')->getPagevars());
    	return $view;
	}
    public function loggedinremembered($data){
        $response = false;
        $loggedin = $this->model('user')->getUserByEmail($data['email']);
        
		$login = App::loginuser($loggedin['id']);
		
		$response['login'] = 2;
		$user = App::getUser();
		$response['activeapp'] = $user['role'][0]['appid'];
		
		$this->setPagevar('response',$response);
		
		$homepage = $this->controller('recentactivities')->load(true,true);
	    $this->setPagevar('homecontent',$homepage);
	    
	    return 'loggedinhome';
    }
    public function loginadmin($data){
		$response = false;
		$login = App::login($data[1],$data[0]);
		if($login == 2){
			$user = App::getUser();
			$response['activeapp'] = $user['role'][0]['appid'];
			foreach($user['role'] as $rolek=>$role){
				if($role['role'] == 1 || $role['role'] == 2){
					$response['login'] = 2;
					break;
				}
			}
			if(!isset($response['login'])){
				$response['login'] = 3;
				App::logout();
			}
		}
		else{
			$response['login'] = $login;
			App::logout();
		}
		$this->setPagevar('response',$response);
		if($response['login'] == 2){
		    if(!isset($data['plugindata'])){
		        $homepage = $this->controller('recentactivities')->load(true,true);
		        $this->setPagevar('homecontent',$homepage);
		    }
		    return 'loggedinhome';
		}
    }
	public function loadlang($data=null){
		$currentlang = fopen($this->pagevar['path']['resources'].'lang/'.$this->pagevar['lang'].'.json','r');
		if($currentlang !== FALSE){
			$langfile = (fread($currentlang,filesize($this->pagevar['path']['resources'].'lang/'.$this->pagevar['lang'].'.json')));	
		}
		fclose($currentlang);
		$this->setPagevar('message',$langfile);
		$this->setPagevar('ajax',true);
		return 'lang';
	}
}
?>