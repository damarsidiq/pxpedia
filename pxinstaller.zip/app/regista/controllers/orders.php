<?php

Class Orders extends Controller{
    function __construct() {
        parent::__construct();
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
	    $this->delmodel('product');
		return !(count($this->model('product')->db->errors));
	}
    public function pageInit($data=null,$view='main'){
         if(isset($data['ajax']))
		     $this->setPagevar('ajax',true);
		 
        if(count($this->model('product')->db->errors)){
		    $response['view'] = '404';
		    $this->setPagevar('response',$response);
			return '404';
        }
	   
    }
}
?>