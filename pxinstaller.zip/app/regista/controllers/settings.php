<?php

Class Settings extends Controller{
    function __construct() {
        parent::__construct();
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
		return true;
	}
    public function pageInit($data=null,$view='settings'){
		$headsrc 	= Pxpedia::appSetting(Pxpedia::currentRole()['appid'],'headsrc','globalpage');
		$footsrc 	= Pxpedia::appSetting(Pxpedia::currentRole()['appid'],'footsrc','globalpage');
		$dbsetting 	= Pxpedia::appSetting(Pxpedia::currentRole()['appid'],'dbsetting','globalpage');
		$keywords   = Pxpedia::appSetting(Pxpedia::currentRole()['appid'],'keywords','globalpage');
		
		if($headsrc !== false)
			$this->setPagevar('headsource',$headsrc);
		
		if($footsrc !== false)
			$this->setPagevar('footsource',$footsrc);
		
		if($dbsetting !== false)
			$this->setPagevar('dbsetting',$dbsetting);
		
		if($keywords !== false)
			$this->setPagevar('keywords',$keywords);
			
		if(isset($data['ajax']))
		    $this->setPagevar('ajax',true);
		    
		return $view;
		
    }
	public function uploadfiles($data){
		$sourcefiles 		= isset($_FILES['file']) ? $_FILES['file'] : array();
		$name = explode('|',$_POST['filedescriptor']);
		$name = $name[1];
		$path = $this->model('setting')->savefile(array($sourcefiles),$name);
		$response['path'] = $path;
		$response['upload'] = true;
		
		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function savedbsetting($data){
	    $appid 	= App::getUser()['currentrole']['appid'];
	    
	    $response['save'] = $this->model('setting')->savedb($data,$appid);
		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function savesettings($data){
		$appid 	= $response['appid'] = App::getUser()['currentrole']['appid'];
		
		$this->model('setting')->savekeywords($data['newkeywords']);
		
		$response['save'] = true;
		
		if(isset($data['sourcename'])){
			$head 	= array(array_slice($data['sourcename'],0,$data['headcount']),array_slice($data['sourcefilepath'],0,$data['headcount']));
			$foot 	= array(array_slice($data['sourcename'],$data['headcount'],$data['footcount']),array_slice($data['sourcefilepath'],$data['headcount'],$data['footcount']));	
		}
		
		$oldname = App::appById($appid);
		if($data['newappname'] != $oldname){
		    $changedname = $this->model('appslist')->changename($data['newappname']);
		    if(!$changedname){
		        $response['save'] = false;
		    }
		    
		    $response['oldname'] = $oldname;

		    if(isset($data['sourcename'])){
		        $filepath = array();
		        $filepathidx = 0;
		        foreach($head[1] as $ke=>$va){
		            if(strpos($va,$oldname.'/') !== false){
		                $head[1][$ke] = str_replace($oldname.'/',$data['newappname'].'/',$va);
		                
		                $filepath[$filepathidx]['idx']  = $ke;
		                $filepath[$filepathidx]['path'] = $head[1][$ke];
		            }
		        }
		        if(count($filepath)){
		            $response['headpath'] = $filepath;    
		        }
		        
		        $filepath = array();
		        $filepathidx = 0;
		        foreach($foot[1] as $ke=>$va){
		            if(strpos($va,$oldname.'/') !== false){
		                $foot[1][$ke] = str_replace($oldname.'/',$data['newappname'].'/',$va);
		                
		                $filepath[$filepathidx]['idx']  = $ke;
		                $filepath[$filepathidx]['path'] = $foot[1][$ke];
		            }
		        }
		        if(count($filepath)){
		            $response['footpath'] = $filepath;    
		        }
		        
    		}
		}
		
		if(isset($data['sourcename'])){
			$this->model('setting')->savehead($head,$appid);
			$this->model('setting')->savefoot($foot,$appid);	
		}
		
		
		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function resourcetree($resname = false,$recursive = false){
		$resources 	= array();
		$respath 	= Pxpedia::getConfig('resources');
		if($resname !== false){
			$respath .= $resname.'/';
		}
		$resfolder 	= opendir($respath);
		
		while(($resfold = readdir($resfolder)) !== false){
			if($resfold == '.' || $resfold == '..')
				continue;
			
			$resourceidx = count($resources);
			$resources[$resourceidx]['type'] = is_dir($respath.$resfold) ? 'folder' :'file';
			$resources[$resourceidx]['name'] = $resfold;
			
			if($recursive && $resources[$resourceidx]['type'] == 'folder'){
				$resources[$resourceidx]['content'] = $this->resourcetree(str_replace(Pxpedia::getConfig('resources'),'',$respath).$resfold,true);
			}
		}
		return $resources;
	}
	public function getresources($data){
		$resources = $this->resourcetree();
		$this->setPagevar('response',$resources);
		return 'ajax';
	}
	public function resourcecontent($data){
		$resources = $this->resourcetree($data['resourcename'],true);
		$this->setPagevar('response',$resources);
		return 'ajax';
	}
	
	public function themestree($resname = false,$recursive = false){
		$resources 	= array();
		$respath 	= Pxpedia::getConfig('views');
		if($resname !== false){
			$respath .= $resname.'/';
		}
		$resfolder 	= opendir($respath);
		
		if($resfolder){
			while(($resfold = readdir($resfolder)) !== false){
				if($resfold == '.' || $resfold == '..')
					continue;
				
				$resourceidx = count($resources);
				$resources[$resourceidx]['type'] = is_dir($respath.$resfold) ? 'folder' :'file';
				$resources[$resourceidx]['name'] = $resfold;
				
				if($recursive && $resources[$resourceidx]['type'] == 'folder'){
					$resources[$resourceidx]['content'] = $this->themestree($resname.'/'.$resfold,true);
				}
			}
		}

		return $resources;
	}
	public function getThemesResources($data){
		$resources = $this->themestree();
		$this->setPagevar('response',$resources);
		return 'ajax';
	}
	public function themesresourcecontent($data){
		$resources = $this->themestree($data['resourcename'],true);
		$this->setPagevar('response',$resources);
		return 'ajax';
	}
}
?>