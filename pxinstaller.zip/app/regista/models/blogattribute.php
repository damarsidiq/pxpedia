<?php

Class BlogAttribute extends Model{
    var $blogattr;
    var $blogid;
    function __construct(){
        $this->blogattr = false;
        $this->blogid   = false;
        
        parent::__construct('blogattribute',App::getUser()['currentrole']['appid']);
    }
    
    public function blogattributes($blogid){
        $attributes = $this->getrecords(array('blogid'=>$blogid),array('attrkey','value'));
        
        return $attributes;
    }
    public function deleteblogattr($blogattrtodelete){
        
        if($this->blogattr === false || $this->blogid != $blogattrtodelete['blogid']){
            $this->blogid = $blogattrtodelete['blogid'];
            $this->blogattr = $this->fetchQueryResult($this->query('select id from '.$this->table.' where blogid ='.$this->blogid));    
            $numrow = count($this->blogattr);
        }
        else{
            $this->blogid = $blogid;
            $numrow = count($this->blogattr);
        }
        
        $todelete = array();
        foreach($blogattrtodelete['attridxs'] as $bk=>$bv){
            if(isset($this->blogattr[$bv]))
                $todelete[] = $this->blogattr[$bv]['id'];
        }
        if(count($todelete))
            $deleted = $this->deleterecord(array('id'=>array('in',$todelete) ));
        else{
            $deleted = true;
            echo print_r($this->blogattr,true);
        }    
        
            
        return $deleted;
    }
    public function updateblogattr($blogid,$type,$index,$value){
        if($this->blogattr === false || $this->blogid != $blogid){
            $this->blogid = $blogid;
            $this->blogattr = $this->fetchQueryResult($this->query('select id from '.$this->table.' where blogid ='.$this->blogid));    
            $numrow = count($this->blogattr);
        }
        else{
            $this->blogid = $blogid;
            $numrow = count($this->blogattr);
        }
        
        if($index < $numrow){
            $updated = $this->updaterecord(array($type=>$value),array('id'=>$this->blogattr[$index]['id']));
            return $updated === false ? $updated : true;
        }
        else{
            while($index>$numrow){
                $fieldval = array($blogid,'','');
                $true = $this->addrecord(array('blogid','attrkey','value'),$fieldval);
                if($true){
                    $this->blogattr[] = array('id'=>$this->insertid());
                    $numrow++;
                }
                else{
                    return false;
                }
            }
            
            if($type == 'attrkey'){
                $fieldval = array($blogid,$value,'');
            }
            else{
                $fieldval = array($blogid,'',$value);
            }
            $added = $this->addrecord(array('blogid','attrkey','value'),$fieldval);
            if($added){
                $this->blogattr[] = array('id'=>$this->insertid());
            }
            return $added;
        }
    }
    
    public function distinctattributes(){
        $distinct = $this->query('select distinct(attrkey) from '.$this->table);
        if($distinct !== false)
        {
            if(!is_array($distinct)){
                $distinct = $this->fetchQueryResult($distinct);
            }   
            return $distinct;
        }
        
        
        return array();
    }
    public function metafilter($key){
        return $this->fetchQueryResult($this->query('select blogid from '.$this->table.' where attrkey like "%'. $key .'%" or value like "'. $key .'" group by blogid'));
    }
}


?>