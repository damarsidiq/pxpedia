<?php

Class Plugin extends Model{
    function __construct(){
        parent::__construct('plugins',App::getappid());
    }
    public function personalizePlugin($appid,$plugin,$pluginid=false){
        if($pluginid === false)
            $pluginid   = $this->getrecord(array('app'=>$appid,'location'=>$plugin),'id');
            
        $copied     = $this->copyPlugin($pluginid,$plugin);
        if(!$copied){
            return false;
        }
        return true;
    }
    public function pluginlink($pluginval){
        $plugindata['plugindata']['plugin'] 	= $pluginval['id'];
        $plugindata['plugindata']['p'] 			= 'admin';
        $plugindata['plugindata']['a'] 			= 'pageInit';
        
        return Pxpedia::appurl('',array('d'=>$plugindata),false);
	}
    public function removePlugin($pluginid){
        $remove     = $this->updaterecord(array('status'=>0,'lastupdated'=>time()),array('id'=>$pluginid));
        $remove     = $remove ? $this->getrecord(array('id'=>$pluginid),array('location','personalized','id')) : $remove;
        
        $link       = $this->pluginlink($remove);
        return array($link,$remove['location']);
    }
    public function activatePlugin($plugin){
        $appid      =   Pxpedia::getUser()['currentrole']['appid'];
        $activated  =   $this->getrecord(array('app'=>$appid,'location'=>$plugin),array('id','personalized'));
        
        if($activated !== false){
			$link       = $this->pluginlink($activated);
            $activatedx = $this->updaterecord(array('status'=>1),array('id'=>$activated['id']));
            $activated  = $activatedx ? $activated['id'] : $activatedx;
        }
        else{
            $activated  =   $this->addrecord(array('app','name','location'),array($appid,ucwords(str_replace('_',' ',$plugin)),$plugin));
            
            if($activated){
                $pluginid 	= $this->insertid();
                $activated 	= $pluginid;
				$link       = $this->pluginlink(array('id'=>$activated));
            }
        }
        return array($link,$activated);
    }
    public function copyPlugin($pluginid,$plugin){
        $onec   = Pxpedia::copyfileindir(str_replace('./','',$this->path['plugins']).$plugin.'/0/controllers',$this->path['plugins'].$plugin.'/'.$pluginid.'/controllers');
        $twoc   = Pxpedia::copyfileindir(str_replace('./','',$this->path['plugins']).$plugin.'/0/models',$this->path['plugins'].$plugin.'/'.$pluginid.'/models');
        $treec  = Pxpedia::copyfileindir(str_replace('./','',$this->path['plugins']).$plugin.'/0/views',$this->path['plugins'].$plugin.'/'.$pluginid.'/views');
        $fourc  = Pxpedia::copyfileindir(str_replace('./','',$this->path['plugins']).$plugin.'/0/res',$this->path['plugins'].$plugin.'/'.$pluginid.'/res');
        
        if($onec && $twoc && $treec && $fourc){
            return true;
        }
        return false;
    }
}
?>