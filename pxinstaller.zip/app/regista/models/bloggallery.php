<?php

Class Bloggallery extends Model{
    function __construct(){
        parent::__construct('bloggallery',App::getUser()['currentrole']['appid']);
    }
    public function addimage($blogid,$imagename){
	    $added = $this->addrecord(array('blogid','image','sortorder'),array($blogid,$imagename,0));
	    if($added){
	        return $this->insertid;
	    }
	    return $added;
    } 
    public function removeimage($imageid){
        return $this->deleterecord(array('id'=>$imageid));
    }
    public function blogimages($blogid){
        return $this->getrecords(array('blogid'=>$blogid),array('id','image'),array('sortorder','asc'));
    }
    public function renameimage($imageid,$name){
        return $this->updaterecord(array('image'=>$name),array('id'=>$imageid));
    }
    public function imageupdate($imagearr){
        $count=0;
        foreach($imagearr as $k=>$v){
            if($v == ''){
                continue;
            }
            $imagedata= explode('<e>',$v);
            $updated = $this->updaterecord(array('image'=>$imagedata[2],'sortorder'=>$count),array('id'=>$imagedata[1]));
            if($updated === false){
                break;
            }
            $count++;
        }
        return $updated;
    }
}


?>