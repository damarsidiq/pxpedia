<?php

Class BlogList extends Model{
    var $itemperpage;
    function __construct(){
        parent::__construct('blog',App::getUser()['currentrole']['appid']);
        $this->itemperpage = 10;
    }
    
    public function bloglist($offset,$limit,$conditions=null,$listorder=array('id','desc')){
        $rowlimit = $limit == 'false' ? array($offset,$this->itemperpage+1) : array($offset,$limit);
        if($conditions !== null){
            /*include descendants*/
            $conditions = $this->catqueryfix($conditions);
        }
        $blog = $this->getrecords($conditions,array('id','title','category','status','created'),$listorder,$rowlimit);
        
        if($limit == 'false' && count($blog) == ($this->itemperpage+1)){
            unset($blog[$this->itemperpage]);
        }
        
        $pagenum = false;
        
        if(count($blog) === 0){
            $blog = false;
        }
        $pagenum = $this->getrecord($conditions,'count(*) as pagenum');
        $pagenum = ($pagenum/$this->itemperpage);
        
        return array($blog,$pagenum,$limit,$this->querystring());
    }
    /**
	 * catqueryfix. include descendants
	 *
	 * @param array $conditions
	 * 
	 * @return array
	 */
    public function catqueryfix($conditions){
        foreach($conditions as $ck=>$cv){
            if($ck === 'and' || $ck === 'or'){
                foreach($conditions[$ck] as $cck=>$ccv){
                    $conditions[$ck][$cck] = $this->catqueryfix($conditions[$ck][$cck]);   
                }
            }
            else{
                if($ck=='category' && (!is_array($cv) || ($cv[0] == '=' || $cv[0] == '!='))){
                    if(is_array($cv)){
                        $descendants = $this->model('blogcategory')->getdescendants($cv[1]);
                        if($descendants !== false){
                            $descendants[] = $cv[1];
                            switch($cv[0]){
                                case '=':
                                    $conditions[$ck] = array('IN',$descendants);
                                break;
                                case '!=':
                                    $conditions[$ck] = array('NOT IN',$descendants);
                                break;   
                            }    
                        }
                    }
                    else{
                        $descendants = $this->model('blogcategory')->getdescendants($cv);
                        if($descendants !== false){
                            $descendants[] = $cv;
                            $conditions[$ck] = array('IN',$descendants);   
                        }
                    }
                }   
            }
        }
        return $conditions;
    }
    public function geteditblogdata($blogid){
        $blogdata = $this->getrecord(array('id'=>$blogid),array('content','excerpt','status'));
        return $blogdata;
    }
    
    public function deleteblog($blogid)
    {
        return $this->deleterecords(array('id'=>$blogid));
    }
    
    public function addblog($data=false){
	    if($data === false)
	        $this->addrecord(array('author','content','excerpt'),array(App::getUser()['id'],'',''));
	    else{
	        $keys = array();
	        $values = array();
	        foreach($data as $k=>$v){
	            $keys[] = $k;
	            $values[] = $v;
	        }
	        $values[] = App::getUser()['id'];
	        $keys[] = 'author';
	        $this->addrecord($keys,$values);
	    }
	    
	    return $this->insertid();
	}
	public function update($data){
	    $id = array('id'=>$data['id']);
	    unset($data['id']);
	    return $this->updaterecord($data,$id);
	}
}


?>