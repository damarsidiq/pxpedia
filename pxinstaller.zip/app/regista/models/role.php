<?php

Class Role extends Model{
    var $pagelimit = 30;
    function __construct(){
        parent::__construct('role',App::getappid());
    }
    public function getRoles($app=false,$order=false,$page=0){
        if($app == false){
            $app = Pxpedia::getUser()['currentrole']['appid'];
        }
        
        $condi = null;
        
        //$limit = ($page*$this->pagelimit).','.$this->pagelimit;
        $limit=null;
        $order = $order == false ? null : $order;
        $roles = $this->getrecords($condi,null,$order,$limit);
        
        return $roles;
    }
    public function addrole($roledata){
        return $this->addrecord(array_keys($roledata),array_values($roledata));
    }
}


?>