var functionparams = {workeraction:'test'}; 

    self.onmessage = function(event){
        var msg = event.data;
        
        if(typeof msg.workeraction !== 'undefined'){
            functionparams.workeraction = msg.workeraction;
            
            functionparams.app  = msg.app;
            functionparams.p    = msg.p;
            functionparams.a    = msg.a;
            functionparams.d    = msg.d === '' || msg.d === false ? [] : JSON.stringify(msg.d);
            
            functionparams.filetype     = typeof msg.filetype       === 'undefined' ? false : msg.filetype;
            functionparams.filename     = typeof msg.filename       === 'undefined' ? false : msg.filename;
            functionparams.filesize     = typeof msg.filesize       === 'undefined' ? false : msg.filesize;
            functionparams.fileinchunk  = typeof msg.fileinchunk    === 'undefined' ? false : msg.fileinchunk;
            functionparams.numofchunk   = typeof msg.numofchunk     === 'undefined' ? false : msg.numofchunk;
            functionparams.currentchunk = typeof msg.currentchunk   === 'undefined' ? 0 : msg.currentchunk;
            
            updateChunk(functionparams.currentchunk);
        }
        else{
            functionparams.fileupload = new Blob([msg], {type: functionparams.filetype});
            
            switch(functionparams.workeraction){
                case 'test':
                    test();
                break;
                case 'uploadfiles':
                    uploadfiles();
                break;
            }
        }
    };
    
    
    function updateChunk(currentchunk){
        functionparams.currentchunk = currentchunk;
        functionparams.filedescriptor  = functionparams.filetype+'|';
        functionparams.filedescriptor  += functionparams.filename+'|';
        functionparams.filedescriptor  += functionparams.filesize+'|';
        functionparams.filedescriptor  += functionparams.fileinchunk+'|';
        functionparams.filedescriptor  += functionparams.numofchunk+'|';
        functionparams.filedescriptor  += functionparams.currentchunk;
    }
    
    function test(){
        self.postMessage('testresponse');
    }
    
    function uploadfiles(){
        var formdata = new FormData();
        formdata.append('app',functionparams.app);
        formdata.append('p',functionparams.p);
        formdata.append('a',functionparams.a);
        formdata.append('d',functionparams.d);
        formdata.append('filedescriptor',functionparams.filedescriptor);
        formdata.append('file',functionparams.fileupload);
        
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function(){
            if (xhr.readyState == 4){
                if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304){
                    if(functionparams.fileinchunk){
                        if(functionparams.currentchunk < functionparams.numofchunk){
                            functionparams.currentchunk  +=1;
                            updateChunk(functionparams.currentchunk);
                            
                            if(functionparams.currentchunk < functionparams.numofchunk)
                                self.postMessage('anotherchunk'+xhr.responseText);
                            else{
                                 self.postMessage(xhr.responseText);
                            }
                        }
                        else{
                            self.postMessage(xhr.responseText);
                            functionparams.workeraction = 'test';
                        }
                    }
                    else{
                        self.postMessage(xhr.responseText);
                        functionparams.workeraction = 'test';
                    }
                } else {
                    self.postMessage(xhr.responseText);
                    console.log("Request was unsuccessful: " + xhr.status);
                }
            }
        };
        
        xhr.open('POST', '../../',true);
        xhr.onload = function() {
        };
        xhr.upload.onprogress = function (event) {
            if (event.lengthComputable) {
                var complete;
                if(functionparams.fileinchunk){
                    complete = ((functionparams.currentchunk+(event.loaded / event.total))/functionparams.numofchunk) * 100;
                }
                else{
                    complete = (event.loaded / event.total) * 100;
                }
                
                self.postMessage(complete);
            }
        };
        xhr.send(formdata);
    }
    
