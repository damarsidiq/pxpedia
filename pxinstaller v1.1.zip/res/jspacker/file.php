<?php
// you can pass this script to PHP CLI to convert your file.


// or uncomment these lines to use the argc and argv passed by CLI :
/*
if ($argc >= 3) {
	$src = $argv[1];
	$out = $argv[2];
} else {
	echo 'you must specify  a source file and a result filename',"\n";
	echo 'example :', "\n", 'php example-file.php myScript-src.js myPackedScript.js',"\n";
	return;
}
*/

$message = '';

if(isset($_POST['pack'])){
	if(isset($_FILES)){
	$srcname    = $_FILES['fileinput']['name'];
    $src        = $_FILES['fileinput']['tmp_name'];
    $exout      = explode('.',$srcname);
	$out = '';
	foreach($exout as $outk=>$outv){
		if($outk == count($exout)-1)
			$out .= time().'.'.$outv;
		else
			$out .= '.'.$outv;
	}
    $out = substr($out,1);
    $fileout = fopen($out,'w');
}
else{
$fileout = false;
}
    



    
    require 'class.JavaScriptPacker.php';


    
    $script = file_get_contents($src);
    
    $t1 = microtime(true);
    
    $packer = new JavaScriptPacker($script, 'Normal', true, false);
    $packed = $packer->pack();
	if($fileout !== false)
    		$response['packed']   = fputs($fileout,$packed);
else
	return $packed;

	print_r($packed);
    $t2 = microtime(true);
    $time = sprintf('%.4f', ($t2 - $t1) );
    $message = '<h4>script '. $srcname . ' packed in '. $time. ' s.</h4>'. "\n";
	$message .= '<h3>Output:</h3>
				<textarea id="fileoutputtextarea">'. $packed .'</textarea>';
}



?>
<style>
	html{width:100%;height:100%;margin:0px;background: #DFDFDD;font-family: Arial}
	a{text-decoration:none;}
	#fileoutputtextarea{width:80%;height:300px;}
</style>

<form action="" method="POST" enctype="multipart/form-data">
    <h3>File Input:</h3>
    <input type="file" name="fileinput">
	<input type="submit" value="Pack" name="pack">
</form>
<?php echo $message; ?>
