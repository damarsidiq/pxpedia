<?php

Class ContactsList extends Model{
    function __construct(){
        parent::__construct('contactform',App::getUser()['currentrole']['appid']);
    }
    
    public function messagelist($page){
        $list = $this->getrecords(null,null,array('id','desc'));
        return $list;
    }
}


?>