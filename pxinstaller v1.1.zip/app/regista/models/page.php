<?php

Class Page extends Model{
    function __construct(){
        parent::__construct('page');
    }
}


?>