<?php

Class User extends Model{
    var $pagelimit = 3;
    function __construct(){
        parent::__construct('users',App::getappid());
    }
    public function username($userid){
        return $this->getrecord(array('id'=>$userid),'username');
    }
    public function getUserByEmail($email){
        return $this->getrecord(array('email'=>$email));
    }
    public function numofusers($condi=false,$app=false,$role=false){
        if($app == false){
            $app = Pxpedia::getUser()['currentrole']['appid'];
        }
        $userrolecondi['appid'] = $app;
        
        if($role !== false){
            $userrolecondi['role'] = $role;
        }
        $condi = array('id'=>array('in','userrole'=>array('userid',$userrolecondi)));
        
        return $this->countrows($condi);
    }
    public function getUsers($condi=false,$app=false,$role=false,$order=array('id','desc'),$page=0){
        if($app == false){
            $app = Pxpedia::getUser()['currentrole']['appid'];
        }
        $userrolecondi['appid'] = $app;
        
        if($role !== false){
            $userrolecondi['role'] = $role;
        }
        $condi = array('id'=>array('in','userrole'=>array('userid',$userrolecondi)));
        
        $limit = ($page*$this->pagelimit).','.$this->pagelimit;
        $order = $order == false ? null : $order;
        $users = $this->getrecords($condi,null,$order,$limit);
        
        return $users;
    }
    public function adduser($data,$appid){
        $newuser = App::register($data,$appid);
        if(is_array($newuser)){
            $data['id'] = $newuser[2];
            $newuser = App::adduserrole($data,$appid);
        }
        return $newuser;
    }
    public function editusersprimary($userid,$data){
        return $this->updaterecord($data,array('id'=>$userid));
    }
    public function updatepassword($userid,$newpassword){
        $user = App::getUserbyId($userid)[0];
        $user['password'] = $newpassword;
        return App::createpasswordhash($user);
    }
}


?>