<?php

Class Usersdata extends Model{
    function __construct(){
        parent::__construct('usersdata',App::getappid());
    }
    public function getusersmeta($userid){
        $row = $this->getrecords(array('userid'=>$userid),array('metakey','metavalue'));
        return $row;
    }
    public function addusermeta($userid,$metakeys,$metavals){
        if(is_array($metakeys)){
            $q = 'insert into '.$this->table.'(userid,metakey,metavalue) values';
            foreach($metakeys as $k=>$v){
                $q.= '('.$userid.','.$v.','.$metavals[$k].'),';
            }
            $q = substr($q,0,-1);
            return $this->query($q);
        }
        else{
            return $this->addrecord(array('userid','metakey','metavalue'),array($userid,$metakeys,$metavals));
        }
    }
    public function distinctmetakey(){
        $distinct = array();
        $query = $this->query('select distinct metakey from '.$this->table);
        if($query){
            $distinct = $this->fetchQueryResult($query);
        }
        return $distinct;
    }
    public function editusermeta($userid,$metas){
        foreach($metas as $metaidx=>$metavals){
            if(!$this->exists(array('userid'=>$userid,'metakey'=>$metavals[0]))){
                $edited = $this->addrecord(array('userid','metakey','metavalue'),array($userid,$metavals[0],$metavals[1]));
                if($edited===false){
                    return $edited;
                }
            }
            else{
                $edited = $this->updaterecord(array('metavalue'=>$metavals[1]),array('userid'=>$userid,'metakey'=>$metavals[0]));
                if($edited===false){
                    return $edited;
                }
            }
        }
        return true;
    }
    public function deleteusermeta($userid,$metas){
        foreach($metas as $metaidx=>$metavals){
            if($this->exists(array('userid'=>$userid,'metakey'=>$metavals[0]))){
                $edited = $this->deleterecord(array('userid'=>$userid,'metakey'=>$metavals[0]));
                if($edited===false){
                    return $edited;
                }
            }
        }
        return true;
    }
}


?>