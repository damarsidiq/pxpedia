<?php

Class BlogCategory extends Model{
    var $categories = false;
    var $categoriesparent = false;
    function __construct(){
        parent::__construct('blogcat',App::getUser()['currentrole']['appid']);
    }
    public function categories(){
        $categories     =  $this->getrecords(null,null,array('id','asc'));
        $assoc          = array();
        $assocparent    = array();
        
        if(count($categories) > 0){
            foreach($categories as $ck=>$cv){
                $assoc[$cv['id']] = $cv;
                $index = (int) $cv['parent'];
                $assocparent[$index][] =  $cv;
            }
        }
        $this->savecategoryvars($assoc,$assocparent);
        return array($assoc,$assocparent);
    }
    public function savecategoryvars($assoc,$assocparent=false){
        if($this->categoriesparent === false){
            $this->categories = $assoc;
            $this->categoriesparent = $assocparent;
        }
    }
    /**
	 * getdescendants. get blog category's descendant
	 * 
	 * @return array
	 */
    public function getdescendants($categoryid){
        if($this->categoriesparent === false){
            $this->categories();
        }
        $descendantsids = false;
        if(isset($this->categoriesparent[$categoryid])){
            $descendantsids = array();
            $descendantsids = $this->_getdescendants($categoryid,$descendantsids);
        }
        return $descendantsids;
    }
    /**
	 * _getdescendants. get blog category's children
	 * 
	 * @return array
	 */
    public function _getdescendants($categoryid,$descendantsids){
        if(isset($this->categoriesparent[$categoryid])){
            foreach($this->categoriesparent[$categoryid] as $pk=>$pv){
                $descendantsids = array_merge($descendantsids,array($pv['id']));
                $descendantsids = $this->_getdescendants($pv['id'],$descendantsids);
            }
        }
        return $descendantsids;
    }
    public function deletec($id){
        $delete = $this->deleterecord(array('parent'=>$id));
        if($delete === false){
            return false;
        }
        return $this->deleterecord(array('id'=>$id));
    }
    public function saveblogcategory($data){
		return $this->addrecord($data['column'],$data['value']);
	}
	public function updatecategory($data){
	    $updated = $this->updaterecord($data['data'],array('id'=>$data['id']));
	    return  $updated ? $updated : ($updated === false ? false :-1);
	}
	public function newparentis_descendant($cid,$pid){
	    $cparent = $this->parentid($pid);
	    while($cparent != 0){
	        if($cparent == $cid){
	            return true;
	        }
	        $cparent = $this->parentid($cparent);
	    }
	    return false;
	}
	public function parentid($cid){
	    return $this->getrecord(array('id'=>$cid),'parent');
	}
}


?>