<?php

Class Userrole extends Model{
    function __construct(){
        parent::__construct('userrole',App::getappid());
    }
    public function getuserrolebyapp($userid,$app){
        $row = $this->getrecord(array('userid'=>$userid,'appid'=>$app),'role');
        return $row;
    }
    public function updaterole($userid,$userrole){
        return $this->updaterecord(array('appid'=>$userrole[0],'role'=>$userrole[1]),array('userid'=>$userid));
    }
}


?>