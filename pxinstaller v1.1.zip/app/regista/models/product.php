<?php

Class Product extends Model{
    function __construct(){
        parent::__construct('product',App::getUser()['currentrole']['appid']);
    }
}


?>