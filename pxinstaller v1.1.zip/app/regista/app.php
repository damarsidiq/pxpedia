<?php

if(!class_exists('Pxpedia')){
	die();
}

/*regista*/
Class App extends Pxpedia{
    public static $dbcreator;

    function __construct(){
		parent::__construct();

		self::$dbcreator = false;
    }
    public static function getAppDbVars(){
		$dbvars = array();
        if(self::$dbcreator === false){
			$dbvars['dbhost'] = self::$db->dbhost;
			$dbvars['dbuser'] = self::$db->dbuser;
			$dbvars['dbpasswd'] = self::$db->dbpasswd;
			$dbvars['dbname'] = self::$db->dbname;
        }
        else{
			$dbvars['dbhost'] = self::$dbcreator->dbhost;
			$dbvars['dbuser'] = self::$dbcreator->dbuser;
			$dbvars['dbpasswd'] = self::$dbcreator->dbpasswd;
			$dbvars['dbname'] = self::$dbcreator->dbname;
        }
        return $dbvars;
    }
    public static function createdbcreator($username,$passwd){
        self::$dbcreator = new db('',self::$db->dbhost,$username,$passwd);

        if(self::$dbcreator === false){
            return false;
        }
        return true;
    }
    public static function createnewdb($dbname){
        if(self::$dbcreator === false){
            $created = self::$db->query('create database '.$dbname);

            if($created === false){
                echo self::$db->printerrors(false);
                return 0;
            }
            return 1;
        }
        else{
            $created = self::$dbcreator->query('create database '.$dbname);
            if($created === false){
                echo self::$db->printerrors(false);
                return 0;
            }
            return 1;
        }
    }
    public static function createnewtable($dbname,$sql){
        if(self::$dbcreator === false){
            $olddbname = self::$db->dbname;
            self::$db->query('use '.$dbname);

            $q = self::$db->query('SHOW VARIABLES WHERE Variable_name = "version"');
            $r = self::$db->fetchQueryResults($q,true);
            if(floatval($r[0]['Value']) < 5.5){
                $sql = self::oldsql($sql);
            }
            $created = self::$db->query($sql);
        }
        else{
            $olddbname = self::$dbcreator->dbname;
            self::$dbcreator->query('use '.$dbname);

            $q = self::$dbcreator->query('SHOW VARIABLES WHERE Variable_name = "version"');
            $r = self::$dbcreator->fetchQueryResults($q,true);
            if(floatval($r[0]['Value']) < 5.5){
                $sql = self::oldsql($sql);
            }
            $created = self::$dbcreator->query($sql);
        }
        if($created === false){
            echo self::$db->printerrors(false);
            return 0;
        }
        else{
            self::$db->query('use '.$olddbname);
        }
        return 1;
    }
    public static function checkPermission($app=false,$privilege=false){
        if($app === false){
            $app = App::getUser()['currentrole']['appid'];
        }
		if(!App::isAppadmin($app) && !App::isRoot()){
			return false;
		}
		return true;
	}
	public static function blogcathierarchylist($blogarr,$exclude=false){
		$hierarchy = '';
		$unset = array();
		$arrkeys = array();
		foreach($blogarr as $l =>$v){
		    $arrkeys[] = $l;
		}
		sort($arrkeys);
		foreach($arrkeys as $keys=>$catparent){
			if(!in_array($catparent,$unset))
			foreach($blogarr[$catparent] as $idx=>$category){
				$skip = false;
				if(is_array($exclude)){
					if(in_array($category['id'],$exclude)){
						$skip = true;
					}
				}

				if(!$skip){
					$hierarchy .= '<div class="row">
									<div class="blogcatlistid">'. $category['id'] .'</div>
									<div class="blogcatlistname"><span class="catname">'. $category['name'] .'</span></div>
									<div class="blogcatlistparent hidden">'. $category['parent'] .'</div>
									<div class="blogcatlistdescription hidden">'. $category['description'] .'</div>
									<div class="blogcatlistaction">
										<span class="editblogcat actionsspan" id="editblogcat_'. $category['id'] .'">edit</span>
										<span class="deleteblogcat actionsspan redfont" id="deleteblogcat_'. $category['id'] .'">delete</span>
									</div>
								</div>';

					if(isset($blogarr[$category['id']])){
						list($childhierarchy,$unsetx) = self::blogcathierarchy($blogarr[$category['id']],$blogarr,1,$exclude);
						$unset = array_merge($unset,$unsetx);
						$hierarchy .= $childhierarchy;
					}
				}
			}
		 }
		 return $hierarchy;
	}
	public static function blogcathierarchy($cblogarr,$blogarr,$depth=1,$exclude=false){
		$hierarchy = '';
		$cunset = false;
		$unsets = array();
		foreach($cblogarr as $idx=>$catval){
			$skip = false;
			if(is_array($exclude)){
				if(in_array($catval['id'],$exclude)){
					$skip = true;
				}
			}

			if(!$skip){
				$cunset = $catval['parent'];

				$nameprefix = '';
				for($i=$depth;$i>0;$i--){
					$nameprefix .= '<span class="subpseudopadding"></span>';
				}
				$hierarchy .= '<div class="row">
									<div class="blogcatlistid">'. $catval['id'] .'</div>
									<div class="blogcatlistname">'.$nameprefix.'<span class="catname">'.$catval['name'] .'</span></div>
									<div class="blogcatlistparent hidden">'. $catval['parent'] .'</div>
									<div class="blogcatlistdescription hidden">'. $catval['description'] .'</div>
									<div class="blogcatlistaction">
										<span class="editblogcat actionsspan" id="editblogcat_'. $catval['id'] .'">edit</span>
										<span class="deleteblogcat actionsspan redfont" id="deleteblogcat_'. $catval['id'] .'">delete</span>
									</div>
								</div>';

				if(isset($blogarr[$catval['id']])){
					list($childhierarchy,$unsetx) = self::blogcathierarchy($blogarr[$catval['id']],$blogarr,($depth+1));
					$unsets = array_merge($unsetx,$unsets);
					$hierarchy .= $childhierarchy;
				}
			}
		 }
		 $cunset = array_merge(array($cunset),$unsets);
		 return array($hierarchy,$cunset);
	}
	public static function switchApp($app=false,$role=false){
		Pxpedia::switchRole($app,$role);
	}
	public static function pluginlist(){
		$list = array();
		$pluginhandle = opendir(App::getConfig('plugins'));
		$appplugins = self::$db->getRows('plugins',array('name','location','id'),array('and'=>array('status'=>1,'app'=>Pxpedia::getUser()['currentrole']['appid'])));
		$apppluginsname = array_column($appplugins,'location','id');
		while(false !== ($plugin = readdir($pluginhandle))){
			if($plugin != '.' && $plugin != '..' ){
				$page = str_replace('_',' ',$plugin);
				$pagex = explode(' ',$page);
				foreach($pagex as $pagexk=>$pagexv){
					$pagex[$pagexk] = strtoupper($pagexv[0]).substr($pagexv,1);
				}
				$pagename 	= implode(' ',$pagex);
				$listidx 	= count($list);

				$plugindata['plugin'] 	= $plugin;
				$plugindata['p'] 		= 'admin';
				$plugindata['a'] 		= 'pageInit';

				$list[$listidx]['name'] 		= $pagename;
				$list[$listidx]['linkactivate'] = in_array($plugin,$apppluginsname) ? '<a href="'. App::appurl('',array('d'=>array('removePlugin'=>array_keys($apppluginsname,$plugin)[0])),true) .'">- deactivate</a>': '<a href="'. App::appurl('',array('d'=>array('activatePlugin'=>$plugin)),true) .'">+ activate</a>';
			}
		}
		return $list;
	}
	public static function checkpage($pagefile,$page){
		require_once self::$config['currentapp'].'/controllers/'.$pagefile;
		$pagecheck = new $page();
		return $pagecheck->checkpage();
	}
	public static function adminmenu(){
		$menus 			= array();
		$pageshandle 	= opendir(self::$config['currentapp'].'/controllers/');

		$menu_app 		= false;
		if(Pxpedia::isRoot() || pxpedia::isAppadmin()){
			$menu_app = true;
		}

        while(false !== ($pagefile = readdir($pageshandle))){
            if($pagefile != '.' && $pagefile != '..' && $pagefile != 'ajax.php' && $pagefile !== 'browser.php' && $pagefile !== 'pages.php'){
				$page 		= str_replace('.php','',$pagefile);

				if(!self::checkpage($pagefile,$page)){
					continue;
				}

				$pagename	= strtoupper($page[0]).substr($page,1);

				if($pagename == 'App' && !$menu_app){
					continue;
				}
				if($pagename == 'Home'){
					$menuidx = 0;
				}
				else{
					$menuidx 	= isset($menus[0]) ? count($menus) : count($menus)+1;
				}

				$menus[$menuidx]['name'] 	= $pagename;
				$menus[$menuidx]['link'] 	= Pxpedia::appurl('',array('p'=>$page));
				if(!isset(Pxpedia::$data['plugindata'])){
					$menus[$menuidx]['current'] = Pxpedia::$page == $page ? true : false;
				}
				else{
					$menus[$menuidx]['current'] = false;
				}
            }
        }

		if(Pxpedia::getUser()['currentrole']['role'] == 2 || Pxpedia::getUser()['currentrole']['role'] == 1){
			$appplugins = self::$db->getRows('plugins',array('name','location','id','personalized'),array('and'=>array('status'=>1,'app'=>Pxpedia::getUser()['currentrole']['appid'])));
			foreach($appplugins as $pluginkey=>$pluginval){
				$menuidx 	= count($menus);

				$plugindata['plugindata']['plugin'] 	= $pluginval['id'];
				$plugindata['plugindata']['p'] 			= 'admin';
				$plugindata['plugindata']['a'] 			= 'pageInit';

				$menus[$menuidx]['name'] 	= $pluginval['name'];
				$menus[$menuidx]['link'] 	= Pxpedia::appurl('',array('d'=>$plugindata),false);

				if(isset(Pxpedia::$data['plugindata'])){
					if(Pxpedia::$data['plugindata']['plugin'] == $plugindata['plugindata']['plugin']){
						if(Pxpedia::$data['plugindata']['p'] == $plugindata['plugindata']['p']){
							$menus[$menuidx]['current'] = true;
						}
					}
				}
				$menus[$menuidx]['current'] = isset($menus[$menuidx]['current']) ? $menus[$menuidx]['current'] : false;
			}
		}
		uasort($menus,function($a,$b){
			if($a['name'] == 'Home'){
				return -1;
			}
			elseif($b['name'] == 'Home'){
				return 1;
			}
            $sortf = $a['name'] < $b['name'] ? -1 : ($a['name'] == $b['name'] ? 0 : 1);
            return $sortf;
        });
		$sortedmenu = array();
		for($i=1;$i<count($menus);$i++){
			$sortedmenu[] = false;
		}
		$counter = 0;
		foreach($menus as $menuidx=>$menuelem){
			$sortedmenu[$counter] = $menuelem;
			$counter++;
		}
		return $sortedmenu;
    }

}


?>