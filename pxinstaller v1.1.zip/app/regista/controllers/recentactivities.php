<?php

Class RecentActivities extends Controller{
    function __construct() {
        parent::__construct();
    }
	public function checkpage(){
		return false;		
	}
    public function load($ajax,$return=false){
        $this->setPagevar('ajax',$ajax);
        $this->setPagevar('visit',6);
        $this->setPagevar('newapp',1);
        $this->setPagevar('newplugin',1);
        $this->setPagevar('newuser',3);
        $this->setPagevar('login',7);
        
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
		    $this->addheadfootsrc(array('mobileregista'=>App::getConfig('appviews').'/styles/mobileregista.css'),false);
		}
		else{
		    $this->setPagevar('mobile','false');
		}
        
        $result = $this->loadView('/modules/activities',$return);
        if($return){
            return $result;
        }
    }
}
?>