<?php

Class Blog extends Controller{
    var $blogattrtodelete;
    function __construct() {
        parent::__construct();
	    $this->blogattrtodelete = false;		
		if(App::isMobile()){
		    $this->addheadfootsrc(array('mobileregista'=>'styles/mobileregista.css'),false);
		}
    }
	public function checkpage(){
	    $this->delmodel('bloglist');
		return (count($this->model('bloglist')->db->errors) > 0 ? false : true );
	}
    public function pageInit($data=null,$view='blog'){
	    if(isset($data['ajax']))
			$this->setPagevar('ajax',true);

		if(count($this->model('bloglist')->db->errors)){
		    $response['view'] = '404';
		    $this->setPagevar('response',$response);
			return '404';
        }
        $response['view'] = 'blog';
		$this->setPagevar('response',$response);
        
        list($bloglist,$pagenum,$limit) 		= $this->model('bloglist')->bloglist(0,'false');
        
        $response['bloglist']   = $bloglist;
        $response['pagenum']    = $pagenum;
        $response['limit']      = $limit;
        
        if(isset($data['ajax'])){
		    $response['scripts'][] = Pxpedia::getConfig('resources').'tinymce/js/tinymce/tinymce.min.js';

			$this->setPagevar('response',$response);
		}
		else{
		    $this->addheadfootsrc(0,array('tinymce'=>Pxpedia::getConfig('resources').'tinymce/js/tinymce/tinymce.min.js|onload="onreceivingpage()"'));
		}

		
		list($blogcat,$blogparenthierarchy) 	= $this->model('blogcategory')->categories();
		$blogstatus 							= array(0=>'draft',1=>'published');
		$blogattrkey							= $this->model('blogattribute')->distinctattributes();
		
		$this->setPagevar('blogstatus',$blogstatus);
		$this->setPagevar('blog',$bloglist);
		$this->setPagevar('blogcat',$blogcat);
		$this->setPagevar('bloghierarchy',$blogparenthierarchy);
		$this->setPagevar('blogattrkey',$blogattrkey);
		$this->setPagevar('blogpagenum',$pagenum);
		$this->setPagevar('pastentriesnumperpage',$this->model('bloglist')->itemperpage);
    }
	
	public function editblog($data){
		$blogdata = $this->model('bloglist')->geteditblogdata($data['blogid']);
		$blogattributes = $this->model('blogattribute')->blogattributes($data['blogid']);
		$blogimages = $this->model('bloggallery')->blogimages($data['blogid']);
		
		
		$blogimg = '';
		$imagedir = App::$config['uploads'].App::appById(App::getUser()['currentrole']['appid']).'/images/';
		foreach($blogimages as $bk=>$bv){
		    $blogimg .= '<*featimage*>'.$imagedir.$bv['id'].'_thumb.png<e>'.$bv['id'].'<e>'.$bv['image'];
		}
		
		$blogdata['attributes'] = $blogattributes;
		$blogdata['featimage']  = $blogimg; 
		
		$this->setPagevar('response',$blogdata);
		
		return 'ajax';
	}
	public function deletecategory($data){
	    $this->setPagevar('response',$this->model('blogcategory')->deletec($data['categoryid']));
	    return 'ajax';
	}
	public function deleteblog($data){
		$blogid = $data['blogid'];
		
		$response['deleted'] = $this->model('bloglist')->deleteblog($blogid);
		
		$this->setPagevar('response',$response);
		return 'ajax';
	}
	
	public function saveblogcategory($data){
		$column = array('parent','name','description');
		$data = array($data['parent'],$data['name'],$data['description']);
		
		$field['column'] = $column;
		$field['value'] = $data;
		
		$saved = $this->model('blogcategory')->saveblogcategory($field);
		if($saved){
			$saved = $this->model('blogcategory')->insertid();
		}
		
		$this->setPagevar('response',$saved);
		return 'ajax';
	}
	public function updatecategory($data){
	    $newparent = 'false';
	    $newparentis_descendant = 'false';
	    if($data['newparent'] != 'false'){
	        $newparent = 'true';
	        $parentisnew = array('column'=>array('name','parent'),'value'=>array($data['parent'],0));
	        $updated = $this->model('blogcategory')->saveblogcategory($parentisnew);
	        
	        if(!$updated){
    	        $this->setPagevar('response',false);
    	        return 'ajax';
    	    }
    	    else{
    	        $data['parent'] = $newparent = $updated;
    	    }
	    }
	    
	    unset($data['newparent']);
	    
	    if($data['cid']==0){
	        unset($data['cid']);
	        $mdata['column']    = array_keys($data);
	        $mdata['value']     = array_values($data);
	        $updated = $this->model('blogcategory')->saveblogcategory($mdata);
	    }
	    else{
	        $mdata= array();
	        $mdata['id'] = $data['cid'];
	        unset($data['cid']);
	        
	        $mdata['data'] = $data;
	        if($mdata['data']['parent'] == $mdata['id']){
	            $mdata['data']['parent'] = 0;
	        }
	        else{
	            if($this->model('blogcategory')->newparentis_descendant($mdata['id'],$mdata['data']['parent'])){
	                $pmdata = array();
	                $pmdata['id'] = $mdata['data']['parent'];
	                $pmdata['data'] = array('parent'=> $this->model('blogcategory')->parentid($mdata['id'])); 
	                $this->model('blogcategory')->updatecategory($pmdata);
	                $newparentis_descendant = 'true';
	            }
	        }
	        $updated = $this->model('blogcategory')->updatecategory($mdata);
	   }
	   
	   
	   $updated = $newparent.','.$updated.','.$newparentis_descendant;
	   
	    echo $updated;
	    return 'plain';
	}
	public function saveChanges($data){
	    $blogid = (int) $data['id'];
	    $edited = $data['changes'];
	    $returnresponse = isset($data['response']) ? true : false;
	    
	    if($blogid == 0){
	        $blogid = $this->model('bloglist')->addblog();
	    }
	    
	    $editeddata     = array();
	    $updated        = false;
	    
	    if(strpos($edited,'<*edsep*>') !== false){
	     	$editedx        = explode('<*edsep*>',$edited);
    	    foreach($editedx as $editedk=>$editedv){
    	        if($editedv != ''){
    	            $editedelem = explode('<*edelemsep*>',$editedv);
    	            
    	            if($editedelem[0] == 'attrval'){
    	               $updated = $this->updateblogattr($blogid,'value',$editedelem[1],$editedelem[2]);
    	            }
    	            elseif($editedelem[0] == 'attrkey'){
                        if($editedelem[2] == '<*delete*>'){
                            if($this->blogattrtodelete === false){
                                $this->blogattrtodelete = [];
                                $this->blogattrtodelete['blogid'] = $blogid;
                                $this->blogattrtodelete['attridxs'] = [];
                            }
                            
                            $this->blogattrtodelete['attridxs'][] = $editedelem[1];
                            $updated = true;
                        }
                        else
                            $updated = $this->updateblogattr($blogid,'attrkey',$editedelem[1],$editedelem[2]);
    	            }
    	            elseif($editedelem[0] == 'featimage'){
    	                $imagefeatstr = explode('<*featimage*>',$editedelem[2]);
    	                $updated = $this->model('bloggallery')->imageupdate($imagefeatstr);
    	            }
    	            else{
        	            $editeddata[$editedelem[0]]= $editedelem[2];
        	            $updated = true;
    	            }
    	            if(!$updated){
    	                if($returnresponse)
    	                    return false;
    	                    
    	                $this->setPagevar('response',false);
    	                return 'ajax';
    	            }
    	        }
    	    }
    	    if(count($editeddata)){
    	        $updatedata = array('id'=>$blogid);    
    	        $updatedata = array_merge($updatedata,$editeddata);
    	    
    	        $updated = $this->model('bloglist')->update($updatedata);
    	        if(!$updated){
    	            if($returnresponse)
    	                 return false;
    	                 
                    $this->setPagevar('response',false);
                    return 'ajax';
                }
    	    }
    	    if($this->blogattrtodelete !== false){
    	        $updated = $this->model('blogattribute')->deleteblogattr($this->blogattrtodelete);
    	        $this->blogattrtodelete   = false;
    	    }   
	    }
	    
	    $updated = $updated ? $blogid : $updated;
	    
        if($returnresponse)
             return $blogid;
	                 
	    $this->setPagevar('response',$updated);
	    return 'ajax';
	}
	public function updateblogattr($blogid,$type,$index,$value){
	    return $this->model('blogattribute')->updateblogattr($blogid,$type,$index,$value);
	}
	
	public function blogpage($data){
	    $condition = array();
	    if($data['category'] != 'category' && $data['category'] != 0){
	        $condition['category'] = $data['category'];
	    }
	    if($data['status'] != -1){
	        $condition['status'] = $data['status'];
	    }
	    
	    if(count($condition) > 1){
	        $condition = array('and'=>$condition);
	    }
	    
	    if($data['keywords'] != 'search'){
	        $keycondition['title'] = array('like',"%".$data['keywords']."%");
	        $keycondition['content'] = array('like',"%".$data['keywords']."%");
	        
	        $metafilter = $this->model('blogattribute')->metafilter($data['keywords']);
	        if(count($metafilter)){
    	        foreach($metafilter as $mk=>$mv){
    	            $metas[] = $mv['blogid'];
    	        }
    	        $keycondition['id'] = array('in',$metas);   
	        }
	        
	        $condition = array_merge($condition,array('or'=>$keycondition));
	    }
	    
	    list($blogs,$pagenum,$limit,$lastq) = $this->model('bloglist')->bloglist($data['offset'],$data['limit'],$condition);
	    
	    $response['blog'] = $blogs;
	    $response['pagenum'] = $pagenum;
	    $response['lastq'] = $lastq;
	    $response['limit'] = $limit;
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function deleteblogimage($data){
	    $imagedir = App::$config['uploads'].App::appById(App::getUser()['currentrole']['appid']).'/images/';
	    $imagefile = $imagedir.$data['blogimageid'].'.png';
	    $delete = unlink($imagefile);
	    
	    $response['delete'] = false;
	    if($delete){
	        $this->model('bloggallery')->removeimage($data['blogimageid']);
	        $response['delete'] = true;
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function blogimageupdate($data){
	    $updated = $this->model('bloggallery')->renameimage($data['imageid'],$data['newname']);
	    $response['result'] = $updated;
	    if($updated === false){
	        $response['error'] = $this->model('bloggallery')->printerrors(false);
	        $response['query'] = $this->model('bloggallery')->querystring();
	    }
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function uploadblogimage($data){
	    if(isset($_FILES) && count($_FILES)){
			$thefile = $_FILES['file'];
		}
		else{
			if(isset($_POST['file'])){
				$thefile = [];
				$thefile['file'] = $_POST['file'];
			}
		}
		
		$response['upload'] = false;
		if($thefile){
			$datax = explode('|',$data);
			$blogid = $datax[0];
			unset($datax[0]);
			
			$imagename = implode('|',$datax);
			
			if(!isset($thefile['tmp_name'])){
				$thefile['tmp_name'] = $thefile['file'];
				$thefile['name'] = $imagename;
			}
			
			if($blogid == 0){
			    $addblog = [];
			    $addblog['id'] = 0;
			    $addblog['response'] = true;
			    $addblog['changes'] = '';
			    
			    $blogid = $this->saveChanges($addblog);
			    if(!$blogid){
			        $response['blogid']   = $blogid;
			        $response['image'] = $this->model('bloglist')->printerrors(false);
			        $this->setPagevar('response',$response);
		            return 'ajax';
			    }
			    $response['blogid']   = $blogid;
			}
			
			$imageid = $this->model('bloggallery')->addimage($blogid,$imagename);
			if($imageid !== false){
			    if(isset($_POST['filedescriptor'])){
			        $descriptor = explode('|',$_POST['filedescriptor']);
			        $thefile['type'] = $descriptor[0];
			    }
			    $imageid = $this->model('bloggallery')->insertid();
			    $imagedir = App::$config['uploads'].App::appById(App::getUser()['currentrole']['appid']).'/images';
			    if(!file_exists($imagedir)){
			        $dir = mkdir($imagedir,0777);
			    }
				$uploaded = App::uploadimage($thefile,$imageid,$imagedir,true);
				if(!$uploaded){
					$deleted = $this->model('bloggallery')->removeimage($imageid);
				}
				else{
				    $thumb  = App::imagewithsize($imageid,0,$imagedir);
				    $medium = App::imagewithsize($imageid,1,$imagedir);
				    
				    $response['imageid'] = $imageid;
					$response['upload'] = true;
					$response['image'] = $thumb;
				}
			}
			else{
			    $response['image'] = $this->model('bloggallery')->printerrors(false);
			}
		}
		$this->setPagevar('response',$response);
		return 'ajax';
	}
}
?>