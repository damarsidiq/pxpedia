<?php

Class Browser extends Controller{
    var $appsplugins;
    var $typetosearch;
    var $capp;
    var $allapp = false;
    function __construct() {
        parent::__construct();
    }
	public function checkPermission($app,$privilege=false){
		if(!App::isAppadmin($app) && !App::isRoot()){
			$response['result'] = false;
			$response['msg'] = 'insufficient permission';
			$this->setPagevar('response',$response);
			return false;
		}
		return true;
	}
	public function renamefile($data){
	    $app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		if(!App::checkPermission($app)){
			return 'ajax';
		}
		if($pathtype == 'plugins'){
		    $pathx = $this->updateappplugin($path,$app);
			if($pathx == false){
				return 'ajax';
			}
			$path = $pathx;
		}

		$path = $this->getFiles($data,true);
		$response = false;

		if(file_exists($path.'/'.$thefile)){
		    if(!file_exists($path.'/'.$data['newname'])){
		        $response = rename($path.'/'.$thefile,$path.'/'.$data['newname']);
		    }
		}

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function deletefile($data){
	    $app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		if(!App::checkPermission($app)){
			return 'ajax';
		}
		if($pathtype == 'plugins'){
		    $pathx = $this->updateappplugin($path,$app);
			if($pathx == false){
				return 'ajax';
			}
			$path = $pathx;
		}

		$path = $this->getFiles($data,true);
		$response = false;

		if(file_exists($path.'/'.$thefile)){
			$response = unlink($path.'/'.$thefile);
		}

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function createfile($data){
	    $app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		if(!App::checkPermission($app)){
			return 'ajax';
		}
		if($pathtype == 'plugins'){
		    $pathx = $this->updateappplugin($path,$app);
			if($pathx == false){
				return 'ajax';
			}
			$path = $pathx;
		}

		$path = $this->getFiles($data,true);
		$response = false;

		if(!file_exists($path.'/'.$thefile)){
		    $thefilenamex = explode('.',$thefile);
		    unset($thefilenamex[count($thefilenamex)-1]);
		    $thefilename = ucfirst(implode('.',$thefilenamex));

		    switch($pathtype){
		        case 'controllers':
		            $newcontent = '<?php '."\r\n".
		                                'Class '.$thefilename.' extends Controller{'."\r\n".
		                               '	function __construct(){'."\r\n".
		                              '		parent::__construct();'."\r\n".
		                             '	}'."\r\n".
		                            '}'."\r\n";
		        break;
		        case 'models':
		            $newcontent = '<?php '."\r\n".
		                                'Class '.$thefilename.' extends Model{'."\r\n".
		                               '	function __construct(){'."\r\n".
		                              '		parent::__construct();'."\r\n".
		                             '	}'."\r\n".
		                            '}'."\r\n".
		                            '?>'."\r\n";
		        break;
		        default:
		            $newcontent = '';
		        break;
		    }
			$handler = @fopen($path.'/'.$thefile,'wb');
			$response = fputs($handler,$newcontent);
		}

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function saveFile($data){
		$app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		if(!App::checkPermission($app)){
			return 'ajax';
		}
		if($pathtype == 'plugins'){
		    $pathx = $this->updateappplugin($path,$app);
			if($pathx == false){
				return 'ajax';
			}
			$path = $pathx;
		}

		$path = $this->getFiles($data,true);
		$response = false;

		if(file_exists($path.'/'.$thefile)){
			$handler = @fopen($path.'/'.$thefile,'wb');
			$response = fputs($handler,$data['content']);
		}

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function updateappplugin($path,$app){
		$pluginx = explode('/',$path);
		if($pluginx[2] != 0){
			return $path;
		}

		$pluginid   	= $this->model('plugin')->getrecord(array('app'=>$app,'location'=>$pluginx[1]),'id');
		$personalized   = $this->model('plugin')->updaterecord(array('personalized'=>$pluginid),array('id'=>$pluginid));

		if($personalized !== false){
			if($personalized === 0){
				$personalized = $this->model('plugin')->personalizePlugin($app,$pluginx[1],$pluginid);
			}

			if($personalized !== false){
				$pluginx[2] = $pluginid;
				return implode('/',$pluginx);
			}
			return $personalized;
		}
		return $personalized;
	}
	public function packcss($data){
	    $app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$theorifile = $thefile 	= $data['file'];

		$thefilex = explode('.',$thefile);
		$thefilex[count($thefilex)-1] = 'min.'.$thefilex[count($thefilex)-1];
		
		$thefile = implode('.',$thefilex);

		$path       = $this->getFiles($data,true);
		$response   = false;

		require_once App::getConfig('resources').'idiallomincss/minifier.php';
        $minifier = new CSSmini();


        // Merge and minify all the files
        $css = $minifier->minify($data);

        $handler    = @fopen($path.'/'.$thefile,'wb');
		$response['packed']   = fputs($handler,$css);
		if($data['packmode'] == 'jspackerdeco'){
		    $handler    = @fopen($path.'/'.$theorifile,'wb');
		    $response['packed']   = fputs($handler,$css);
		}
		$response['filename'] = $thefile;
		$response['content'] = $css; 

        fclose($handler);

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function packfile($data){
	    $app 		= $data['appid'];
		if(!App::checkPermission($app)){
			return 'ajax';
		}
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		if (get_magic_quotes_gpc())
            $data['content'] = stripslashes($data['content']);
            
		$thefilex = explode('.',$thefile);
		if($thefilex[count($thefilex)-1] == 'css'){
		    return $this->packcss($data);
		}
		$thefilex[count($thefilex)-1] = 'min.'.$thefilex[count($thefilex)-1];
		$thefile = implode('.',$thefilex);

		$path       = $this->getFiles($data,true);
		$response   = false;

        require_once App::getConfig('resources').'jspacker/class.JavaScriptPacker.php';

        $encoding = $data['packmode'] == 'jspackerdeco' ? 0 : 62;
        $fast_decode = true;
        $special_char = false;

        $packer = new JavaScriptPacker($data['content'], $encoding, $fast_decode, $special_char);
        $packed = $packer->pack();
        $packed = addslashes($packed);

		$handler    = @fopen($path.'/'.$thefile,'wb');
		$response['packed']   = fputs($handler,$packed);
		$response['filename'] = $thefile;

		fclose($handler);
		$saved = stripslashes(file_get_contents($path.'/'.$thefile));
		$handler = @fopen($path.'/'.$thefile,'wb');
		$saved2 = fputs($handler,$saved);

		fclose($handler);

		$this->setPagevar('response',$response);
		return 'ajax';
	}
	public function searchrescontent($data){
	    if(!App::checkPermission($data['appid'])){
			return 'ajax';
		}
	    $app 		= $data['appid'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

	    if(file_exists($path.'/'.$thefile)){
			if(strpos($thefile,'.js') !== false)
				$content = stripslashes(file_get_contents($path.'/'.$thefile));
			else
			    $content = file_get_contents($path.'/'.$thefile);
		}
		else{
			$content = $path.'/'.$thefile;
		}
		$this->setPagevar('response',$content);
		return 'ajax';
	}
	public function completeStub($data){
	    if(!App::checkPermission($data['appid'])){
			return 'ajax';
		}
		$app 		= $data['appid'];
		$pathtype 	= $data['pathtype'];
		$path 		= $data['path'];
		$thefile 	= $data['file'];

		$path = $this->getFiles($data,true);

		if(file_exists($path.'/'.$thefile)){
			if(strpos($thefile,'.js') !== false)
				$content = stripslashes(file_get_contents($path.'/'.$thefile));
			else
			    $content = file_get_contents($path.'/'.$thefile);
		}
		else{
			$content = $path.'/'.$thefile;
		}
		$this->setPagevar('response',$content);
		return 'ajax';
	}
	public function pluginlist($appid){
	    if(!App::checkPermission($appid)){
			return 'ajax';
		}
		$list = array();
		$pluginhandle = opendir(App::getConfig('plugins'));

		$this->table 		= 'plugins';
		$this->appsplugins 	= $this->getrecords(array('and'=>array('status'=>1,'app'=>$appid)),array('location','id','personalized'));
		foreach($this->appsplugins as $k=>$v){
			if(!$v['personalized']){
				$this->appsplugins[$k]['id'] = 0;
			}
		}
	}
	public function updatetree($data){
	    $oldcontent = $data['oldcontent'];
	    $oldcontentx = explode('<edsep>',$oldcontent);
	    
	    $appid = $data['appid'];
	    $app 			= isset($data['appid']) ? $data['appid'] : App::getappid($data['appname']);
	    $appname 		= isset($data['appname']) ? $data['appname'] : App::appById($app);
	    if(!App::checkPermission($appid)){
			return 'ajax';
		}
		
		$pathx          = explode('/',$data['path']);
		$pathx[0]       = strtolower($pathx[0]);
		$basepath       = $pathx[0];
		unset($pathx[0]);
		$data['path']   = implode('/',$pathx);
		
		 switch($basepath){
			case 'app':
				$folder = App::$config['approot'].$appname;
			break;
            case 'controllers':
                $cfolder = '/controllers/';
                $folder = App::$config['approot'].$appname.$cfolder.$data['path'];
            break;
            case 'models':
                $cfolder = '/models/';
                $folder = App::$config['approot'].$appname.$cfolder.$data['path'];
            break;
            case 'views':
                $cfolder = '/views/';
                $folder = str_replace('./','',App::$config['views']).$appname.'/'.$data['path'];
            break;
            case 'resources':
                $folder = $appname == 'regista' ? str_replace('./','',App::$config['resources']).$data['path'] : str_replace('./','',App::$config['resources']).$appname.'/'.$data['path'];
            break;
            case 'uploads':
                $folder = str_replace('./','',App::$config['uploads']).$appname.'/'.$data['path'];
            break;
            case 'plugins':
                $folder = str_replace('./','',App::$config['plugins']).'/'.$data['path'];
				$this->pluginlist($app);
            break;
			default:
				$folder = str_replace('./','',$path).$data['path'];
			break;
        }
		
		
		if(strpos($data['path'],'plugins/') !== false){
			$tree = $this->pluginfileinfolder($folder,array(),true,$this->appsplugins,false);
			$content = $this->pluginfileinfolder($folder,array(),false,$this->appsplugins,false);
		}
		else{
			$tree = $this->fileinfolder($folder,array(),true,0,false);
			$content = $this->fileinfolder($folder,array(),false,0,false);
		}
		if(count($content)){
		    if(count($oldcontentx)){
		        $newcontent = array();
		        foreach($content as $ck=>$cv){
		            $cidx = array_search($cv['name'],$oldcontentx);
		            if($cidx === false){
		                $newcontent[] = $cv;
		            }
		            else{
		                array_splice($oldcontentx,$cidx,1);
		            }
		        }
		        $content = $newcontent;
		    }
		}
		
		$response['tree'] = $tree;
		$response['content'] = $content;
		$response['obsolete'] = $oldcontentx;

		$this->setPagevar('response',$response);

		return 'ajax';
	}
	public function browser($data=null){
		$appid = $data['appid'];
		$path = array('controllers','models','views','resources','uploads','plugins');

		if(!App::checkPermission($appid)){
			return 'ajax';
		}

		$data = array('appid'=>$appid,'treestruct'=>true);
		$tree = array();
		foreach($path as $pk=>$pv){
			$data['path'] = $pv;
			$tree[$pv] = $this->getFiles($data);
		}

		$this->setPagevar('response',$tree);
		$this->setPagevar('ajax',true);

		return 'browsertree';
	}
	public function searchcode($data){
	    $data['apptosearch']    = explode('|',$data['apptosearch']);
	    $data['type']           = ($data['type'] == '' || strpos($data['type'],'|') === false) ? array() : explode('|',$data['type']);
	    $prior                  = array();

	    $this->typetosearch = array();
	    if(count($data['type'])){
    	    if(in_array('phpsearch',$data['type']) !== false){
    	        $this->typetosearch[] = 'php';
    	        $prior[] = 'app';
    	        $prior[] = 'controllers';
    	        $prior[] = 'models';
    	        $prior[] = 'views';
    	    }
    	    if(in_array('jssearch',$data['type']) !== false){
    	        $this->typetosearch[] = 'js';
    	        $prior[] = 'resources';
    	    }
    	    if(in_array('csssearch',$data['type']) !== false){
    	        $this->typetosearch[] = 'css';
    	        if(!in_array('views',$prior)){
    	            $prior[] = 'views';
    	        }
    	    }
	    }
	    else{
	        $this->typetosearch[] = 'php';
	        $this->typetosearch[] = 'js';
	        $this->typetosearch[] = 'css';
	        $prior = array('app','controllers','models','views','resources');
	    }

	    $files = array();
	    foreach($data['apptosearch'] as $appk=>$appname){
	        if($appname =='')
	            continue;

	       $files[$appname] = array();

	        $appdata = array('appname'=>$appname);
	        foreach($prior as $priok=>$richardpryor){
	            if($richardpryor == ''){
	                continue;
	            }
	            $appdata['path'] = $richardpryor;
	            $files[$appname] = array_merge($files[$appname],$this->getFiles($appdata,false,$data['keyword']));
	        }
	        if(!count($files[$appname])){
	            unset($files[$appname]);
	        }
	    }
	    $this->setPagevar('response',$files);
	    return 'ajax';
	}
    public function getFiles($data,$returnpath=false,$keyword=false){
        $app 			= isset($data['appid']) ? $data['appid'] : App::getappid($data['appname']);
        $path 			= $data['path'];
	    $treestruct 	= isset($data['treestruct']) ? true : false;
        $appname 		= $this->capp = isset($data['appname']) ? $data['appname'] : App::appById($app);

    	if($appname === false){
    		return 'ajax';
    	}

        if(!App::checkPermission($app)){
			return 'ajax';
		}

        switch($path){
			case 'app':
				$folder = App::$config['approot'].$appname;
			break;
            case 'controllers':
                $cfolder = '/controllers';
                $folder = App::$config['approot'].$appname.$cfolder;
            break;
            case 'models':
                $cfolder = '/models';
                $folder = App::$config['approot'].$appname.$cfolder;
            break;
            case 'views':
                $cfolder = '/views';
                $folder = str_replace('./','',App::$config['views']).$appname;
            break;
            case 'resources':
                $folder = $appname == 'regista' ? str_replace('./','',App::$config['resources']) : str_replace('./','',App::$config['resources']).$appname;
            break;
            case 'uploads':
                $folder = str_replace('./','',App::$config['uploads']).$appname;
            break;
            case 'plugins':
                $folder = str_replace('./','',App::$config['plugins']);
				$this->pluginlist($app);
            break;
			default:
				$folder = str_replace('./','',$path);
			break;
        }

		if($returnpath){
			return $folder;
		}

		if($path == 'plugins'){
			$filelists = $this->pluginfileinfolder($folder,array(),$treestruct,$this->appsplugins,$keyword);
		}
		else{
			$filelists = $this->fileinfolder($folder,array(),$treestruct,0,$keyword);
		}

        if($treestruct || $keyword !== false){
			return $filelists;
        }

		$this->setPagevar('response',$filelists);
        return 'ajax';
    }
	public function pluginfileinfolder($dirpathsrc,$filearr=array(),$treestruct = false,$filter=0,$keyword=false){
		if(!file_exists($dirpathsrc)){
			return $filearr;
		}

        $handle = opendir($dirpathsrc);
        while(false !== ($thefile = readdir($handle))){
			if($filter !== 0){
				$continueloop = true;
				foreach($filter as $k=>$v){
					if($v['location'] == $thefile){
						if(isset($v['id'])){
							$continueloop = array();
							$continueloop[] = array('location'=>$v['id']);
						}
						else{
							$continueloop = 0;
						}
					}
				}

				if($continueloop === true){
					continue;
				}
			}
			else{
				$continueloop = 0;
			}

            if($thefile != '.' && $thefile != '..' ){
				if($treestruct === false){
					if(is_dir($dirpathsrc.'/'.$thefile)){
						//$filearr = array_merge($this->fileinfolder($dirpathsrc.'/'.$thefile,$filearr,false,$c),$filearr);
					}
					else{
						$filearridx = count($filearr);
						$filearr[$filearridx] = array();
						$filearr[$filearridx]['path'] = str_replace('./','',$dirpathsrc);
						$pathx = explode('/',$filearr[$filearridx]['path']);
						$except = array('controllers','models','views','res');
						if(in_array($pathx[count($pathx)-1],$except)){
							$filearr[$filearridx]['path'] = $pathx[count($pathx)-1];
						}
						$filearr[$filearridx]['name'] = $thefile;
					}
				}
				else{
					if(is_dir($dirpathsrc.'/'.$thefile)){
						$filearridx = count($filearr);
						$filearr[$filearridx] = array();
						$filearr[$filearridx]['name'] 	= $thefile;
						$filearr[$filearridx]['path'] 	= str_replace('./','',$dirpathsrc);

						$nextpath = substr($dirpathsrc,-1) == '/' ? substr($dirpathsrc,0,-1) : $dirpathsrc;
						$filearr[$filearridx]['sub'] 	= $this->pluginfileinfolder($nextpath.'/'.$thefile,array(),$treestruct,$continueloop);
					}
				}
            }
        }
        closedir($handle);
        return $filearr;
    }
    public function fileinfolder($dirpathsrc,$filearr=array(),$treestruct = false,$filter=0,$keyword=false){
		if(!file_exists($dirpathsrc)){
			return $filearr;
		}
		
		if($this->capp == 'regista' && $this->allapp === false){
		    $this->allapp = array();
		    $allapp = $this->model('appslist')->userApps();
		    foreach($allapp as $k=>$v){
		        if($v['name'] != $this->capp)
		            $this->allapp[] = $v['name'];
		    }
		}
        $handle = opendir($dirpathsrc);
        while(false !== ($thefile = readdir($handle))){
            if($thefile != '.' && $thefile != '..' ){
				if($treestruct === false){
					if(is_dir($dirpathsrc.'/'.$thefile)){
						if($keyword !== false && $thefile != 'controllers' && $thefile != 'models'){
						    $filearr = $this->fileinfolder($dirpathsrc.'/'.$thefile,$filearr,$treestruct,$filter,$keyword);
						}
					}
					else{
					    if($keyword !== false){
					        $filesize= filesize($dirpathsrc.'/'.$thefile);
					        if($filesize == 0)
					            continue;


					        $filetypex = explode('.',$thefile);
					        if(in_array($filetypex[count($filetypex)-1],$this->typetosearch)){
					            if($filetypex[count($filetypex)-1] == 'js' && $filetypex[count($filetypex)-2] == 'min'){
					                continue;
					            }
					         	$keyhandler     = @fopen($dirpathsrc.'/'.$thefile,'rb');
    					        $filecontent    = fread($keyhandler,filesize($dirpathsrc.'/'.$thefile));
    					        if(strpos($filecontent,$keyword) !== false){
    					            $filearridx = count($filearr);
            						$filearr[$filearridx] = array();
            						$filearr[$filearridx]['path'] = str_replace('./','',$dirpathsrc);
            						$filearr[$filearridx]['name'] = $thefile;
    					        }
					        }
					    }
					    else{
					     	$filearridx = count($filearr);
    						$filearr[$filearridx] = array();
    						$filearr[$filearridx]['path'] = str_replace('./','',$dirpathsrc);
    						$pathx = explode('/',$filearr[$filearridx]['path']);
    						$except = array('controllers','models','views');
    						if(in_array($pathx[count($pathx)-1],$except)){
    							$filearr[$filearridx]['path'] = $pathx[count($pathx)-1];
    						}
    						$filearr[$filearridx]['name'] = $thefile;
					    }
					}
				}
				else{
					if(is_dir($dirpathsrc.'/'.$thefile)){
					    if($this->capp != 'regista' || $this->capp == 'regista' && !in_array($thefile,$this->allapp)){
					     	$filearridx = count($filearr);
    						$filearr[$filearridx] = array();
    						$filearr[$filearridx]['name'] 	= $thefile;
    						$filearr[$filearridx]['path'] 	= str_replace(array('./','//'),array('','/'),$dirpathsrc);
    						$filearr[$filearridx]['sub'] 	= $this->fileinfolder($dirpathsrc.'/'.$thefile,array(),$treestruct,$filter);
					    }
					}
				}
            }
        }
        closedir($handle);
        return $filearr;
    }
}
?>