<?php
/**
 * Controller Class.
 */

/**
 *	Class Controller. base class for all the controllers in every app
 *	@name Controller
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class Controller{
	/**
	 * @var mixed stores the database connection or false if failed connecting
	*/
    var $db;
	/**
	 * @var array stores the models class instance
	*/
    var $models;
	/**
	 * @var array stores page variable
	*/
    var $pagevar;
	/**
	 * @var array stores paths to the framework's working sub directory such as base,uploads,app,res, and plugins
	*/
    var $path;
	/**
	 * @var int the app id
	*/
    var $app;
	/**
	 * @var string tablename in current operation
	*/
	var $table;
	/**
	 * @var int insertid from the last insert query operation
	*/
	var $insertid;

	/**
	 * Constructor.
	 */
    public function __construct(){
        $this->app          = Pxpedia::getappid();
        $this->db           = Pxpedia::appdb();
        $this->pagevar      = Array();
        $this->models       = Array();
		$this->controllers  = Array();

        $this->path                 = [];
        $this->path['resources']    = Pxpedia::getConfig('resources');
        $this->path['uploads']      = Pxpedia::getConfig('uploads');
        $this->path['theme']        = Pxpedia::getConfig('theme');

        $this->setPagevar('path', $this->path);
        $this->setPagevar('app', $this->app);

        if(!isset($_SESSION[$_SESSION['currentapp']]['lang'])){
            $this->setPagevar('lang',Application::$config['lang']);
        }
        else{
            $this->setPagevar('lang',$_SESSION[$_SESSION['currentapp']]['lang']);
        }

        if(Application::$config['autoloadmodels']){
            $this->loadAllModels();
        }
    }
	public function pageInit($data,$view='home'){
		return $view;
	}
	/**
	 * Load plugin,automatically add script and stylesheet files resided on the res folder of the plugin, if the current request is on
	 * the admin page all the resource file beginning with admin_ will be loaded, on the frontpage its the plain named files that are loaded
	 *
	 * this function differs from applyPlugin in the context of when the plugin is being required, applying a plugin is valid on every app request while load plugin is
	 * valid on a specific request to that certain plugin
	 *
	 * @param array $plugin plugin description, 'plugin': could be folder name or path;
	 *
	 * @return array plugin view file,plugin location,plugin name
	 */
    public function loadPlugin($plugin){
        if(strpos($plugin['plugin'],'/') === false){
            $plugindesc 	= is_numeric($plugin['plugin']) ?  Application::getPlugin($plugin['plugin']) : Application::getPluginByLoc($plugin['plugin'],Pxpedia::getUser()['currentrole']['appid']);
            $pluginfolder   = $plugindesc['location'];
            $pluginid       = $plugindesc['id'];
            $pluginloc      = $plugindesc['location'].'/'.$plugindesc['personalized'];
            $pluginclass    = $plugin['p'].'_'.$plugindesc['location'];
        }
        else{
            $pluginclassx   = explode('/',$plugin['plugin']);
            $pluginfolder   = $pluginclassx[0];
            $pluginid       = $pluginclassx[1];
            $pluginclass    = $plugin['p'].'_'.$pluginfolder;
            $pluginloc      = $pluginfolder.'/'.$pluginid;
        }
		$pluginbase = Pxpedia::getConfig('plugins');
        $reshandle 	= opendir($pluginbase.$pluginloc.'/res/');

		if(Pxpedia::pagedata('ajax')){
			while(false !== ($resfile = readdir($reshandle))){
				if($resfile != '.' && $resfile != '..' && !is_dir($pluginbase.$pluginloc.'/res/'.$resfile) ){
					if(strpos($resfile,'.js') !== false){
						if(strpos($resfile,'.min.js') !== false){
							$response['scripts'][] = $pluginbase.$pluginloc.'/res/'.$resfile;
						}
					}
					else{
						$response['scripts'][] = $pluginbase.$pluginloc.'/res/'.$resfile;
					}
				}
			}
			$this->setPagevar('response',$response);
		}
		else{
			while(false !== ($resfile = readdir($reshandle))){
				if($resfile != '.' && $resfile != '..' && !is_dir($pluginbase.$pluginloc.'/res/'.$resfile) ){
					if(strpos($resfile,'css') || strpos($resfile,'.ico'))
						$this->addheadfootsrc($pluginbase.$pluginloc.'/res/'.$resfile);
					else{
						if(strpos($resfile,'.min.js') !== false)
							$this->addheadfootsrc(0,$pluginbase.$pluginloc.'/res/'.$resfile);
					}
				}
			}
		}

        require_once $pluginbase.$pluginloc.'/controllers/'.$plugin['p'].'.php';

        $pluginobj	= new $pluginclass($pluginid,$this->getPagevars());
        $plugind	= isset($plugin['d']) ? $plugin['d'] : null;
				$pluginact = isset($plugin['a']) ? $plugin['a'] : 'pageInit';

        $pluginview = $pluginobj->$pluginact($plugind);

        $this->pagevar = $pluginobj->getPagevars();
        $this->setPagevar('plugin',array($pluginfolder=>$pluginobj->getPluginvars()));


        return array($pluginview,$pluginloc,$pluginfolder);
    }
	/**
	 * Apply active plugin,automatically add script and stylesheet files resided on the res folder of the plugin, if the current request is on
	 * the admin page all the resource file beginning with admin_ will be loaded, on the frontpage its the plain named files that are loaded
	 *
	 * this function differs from loadPlugin in the context of when the plugin is being required, applying a plugin is valid on every app call while load plugin is
	 * valid on a specific request to that certain plugin
	 *
	 * @param array $plugin plugin description, 'plugin': could be folder name or path;
	 */
    public function applyPlugin($plugin){
        global $admin;
		$pluginbase = Pxpedia::getConfig('plugins');
        $plugin['p'] = isset($plugin['p']) ? $plugin['p'] : ($admin ? 'admin' : 'home');
        $pluginloc = $pluginbase.$plugin['location'].'/'.$plugin['id'];
        $pluginpage = App::getConfig('plugins').$plugin['location'].'/'.$plugin['id'].'/controllers/'.$plugin['p'].'.php';

        if(!file_exists($pluginpage)){
            return;
        }
        require_once $pluginbase.$plugin['location'].'/'.$plugin['id'].'/controllers/'.$plugin['p'].'.php';

        $pluginclass  = $plugin['p'].'_'.$plugin['location'];
        $pluginobj    = new $pluginclass($plugin['id'],$this->getPagevars());

        if(isset($plugin['d']))
            $pluginobj->pageInit($plugin['d']);
        else
            $pluginobj->pageInit();

        $this->pagevar = $pluginobj->getPagevars();
        $this->setPagevar('plugin',array($plugin['location']=>$pluginobj->getPluginvars()));
        $pluginsettings = json_decode($plugin['settings']);

        $reshandle = opendir($pluginbase.$plugin['location'].'/'.$plugin['id'].'/res/');
		if(Pxpedia::pagedata('ajax')){
		   while(false !== ($resfile = readdir($reshandle))){
				if($admin){
					if($resfile != '.' && $resfile != '..' && !is_dir($pluginloc.'/res/'.$resfile) && strpos($resfile,'admin_') !== false ){
						if(strpos($resfile,'.css') || strpos($resfile,'.ico'))
							$this->addheadfootsrc($pluginloc.'/res/'.$resfile);
						else{
							if(strpos($resfile,'.min.js') !== false)
								$this->addheadfootsrc(0,$pluginloc.'/res/'.$resfile);
						}
					}
				}
				else{
					if($resfile != '.' && $resfile != '..' && !is_dir($pluginloc.'/res/'.$resfile) && strpos($resfile,'admin_') === false ){
						if(strpos($resfile,'.css') || strpos($resfile,'.ico'))
							$this->addheadfootsrc($pluginloc.'/res/'.$resfile);
						else{
							if(strpos($resfile,'.min.js') !== false)
								$this->addheadfootsrc(0,$pluginloc.'/res/'.$resfile);
						}
					}
				}
			}
		}
		else{
			while(false !== ($resfile = readdir($reshandle))){
				if($admin){
					if($resfile != '.' && $resfile != '..' && !is_dir($pluginloc.'/res/'.$resfile) && strpos($resfile,'admin_') !== false ){
						if(strpos($resfile,'.js') !== false){
							if(strpos($resfile,'.min.js') !== false){
								$response['scripts'][] = $pluginloc.'/res/'.$resfile;
							}
						}
						else{
							$response['scripts'][] = $pluginloc.'/res/'.$resfile;
						}
					}
				}
				else{
					if($resfile != '.' && $resfile != '..' && !is_dir($pluginloc.'/res/'.$resfile) && strpos($resfile,'admin_') === false ){
						if(strpos($resfile,'.js') !== false){
							if(strpos($resfile,'.min.js') !== false){
								$response['scripts'][] = $pluginloc.'/res/'.$resfile;
							}
						}
						else{
							$response['scripts'][] = $pluginloc.'/res/'.$resfile;
						}
					}
				}
			}
			$this->setPagevar('response',$response);
		}
    }
	/**
	 * delete loaded model if exists
	 *
	 * @param string $modelname the model name to delete
	 */
    public function delmodel($modelname){
        if(isset($this->models[$modelname])){
            unset($this->models[$modelname]);
        }
    }
	/**
	 * calls a model class instance
	 *
	 * @param string $modelname the model's class name
	 * @return Object
	 */
    public function model($modelname){
        if(isset($this->models[$modelname])){
            return $this->models[$modelname];
        }
        else{
            $this->loadModels($modelname);
            return $this->models[$modelname];
        }
    }
	/**
	 * calls a controller class instance
	 *
	 * @param string $controllername the controller's class name
	 * @return Object
	 */
    public function controller($controllername){
        if(isset($this->controllers[$controllername])){
            return $this->controllers[$controllername];
        }
        else{
            $this->loadControllers($controllername);
            return $this->controllers[$controllername];
        }
    }
	/**
	 * Load one or more controller
	 *
	 * @param mixed $controllernames the controllers's class name to load
	 */
    public function loadControllers($controllernames){
        $controllers = Application::loadControllers($controllernames);
        if(is_array($controllers)){
            foreach($controllers as $mk=>$mv){
                if(!isset($this->controllers[$mk])){
                    $this->controllers[$mk] = $mv;
                }
            }
        }
        else{
            if(!isset($this->controllers[$controllernames])){
                $this->controllers[$controllernames] = $controllers;
            }
        }
    }
	 /**
	 * instantiate all the existing models to the controllers variable
	 */
    public function loadAllModels(){
        $models = Application::loadAllModels();
        if(is_array($models)){
            foreach($models as $mk=>$mv){
                if(!isset($this->models[$mk])){
                    $this->models[$mk] = $mv;
                }
            }
        }
    }
	/**
	 * Load one or more model
	 *
	 * @param mixed $modelnames the model name to load
	 */
    public function loadModels($modelnames){
        $models = Application::loadModels($modelnames);
        if(is_array($models)){
            foreach($models as $mk=>$mv){
                if(!isset($this->models[$mk])){
                    $this->models[$mk] = $mv;
                }
            }
        }
        else{
            if(!isset($this->models[$modelnames])){
                $this->models[$modelnames] = $models;
            }
        }
    }
	/**
	 * get all pagevars assigned
	 * @return array
	 */
    public function getPagevars(){
        return $this->pagevar;
    }
	/**
	 * get a pagevar value
	 *
	 * @param string $index the pagevar index name
	 * @return mixed
	 */
    public function getPagevar($index){
        return $this->pagevar[$index];
    }
	/**
	 * Store a pagevar
	 *
	 * @param string $index pagevar index to be used
	 * @param mixed $value pagevar value
	 */
    public function setPagevar($index='',$value=''){
        $index = $index=='' ? count($this->pagevar) : $index;
        if(isset($this->pagevar[$index])){
            if(is_array($this->pagevar[$index]))
                $this->pagevar[$index] = array_merge($this->pagevar[$index], $value);
            else
                $this->pagevar[$index] = $value;
        }
        else{
            $this->pagevar[$index] = $value;
        }
    }
	/**
	 * exclude a script/stylesheet or any sourced document element from the settings assigned beforehand
	 *
	 * @param mixed $head document element resided on the document's head
	 * @param mixed $foot document element resided on the document's foot
	 */
    public function exclheadfootsrc($head=0,$foot=0){
		$pagesrc = isset($this->pagevar['pagesrc']) ? $this->pagevar['pagesrc'] : false;
        $this->setPagevar('pagesrc',App::exclheadfootsrc($pagesrc,$head,$foot));
    }
	/**
	 * include a script/stylesheet or any sourced document element to head or foot document,everything else assigned beforehand is discarded
	 * 	 *
	 * @param mixed $head document element resided on the document's head
	 * @param mixed $foot document element resided on the document's foot
	 */
    public function incheadfootsrc($head=0,$foot=0){
		$pagesrc = isset($this->pagevar['pagesrc']) ? $this->pagevar['pagesrc'] : false;
        $this->setPagevar('pagesrc',App::incheadfootsrc($pagesrc,$head,$foot));
    }
	/**
	 * add a script/stylesheet or any sourced document element to the settings assigned beforehand
	 *
	 * @param mixed $head document element resided on the document's head
	 * @param mixed $foot document element resided on the document's foot
	 */
    public function addheadfootsrc($head=0,$foot=0){
        $pagesrc = isset($this->pagevar['pagesrc']) ? $this->pagevar['pagesrc'] : false;
        $this->setPagevar('pagesrc',App::addheadfootsrc($pagesrc,$head,$foot));
    }
	/**
	 * gets the inserid for the last insert database operation
	 * @return int
	 */
    public function insertid(){
        return $this->insertid;
    }
	/**
	 * add record to the database
	 *
	 * @param array $fieldnames the field to populate new data
	 * @param array $fielddata the data value for the new record
	 *
	 * @return bool
	 */
    public function addrecord($fieldnames,$fielddata){
        $this->insertid = false;
        if(!is_array($fieldnames)){
            $fieldnames = array($fieldnames);
            $fielddata  = array($fielddata);
        }

        foreach($fielddata as $fk=>$fv){
            $fielddata[$fk] = $this->db->escapestr($fielddata[$fk]);
        }
        $add = $this->db->insertRows($this->table,$fieldnames,$fielddata);
        if($add)
            $this->insertid = $this->db->getinsertid();

        return $add;
    }
	/**
	 * get record from the database
	 *
	 * @param array $condition array containing the description of the condition to met by a record to be fetched
	 * @param mixed $field string or array of string of the column's name to be selected in the result
	 * @param mixed $order string in the form of 'fieldname sortdirection' or array (fieldname,sortdirection
	 * @param mixed $limit string in the form of 'offset,amount' or array (offset,amount)
	 *
	 * @return mixed -- the value or false if query failed
	 */
    public function getrecord($condition=null,$field=null,$order=null,$limit=null){
        $this->db->getRows($this->table,$field,$condition,$order,$limit);
        if($this->db->count() === 1){
            if((!is_null($field) && !is_array($field))){
                $field = strpos($field,' as ') !== false ? explode(' as ',$field) : $field;
                if(is_array($field))
                    $field = $field[count($field)-1];

                return $this->db->rows[0][$field];
            }
            elseif(is_array($field) && count($field) == 1){
                $field = $field[0];
                $field = strpos($field,' as ') !== false ? explode(' as ',$field) : $field;
                if(is_array($field))
                    $field = $field[count($field)-1];

                return $this->db->rows[0][$field];
            }

            return $this->db->rows[0];
        }
        else
            return false;
    }
	/**
	 * get records from the database
	 *
	 * @param array $condition array containing the description of the condition to met by a record to be fetched
	 * @param mixed $field string or array of string of the column's name to be selected in the result
	 * @param mixed $order string in the form of 'fieldname sortdirection' or array (fieldname,sortdirection
	 * @param mixed $limit string in the form of 'offset,amount' or array (offset,amount)
	 *
	 * @return mixed -- the values or false if query failed
	 */
    public function getrecords($condition=null,$field=null,$order=null,$limit=null){
        $this->db->getRows($this->table,$field,$condition,$order,$limit);
        return $this->db->rows;
    }
	/**
	 * update record from the database
	 *
	 * @param array $data key-value array
	 * @param mixed $condition condition to filter the record set
	 *
	 * @return bool
	 */
    public function updaterecord($data,$condition){
        return $this->db->editRows($this->table,$data,$condition);
    }
	/**
	 * update records from the database
	 *
	 * @param array $data key-value array
	 * @param mixed $condition condition to filter the record set
	 *
	 * @return bool
	 */
    public function updaterecords($data,$condition){
        return $this->db->editRows($this->table,$data,$condition);
    }
	/**
	 * count the numbers of rows deleted
	 *
	 * @return int
	 */
    public function deletednum(){
        return $this->db->deletednum();
    }
	/**
	 * delete records from the database
	 *
	 * @param mixed $condition condition to filter the record set
	 *
	 * @return bool
	 */
    public function deleterecords($condition){
        return $this->db->deleteRows($this->table,$condition);
    }
	/**
	 * delete records from the database
	 *
	 * @param mixed $condition condition to filter the record set
	 *
	 * @return bool
	 */
    public function deleterecord($condition){
        return $this->deleterecords($condition);
    }
	/**
	 * perform a query string to the database
	 *
	 * @param string the query string
	 *
	 * @return bool
	 */
    public function query($query){
        return $this->db->query($query);
    }
	/**
	 * fetch the results from the last query operation
	 *
	 * @param object the query object
	 *
	 * @return array
	 */
    public function fetchQueryResult($query){
        return $this->db->fetchQueryResult($query,true);
    }
		/**
	 * fetch the results from the last query operation
	 *
	 * @param object the query object
	 *
	 * @return array
	 */
    public function fetchQueryResults($query){
        return $this->db->fetchQueryResult($query,true);
    }
	/**
	 * print existing errors from previous queries
	 *
	 * @param bool $print whether to print it or not defaults to true;
	 *
	 * @return mixed the errors array pretty print string or void
	 */
    public function printerrors($print=true){
        return $this->db->printerrors($print);
    }
	/**
	 * gets the last query string of the most recent query operation
	 *
	 * @return string
	 */
    public function querystring(){
        return $this->db->querystring;
    }
	/**
	 * prepares a string to be safe for database query operation
	 *
	 * @param string $str the string to processed
	 *
	 * @return string
	 */
    public function escapestr($str){
        return $this->db->escapestr($str);
    }
	/**
	 * fetches one row from the current result
	 *
	 * @return array the row of the current index, or false if it reached the end of rows
	 */
    public function getrow(){
        return $this->db->getRow();
    }
    /**
	 * loadView. process view file
	 *
	 * @param string $page page layout file
	 * @param bool $return return page result
	 *
	 * @return string
	 */
    public function loadView($page,$return=false){
		if($return)
	        return App::loadView($page,$this,true);

        App::loadView($page,$this);
    }
}
?>