<?php

Class Users extends Model{
    function __construct(){
        parent::__construct('users');
    }
    public function getuserbyid($uid){
        return $this->getrecord(array('id'=>$uid));
    }
}


?>