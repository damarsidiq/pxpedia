<?php
/**
 * BlogGallery model class.
 */

/**
 *	Class BlogGallery. class for BlogGallery table manipulation
 *	@name BlogGallery
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class BlogGallery extends Model{
    /**
	 * Constructor. 
	 */
    function __construct(){
        parent::__construct('bloggallery');
    }
    /**
	 * poster. get blog poster
	 *
	 * @param int $blogid the blog ID
	 * 
	 * @return array
	 */
    public function poster($blogid,$size='medium'){
        return $this->getrecord(array('blogid'=>$blogid),'id',array('sortorder','asc'),1).'_'.$size.'.png';
    }
}


?>