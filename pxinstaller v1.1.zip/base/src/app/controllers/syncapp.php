<?php 
Class Syncapp extends Controller{
    var $config;
	function __construct(){
		parent::__construct();
		$this->setPagevar('ajax',true);
		$this->config = array();
	}
	public function syncconfig($data=false)
	    $this->config['sync'] = array('app','view','res','plugin','appconfig','appdb');
	}
	
}
