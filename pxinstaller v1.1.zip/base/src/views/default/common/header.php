<!DOCTYPE html><html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="canonical" href="http://localhost/vine.etc">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
</head>
<body>
    