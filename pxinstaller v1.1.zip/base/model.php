<?php
/**
 * Model Class.
 */

/**
 *	Class Model. base class for each models on every app
 *	@name Model
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class Model{
 	/**
	 * @var object the database object after it is connected or false if failed
	*/
    var $db;
	/**
	 * @var array variable to paths to the framework's working sub directory such as base,uploads,app,res, and plugins
	*/
    var $path;
	/**
	 * @var string tablename for this instance to operate on
	*/
    var $table;
    /**
	 * @var array stores all the fields names in this instance's table
	*/
    var $fields;
    /**
	 * @var array stores the field's descriptions in this instance's table
	*/
    var $columns;
	/**
	 * @var int stores insertid of the last insert query,holds valid until the output is produce, any subsequent non-insert operation wont affect its value
	*/
    var $insertid;
	/**
	 * @var int stores the number of records deleted of the last delete operation,holds valid until the output is produce, any subsequent non-delete operation wont affect its value
	*/
    var $deleted;
	/**
	 * @var int appid
	*/
    var $appid;
    	/**
	 * @var array stores page variable
	*/
    var $pagevar;

    /**
	 * Constructor.
	 *
	 * @param string $table the table for this instance of model
	 * @param int $appid the appid if the database differs from the main database of the framework
	 */
    public function __construct($table='',$appid=false){
				$this->appid	= $appid === false ? Pxpedia::getappid(): $appid;
        $this->db       = Pxpedia::appdb($this->appid);
        $this->table    = $table;
				$this->models	= array();

        if($this->table !== ''){
            $columnset      = $this->db->columnset(null,$table);
            if($columnset !== false){
                $this->fields   = $columnset[1];
                $this->columns  = $columnset[2];
            }
        }
        $this->path                 = [];
        $this->path['resources']    = Pxpedia::getConfig('resources');
        $this->path['uploads']      = Pxpedia::getConfig('uploads');
        $this->path['plugins']      = Pxpedia::getConfig('plugins');
        $this->path['theme']        = Pxpedia::getConfig('theme');
    }
	/**
	 * Load one or more model
	 *
	 * @param mixed $modelnames the model name to load
	 */
    public function loadModels($modelnames){
        $models = Application::loadModels($modelnames);
        if(is_array($models)){
            foreach($models as $mk=>$mv){
                if(!isset($this->models[$mk])){
                    $this->models[$mk] = $mv;
                }
            }
        }
        else{
            if(!isset($this->models[$modelnames])){
                $this->models[$modelnames] = $models;
            }
        }
    }
	/**
	 * calls a model class instance
	 *
	 * @param string $modelname the model's class name
	 * @return Object
	 */
    public function model($modelname){
        if(isset($this->models[$modelname])){
            return $this->models[$modelname];
        }
        else{
            $this->loadModels($modelname);
            return $this->models[$modelname];
        }
    }
    /**
	 * Retrieve any variable in the instance
	 *
	 * @param string $varname the variable name to return
	 *
	 * @return mixed
	 */
    public function attr($varname){
        return $this->$varname;
    }
    /**
	 * Sets the value for a variable
	 *
	 * @param array key value pair of variable name and the value
	 *
	 * @return void
	 */
    public function setAttr($attr){
        foreach($attr as $attrk=>$attrv){
            $this->$attrk = $attrv;
        }
    }
    /**
	 * Check if a record that meets the given condition exists in the table
	 *
	 * @param array $condition condition/conditions that is required
	 *
	 * @return bool
	 */
    public function exists($condition){
        if(!$this->db->exists($this->table,$condition)){
            return false;
        }
        return true;
    }
		/**
	 * Check if a record that meets the given condition exists in the table
	 *
	 * @param array $condition condition/conditions that is required
	 *
	 * @return bool
	 */
    public function exist($condition){
        if(!$this->db->exists($this->table,$condition)){
            return false;
        }
        return true;
    }
    /**
	 * Retrieves the insert ID for the last insert operation
	 *
	 * @return int
	 */
    public function insertid(){
        return $this->insertid;
    }
		    /**
	 * Insert one or more record to the table
	 *
	 * @param array $fieldnames the field name/names of the column
	 * @param array $fielddata the data for the column/columns
	 *
	 * @return bool
	 */
    public function addrecords($fieldnames,$fielddata){
        $this->insertid = false;
        if(!is_array($fieldnames)){
            $fieldnames = array($fieldnames);
            $fielddata  = array($fielddata);
        }

        foreach($fielddata as $fk=>$fv){
						if(is_array($fv)){
							foreach($fv as $fvk=>$fvv){
								$fielddata[$fk][$fvk] = $this->db->escapestr($fielddata[$fk][$fvk]);
							}
						}
						else
							$fielddata[$fk] = $this->db->escapestr($fielddata[$fk]);
        }
        $add = $this->db->insertRows($this->table,$fieldnames,$fielddata);
        if($add)
            $this->insertid = $this->db->getinsertid();

        return $add;
    }
    /**
	 * Insert one or more record to the table
	 *
	 * @param array $fieldnames the field name/names of the column
	 * @param array $fielddata the data for the column/columns
	 *
	 * @return bool
	 */
    public function addrecord($fieldnames,$fielddata){
        $this->insertid = false;
        if(!is_array($fieldnames)){
            $fieldnames = array($fieldnames);
            $fielddata  = array($fielddata);
        }

        foreach($fielddata as $fk=>$fv){
						if(is_array($fv)){
							foreach($fv as $fvk=>$fvv){
								$fielddata[$fk][$fvk] = $this->db->escapestr($fielddata[$fk][$fvk]);
							}
						}
						else
							$fielddata[$fk] = $this->db->escapestr($fielddata[$fk]);
        }
        $add = $this->db->insertRows($this->table,$fieldnames,$fielddata);
        if($add)
            $this->insertid = $this->db->getinsertid();

        return $add;
    }
    /**
	 * Retrieve one record from the table
	 *
	 * if the $field parameter is set to one column only then this function would return the value of that column and not an array
	 *
	 * @param mixed $condition conditional statement to meet
	 * @param mixed $field the column to include in the result
	 * @param mixed $order array in the form of (field,sortdirection) or string in the form 'field,sortdirection'
	 * @param mixed $limit array in the form of (offset,amount) or string in the form 'offset,amount'
	 *
	 * @return array an associative array of the result or false if not found
	 */
    public function getrecord($condition=null,$field=null,$order=null,$limit=null){
        $this->db->getRows($this->table,$field,$condition,$order,$limit);
        if($this->db->count() === 1){
            if((!is_null($field) && !is_array($field))){
                $field = strpos($field,' as ') !== false ? explode(' as ',$field) : $field;
                if(is_array($field))
                    $field = $field[count($field)-1];

                return $this->db->rows[0][$field];
            }
            elseif(is_array($field) && count($field) == 1){
                $field = $field[0];
                $field = strpos($field,' as ') !== false ? explode(' as ',$field) : $field;
                if(is_array($field))
                    $field = $field[count($field)-1];

                return $this->db->rows[0][$field];
            }

            return $this->db->rows[0];
        }
        else
            return false;
    }
		public function primary(){
			 $cols = $this->db->query('SHOW COLUMNS FROM '.$this->table);
			 if($cols){
					$cols = $this->fetchQueryResults($cols);
					foreach($cols as $ck=>$cv){
						if($cv['Key'] == 'PRI'){
							return $cv['Field'];
						}
					}
			 }
			 return false;
		}
    /**
	 * Retrieves one or more records from the table
	 *
	 * @param mixed $condition conditional statement to check
	 * @param mixed $field the column to include in the result
	 * @param mixed $order array in the form of (field,sortdirection) or string in the form 'field,sortdirection'
	 * @param mixed $limit array in the form of (offset,amount) or string in the form 'offset,amount'
	 *
	 * @return array associative array of the results set
	 */
    public function getrecords($condition=null,$field=null,$order=null,$limit=null){
        $this->db->getRows($this->table,$field,$condition,$order,$limit);
        return $this->db->rows;
    }
    /**
	 * Update the table
	 *
	 * @param array $data associative array key values
	 * @param array $condition conditional statement to meet
	 *
	 * @return mixed the number of rows affected or false if an error occured
	 */
    public function updaterecord($data,$condition){
        return $this->db->editRows($this->table,$data,$condition);
    }
    /**
	 * Update the table
	 *
	 * @param array $data associative array key values
	 * @param array $condition conditional statement to meet
	 *
	 * @return mixed the number of rows affected or false if an error occured
	 */
    public function updaterecords($data,$condition){
        return $this->db->editRows($this->table,$data,$condition);
    }
	/**
	 * Get the number of items delete from last delete operation
	 *
	 * @return int
	 */
    public function deletednum(){
        return $this->db->deletednum();
    }
	/**
	 * Perform a delete operation on the table
	 *
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return bool
	 */
    public function deleterecords($condition){
        return $this->db->deleteRows($this->table,$condition);
    }
	/**
	 * Perform a delete operation on the table
	 *
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return bool
	 */
    public function deleterecord($condition){
        return $this->deleterecords($condition);
    }
    /**
	 * Execute a query string
	 *
	 * @param string $query the query string
	 *
	 * @return mixed the query object resulted from the operation or false if failed
	 */
    public function query($query){
        return $this->db->query($query);
    }
	/**
	 * Fetch results in associative array
	 *
	 * @param object $query the query object
	 *
	 * @return array associative array of the result set
	 */
    public function fetchQueryResult($query){
        return $this->db->fetchQueryResult($query,true);
    }
			/**
	 * Fetch results in associative array
	 *
	 * @param object $query the query object
	 *
	 * @return array associative array of the result set
	 */
    public function fetchQueryResults($query){
        return $this->db->fetchQueryResult($query,true);
    }
    /**
	 * Retrieves the error log
	 *
	 * @param bool $print whether to print directly or return the error string
	 *
	 * @return string
	 */
    public function printerrors($print=true){
        return $this->db->printerrors($print);
    }
    /**
	 * Retrieves the error log
	 *
	 * @param bool $print whether to print directly or return the error string
	 *
	 * @return string
	 */
    public function printerror($print=true){
        return $this->db->printerrors($print);
    }
    /**
	 * Retrieves the last query's query string
	 *
	 * @return string
	 */
    public function querystring(){
        return $this->db->querystring;
    }
  	/**
	 * cleans the string for legal query operation
	 *
	 * @param string $str the string to clean
	 *
	 * @return string
	 */
    public function escapestr($str){
        return $this->db->escapestr($str);
    }
	/**
	 * Retrieves one row from the result set
	 *
	 * @return array
	 */
    public function getrow(){
        return $this->db->getRow();
    }
    /**
	 * Count how many record exists in a table, optionally as specified by the conditional statement
	 *
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return int
	 */
    public function countrows($condition=null){
        return $this->db->countRows($this->table,$condition);
    }
	 /**
	 * Count how many record exists in a table, optionally as specified by the conditional statement
	 *
	 * @param mixed $condition conditional statement to meet
	 *
	 * @return int
	 */
    public function countrow($condition=null){
        return $this->db->countRows($this->table,$condition);
    }
	/**
	 * get all pagevars assigned
	 * @return array
	 */
    public function getPagevars(){
        return $this->pagevar;
    }
	/**
	 * get a pagevar value
	 *
	 * @param string $index the pagevar index name
	 * @return mixed
	 */
    public function getPagevar($index){
        return $this->pagevar[$index];
    }
	/**
	 * Store a pagevar
	 *
	 * @param string $index pagevar index to be used
	 * @param mixed $value pagevar value
	 */
    public function setPagevar($index='',$value=''){
        $index = $index=='' ? count($this->pagevar) : $index;
        if(isset($this->pagevar[$index])){
            if(is_array($this->pagevar[$index]))
                $this->pagevar[$index] = array_merge($this->pagevar[$index], $value);
            else
                $this->pagevar[$index] = $value;
        }
        else{
            $this->pagevar[$index] = $value;
        }
    }
		  /**
	 * createtablesql. create the table sql statement
	 *
	 * @return string
	 */
    public function createtablesql(){
			$cts = 'CREATE TABLE IF NOT EXISTS '.$this->table.'(';

			$prim = false;
			foreach($this->columns as $ck=>$cv){
				$cts .= $cv['Field'].' '.$cv['Type'].' ';
				$cts .= $cv['Null'] == 'YES' ? 'NULL ' : 'NOT NULL ';

				$cv['Default'] = (in_array($cv['type'],$this->db->stringtype) && $cv['Default'] !='') ? '"'.$cv['Default'].'"' : $cv['Default'];
				$cts .= $cv['Default'] == '' ? '' : 'DEFAULT '.$cv['Default'].' ';
				$cts .= $cv['Extra'].' ';

				$cts .= ',';

				if(strtolower($cv['Key'])=='pri'){
					$prim = $cv['Field'];
				}
			}

			if($prim !== false){
				$cts .= 'PRIMARY KEY('.$prim.')';
			}
			else{
				$cts = substr($cts,0,-1);
			}

			$cts.=')';

			return $cts;
    }
    /**
	 * loadView. process view file
	 *
	 * @param string $page page layout file
	 * @param bool $return return page result
	 *
	 * @return string
	 */
    public function loadView($page,$return=false){
	if($return)
	        return App::loadView($page,$this,true);

        App::loadView($page,$this);
    }
}

