<?php
/**
 * Application Class.
 */

/**
 *	Class Application. the backbone of the project, kept simple, to extend as needed
 *	@name Application
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class Application{
	/** 
	 * @var array Container for all the config variables in config.php
	*/
    public static $config;
	/** 
	 * @var mixed database object specified accordingly through config.php
	*/
    public static $db;
    
	/**
	 * Constructor. Populate the static config with globals from config.php, instantiate the primary database object to static $db, and load the base classes 
	 */
    function __construct(){
        self::$config 	= $GLOBALS;
		self::$db 		= new db(self::$config['dbname'],self::$config['dbhost'],self::$config['dbuser'],self::$config['dbpasswd'],self::$config['dbtype']);
        
        require_once self::$config['baseroot'].'controller.php';
		require_once self::$config['baseroot'].'plugincontroller.php';
        require_once self::$config['baseroot'].'model.php';
		require_once self::$config['baseroot'].'pluginmodel.php';
        require_once self::$config['baseroot'].'view.php';
    }
	/**
	 * Get a certain App ID
	 *
	 * @param string $name optional argument, the app name
	 * @return int
	 */
	public static function getappid($name=false){
		$name = $name == false ? self::getAppname() : $name;
		self::$db->getRows('app','id',array('name'=>$name));
		if(self::$db->count())
			return self::$db->getRow()['id'];
		return false;
	}
	/**
	 * Get a certain App name by its id
	 *
	 * @param mixed $id app id
	 * @return string
	 */
	public static function appById($id){
		$appname = self::$db->getRows('app','name',array('id'=>$id));
		if(self::$db->count())
			return self::$db->getRow()['name'];
		return false;
	}
	/**
	 * Get the current app name
	 *
	 * @return string
	 */
	public static function getAppname(){
		$appname = str_replace(array(self::$config['approot'],'/','.'),'',$_SESSION['currentapp']);
		return $appname;
	}
	/**
	 * Get settings for an app by its name, setting's name and type
	 *
	 * @param string $app the app name
	 * @param string $name the setting's name
	 * @param string $type the setting's type
	 * 
	 * @return array the settings value decoded
	 */
	public static function getSetting($app,$name,$type){
		$app = str_replace(self::$config['approot'],'',$app);
		$appid = self::getappid($app);
		self::$db->getRows('setting','value',array('app'=>$appid,'name'=>$name,'type'=>$type));
		if(self::$db->count())
			return(json_decode(self::$db->getRow()['value'],true));
		return false;
	}
	/**
	 * Get settings for an app by its ID,setting's name and type
	 *
	 * @param string $appid the app ID
	 * @param string $name the setting's name
	 * @param string $type the setting's type
	 * 
	 * @return array the settings value decoded
	 */
	public static function appSetting($appid,$name,$type){
		self::$db->getRows('setting','value',array('app'=>$appid,'name'=>$name,'type'=>$type));
		if(self::$db->count()){
			$value = self::$db->getRow()['value'];
			$valuedecoded = json_decode($value,true);
			return $valuedecoded == '' ? $value : $valuedecoded;
		}
		return false;
	}
	/**
	 * Get the primary database object
	 *
	 * @return Object the database object 
	 */
	public static function getdb(){
        return self::$db;
    }
	/**
	 * Get active plugins for the current app
	 * 
	 * @return array the plugins rows stored in the database
	 */
	public static function getActivePlugins(){
		$actp = self::$db->getRows('plugins',null,array('app'=>self::getappid(),'status'=>1));
		
		if(count($actp)){
			return $actp;
		}
		return false;
	}
	/**
	 * Get plugins data by its location
	 *
	 * @param string $pluginloc the plugin's location
	 * @param int $app the app ID
	 * 
	 * @return array the plugin's data as an array
	 */
	public static function getPluginByLoc($pluginloc,$app){
		self::$db->getRows('plugins',null,array('location'=>$pluginloc,'app'=>$app));
		return self::$db->getRow();
	}
	/**
	 * Get plugin's data by its ID
	 *
	 * @param int $pluginid the plugin's ID
	 * 
	 * @return array the plugin's data
	 */
	public static function getPlugin($pluginid){
		self::$db->getRows('plugins',null,array('id'=>$pluginid));
		return self::$db->getRow();
	}
	/**
	 * load plugin models
	 *
	 * @param int $pluginid the app ID
	 * 
	 * @return Object an object containing all  the model's object instance
	 */
	public static function loadAllPluginModels($pluginid){
		self::$db->getRows('plugins',null,array('id'=>$pluginid));
		$plugin = self::$db->getRow();
		
		$models 		= new stdClass();
        $modelhandle 	= opendir(self::$config['plugins'].$plugin['location'].'/'.$plugin['personalized'].'/models/');
		
        while(false !== ($modelfile = readdir($modelhandle))){
            if($modelfile != '.' && $modelfile != '..'){
                $model = str_replace('.php','',$modelfile);
                require_once self::$config['plugins'].$plugin['location'].'/'.$plugin['personalized'].'/models/'.$modelfile;
				$modelclass = $model.'_'.$plugin['location'];
                $models->$model = new $modelclass($pluginid);
            }
        }
        return $models;
	}
	/**
	 * Load plugin's model/models 
	 *
	 * @param mixed $modelsname the model's class name/names
	 * @param int $pluginid the plugin ID
	 * 
	 * @return mixed this function returns an array of model class or one object of a model class depending on the given parameter
	 */
	public static function loadPluginModels($modelsname='',$pluginid){
		if($modelsname!=''){
			self::$db->getRows('plugins',null,array('id'=>$pluginid));
			$plugin = self::$db->getRow();
			
            if(is_array($modelsname)){
                $modelsarr = array();
                foreach($modelsname as $modelkey=>$modelname){
                    require_once self::$config['plugins'].$plugin['location'].'/'.$plugin['personalized'].'/models/'.$modelname.'.php';
					$modelclass = $modelname.'_'.$plugin['location'];
                    $modelsarr[$modelname] = new $modelclass($pluginid);
                }
                return $modelsarr;
            }
            else{
                require_once self::$config['plugins'].$plugin['location'].'/'.$plugin['personalized'].'/models/'.$modelsname.'.php';
				$modelclass = $modelsname.'_'.$plugin['location'];
                return new $modelclass($pluginid);
            }
        }
	}
	/**
	 * Load the app model/models 
	 *
	 * @param mixed $modelsname the model's class name/names
	 * 
	 * @return mixed this function returns an array of model class or one object of a model class depending on the given parameter
	 */
    public static function loadModels($modelsname=''){
        if($modelsname!=''){
            if(is_array($modelsname)){
                $modelsarr = array();
                foreach($modelsname as $modelkey=>$modelname){
                    require_once self::$config['currentapp'].'/models/'.$modelname.'.php';
                    $modelsarr[$modelname] = new $modelname();
                }
                return $modelsarr;
            }
            else{
                require_once self::$config['currentapp'].'/models/'.$modelsname.'.php';
                return new $modelsname();
            }
        }
    }
	/**
	 * Load all the app models 
	 * 
	 * @return object this function returns an object containing all the models instance
	 */
    public static function loadAllModels(){
        $models = new stdClass();
        $modelhandle = opendir(self::$config['currentapp'].'/models/');
        while(false !== ($modelfile = readdir($modelhandle))){
            if($modelfile != '.' && $modelfile != '..'){
                $model = str_replace('.php','',$modelfile);
                require_once self::$config['currentapp'].'/models/'.$modelfile;
                $models->$model = new $model();
            }
        }
        return $models;
    }
	/**
	 * Load a controller for the current app
	 *
	 * @param string $controller the controller's name
	 * 
	 * @return object an instance of the controller's class
	 */
    public static function loadController($controller){
        return self::loadControllers($controller);
    }
	/**
	 * Load controllers
	 *
	 * @param mixed $controllers the controllers's name
	 * 
	 * @return object instance/instances of the controller's class
	 */
    public static function loadControllers($controllers){
		if(is_array($controllers)){
			$cs = array();
			foreach($controllers as $ck=>$cv){
				if(!file_exists(self::$config['currentapp'].'/controllers/'.$cv.'.php')){
					return false;
				}
				require_once self::$config['currentapp'].'/controllers/'.$cv.'.php';
				$cs[] = new $cv();
			}
			return $cs;
		}
		if(!file_exists(self::$config['currentapp'].'/controllers/'.$controllers.'.php')){
			return false;
		}
        require_once self::$config['currentapp'].'/controllers/'.$controllers.'.php';
        return new $controllers();
    }
	public static function _loadView($page,$pagevar,$velp,$buffer){
		$buffercleaned  = false;
		if( $page !== 'ajax' && (!isset($pagevar['ajax']) || $pagevar['ajax'] === false )  && $page !== 'debug' && $page !== 'plain' && !$buffer){
			require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/common/header.php';
			
			if(strpos($page,'.php') !== false)
				require $page;
			else
				require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/'.$page.'.php';
				
			require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/common/footer.php';	
		}
		else{
			if($buffer){
				ob_start();
			}
			if(strpos($page,'.php') !== false){
				require $page;
				$pagex = explode('/',$page);
				$page = $pagex[count($pagex)-1];
			}
			else{
				require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/'.$page.'.php';
				$page = $page.'.php';
			}
			
			if($page !== 'ajax.php' && $page !== 'debug.php' && $page !== 'plain.php' && !$buffer){
				$buffercleaned 			= true;
				$pagevar['response'] 	= isset($pagevar['response']) && is_array($pagevar['response']) ? $pagevar['response'] : array();
				$pagevar_pagecontent 	= ob_get_clean();
				if($pagevar_pagecontent != ''){
					if(isset($pagevar['response']['pagecontent'])){
						$pagevar['response']['pagecontent'] .= $pagevar_pagecontent;
					}
					else{
						$pagevar['response']['pagecontent'] = $pagevar_pagecontent;
					}
				}				
				$page = 'ajax';
				require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/'.$page.'.php';
			}
		}
		return $buffercleaned;
	}
	/**
	 * Load the view needed for the current run of the app, it also prepares the variables form according to its type of view and request style
	 *
	 * @param string $page the view file
	 * @param object $controller the controller instance
	 */
    public static function loadView($page,$controller,$buffer=false){
		$pagevar 		= $controller->getPagevars();
		$velp 			= new viewHelper($controller);
		
		if(is_array($page)){
			foreach($page as $pagek=>$pagev){
				if($pagek > 0){
					self::_loadView($pagev,$pagevar,$velp,true);
				}
				else{
					require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/common/header.php';
					self::_loadView($pagev,$pagevar,$velp,true);
				}
			}
			require self::$config['views']. self::getAppname().'/'.self::$config['theme'].'/common/footer.php';	
		}
		else{
			$buffercleaned  = self::_loadView($page,$pagevar,$velp,$buffer);
			if($buffercleaned){
				ob_start();
			}
		}
		
		if($buffer){
			$buffer = ob_get_clean();
			return $buffer;
		}
    }
}
?>
