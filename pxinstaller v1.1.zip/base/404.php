<style>
h1,h3{color: #3A3535;display: block;font-weight: 400;height: 50%;margin: auto;text-shadow: 2px 2px 7px #5E6161;width: 100%;}
h1{font-size: 80px;}
h3{font-size: 40px;}
.table{display: table;width: 100%;height: 100%;text-align: center;}
.tablecell{display: table-cell;vertical-align: middle;}
.boxed{display: block;margin: auto;border:none;width: 30%;height: 40%;background: white;box-shadow: 0px 0px 4px 1px #ffffff;border-radius: 4px;}
</style>

<div class="table">
  <div class="tablecell">
    <div class="boxed">
      <h1>
        <div class="table">
          <div class="tablecell">
            404
          </div>
        </div>
      </h1>
      <h3>
        <div class="table">
          <div class="tablecell">
            not found
          </div>
        </div>
      </h3>
    </div>
  </div>
</div>
